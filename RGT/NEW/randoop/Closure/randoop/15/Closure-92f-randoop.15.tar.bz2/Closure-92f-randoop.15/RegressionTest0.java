import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_CONST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test003");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.rhino.Context context0 = null;
        try {
            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        try {
            boolean boolean2 = defaultCodingConvention0.isOptionalParameter(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "");
        com.google.javascript.rhino.Node node8 = null;
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        try {
            com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '#', node4, node7, node8, node12, 37, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        try {
            com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(errorManager0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        try {
            node3.setDouble((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! 32 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        try {
            node1.setSideEffectFlags(21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.new FileLevelJsDocBuilder();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: reflection call to com.google.javascript.rhino.Node$FileLevelJsDocBuilder with null for superclass argument");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray1 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0 };
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticTypeArray1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 21");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        java.lang.String[] strArray4 = null;
        try {
            com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make("STRING hi! 32", 12, (int) (byte) 10, diagnosticType3, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.rhino.Context context0 = null;
        try {
            long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) 10.0f, (int) 'a', 21);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str36 = node32.toString(true, false, false);
        node32.detachChildren();
        try {
            com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 10, node12, node28, node32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "STRING hi! 32" + "'", str36.equals("STRING hi! 32"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        try {
            jSTypeRegistry2.registerPropertyOnType("hi!", jSType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newExpr(node27);
        try {
            boolean boolean29 = googleCodingConvention0.isVarArgsParameter(node27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: NUMBER 3.0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_PARAMETER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = null;
        java.lang.String[] strArray29 = new java.lang.String[] { "", "STRING hi! 32" };
        try {
            com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("hi!", node12, checkLevel25, diagnosticType26, strArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray29);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.NO_DUPLICATE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newExpr(node27);
        try {
            boolean boolean29 = googleCodingConvention0.isVarArgsParameter(node27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: NUMBER 3.0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.createOptionalNullableType(jSType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("hi!", "STRING hi! 32", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) 33, (java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        com.google.javascript.rhino.Node node9 = node3.cloneNode();
        try {
            node3.setSideEffectFlags(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) ' ', "");
        com.google.javascript.rhino.Node node3 = node2.getNext();
        try {
            java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.children();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node9 = node3.copyInformationFrom(node8);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast10 = googleCodingConvention0.getObjectLiteralCast(nodeTraversal1, node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler4 = null;
        try {
            com.google.javascript.rhino.Node node5 = jsAst3.getAstRoot(abstractCompiler4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig1 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) "hi!");
        java.lang.Throwable[] throwableArray2 = runtimeException1.getSuppressed();
        org.junit.Assert.assertNotNull(runtimeException1);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        java.lang.String str5 = defaultCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node8 = node2.copyInformationFrom(node7);
        node2.addSuppression("STRING hi! 32");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node12);
        node13.putIntProp(0, (-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "");
        com.google.javascript.rhino.Node node20 = node19.getNext();
        try {
            com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 10, node2, node13, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str15 = node11.toString(true, false, false);
        node11.detachChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        node19.putIntProp(0, (-1));
        node3.addChildAfter(node11, node19);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention24 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str32 = node28.toString(true, false, false);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str40 = node36.toString(true, false, false);
        node36.detachChildren();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newExpr(node43);
        node44.putIntProp(0, (-1));
        node28.addChildAfter(node36, node44);
        java.util.List<java.lang.String> strList49 = googleCodingConvention24.identifyTypeDeclarationCall(node44);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) 3);
        try {
            node19.addChildBefore(node44, node51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node has siblings.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING hi! 32" + "'", str15.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "STRING hi! 32" + "'", str32.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "STRING hi! 32" + "'", str40.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(strList49);
        org.junit.Assert.assertNotNull(node51);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str15 = node11.toString(true, false, false);
        node11.detachChildren();
        com.google.javascript.rhino.Node node17 = node11.cloneNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node2, node7, node11, node21 };
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(7, nodeArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING hi! 32" + "'", str15.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType9 = jSTypeRegistry2.getNativeObjectType(jSTypeNative8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.AllType cannot be cast to com.google.javascript.rhino.jstype.ObjectType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node10 = node4.copyInformationFrom(node9);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        try {
            node2.replaceChild(node9, (com.google.javascript.rhino.Node) scriptOrFnNode14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        try {
            int int5 = node3.getExistingIntProp((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative13 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType14 = jSTypeRegistry2.getNativeObjectType(jSTypeNative13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.NumberType cannot be cast to com.google.javascript.rhino.jstype.ObjectType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative13 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE + "'", jSTypeNative13.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node8 = node2.copyInformationFrom(node7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node8, callback9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType17.isAllType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("STRING hi! 32");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        try {
            scriptOrFnNode3.setBaseLineno((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("Not declared as a constructor", "STRING hi! 32", "Not declared as a constructor");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a constructor");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        context1.addActivationName("Not declared as a constructor");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.setErrorReporter(errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("Not declared as a constructor", "Unknown class name", (int) (byte) 0, "STRING hi! 32", (int) (byte) 10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        boolean boolean14 = functionPrototypeType9.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.setEndLineno(20);
        boolean boolean6 = scriptOrFnNode3.hasSideEffects();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node8 = node2.copyInformationFrom(node7);
        com.google.javascript.rhino.Node node9 = node2.getNext();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node12);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node18 = node12.copyInformationFrom(node17);
        node12.addSuppression("STRING hi! 32");
        boolean boolean21 = defaultCodingConvention10.isPropertyTestFunction(node12);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.Node node25 = null;
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str33 = node29.toString(true, false, false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str41 = node37.toString(true, false, false);
        node37.detachChildren();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node45 = com.google.javascript.jscomp.NodeUtil.newExpr(node44);
        node45.putIntProp(0, (-1));
        node29.addChildAfter(node37, node45);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
        com.google.javascript.rhino.jstype.JSType jSType53 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList55 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList55, jSTypeArray54);
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry52.createFunctionTypeWithVarArgs(jSType53, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList55);
        com.google.javascript.rhino.jstype.JSType jSType62 = jSTypeRegistry52.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63, false);
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray67 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList68 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean69 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList68, jSTypeArray67);
        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry65.createFunctionTypeWithVarArgs(jSType66, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList68);
        java.lang.String str71 = functionType70.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry75 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73, false);
        com.google.javascript.rhino.jstype.JSType jSType76 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean79 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList78, jSTypeArray77);
        com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry75.createFunctionTypeWithVarArgs(jSType76, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList78);
        boolean boolean81 = functionType80.isAllType();
        boolean boolean83 = functionType70.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType80, true);
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry52.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType70, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry23.createConstructorType("", node25, node37, (com.google.javascript.rhino.jstype.JSType) functionType70);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode90 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder91 = scriptOrFnNode90.new FileLevelJsDocBuilder();
        scriptOrFnNode90.setEncodedSourceBounds(150, (-1));
        try {
            com.google.javascript.rhino.Node node97 = new com.google.javascript.rhino.Node(9, node9, node12, node25, (com.google.javascript.rhino.Node) scriptOrFnNode90, 13, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "STRING hi! 32" + "'", str33.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "STRING hi! 32" + "'", str41.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(jSTypeArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNotNull(jSType62);
        org.junit.Assert.assertNotNull(jSTypeArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(functionType70);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(functionType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(functionType86);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("Not declared as a constructor", "STRING hi! 32");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = null;
        com.google.javascript.rhino.Node node4 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast5 = googleCodingConvention0.getObjectLiteralCast(nodeTraversal3, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
        java.lang.String[] strArray11 = new java.lang.String[] { "Not declared as a constructor", "hi!", "Unknown class name", "Not declared as a constructor", "STRING hi! 32", "Unknown class name" };
        try {
            com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("Unknown class name", node2, diagnosticType4, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        ecmaError1.initLineSource("hi!");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node3, callback4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createOptionalType(jSType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("hi!");
        boolean boolean4 = googleCodingConvention0.isConstantKey("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        boolean boolean7 = compilerInput6.isExtern();
        try {
            java.lang.String str9 = compilerInput6.getLine(33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType13);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList22 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList22, jSTypeArray21);
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createFunctionTypeWithVarArgs(jSType20, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList22);
        java.lang.String str25 = functionType24.getNormalizedReferenceName();
        boolean boolean26 = functionType24.isCheckedUnknownType();
        boolean boolean27 = functionType24.isStringObjectType();
        boolean boolean29 = objectType15.defineInferredProperty("TypeError: STRING hi! 32", (com.google.javascript.rhino.jstype.JSType) functionType24, false);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType31 = functionType24.getGreatestSubtype(jSType30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.google.javascript.rhino.Context.checkOptimizationLevel(2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str11 = node7.toString(true, false, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        node15.detachChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newExpr(node22);
        node23.putIntProp(0, (-1));
        node7.addChildAfter(node15, node23);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry1.createConstructorType("", node3, node15, (com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str73 = node69.toString(true, false, false);
        node69.detachChildren();
        com.google.javascript.rhino.Node node75 = node69.cloneNode();
        int int76 = node69.getSideEffectFlags();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, false);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList82 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean83 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList82, jSTypeArray81);
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry79.createFunctionTypeWithVarArgs(jSType80, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList82);
        java.lang.String str85 = functionType84.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType86 = functionType84.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = null;
        functionPrototypeType86.setPropertyJSDocInfo("", jSDocInfo88, false);
        com.google.javascript.rhino.jstype.ObjectType objectType91 = jSTypeRegistry1.createObjectType("hi!", node69, (com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType86);
        com.google.javascript.rhino.jstype.JSType jSType92 = node69.getJSType();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection93 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node69);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "STRING hi! 32" + "'", str73.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNull(str85);
        org.junit.Assert.assertNotNull(functionPrototypeType86);
        org.junit.Assert.assertNotNull(objectType91);
        org.junit.Assert.assertNull(jSType92);
        org.junit.Assert.assertNotNull(nodeCollection93);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(23, 130, 9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node29 = node4.clonePropsFrom(node28);
        com.google.javascript.jscomp.NodeTraversal.Callback callback30 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node29, callback30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node29);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        try {
            context1.removePropertyChangeListener(propertyChangeListener2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        boolean boolean22 = functionType20.isCheckedUnknownType();
        boolean boolean23 = functionType20.isStringObjectType();
        boolean boolean24 = functionType20.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        boolean boolean33 = functionType32.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.ObjectType) functionType20, (com.google.javascript.rhino.jstype.JSType) functionType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList43 = functionType32.getSubTypes();
        boolean boolean44 = functionType32.isEmptyType();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(functionTypeList43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_EXPRESSION_STATEMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList13 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList13, jSTypeArray12);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createFunctionTypeWithVarArgs(jSType11, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList13);
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry10.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSType20.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] { jSType20 };
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createOptionalParameters(jSTypeArray22);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope24 = null;
        jSTypeRegistry2.resolveTypesInScope(jSTypeStaticScope24);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        int int2 = context1.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.setTemplateTypeName("language version");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry7.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList23, jSTypeArray22);
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createFunctionTypeWithVarArgs(jSType21, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList23);
        java.lang.String str26 = functionType25.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        boolean boolean36 = functionType35.isAllType();
        boolean boolean38 = functionType25.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType35, true);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry7.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType25, "hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        boolean boolean62 = functionType58.matchesObjectContext();
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode65 = null;
        jSTypeRegistry64.setResolveMode(resolveMode65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry70.createFunctionTypeWithVarArgs(jSType71, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, false);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList81 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList81, jSTypeArray80);
        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry78.createFunctionTypeWithVarArgs(jSType79, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList81);
        com.google.javascript.rhino.jstype.JSType jSType88 = jSTypeRegistry78.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType89 = jSType88.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] { jSType88 };
        com.google.javascript.rhino.Node node91 = jSTypeRegistry70.createOptionalParameters(jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry64.createConstructorType(jSType67, jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType93 = jSTypeRegistry7.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType58, jSTypeArray90);
        jSTypeRegistry1.registerPropertyOnType("Not declared as a constructor", (com.google.javascript.rhino.jstype.JSType) functionType58);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertNotNull(jSType88);
        org.junit.Assert.assertNotNull(objectType89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertNotNull(functionType93);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isStringObjectType();
        int int11 = functionType7.getMaxArguments();
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList12 = null;
        try {
            functionType7.setImplementedInterfaces(objectTypeList12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset1);
        jSSourceFile2.clearCachedSource();
        java.lang.String str5 = jSSourceFile2.getLine(0);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node node4 = scriptOrFnNode3.getNext();
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        try {
            int int10 = node3.getExistingIntProp(130);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        boolean boolean6 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING hi! 32");
        java.lang.String str6 = scriptOrFnNode3.getSourceName();
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) str6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(runtimeException7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst(sourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst10, "", true);
        jsAst10.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile15 = jsAst10.getSourceFile();
        compilerInput6.setSourceFile(sourceFile15);
        sourceFile15.setOriginalPath("goog.exportProperty");
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNotNull(sourceFile15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        java.lang.String str3 = googleCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode7.addParam("");
        int int10 = scriptOrFnNode7.getFunctionCount();
        int int11 = scriptOrFnNode7.getRegexpCount();
        try {
            boolean boolean12 = googleCodingConvention0.isPropertyTestFunction((com.google.javascript.rhino.Node) scriptOrFnNode7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.foldConstants = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList20 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList20, jSTypeArray19);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createFunctionTypeWithVarArgs(jSType18, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList20);
        boolean boolean23 = functionType22.isNoObjectType();
        boolean boolean25 = objectType13.defineInferredProperty("Unknown class name", (com.google.javascript.rhino.jstype.JSType) functionType22, true);
        com.google.javascript.rhino.jstype.JSType jSType26 = objectType13.getParameterType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(jSType26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("Not declared as a constructor", "Not declared as a constructor", 27);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry13.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType24 = jSType23.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] { jSType23 };
        com.google.javascript.rhino.Node node26 = jSTypeRegistry5.createOptionalParameters(jSTypeArray25);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast27 = googleCodingConvention0.getObjectLiteralCast(nodeTraversal2, node26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(objectType24);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("Not declared as a constructor");
        java.lang.String str2 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList11 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList11, jSTypeArray10);
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createFunctionTypeWithVarArgs(jSType9, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList11);
        boolean boolean14 = functionType13.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType16 = functionType13.findPropertyType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str28 = node24.toString(true, false, false);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str36 = node32.toString(true, false, false);
        node32.detachChildren();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newExpr(node39);
        node40.putIntProp(0, (-1));
        node24.addChildAfter(node32, node40);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, false);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList50 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList50, jSTypeArray49);
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry47.createFunctionTypeWithVarArgs(jSType48, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList50);
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry47.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList63 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList63, jSTypeArray62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry60.createFunctionTypeWithVarArgs(jSType61, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList63);
        java.lang.String str66 = functionType65.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry70.createFunctionTypeWithVarArgs(jSType71, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        boolean boolean76 = functionType75.isAllType();
        boolean boolean78 = functionType65.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType75, true);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry47.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType65, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry18.createConstructorType("", node20, node32, (com.google.javascript.rhino.jstype.JSType) functionType65);
        com.google.javascript.rhino.ErrorReporter errorReporter82 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter82, false);
        com.google.javascript.rhino.jstype.JSType jSType85 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry84.createFunctionTypeWithVarArgs(jSType85, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
        boolean boolean90 = functionType89.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType92 = functionType89.findPropertyType("hi!");
        googleCodingConvention0.applySingletonGetter(functionType13, functionType65, (com.google.javascript.rhino.jstype.ObjectType) functionType89);
        boolean boolean94 = functionType13.isBooleanValueType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "STRING hi! 32" + "'", str28.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "STRING hi! 32" + "'", str36.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(jSTypeArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(jSType92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean6 = googleCodingConvention1.isOptionalParameter(node5);
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = null;
        java.lang.String[] strArray10 = new java.lang.String[] { "STRING hi! 32" };
        try {
            com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("goog.exportProperty", node5, checkLevel7, diagnosticType8, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean6 = googleCodingConvention1.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node7 = node5.cloneNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newExpr(node9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node15 = node9.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node18 = node9.clonePropsFrom(node17);
        try {
            com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(32, node7, node18, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        int int5 = scriptOrFnNode3.getParamOrVarIndex("STRING hi! 32");
        try {
            java.lang.String str7 = scriptOrFnNode3.getParamOrVarName(40);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: 40 ∉ [0, 0)");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        com.google.javascript.rhino.jstype.FunctionType functionType15 = functionPrototypeType9.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        java.lang.String str24 = functionType23.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createFunctionTypeWithVarArgs(jSType29, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        boolean boolean34 = functionType33.isAllType();
        boolean boolean36 = functionType23.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType33, true);
        com.google.javascript.rhino.jstype.JSType jSType37 = functionType23.restrictByNotNullOrUndefined();
        boolean boolean38 = functionPrototypeType9.canTestForShallowEqualityWith(jSType37);
        boolean boolean39 = functionPrototypeType9.isEmptyType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_EXPRESSION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str9 = node5.toString(true, false, false);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str17 = node13.toString(true, false, false);
        node13.detachChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node20);
        node21.putIntProp(0, (-1));
        node5.addChildAfter(node13, node21);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node30 = node5.clonePropsFrom(node29);
        boolean boolean31 = node1.hasChild(node30);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "STRING hi! 32" + "'", str9.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 32" + "'", str17.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str11 = node7.toString(true, false, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        node15.detachChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newExpr(node22);
        node23.putIntProp(0, (-1));
        node7.addChildAfter(node15, node23);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry1.createConstructorType("", node3, node15, (com.google.javascript.rhino.jstype.JSType) functionType48);
        java.util.Set set65 = functionType48.getOwnPropertyNames();
        java.util.Set<java.lang.String> strSet66 = functionType48.getPropertyNames();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertNotNull(set65);
        org.junit.Assert.assertNotNull(strSet66);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        try {
            context1.setLanguageVersion(24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 24");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        try {
//            com.google.javascript.rhino.Context.reportError("", "Not declared as a constructor", 13, "hi!", 0);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message:  (Not declared as a constructor#13)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str11 = node7.toString(true, false, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        node15.detachChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newExpr(node22);
        node23.putIntProp(0, (-1));
        node7.addChildAfter(node15, node23);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry1.createConstructorType("", node3, node15, (com.google.javascript.rhino.jstype.JSType) functionType48);
        boolean boolean66 = functionType48.hasOwnProperty("goog.global");
        boolean boolean67 = functionType48.isUnknownType();
        functionType48.clearResolved();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 2, 6, (int) 'a');
        java.lang.Object obj5 = node3.getProp(1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str12 = node8.toString(true, false, false);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str20 = node16.toString(true, false, false);
        node16.detachChildren();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newExpr(node23);
        node24.putIntProp(0, (-1));
        node8.addChildAfter(node16, node24);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry31.createFunctionTypeWithVarArgs(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry31.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList57 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList57, jSTypeArray56);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createFunctionTypeWithVarArgs(jSType55, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList57);
        boolean boolean60 = functionType59.isAllType();
        boolean boolean62 = functionType49.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType59, true);
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry31.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType49, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry2.createConstructorType("", node4, node16, (com.google.javascript.rhino.jstype.JSType) functionType49);
        java.util.Set set66 = functionType49.getOwnPropertyNames();
        try {
            java.lang.String str67 = com.google.javascript.rhino.ScriptRuntime.getMessage1("Unknown class name", (java.lang.Object) functionType49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Unknown class name");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "STRING hi! 32" + "'", str12.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "STRING hi! 32" + "'", str20.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNotNull(set66);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("", "hi!", "goog.exportProperty", "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        boolean boolean14 = functionPrototypeType9.isNativeObjectType();
        com.google.javascript.rhino.jstype.FunctionType functionType15 = functionPrototypeType9.getConstructor();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(functionType15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.SourceFile sourceFile7 = jsAst3.getSourceFile();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags1.clearAllFlags();
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node7 = node1.copyInformationFrom(node6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node9);
        node1.putBooleanProp(21, false);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        boolean boolean22 = functionType20.isCheckedUnknownType();
        boolean boolean23 = functionType20.isStringObjectType();
        boolean boolean24 = functionType20.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        boolean boolean33 = functionType32.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.ObjectType) functionType20, (com.google.javascript.rhino.jstype.JSType) functionType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType32.getOwnPropertyJSDocInfo("");
        java.lang.String str45 = functionType32.getNormalizedReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = scriptOrFnNode3.new FileLevelJsDocBuilder();
        scriptOrFnNode3.setEncodedSourceBounds(150, (-1));
        boolean[] booleanArray8 = scriptOrFnNode3.getParamAndVarConst();
        scriptOrFnNode3.setWasEmptyNode(true);
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = scriptOrFnNode3.getJSDocInfo();
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNull(jSDocInfo11);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setAllFlags();
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.aggressiveVarCheck;
        java.lang.String str13 = compilerOptions0.syntheticBlockStartMarker;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        boolean boolean36 = functionType20.matchesStringContext();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eof" + "'", str1.equals("eof"));
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        try {
//            com.google.javascript.rhino.Context.reportError("eof", "goog.exportProperty", 3, "<No stack trace available>", 100);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: eof (goog.exportProperty#3)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "TypeError: STRING hi! 32");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        try {
            com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        com.google.javascript.rhino.jstype.FunctionType functionType15 = functionPrototypeType9.getOwnerFunction();
        boolean boolean16 = functionType15.isUnknownType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = jSType12.unboxesTo();
        boolean boolean14 = jSType12.isNumberObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        try {
            java.util.Collection<java.lang.String> strCollection7 = compilerInput6.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("Unknown class name");
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = scriptOrFnNode6.getJsDocBuilderForNode();
        int int8 = scriptOrFnNode6.getParamCount();
        try {
            boolean boolean9 = googleCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isStringObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        boolean boolean9 = compilerOptions0.generateExports;
        compilerOptions0.renamePrefix = "TypeError: STRING hi! 32";
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder2 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder2.forConstructor();
        org.junit.Assert.assertNotNull(functionBuilder3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkTypes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel2, "hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.removeUnusedVars = true;
        java.lang.String str8 = compilerOptions5.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel10, "hi!");
        compilerOptions5.checkRequires = checkLevel10;
        boolean boolean14 = compilerOptions5.removeDeadCode;
        compilerOptions5.setProcessObjectPropertyString(false);
        com.google.javascript.rhino.EcmaError ecmaError18 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.Class<?> wildcardClass19 = ecmaError18.getClass();
        try {
            java.lang.String str20 = com.google.javascript.rhino.ScriptRuntime.getMessage3("goog.exportProperty", (java.lang.Object) "STRING hi! 32", (java.lang.Object) compilerOptions5, (java.lang.Object) wildcardClass19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportProperty");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(ecmaError18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(sourceAst0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        compilerOptions0.markNoSideEffectCalls = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType13);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry18.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSType28.dereference();
        boolean boolean30 = objectType29.isArrayType();
        boolean boolean31 = objectType13.differsFrom((com.google.javascript.rhino.jstype.JSType) objectType29);
        boolean boolean33 = objectType29.hasOwnProperty("eof");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        boolean boolean12 = functionType7.isPropertyTypeInferred("");
        boolean boolean13 = functionType7.isInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("<No stack trace available>", "Unknown class name", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str6 = diagnosticType5.key;
        boolean boolean7 = diagnosticGroup0.matches(diagnosticType5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        try {
            boolean boolean9 = diagnosticGroup0.matches(jSError8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi! 32" + "'", str6.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        boolean boolean22 = functionType20.isCheckedUnknownType();
        boolean boolean23 = functionType20.isStringObjectType();
        boolean boolean24 = functionType20.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        boolean boolean33 = functionType32.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.ObjectType) functionType20, (com.google.javascript.rhino.jstype.JSType) functionType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType32.getOwnPropertyJSDocInfo("");
        boolean boolean45 = functionType32.isObject();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry15.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSType25.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType25 };
        com.google.javascript.rhino.Node node28 = jSTypeRegistry7.createOptionalParameters(jSTypeArray27);
        try {
            boolean boolean29 = defaultCodingConvention0.isVarArgsParameter(node28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode9.addParam("");
        int int12 = scriptOrFnNode9.getFunctionCount();
        scriptOrFnNode9.putBooleanProp(23, false);
        try {
            boolean boolean16 = googleCodingConvention0.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, false);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList44 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList44, jSTypeArray43);
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry41.createFunctionTypeWithVarArgs(jSType42, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList44);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry41.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList57 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList57, jSTypeArray56);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createFunctionTypeWithVarArgs(jSType55, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList57);
        java.lang.String str60 = functionType59.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry64.createFunctionTypeWithVarArgs(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        boolean boolean70 = functionType69.isAllType();
        boolean boolean72 = functionType59.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType69, true);
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry41.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType59, "hi!");
        jSTypeRegistry41.identifyEnumName("language version");
        jSTypeRegistry41.resetForTypeCheck();
        jSTypeRegistry41.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter81 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry83 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter81, false);
        com.google.javascript.rhino.jstype.JSType jSType84 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList86, jSTypeArray85);
        com.google.javascript.rhino.jstype.FunctionType functionType88 = jSTypeRegistry83.createFunctionTypeWithVarArgs(jSType84, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList86);
        java.lang.String str89 = functionType88.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType90 = functionType88.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo92 = null;
        functionPrototypeType90.setPropertyJSDocInfo("", jSDocInfo92, false);
        boolean boolean95 = functionPrototypeType90.isNativeObjectType();
        jSTypeRegistry41.registerPropertyOnType("goog.global", (com.google.javascript.rhino.jstype.JSType) functionPrototypeType90);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode97 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        jSTypeRegistry41.setResolveMode(resolveMode97);
        jSTypeRegistry2.setResolveMode(resolveMode97);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(functionType88);
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertNotNull(functionPrototypeType90);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + resolveMode97 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode97.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        compilerOptions0.deadAssignmentElimination = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        com.google.javascript.rhino.jstype.JSType jSType15 = functionPrototypeType9.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry18.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSType28.dereference();
        boolean boolean30 = objectType29.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType31 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType29);
        try {
            boolean boolean32 = jSType15.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) objectType29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(objectType31);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node7 = node1.copyInformationFrom(node6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node9);
        int int11 = node10.getLineno();
        try {
            node10.setSideEffectFlags(24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst(sourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst10, "", true);
        jsAst10.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile15 = jsAst10.getSourceFile();
        compilerInput6.setSourceFile(sourceFile15);
        com.google.javascript.jscomp.JsAst jsAst17 = new com.google.javascript.jscomp.JsAst(sourceFile15);
        com.google.javascript.jscomp.SourceFile sourceFile18 = jsAst17.getSourceFile();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNotNull(sourceFile15);
        org.junit.Assert.assertNotNull(sourceFile18);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType13);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList22 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList22, jSTypeArray21);
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createFunctionTypeWithVarArgs(jSType20, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList22);
        java.lang.String str25 = functionType24.getNormalizedReferenceName();
        boolean boolean26 = functionType24.isCheckedUnknownType();
        boolean boolean27 = functionType24.isStringObjectType();
        boolean boolean29 = objectType15.defineInferredProperty("TypeError: STRING hi! 32", (com.google.javascript.rhino.jstype.JSType) functionType24, false);
        java.util.Set<java.lang.String> strSet30 = objectType15.getOwnPropertyNames();
        boolean boolean31 = objectType15.hasReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str6 = diagnosticType5.key;
        boolean boolean7 = diagnosticGroup0.matches(diagnosticType5);
        java.lang.String str8 = diagnosticType5.key;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi! 32" + "'", str6.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType51 = functionType49.getPrototype();
        com.google.javascript.rhino.jstype.EnumType enumType52 = jSTypeRegistry2.createEnumType("TypeError: STRING hi! 32", (com.google.javascript.rhino.jstype.JSType) functionType49);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSType jSType56 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList58 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList58, jSTypeArray57);
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry55.createFunctionTypeWithVarArgs(jSType56, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList58);
        java.lang.String str61 = functionType60.getNormalizedReferenceName();
        boolean boolean62 = functionType60.isCheckedUnknownType();
        boolean boolean63 = functionType60.isNumberObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode66 = null;
        jSTypeRegistry65.setResolveMode(resolveMode66);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter69 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter69, false);
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList74 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList74, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry71.createFunctionTypeWithVarArgs(jSType72, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList74);
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, false);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList82 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean83 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList82, jSTypeArray81);
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry79.createFunctionTypeWithVarArgs(jSType80, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList82);
        com.google.javascript.rhino.jstype.JSType jSType89 = jSTypeRegistry79.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType90 = jSType89.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray91 = new com.google.javascript.rhino.jstype.JSType[] { jSType89 };
        com.google.javascript.rhino.Node node92 = jSTypeRegistry71.createOptionalParameters(jSTypeArray91);
        com.google.javascript.rhino.jstype.FunctionType functionType93 = jSTypeRegistry65.createConstructorType(jSType68, jSTypeArray91);
        com.google.javascript.rhino.jstype.FunctionType functionType94 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType60, jSTypeArray91);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(functionPrototypeType51);
        org.junit.Assert.assertNotNull(enumType52);
        org.junit.Assert.assertNotNull(jSTypeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNotNull(jSType89);
        org.junit.Assert.assertNotNull(objectType90);
        org.junit.Assert.assertNotNull(jSTypeArray91);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNotNull(functionType93);
        org.junit.Assert.assertNotNull(functionType94);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        com.google.javascript.rhino.Node node9 = node3.cloneNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str17 = node13.toString(true, false, false);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str25 = node21.toString(true, false, false);
        node21.detachChildren();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newExpr(node28);
        node29.putIntProp(0, (-1));
        node13.addChildAfter(node21, node29);
        com.google.javascript.rhino.Node node35 = node13.getAncestor(13);
        try {
            com.google.javascript.rhino.Node node36 = node9.clonePropsFrom(node35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 32" + "'", str17.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "STRING hi! 32" + "'", str25.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node35);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 22");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        try {
            node20.removeChild(node29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.labelRenaming = false;
        compilerOptions0.ambiguateProperties = false;
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str6 = diagnosticType5.key;
        boolean boolean7 = diagnosticGroup0.matches(diagnosticType5);
        java.lang.String[] strArray12 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray12);
        int int14 = jSError13.getCharno();
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = jSError13.getType();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi! 32" + "'", str6.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(diagnosticType15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry15.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSType25.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType25 };
        com.google.javascript.rhino.Node node28 = jSTypeRegistry7.createOptionalParameters(jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry1.createConstructorType(jSType4, jSTypeArray27);
        java.util.Set set30 = functionType29.getOwnPropertyNames();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(set30);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 10.0f, (int) 'a', 21);
        com.google.javascript.rhino.Node node5 = null;
        try {
            com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(32, node4, node5, 23, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = scriptOrFnNode3.getJsDocBuilderForNode();
        fileLevelJsDocBuilder4.append("Unknown class name");
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.String str2 = ecmaError1.sourceName();
        java.lang.String str3 = ecmaError1.getLineSource();
        java.lang.String str4 = ecmaError1.sourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("", "Not declared as a constructor", "hi!");
        java.lang.String str4 = sourceFile3.getName();
        java.lang.String str6 = sourceFile3.getLine((int) (byte) 1);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.moveFunctionDeclarations = true;
        boolean boolean7 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str11 = node7.toString(true, false, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        node15.detachChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newExpr(node22);
        node23.putIntProp(0, (-1));
        node7.addChildAfter(node15, node23);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry1.createConstructorType("", node3, node15, (com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative65 = null;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType66 = jSTypeRegistry1.getNativeObjectType(jSTypeNative65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType64);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode29 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode29.addParam("");
        int int32 = scriptOrFnNode29.getFunctionCount();
        java.lang.RuntimeException runtimeException34 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) "hi!");
        scriptOrFnNode29.setCompilerData((java.lang.Object) runtimeException34);
        try {
            boolean boolean36 = googleCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(runtimeException34);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.ideMode;
        java.lang.Object obj5 = compilerOptions0.clone();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        boolean boolean13 = functionType10.isCheckedUnknownType();
        java.util.Set set14 = functionType10.getOwnPropertyNames();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(set14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.labelRenaming;
        compilerOptions0.closurePass = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearAllFlags();
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean9 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.crossModuleMethodMotion = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        context1.addActivationName("Not declared as a constructor");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        try {
            context1.removePropertyChangeListener(propertyChangeListener4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str15 = node11.toString(true, false, false);
        node11.detachChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        node19.putIntProp(0, (-1));
        node3.addChildAfter(node11, node19);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        java.lang.String str33 = functionType32.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType34 = functionType32.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo36 = null;
        functionPrototypeType34.setPropertyJSDocInfo("", jSDocInfo36, false);
        java.util.Set<java.lang.String> strSet39 = functionPrototypeType34.getPropertyNames();
        node3.putProp((int) (byte) -1, (java.lang.Object) strSet39);
        try {
            com.google.javascript.rhino.Node node41 = node3.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING hi! 32" + "'", str15.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(functionPrototypeType34);
        org.junit.Assert.assertNotNull(strSet39);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING hi! 32");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode10.addParam("");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode16.addParam("");
        int int19 = scriptOrFnNode16.getFunctionCount();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        boolean boolean24 = node23.isVarArgs();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(10, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode16, node23, node28);
        try {
            scriptOrFnNode3.addChildrenToBack(node28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        java.lang.String str4 = compilerOptions0.sourceMapOutputPath;
        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.ideMode;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "or" + "'", str1.equals("or"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        context1.setCompileFunctionsWithDynamicScope(false);
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.decomposeExpressions = true;
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.Class<?> wildcardClass2 = ecmaError1.getClass();
        java.lang.String str3 = ecmaError1.details();
        java.lang.String str4 = ecmaError1.lineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: STRING hi! 32" + "'", str3.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.decomposeExpressions = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        java.lang.String str4 = compilerOptions0.appNameStr;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("or");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property or");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType7.isReturnTypeInferred();
        java.lang.String str22 = functionType7.getReferenceName();
        boolean boolean23 = functionType7.matchesNumberContext();
        boolean boolean24 = functionType7.hasReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule4, jSModule5);
        com.google.javascript.jscomp.JSModule[] jSModuleArray7 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList8, jSModuleArray7);
        try {
            com.google.javascript.jscomp.JSModule jSModule10 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList8);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNotNull(jSModuleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        boolean boolean4 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        boolean boolean7 = googleCodingConvention0.isExported("<No stack trace available>", false);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal8 = null;
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        node19.putIntProp(0, (-1));
        java.lang.String str23 = node12.checkTreeEquals(node19);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast24 = googleCodingConvention0.getObjectLiteralCast(nodeTraversal8, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n" + "'", str23.equals("Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        int int8 = node3.getType();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 40 + "'", int8 == 40);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str15 = node11.toString(true, false, false);
        node11.detachChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        node19.putIntProp(0, (-1));
        node3.addChildAfter(node11, node19);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node28 = node3.clonePropsFrom(node27);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention29 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean34 = googleCodingConvention29.isOptionalParameter(node33);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode39 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode39.addParam("");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode45 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode45.addParam("");
        int int48 = scriptOrFnNode45.getFunctionCount();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        boolean boolean53 = node52.isVarArgs();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(10, (com.google.javascript.rhino.Node) scriptOrFnNode39, (com.google.javascript.rhino.Node) scriptOrFnNode45, node52, node57);
        boolean boolean59 = googleCodingConvention29.isOptionalParameter(node57);
        try {
            com.google.javascript.rhino.Node node60 = node28.removeChildAfter(node57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING hi! 32" + "'", str15.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setReturnsTainted();
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst(sourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst10, "", true);
        jsAst10.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile15 = jsAst10.getSourceFile();
        compilerInput6.setSourceFile(sourceFile15);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        try {
            com.google.javascript.rhino.Node node18 = compilerInput6.getAstRoot(abstractCompiler17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNotNull(sourceFile15);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        com.google.javascript.rhino.Node node9 = node3.cloneNode();
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        boolean boolean9 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineLocalFunctions = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("TypeError: STRING hi! 32");
        java.lang.Throwable[] throwableArray2 = evaluatorException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.jstype.JSType jSType11 = functionType7.getPropertyType("");
        boolean boolean12 = functionType7.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        boolean boolean34 = functionType7.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType30);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        boolean boolean43 = functionType7.equals((java.lang.Object) jSTypeList40);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.renamePrefix;
        boolean boolean2 = compilerOptions0.generatePseudoNames;
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n", "<No stack trace available>");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder1 = null;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode7.addParam("");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode13 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode13.addParam("");
        int int16 = scriptOrFnNode13.getFunctionCount();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        boolean boolean21 = node20.isVarArgs();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(10, (com.google.javascript.rhino.Node) scriptOrFnNode7, (com.google.javascript.rhino.Node) scriptOrFnNode13, node20, node25);
        try {
            compiler0.toSource(codeBuilder1, 0, (com.google.javascript.rhino.Node) scriptOrFnNode13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean5 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean6 = compilerOptions0.markAsCompiled;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Context context0 = null;
        try {
            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        boolean boolean14 = functionPrototypeType9.matchesStringContext();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node7 = node1.copyInformationFrom(node6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node11 = node9.getLastChild();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineConstantVars = false;
        boolean boolean10 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, true);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        loggerErrorManager5.generateReport();
        int int8 = loggerErrorManager5.getErrorCount();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("Named type with empty name component", "eof");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        compilerOptions0.collapseAnonymousFunctions = false;
        boolean boolean8 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel9;
        boolean boolean11 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry2.getNativeType(jSTypeNative38);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType50 = functionType48.getPrototype();
        com.google.javascript.rhino.jstype.JSType jSType52 = functionType48.getPropertyType("");
        boolean boolean53 = functionType48.isNullable();
        com.google.javascript.rhino.jstype.EnumType enumType54 = jSTypeRegistry2.createEnumType("hi!", (com.google.javascript.rhino.jstype.JSType) functionType48);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(functionPrototypeType50);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(enumType54);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node4 = node3.getParent();
        try {
            java.lang.String str5 = node4.toStringTree();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("Not declared as a constructor", "eof");
        java.lang.String str3 = diagnosticType2.key;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Not declared as a constructor" + "'", str3.equals("Not declared as a constructor"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = functionType7.restrictByNotNullOrUndefined();
        boolean boolean22 = jSType21.isBooleanValueType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.sourceMapOutputPath = "or";
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("// Input %num%");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(// Input %num%)" + "'", str1.equals("(// Input %num%)"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isNoObjectType();
        com.google.javascript.rhino.jstype.ObjectType objectType9 = functionType7.getTypeOfThis();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectType9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.removeUnusedVars = true;
        java.lang.String str5 = compilerOptions2.aliasableGlobals;
        try {
            context0.unseal((java.lang.Object) compilerOptions2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("(// Input %num%)");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        node2.putIntProp(0, (-1));
        com.google.javascript.rhino.Node node6 = node2.cloneNode();
        try {
            node2.setString("goog.exportProperty");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EXPR_RESULT [label_id_prop: -1] is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        try {
            java.lang.String str7 = compilerInput6.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean42 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList41, jSTypeArray40);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createFunctionTypeWithVarArgs(jSType39, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList41);
        java.lang.String str44 = functionType43.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, false);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList51 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList51, jSTypeArray50);
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createFunctionTypeWithVarArgs(jSType49, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList51);
        boolean boolean54 = functionType53.isAllType();
        boolean boolean56 = functionType43.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType53, true);
        boolean boolean57 = functionType53.matchesObjectContext();
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode60 = null;
        jSTypeRegistry59.setResolveMode(resolveMode60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63, false);
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray67 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList68 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean69 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList68, jSTypeArray67);
        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry65.createFunctionTypeWithVarArgs(jSType66, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList68);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, false);
        com.google.javascript.rhino.jstype.JSType jSType74 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList76 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean77 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList76, jSTypeArray75);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry73.createFunctionTypeWithVarArgs(jSType74, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList76);
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry73.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSType83.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { jSType83 };
        com.google.javascript.rhino.Node node86 = jSTypeRegistry65.createOptionalParameters(jSTypeArray85);
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry59.createConstructorType(jSType62, jSTypeArray85);
        com.google.javascript.rhino.jstype.FunctionType functionType88 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType53, jSTypeArray85);
        com.google.javascript.rhino.jstype.ObjectType objectType89 = functionType88.getTypeOfThis();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(jSTypeArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(functionType70);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertNotNull(functionType88);
        org.junit.Assert.assertNotNull(objectType89);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType7.getImplementedInterfaces();
        boolean boolean12 = functionType7.isRegexpType();
        boolean boolean13 = functionType7.isConstructor();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList19 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList19, jSTypeArray18);
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createFunctionTypeWithVarArgs(jSType17, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList19);
        java.lang.String str22 = functionType21.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType23 = functionType21.getPrototype();
        boolean boolean24 = functionPrototypeType23.hasCachedValues();
        boolean boolean25 = functionPrototypeType23.hasReferenceName();
        com.google.javascript.rhino.jstype.JSType jSType26 = functionType7.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) functionPrototypeType23);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(functionPrototypeType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(jSType26);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel1, "hi!");
        java.lang.String str4 = diagnosticType3.toString();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "STRING hi! 32: hi!" + "'", str4.equals("STRING hi! 32: hi!"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) ' ', "");
        com.google.javascript.rhino.Node node3 = node2.getNext();
        try {
            node2.setSideEffectFlags(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got TYPEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("// Input %num%", "Named type with empty name component");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property // Input %num%");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel9;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap11 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strMap11);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        com.google.javascript.rhino.Node node26 = null;
        try {
            boolean boolean27 = googleCodingConvention0.isPropertyTestFunction(node26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.SourceMap.Format format5 = compilerOptions0.sourceMapFormat;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        boolean boolean10 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.setDefineToBooleanLiteral("or", true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(format5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getLanguageVersion();
        context0.setLanguageVersion(130);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        boolean boolean3 = compilerOptions0.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingReturn;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy5;
        boolean boolean7 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType7.isReturnTypeInferred();
        java.lang.String str22 = functionType7.getReferenceName();
        boolean boolean23 = functionType7.isOrdinaryFunction();
        try {
            com.google.javascript.rhino.jstype.JSType jSType25 = functionType7.getTopMostDefiningType("Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = scriptOrFnNode3.getJsDocBuilderForNode();
        int int5 = scriptOrFnNode3.getParamCount();
        boolean boolean7 = scriptOrFnNode3.hasParamOrVar("Not declared as a constructor");
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getGlobalObject();
        java.lang.String str2 = googleCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str10 = node6.toString(true, false, false);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str18 = node14.toString(true, false, false);
        node14.detachChildren();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        node22.putIntProp(0, (-1));
        node6.addChildAfter(node14, node22);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        java.lang.String str36 = functionType35.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType37 = functionType35.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = null;
        functionPrototypeType37.setPropertyJSDocInfo("", jSDocInfo39, false);
        java.util.Set<java.lang.String> strSet42 = functionPrototypeType37.getPropertyNames();
        node6.putProp((int) (byte) -1, (java.lang.Object) strSet42);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = googleCodingConvention0.getClassesDefinedByCall(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "STRING hi! 32" + "'", str10.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "STRING hi! 32" + "'", str18.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(functionPrototypeType37);
        org.junit.Assert.assertNotNull(strSet42);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str3 = diagnosticType2.key;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType2.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "STRING hi! 32" + "'", str3.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        try {
//            com.google.javascript.rhino.Context.reportError("TypeError: STRING hi! 32", "Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n", 22, "Named type with empty name component", (-2));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isAllType();
        int int9 = functionType7.getPropertiesCount();
        boolean boolean10 = functionType7.isRegexpType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.groupVariableDeclarations = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("goog.global", "<No stack trace available>", 4095);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        boolean boolean21 = functionType20.isNoObjectType();
        boolean boolean23 = jSTypeRegistry2.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.resetForTypeCheck();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "TypeError: STRING hi! 32", 0);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
//        com.google.javascript.rhino.jstype.JSType jSType4 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
//        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createFunctionTypeWithVarArgs(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
//        java.lang.String str9 = functionType8.getNormalizedReferenceName();
//        boolean boolean10 = functionType8.isCheckedUnknownType();
//        boolean boolean11 = functionType8.isNumberObjectType();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = functionType8.getImplementedInterfaces();
//        boolean boolean13 = functionType8.isRegexpType();
//        boolean boolean14 = functionType8.isConstructor();
//        java.lang.Object obj15 = null;
//        java.lang.Object obj16 = null;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
//        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup17;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup17;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup17;
//        try {
//            java.lang.String str21 = com.google.javascript.rhino.ScriptRuntime.getMessage4("goog.global", (java.lang.Object) boolean14, obj15, obj16, (java.lang.Object) diagnosticGroup17);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.global");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(functionType8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup17);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "STRING hi! 32", (int) '#');
        int int5 = tokenStream4.getTokenno();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        boolean boolean22 = functionType20.isCheckedUnknownType();
        boolean boolean23 = functionType20.isStringObjectType();
        boolean boolean24 = functionType20.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        boolean boolean33 = functionType32.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.ObjectType) functionType20, (com.google.javascript.rhino.jstype.JSType) functionType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        boolean boolean43 = functionType20.isFunctionType();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope39 = null;
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry2.getType(jSTypeStaticScope39, "Unknown class name", "or", 2, (int) (byte) -1);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType44);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule4, jSModule5);
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        try {
            boolean boolean9 = jSModuleGraph3.dependsOn(jSModule7, jSModule8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str12 = node8.toString(true, false, false);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str20 = node16.toString(true, false, false);
        node16.detachChildren();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newExpr(node23);
        node24.putIntProp(0, (-1));
        node8.addChildAfter(node16, node24);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry31.createFunctionTypeWithVarArgs(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry31.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList57 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList57, jSTypeArray56);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createFunctionTypeWithVarArgs(jSType55, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList57);
        boolean boolean60 = functionType59.isAllType();
        boolean boolean62 = functionType49.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType59, true);
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry31.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType49, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry2.createConstructorType("", node4, node16, (com.google.javascript.rhino.jstype.JSType) functionType49);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str74 = node70.toString(true, false, false);
        node70.detachChildren();
        com.google.javascript.rhino.Node node76 = node70.cloneNode();
        int int77 = node70.getSideEffectFlags();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78, false);
        com.google.javascript.rhino.jstype.JSType jSType81 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray82 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList83 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean84 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList83, jSTypeArray82);
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry80.createFunctionTypeWithVarArgs(jSType81, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList83);
        java.lang.String str86 = functionType85.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType87 = functionType85.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo89 = null;
        functionPrototypeType87.setPropertyJSDocInfo("", jSDocInfo89, false);
        com.google.javascript.rhino.jstype.ObjectType objectType92 = jSTypeRegistry2.createObjectType("hi!", node70, (com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType87);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship93 = defaultCodingConvention0.getDelegateRelationship(node70);
        node70.setQuotedString();
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "STRING hi! 32" + "'", str12.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "STRING hi! 32" + "'", str20.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "STRING hi! 32" + "'", str74.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertNull(str86);
        org.junit.Assert.assertNotNull(functionPrototypeType87);
        org.junit.Assert.assertNotNull(objectType92);
        org.junit.Assert.assertNull(delegateRelationship93);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("Named type with empty name component", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.checkDuplicateMessages = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray9 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList10 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList10, warningsGuardArray9);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard12 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList10);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray13 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList14 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList14, warningsGuardArray13);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList14);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray17 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard12, composeWarningsGuard16 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard18 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray17);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean20 = composeWarningsGuard18.enables(diagnosticGroup19);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = null;
        boolean boolean23 = diagnosticGroup21.matches(diagnosticType22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str27 = diagnosticType26.key;
        boolean boolean28 = diagnosticGroup21.matches(diagnosticType26);
        java.lang.String[] strArray33 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make(diagnosticType26, strArray33);
        java.lang.String str35 = jSError34.description;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = composeWarningsGuard18.level(jSError34);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard18);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray17);
        org.junit.Assert.assertNotNull(diagnosticGroup19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "STRING hi! 32" + "'", str27.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "STRING hi! 32" + "'", str35.equals("STRING hi! 32"));
        org.junit.Assert.assertNull(checkLevel36);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 10.0f, (int) 'a', 21);
        com.google.javascript.rhino.Node node4 = node3.removeChildren();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        compilerOptions0.ideMode = true;
        compilerOptions0.decomposeExpressions = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.renamePrefix;
        boolean boolean2 = compilerOptions0.generatePseudoNames;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.checkGlobalNamesLevel = checkLevel3;
        boolean boolean5 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.jstype.ObjectType objectType41 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope42 = null;
        jSTypeRegistry2.resolveTypesInScope(jSTypeStaticScope42);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
        jSTypeRegistry2.resolveTypesInScope(jSTypeStaticScope44);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType41);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((-1.0d), 26, (int) (short) -1);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.String str2 = ecmaError1.sourceName();
        java.lang.String str3 = ecmaError1.toString();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32" + "'", str3.equals("com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset1);
        jSSourceFile2.clearCachedSource();
        jSSourceFile2.clearCachedSource();
        com.google.javascript.jscomp.Region region6 = jSSourceFile2.getRegion(0);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(27);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bitnot" + "'", str1.equals("bitnot"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope8 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope8, "Not declared as a constructor", "Unknown class name", 5, 38);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry2.createNullableType(jSType14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType13);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        int int5 = scriptOrFnNode3.getParamOrVarIndex("STRING hi! 32");
        scriptOrFnNode3.setEndLineno(1);
        java.lang.String str8 = scriptOrFnNode3.getSourceName();
        com.google.javascript.rhino.EcmaError ecmaError10 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.String str11 = ecmaError10.sourceName();
        int int12 = ecmaError10.columnNumber();
        java.lang.String str13 = ecmaError10.getLineSource();
        try {
            scriptOrFnNode3.setCompilerData((java.lang.Object) str13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(ecmaError10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.ideMode = true;
        boolean boolean14 = compilerOptions11.checkCaja;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = null;
        boolean boolean17 = diagnosticGroup15.matches(diagnosticType16);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel19, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel19);
        compilerOptions11.checkGlobalThisLevel = checkLevel19;
        compilerOptions0.reportUnknownTypes = checkLevel19;
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType21);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("eof", "bitnot");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getLanguageVersion();
        int int2 = context0.getLanguageVersion();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSTypeRegistry2.createObjectType(objectType36);
        jSTypeRegistry2.incrementGeneration();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType37);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType7.getImplementedInterfaces();
        boolean boolean12 = functionType7.isRegexpType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope14 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = functionType7.forceResolve(errorReporter13, jSTypeStaticScope14);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str15 = node11.toString(true, false, false);
        node11.detachChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        node19.putIntProp(0, (-1));
        node3.addChildAfter(node11, node19);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node28 = node3.clonePropsFrom(node27);
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.SourceFile sourceFile32 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator31);
        com.google.javascript.jscomp.JsAst jsAst33 = new com.google.javascript.jscomp.JsAst(sourceFile32);
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst33, "", true);
        jsAst33.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile38 = jsAst33.getSourceFile();
        node27.putProp(6, (java.lang.Object) sourceFile38);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable40 = node27.siblings();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING hi! 32" + "'", str15.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(sourceFile32);
        org.junit.Assert.assertNotNull(sourceFile38);
        org.junit.Assert.assertNotNull(nodeIterable40);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.Class<?> wildcardClass2 = ecmaError1.getClass();
        java.lang.String str3 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str11 = node7.toString(true, false, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        node15.detachChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newExpr(node22);
        node23.putIntProp(0, (-1));
        node7.addChildAfter(node15, node23);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry1.createConstructorType("", node3, node15, (com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str73 = node69.toString(true, false, false);
        node69.detachChildren();
        com.google.javascript.rhino.Node node75 = node69.cloneNode();
        int int76 = node69.getSideEffectFlags();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, false);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList82 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean83 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList82, jSTypeArray81);
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry79.createFunctionTypeWithVarArgs(jSType80, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList82);
        java.lang.String str85 = functionType84.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType86 = functionType84.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = null;
        functionPrototypeType86.setPropertyJSDocInfo("", jSDocInfo88, false);
        com.google.javascript.rhino.jstype.ObjectType objectType91 = jSTypeRegistry1.createObjectType("hi!", node69, (com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType86);
        boolean boolean93 = functionPrototypeType86.isPropertyTypeInferred("hi!");
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "STRING hi! 32" + "'", str73.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNull(str85);
        org.junit.Assert.assertNotNull(functionPrototypeType86);
        org.junit.Assert.assertNotNull(objectType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str12 = node8.toString(true, false, false);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str20 = node16.toString(true, false, false);
        node16.detachChildren();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newExpr(node23);
        node24.putIntProp(0, (-1));
        node8.addChildAfter(node16, node24);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry31.createFunctionTypeWithVarArgs(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry31.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList57 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList57, jSTypeArray56);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createFunctionTypeWithVarArgs(jSType55, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList57);
        boolean boolean60 = functionType59.isAllType();
        boolean boolean62 = functionType49.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType59, true);
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry31.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType49, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry2.createConstructorType("", node4, node16, (com.google.javascript.rhino.jstype.JSType) functionType49);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str74 = node70.toString(true, false, false);
        node70.detachChildren();
        com.google.javascript.rhino.Node node76 = node70.cloneNode();
        int int77 = node70.getSideEffectFlags();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78, false);
        com.google.javascript.rhino.jstype.JSType jSType81 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray82 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList83 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean84 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList83, jSTypeArray82);
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry80.createFunctionTypeWithVarArgs(jSType81, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList83);
        java.lang.String str86 = functionType85.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType87 = functionType85.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo89 = null;
        functionPrototypeType87.setPropertyJSDocInfo("", jSDocInfo89, false);
        com.google.javascript.rhino.jstype.ObjectType objectType92 = jSTypeRegistry2.createObjectType("hi!", node70, (com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType87);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship93 = defaultCodingConvention0.getDelegateRelationship(node70);
        com.google.javascript.rhino.Node node97 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("<No stack trace available>", (-2), (int) (short) -1);
        com.google.javascript.rhino.jstype.JSType jSType98 = node97.getJSType();
        java.lang.String str99 = defaultCodingConvention0.identifyTypeDefAssign(node97);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "STRING hi! 32" + "'", str12.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "STRING hi! 32" + "'", str20.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "STRING hi! 32" + "'", str74.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertNull(str86);
        org.junit.Assert.assertNotNull(functionPrototypeType87);
        org.junit.Assert.assertNotNull(objectType92);
        org.junit.Assert.assertNull(delegateRelationship93);
        org.junit.Assert.assertNotNull(node97);
        org.junit.Assert.assertNull(jSType98);
        org.junit.Assert.assertNull(str99);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        boolean boolean7 = compilerInput6.isExtern();
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str9 = compiler8.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider11 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = errorFormat10.toFormatter(sourceExcerptProvider11, true);
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter13, logger14);
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = loggerErrorManager15.getWarnings();
        int int17 = loggerErrorManager15.getErrorCount();
        compiler8.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(messageFormatter13);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.SourceMap.Format format5 = compilerOptions0.sourceMapFormat;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.convertToDottedProperties = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(format5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int6 = scriptOrFnNode3.getFunctionCount();
        scriptOrFnNode3.putBooleanProp(23, false);
        scriptOrFnNode3.setCompilerData((java.lang.Object) 1L);
        java.lang.String str12 = scriptOrFnNode3.getQualifiedName();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode4.addParam("");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode10.addParam("");
        int int13 = scriptOrFnNode10.getFunctionCount();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        boolean boolean18 = node17.isVarArgs();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(10, (com.google.javascript.rhino.Node) scriptOrFnNode4, (com.google.javascript.rhino.Node) scriptOrFnNode10, node17, node22);
        try {
            scriptOrFnNode10.setSideEffectFlags(37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got BITAND");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry15.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSType25.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType25 };
        com.google.javascript.rhino.Node node28 = jSTypeRegistry7.createOptionalParameters(jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry1.createConstructorType(jSType4, jSTypeArray27);
        com.google.javascript.rhino.jstype.JSType jSType31 = functionType29.findPropertyType("goog.exportProperty");
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNull(jSType31);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node10);
        node11.putIntProp(0, (-1));
        java.lang.String str15 = node4.checkTreeEquals(node11);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str23 = node19.toString(true, false, false);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str31 = node27.toString(true, false, false);
        node27.detachChildren();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node35 = com.google.javascript.jscomp.NodeUtil.newExpr(node34);
        node35.putIntProp(0, (-1));
        node19.addChildAfter(node27, node35);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node44 = node19.clonePropsFrom(node43);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str52 = node48.toString(true, false, false);
        node48.detachChildren();
        com.google.javascript.rhino.Node node54 = node48.cloneNode();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str62 = node58.toString(true, false, false);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str70 = node66.toString(true, false, false);
        node66.detachChildren();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node74 = com.google.javascript.jscomp.NodeUtil.newExpr(node73);
        node74.putIntProp(0, (-1));
        node58.addChildAfter(node66, node74);
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node83 = node58.clonePropsFrom(node82);
        com.google.javascript.rhino.Node node86 = new com.google.javascript.rhino.Node(35, node4, node19, node54, node83, (int) (short) 0, 11);
        com.google.javascript.rhino.Node node87 = node83.cloneNode();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n" + "'", str15.equals("Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "STRING hi! 32" + "'", str23.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "STRING hi! 32" + "'", str31.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "STRING hi! 32" + "'", str52.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "STRING hi! 32" + "'", str62.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "STRING hi! 32" + "'", str70.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node87);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.labelRenaming;
        compilerOptions0.nameReferenceGraphPath = "// Input %num%";
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        compilerOptions0.reserveRawExports = true;
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList20 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList20, jSTypeArray19);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createFunctionTypeWithVarArgs(jSType18, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList20);
        boolean boolean23 = functionType22.isNoObjectType();
        boolean boolean25 = objectType13.defineInferredProperty("Unknown class name", (com.google.javascript.rhino.jstype.JSType) functionType22, true);
        java.lang.String str26 = functionType22.toString();
        boolean boolean27 = functionType22.isOrdinaryFunction();
        boolean boolean28 = functionType22.isReturnTypeInferred();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "function (): ?" + "'", str26.equals("function (): ?"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.jstype.JSType jSType11 = functionType7.getPropertyType("");
        boolean boolean12 = functionType7.isNullable();
        boolean boolean13 = functionType7.isNoType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry2.getNativeType(jSTypeNative38);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "");
        com.google.javascript.rhino.Node node44 = node43.getNext();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newExpr(node46);
        node47.putIntProp(0, (-1));
        com.google.javascript.rhino.Node node51 = node47.cloneNode();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
        com.google.javascript.rhino.jstype.JSType jSType58 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList60 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean61 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList60, jSTypeArray59);
        com.google.javascript.rhino.jstype.FunctionType functionType62 = jSTypeRegistry57.createFunctionTypeWithVarArgs(jSType58, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList60);
        boolean boolean63 = functionType62.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection64 = jSTypeRegistry54.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry2.createConstructorType("hi!", node44, node51, (com.google.javascript.rhino.jstype.JSType) functionType62);
        java.lang.String str66 = functionType62.getTemplateTypeName();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(functionType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection64);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNull(str66);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32", 43, 0);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.collapseProperties = true;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.aliasableStrings;
        boolean boolean5 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        compilerOptions0.setManageClosureDependencies(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType51 = functionType49.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo53 = null;
        functionPrototypeType51.setPropertyJSDocInfo("", jSDocInfo53, false);
        boolean boolean56 = functionPrototypeType51.isNativeObjectType();
        jSTypeRegistry2.registerPropertyOnType("goog.global", (com.google.javascript.rhino.jstype.JSType) functionPrototypeType51);
        boolean boolean58 = functionPrototypeType51.matchesStringContext();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(functionPrototypeType51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str15 = node11.toString(true, false, false);
        node11.detachChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        node19.putIntProp(0, (-1));
        node3.addChildAfter(node11, node19);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node28 = node3.clonePropsFrom(node27);
        node28.removeProp(31);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING hi! 32" + "'", str15.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = null;
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.moveFunctionDeclarations = true;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.strictMessageReplacement = false;
        boolean boolean10 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_VAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "");
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str13 = node9.toString(true, false, false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str21 = node17.toString(true, false, false);
        node17.detachChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newExpr(node24);
        node25.putIntProp(0, (-1));
        node9.addChildAfter(node17, node25);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node34 = node9.clonePropsFrom(node33);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) 3);
        boolean boolean37 = node36.wasEmptyNode();
        try {
            com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(17, node1, node4, node9, node36, 26, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING hi! 32" + "'", str13.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "STRING hi! 32" + "'", str21.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        node2.putIntProp(0, (-1));
        try {
            com.google.javascript.rhino.Node node6 = node2.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        boolean boolean7 = compilerInput6.isExtern();
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput6.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(jSModule8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel12 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel12;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        boolean boolean15 = functionPrototypeType9.isStringValueType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable16 = functionPrototypeType9.getCtorImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable16);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.JSModule jSModule0 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray1 = new com.google.javascript.jscomp.JSModule[] { jSModule0 };
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.Class<?> wildcardClass2 = ecmaError1.getClass();
        java.lang.String str3 = ecmaError1.details();
        int int4 = ecmaError1.getColumnNumber();
        java.io.FilenameFilter filenameFilter5 = null;
        java.lang.String str6 = ecmaError1.getScriptStackTrace(filenameFilter5);
        java.lang.String str7 = ecmaError1.getErrorMessage();
        try {
            ecmaError1.initColumnNumber((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: STRING hi! 32" + "'", str3.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "<No stack trace available>" + "'", str6.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        boolean boolean36 = functionType20.isAllType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = functionType20.getOwnPropertyJSDocInfo("STRING hi! 32");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(jSDocInfo38);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.renamePrefix;
        compilerOptions0.inlineGetters = true;
        boolean boolean4 = compilerOptions0.foldConstants;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.setSummaryDetailLevel(0);
        compilerOptions0.enableExternExports(false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = null;
        boolean boolean6 = diagnosticGroup4.matches(diagnosticType5);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel8, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup4, checkLevel8);
        compilerOptions0.checkGlobalThisLevel = checkLevel8;
        compilerOptions0.generatePseudoNames = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType10);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        try {
//            com.google.javascript.rhino.Context.reportError("()", "", (int) (short) 0, "STRING hi! 32. STRING hi! 32 at (unknown source) line (unknown line) : (unknown column)", 1);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ()");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.printInputDelimiter = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType51 = functionType49.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo53 = null;
        functionPrototypeType51.setPropertyJSDocInfo("", jSDocInfo53, false);
        boolean boolean56 = functionPrototypeType51.isNativeObjectType();
        jSTypeRegistry2.registerPropertyOnType("goog.global", (com.google.javascript.rhino.jstype.JSType) functionPrototypeType51);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode58 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        jSTypeRegistry2.setResolveMode(resolveMode58);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention60 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean62 = googleCodingConvention60.isPrivate("STRING hi! 32");
        boolean boolean64 = googleCodingConvention60.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList70 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean71 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList70, jSTypeArray69);
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry67.createFunctionTypeWithVarArgs(jSType68, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList70);
        java.lang.String str73 = functionType72.getNormalizedReferenceName();
        boolean boolean74 = functionType72.isCheckedUnknownType();
        boolean boolean75 = functionType72.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, false);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList81 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList81, jSTypeArray80);
        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry78.createFunctionTypeWithVarArgs(jSType79, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList81);
        boolean boolean84 = functionType83.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType85 = null;
        googleCodingConvention60.applySubclassRelationship(functionType72, functionType83, subclassType85);
        boolean boolean87 = functionType83.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.ObjectType objectType88 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType83);
        java.util.Set<java.lang.String> strSet89 = objectType88.getOwnPropertyNames();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(functionPrototypeType51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + resolveMode58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode58.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(jSTypeArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(strSet89);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        boolean boolean6 = compilerOptions0.checkTypedPropertyCalls;
        boolean boolean7 = compilerOptions0.lineBreak;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        ecmaError1.initLineSource("STRING hi! 32");
        int int4 = ecmaError1.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.ObjectType objectType9 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType7);
        int int10 = functionType7.getPropertiesCount();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.renamePrefix;
        compilerOptions0.inlineGetters = true;
        boolean boolean4 = compilerOptions0.foldConstants;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        boolean boolean6 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean7 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        int int5 = scriptOrFnNode3.getParamOrVarIndex("STRING hi! 32");
        scriptOrFnNode3.setEndLineno(1);
        scriptOrFnNode3.setWasEmptyNode(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList13 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList13, jSTypeArray12);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createFunctionTypeWithVarArgs(jSType11, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList13);
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry10.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSType20.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] { jSType20 };
        com.google.javascript.rhino.Node node23 = jSTypeRegistry2.createOptionalParameters(jSTypeArray22);
        try {
            com.google.javascript.rhino.Node node24 = node23.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList11 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList11, jSTypeArray10);
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createFunctionTypeWithVarArgs(jSType9, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList11);
        boolean boolean14 = functionType13.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType16 = functionType13.findPropertyType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str28 = node24.toString(true, false, false);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str36 = node32.toString(true, false, false);
        node32.detachChildren();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newExpr(node39);
        node40.putIntProp(0, (-1));
        node24.addChildAfter(node32, node40);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, false);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList50 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList50, jSTypeArray49);
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry47.createFunctionTypeWithVarArgs(jSType48, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList50);
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry47.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList63 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList63, jSTypeArray62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry60.createFunctionTypeWithVarArgs(jSType61, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList63);
        java.lang.String str66 = functionType65.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry70.createFunctionTypeWithVarArgs(jSType71, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        boolean boolean76 = functionType75.isAllType();
        boolean boolean78 = functionType65.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType75, true);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry47.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType65, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry18.createConstructorType("", node20, node32, (com.google.javascript.rhino.jstype.JSType) functionType65);
        com.google.javascript.rhino.ErrorReporter errorReporter82 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter82, false);
        com.google.javascript.rhino.jstype.JSType jSType85 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry84.createFunctionTypeWithVarArgs(jSType85, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
        boolean boolean90 = functionType89.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType92 = functionType89.findPropertyType("hi!");
        googleCodingConvention0.applySingletonGetter(functionType13, functionType65, (com.google.javascript.rhino.jstype.ObjectType) functionType89);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable94 = functionType89.getParameters();
        com.google.javascript.rhino.jstype.ObjectType objectType95 = functionType89.getTypeOfThis();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "STRING hi! 32" + "'", str28.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "STRING hi! 32" + "'", str36.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(jSTypeArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(jSType92);
        org.junit.Assert.assertNotNull(nodeIterable94);
        org.junit.Assert.assertNotNull(objectType95);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = null;
        boolean boolean8 = diagnosticGroup6.matches(diagnosticType7);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str12 = diagnosticType11.key;
        boolean boolean13 = diagnosticGroup6.matches(diagnosticType11);
        boolean boolean14 = diagnosticGroup4.matches(diagnosticType11);
        java.lang.String[] strArray21 = new java.lang.String[] { "eof", "TypeError: STRING hi! 32", "language version", "function (): ?", "goog.global", "or" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", 7, 27, checkLevel3, diagnosticType11, strArray21);
        java.text.MessageFormat messageFormat23 = diagnosticType11.format;
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "STRING hi! 32" + "'", str12.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(messageFormat23);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = defaultCodingConvention0.isConstant("");
        java.lang.String str7 = defaultCodingConvention0.getDelegateSuperclassName();
        java.lang.String str8 = defaultCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry2.getNativeType(jSTypeNative38);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "");
        com.google.javascript.rhino.Node node44 = node43.getNext();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newExpr(node46);
        node47.putIntProp(0, (-1));
        com.google.javascript.rhino.Node node51 = node47.cloneNode();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
        com.google.javascript.rhino.jstype.JSType jSType58 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList60 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean61 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList60, jSTypeArray59);
        com.google.javascript.rhino.jstype.FunctionType functionType62 = jSTypeRegistry57.createFunctionTypeWithVarArgs(jSType58, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList60);
        boolean boolean63 = functionType62.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection64 = jSTypeRegistry54.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry2.createConstructorType("hi!", node44, node51, (com.google.javascript.rhino.jstype.JSType) functionType62);
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, false);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray70 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList71 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean72 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList71, jSTypeArray70);
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry68.createFunctionTypeWithVarArgs(jSType69, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList71);
        try {
            boolean boolean74 = functionType65.isSubtype(jSType69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(functionType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection64);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNotNull(jSTypeArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(functionType73);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType13);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList22 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList22, jSTypeArray21);
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createFunctionTypeWithVarArgs(jSType20, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList22);
        java.lang.String str25 = functionType24.getNormalizedReferenceName();
        boolean boolean26 = functionType24.isCheckedUnknownType();
        boolean boolean27 = functionType24.isStringObjectType();
        boolean boolean29 = objectType15.defineInferredProperty("TypeError: STRING hi! 32", (com.google.javascript.rhino.jstype.JSType) functionType24, false);
        java.util.Set<java.lang.String> strSet30 = objectType15.getOwnPropertyNames();
        boolean boolean31 = objectType15.isNumber();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        try {
            compiler0.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler0.getErrors();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt12);
        com.google.javascript.jscomp.ErrorManager errorManager14 = compiler0.getErrorManager();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(errorManager14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("hi!");
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection3 = googleCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        int int9 = scriptOrFnNode7.getParamOrVarIndex("STRING hi! 32");
        try {
            boolean boolean10 = googleCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType17.matchesObjectContext();
        boolean boolean22 = functionType17.isCheckedUnknownType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry2.getType("Not declared as a constructor");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNull(jSType37);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        boolean boolean8 = node3.isLocalResultCall();
        boolean boolean10 = node3.getBooleanProp(47);
        try {
            double double11 = node3.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! 32 is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str6 = diagnosticType5.key;
        boolean boolean7 = diagnosticGroup0.matches(diagnosticType5);
        java.lang.String[] strArray12 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray12);
        int int14 = jSError13.lineNumber;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = jSError13.getType();
        java.lang.String[] strArray17 = new java.lang.String[] { "()" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make(diagnosticType15, strArray17);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi! 32" + "'", str6.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler0.getState();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(intermediateState4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType51 = functionType49.getPrototype();
        com.google.javascript.rhino.jstype.EnumType enumType52 = jSTypeRegistry2.createEnumType("TypeError: STRING hi! 32", (com.google.javascript.rhino.jstype.JSType) functionType49);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry2.createNamedType("or", "", 3, (int) (byte) -1);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(functionPrototypeType51);
        org.junit.Assert.assertNotNull(enumType52);
        org.junit.Assert.assertNotNull(jSType58);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType7.getImplementedInterfaces();
        boolean boolean12 = functionType7.isRegexpType();
        boolean boolean13 = functionType7.isConstructor();
        int int14 = functionType7.getMaxArguments();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) ' ', "");
        com.google.javascript.rhino.JSDocInfo jSDocInfo3 = null;
        node2.setJSDocInfo(jSDocInfo3);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(48);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bindname" + "'", str1.equals("bindname"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler0.getErrors();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str27 = node23.toString(true, false, false);
        node23.detachChildren();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newExpr(node30);
        node31.putIntProp(0, (-1));
        node15.addChildAfter(node23, node31);
        com.google.javascript.jscomp.NodeTraversal.Callback callback36 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node23, callback36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "STRING hi! 32" + "'", str27.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        boolean boolean3 = diagnosticGroup0.matches(diagnosticType2);
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        com.google.javascript.rhino.Node node9 = node3.cloneNode();
        node3.putIntProp(6, (-1));
        com.google.javascript.jscomp.SourceFile.Generator generator15 = null;
        com.google.javascript.jscomp.SourceFile sourceFile16 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator15);
        com.google.javascript.jscomp.JsAst jsAst17 = new com.google.javascript.jscomp.JsAst(sourceFile16);
        node3.putProp((int) (short) 10, (java.lang.Object) sourceFile16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(sourceFile16);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        boolean boolean5 = compilerOptions0.foldConstants;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node7 = node1.copyInformationFrom(node6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node10 = node1.clonePropsFrom(node9);
        int int11 = node10.getLineno();
        com.google.javascript.rhino.Node node12 = node10.removeFirstChild();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node15 = com.google.javascript.jscomp.NodeUtil.newExpr(node14);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode19 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode19.addParam("");
        int int22 = scriptOrFnNode19.getFunctionCount();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode26 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = scriptOrFnNode26.new FileLevelJsDocBuilder();
        int int28 = scriptOrFnNode26.getParamAndVarCount();
        node14.addChildAfter((com.google.javascript.rhino.Node) scriptOrFnNode19, (com.google.javascript.rhino.Node) scriptOrFnNode26);
        int int31 = scriptOrFnNode19.addVar("eof");
        boolean boolean32 = node10.checkTreeEqualsSilent((com.google.javascript.rhino.Node) scriptOrFnNode19);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode1 = new com.google.javascript.rhino.ScriptOrFnNode(8);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.nameReferenceReportPath = "";
        boolean boolean8 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isReturnTypeInferred();
        boolean boolean11 = functionType7.isInterface();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode5.setEndLineno(20);
        boolean boolean8 = scriptOrFnNode5.isOnlyModifiesThisCall();
        java.lang.String str9 = googleCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.removeUnusedVars = true;
        boolean boolean6 = compilerOptions3.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions3.checkMissingReturn;
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) false, (java.lang.Object) checkLevel7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(runtimeException8);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        boolean boolean11 = compilerOptions0.removeUnusedVarsInGlobalScope;
        compilerOptions0.checkTypedPropertyCalls = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.toString();
        java.lang.String str4 = sourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.collapseProperties = true;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.aliasableStrings;
        boolean boolean5 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("(// Input %num%)", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        java.lang.String str4 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.instrumentationTemplate = "";
        boolean boolean7 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str11 = node7.toString(true, false, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        node15.detachChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newExpr(node22);
        node23.putIntProp(0, (-1));
        node7.addChildAfter(node15, node23);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry1.createConstructorType("", node3, node15, (com.google.javascript.rhino.jstype.JSType) functionType48);
        boolean boolean66 = functionType48.hasOwnProperty("goog.global");
        boolean boolean67 = functionType48.isUnknownType();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry70.createFunctionTypeWithVarArgs(jSType71, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry70.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType81 = jSType80.dereference();
        com.google.javascript.rhino.jstype.JSType jSType83 = jSType80.findPropertyType("STRING hi! 32");
        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = functionType48.getTypesUnderShallowEquality(jSType80);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(typePair84);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        boolean boolean6 = scriptOrFnNode4.hasParamOrVar("STRING hi! 32");
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel8, "hi!");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = null;
        boolean boolean13 = diagnosticGroup11.matches(diagnosticType12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str17 = diagnosticType16.key;
        boolean boolean18 = diagnosticGroup11.matches(diagnosticType16);
        java.lang.String[] strArray23 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(diagnosticType16, strArray23);
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("eof", (com.google.javascript.rhino.Node) scriptOrFnNode4, diagnosticType10, strArray23);
        java.text.MessageFormat messageFormat26 = diagnosticType10.format;
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 32" + "'", str17.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(messageFormat26);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        com.google.javascript.rhino.jstype.FunctionType functionType15 = functionPrototypeType9.getOwnerFunction();
        boolean boolean16 = functionPrototypeType9.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType10 = functionType7.findPropertyType("hi!");
        boolean boolean11 = functionType7.hasCachedValues();
        boolean boolean12 = functionType7.hasInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        java.lang.String str6 = googleCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.aliasExternals;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        node2.putIntProp(0, (-1));
        com.google.javascript.rhino.Node node6 = node2.cloneNode();
        boolean boolean7 = node6.isSyntheticBlock();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        try {
            com.google.javascript.rhino.Context.reportWarning("// Input %num%");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType13);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry18.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSType28.dereference();
        boolean boolean30 = objectType29.isArrayType();
        boolean boolean31 = objectType13.differsFrom((com.google.javascript.rhino.jstype.JSType) objectType29);
        com.google.javascript.rhino.jstype.JSType jSType33 = objectType29.findPropertyType("hi!");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSType33);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode4.addParam("");
        int int7 = scriptOrFnNode4.getFunctionCount();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((-1), (com.google.javascript.rhino.Node) scriptOrFnNode4, (int) (byte) -1, 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        try {
            java.lang.String str8 = compilerInput6.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(jSModule7);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        java.lang.String str3 = googleCodingConvention0.getExportPropertyFunction();
        boolean boolean5 = googleCodingConvention0.isPrivate("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.String str2 = ecmaError1.sourceName();
        int int3 = ecmaError1.columnNumber();
        java.lang.String str4 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TypeError: STRING hi! 32" + "'", str4.equals("TypeError: STRING hi! 32"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder2 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder2.withTypeOfThis(objectType3);
        org.junit.Assert.assertNotNull(functionBuilder4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = functionType7.restrictByNotNullOrUndefined();
        boolean boolean23 = functionType7.hasProperty("language version");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst(sourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst10, "", true);
        jsAst10.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile15 = jsAst10.getSourceFile();
        compilerInput6.setSourceFile(sourceFile15);
        com.google.javascript.jscomp.JsAst jsAst17 = new com.google.javascript.jscomp.JsAst(sourceFile15);
        com.google.javascript.jscomp.SourceFile.Generator generator19 = null;
        com.google.javascript.jscomp.SourceFile sourceFile20 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator19);
        java.lang.String str21 = sourceFile20.getOriginalPath();
        jsAst17.setSourceFile(sourceFile20);
        try {
            java.io.Reader reader23 = sourceFile20.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNotNull(sourceFile15);
        org.junit.Assert.assertNotNull(sourceFile20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.disambiguateProperties = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        boolean boolean2 = context0.hasCompileFunctionsWithDynamicScope();
        java.lang.String str3 = context0.getImplementationVersion();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.Class<?> wildcardClass2 = ecmaError1.getClass();
        java.lang.String str3 = ecmaError1.details();
        int int4 = ecmaError1.getColumnNumber();
        java.lang.String str5 = ecmaError1.lineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: STRING hi! 32" + "'", str3.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("goog.global", "goog.global");
        org.junit.Assert.assertNotNull(sourceFile2);
    }
}

