import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.Node node3 = null;
        try {
            java.lang.String str4 = googleCodingConvention0.identifyTypeDefAssign(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 16, (int) (short) 10);
        java.util.Set<java.lang.String> strSet4 = node3.getDirectives();
        boolean boolean5 = node3.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder2 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        java.lang.String str11 = functionType10.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType12 = functionType10.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = null;
        functionPrototypeType12.setPropertyJSDocInfo("", jSDocInfo14, false);
        java.util.Set<java.lang.String> strSet17 = functionPrototypeType12.getPropertyNames();
        boolean boolean18 = functionPrototypeType12.isStringValueType();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder19 = functionBuilder2.withTypeOfThis((com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType12);
        boolean boolean20 = functionPrototypeType12.hasReferenceName();
        boolean boolean21 = functionPrototypeType12.isEnumType();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(functionPrototypeType12);
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        boolean boolean5 = node4.isVarArgs();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode9 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        int int11 = scriptOrFnNode9.getParamOrVarIndex("STRING hi! 32");
        com.google.javascript.rhino.Node node12 = null;
        try {
            com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(23, node4, (com.google.javascript.rhino.Node) scriptOrFnNode9, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.forwardDeclareType("STRING hi! 32");
        java.util.List<com.google.javascript.rhino.jstype.JSType> jSTypeList38 = null;
        try {
            com.google.javascript.rhino.Node node39 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeList38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str10 = node6.toString(true, false, false);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str18 = node14.toString(true, false, false);
        node14.detachChildren();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        node22.putIntProp(0, (-1));
        node6.addChildAfter(node14, node22);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node31 = node6.clonePropsFrom(node30);
        try {
            boolean boolean32 = googleCodingConvention0.isVarArgsParameter(node30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: OR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "STRING hi! 32" + "'", str10.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "STRING hi! 32" + "'", str18.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node31);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isReturnTypeInferred();
        boolean boolean12 = functionType7.hasProperty("Not declared as a constructor");
        boolean boolean14 = functionType7.isPropertyInExterns("()");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType51 = functionType49.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo53 = null;
        functionPrototypeType51.setPropertyJSDocInfo("", jSDocInfo53, false);
        boolean boolean56 = functionPrototypeType51.isNativeObjectType();
        jSTypeRegistry2.registerPropertyOnType("goog.global", (com.google.javascript.rhino.jstype.JSType) functionPrototypeType51);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope58 = null;
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry2.getType(jSTypeStaticScope58, "// Input %num%", "or", 43, 100);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(functionPrototypeType51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSType63);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        java.util.logging.Logger logger5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.parsing.ParserRunner.parse("goog.global", "STRING hi! 32", config3, errorReporter4, logger5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.ignoreCajaProperties = true;
        boolean boolean11 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = functionPrototypeType9.getOwnerFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType15 = functionPrototypeType9.getConstructor();
        boolean boolean16 = functionPrototypeType9.isNativeObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.String str2 = ecmaError1.sourceName();
        int int3 = ecmaError1.columnNumber();
        java.lang.String str4 = ecmaError1.getLineSource();
        int int5 = ecmaError1.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, false);
        com.google.javascript.jscomp.SourceFile sourceFile9 = null;
        try {
            compilerInput8.setSourceFile(sourceFile9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("", "function (): ?", "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.enableExternExports(false);
        compilerOptions0.checkMissingGetCssNameBlacklist = "";
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType13);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry18.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSType28.dereference();
        boolean boolean30 = objectType29.isArrayType();
        boolean boolean31 = objectType13.differsFrom((com.google.javascript.rhino.jstype.JSType) objectType29);
        boolean boolean32 = objectType13.isEnumType();
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType34 = objectType13.getGreatestSubtype(jSType33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.getName();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.renamePrefix;
        boolean boolean2 = compilerOptions0.generatePseudoNames;
        compilerOptions0.setProcessObjectPropertyString(false);
        boolean boolean5 = compilerOptions0.inlineGetters;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.enableExternExports(false);
        boolean boolean11 = compilerOptions0.computeFunctionSideEffects;
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        double double11 = loggerErrorManager7.getTypedPercent();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        java.util.Map<java.lang.String, com.google.javascript.rhino.jstype.JSType> strMap36 = null;
        try {
            com.google.javascript.rhino.jstype.RecordType recordType37 = jSTypeRegistry2.createRecordType(strMap36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        boolean boolean4 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int6 = scriptOrFnNode3.getFunctionCount();
        scriptOrFnNode3.putBooleanProp(23, false);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 10.0f, (int) 'a', 21);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        scriptOrFnNode3.addChildAfter(node13, node17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "STRING hi! 32", (int) '#');
        int int5 = tokenStream4.getToken();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 38 + "'", int5 == 38);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        boolean boolean9 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalNamesLevel;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap11;
        compilerOptions0.collapseVariableDeclarations = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        boolean boolean3 = compilerOptions0.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node9 = node3.copyInformationFrom(node8);
        node3.addSuppression("STRING hi! 32");
        boolean boolean12 = defaultCodingConvention1.isPropertyTestFunction(node3);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.removeUnusedVars = true;
        java.lang.String str17 = compilerOptions14.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel19, "hi!");
        compilerOptions14.checkRequires = checkLevel19;
        boolean boolean23 = compilerOptions14.generateExports;
        try {
            java.lang.String str24 = com.google.javascript.rhino.ScriptRuntime.getMessage3("language version", (java.lang.Object) defaultCodingConvention1, (java.lang.Object) 10L, (java.lang.Object) compilerOptions14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("TypeError: STRING hi! 32");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("or", "Unknown class name", "goog.exportSymbol", "(// Input %num%)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property or");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode10.addParam("");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode16.addParam("");
        int int19 = scriptOrFnNode16.getFunctionCount();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        boolean boolean24 = node23.isVarArgs();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(10, (com.google.javascript.rhino.Node) scriptOrFnNode10, (com.google.javascript.rhino.Node) scriptOrFnNode16, node23, node28);
        boolean boolean30 = googleCodingConvention0.isOptionalParameter(node28);
        com.google.javascript.jscomp.Compiler compiler31 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str32 = compiler31.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback33 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal34 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler31, callback33);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node37 = com.google.javascript.jscomp.NodeUtil.newExpr(node36);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node42 = node36.copyInformationFrom(node41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node45 = node36.clonePropsFrom(node44);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder46 = node36.getJsDocBuilderForNode();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup48 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = null;
        boolean boolean50 = diagnosticGroup48.matches(diagnosticType49);
        com.google.javascript.jscomp.CheckLevel checkLevel52 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel52, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard55 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup48, checkLevel52);
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.DiagnosticType.make("TypeError: STRING hi! 32", checkLevel52, "or");
        java.lang.String str58 = diagnosticType57.key;
        java.lang.String[] strArray59 = null;
        com.google.javascript.jscomp.JSError jSError60 = nodeTraversal34.makeError(node36, diagnosticType57, strArray59);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode64 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder65 = scriptOrFnNode64.new FileLevelJsDocBuilder();
        scriptOrFnNode64.setEncodedSourceBounds(150, (-1));
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast69 = googleCodingConvention0.getObjectLiteralCast(nodeTraversal34, (com.google.javascript.rhino.Node) scriptOrFnNode64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder46);
        org.junit.Assert.assertNotNull(diagnosticGroup48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel52 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel52.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "TypeError: STRING hi! 32" + "'", str58.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertNotNull(jSError60);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup7;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup7;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray10 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1, diagnosticGroup2, diagnosticGroup4, diagnosticGroup7 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray10);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertNotNull(diagnosticGroupArray10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING hi! 32");
        boolean boolean7 = scriptOrFnNode3.hasParamOrVar("STRING hi! 32");
        java.lang.String str8 = scriptOrFnNode3.getSourceName();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset2);
        jSSourceFile3.clearCachedSource();
        jSSourceFile3.clearCachedSource();
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset7);
        jSSourceFile8.clearCachedSource();
        java.lang.String str11 = jSSourceFile8.getLine(0);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset13);
        jSSourceFile14.clearCachedSource();
        jSSourceFile14.clearCachedSource();
        com.google.javascript.jscomp.Region region18 = jSSourceFile14.getRegion(0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile3, jSSourceFile8, jSSourceFile14 };
        java.nio.charset.Charset charset21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset21);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset24);
        jSSourceFile25.clearCachedSource();
        java.lang.String str28 = jSSourceFile25.getLine(0);
        java.nio.charset.Charset charset30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset30);
        jSSourceFile31.clearCachedSource();
        java.lang.String str34 = jSSourceFile31.getLine(0);
        java.nio.charset.Charset charset36 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset36);
        jSSourceFile37.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray39 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile22, jSSourceFile25, jSSourceFile31, jSSourceFile37 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = null;
        try {
            compiler0.init(jSSourceFileArray19, jSSourceFileArray39, compilerOptions40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(region18);
        org.junit.Assert.assertNotNull(jSSourceFileArray19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNotNull(jSSourceFileArray39);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("<No stack trace available>", (-2), (int) (short) -1);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        node4.setJSDocInfo(jSDocInfo6);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup12;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = null;
        boolean boolean16 = diagnosticGroup14.matches(diagnosticType15);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str20 = diagnosticType19.key;
        boolean boolean21 = diagnosticGroup14.matches(diagnosticType19);
        boolean boolean22 = diagnosticGroup12.matches(diagnosticType19);
        java.lang.String[] strArray29 = new java.lang.String[] { "eof", "TypeError: STRING hi! 32", "language version", "function (): ?", "goog.global", "or" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("<No stack trace available>", 7, 27, checkLevel11, diagnosticType19, strArray29);
        com.google.javascript.jscomp.ErrorFormat errorFormat31 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider32 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter34 = errorFormat31.toFormatter(sourceExcerptProvider32, true);
        java.util.logging.Logger logger35 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager36 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter34, logger35);
        try {
            java.lang.String str37 = com.google.javascript.rhino.ScriptRuntime.getMessage3("", (java.lang.Object) node4, (java.lang.Object) 27, (java.lang.Object) loggerErrorManager36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "STRING hi! 32" + "'", str20.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(errorFormat31);
        org.junit.Assert.assertNotNull(messageFormatter34);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        boolean boolean10 = functionPrototypeType9.matchesNumberContext();
        java.lang.String str11 = functionPrototypeType9.getReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "null.prototype" + "'", str11.equals("null.prototype"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        java.lang.String[] strArray15 = new java.lang.String[] { "STRING hi! 32", "STRING hi! 32", "or", "Unknown class name", "Unknown class name", "// Input %num%", "goog.global", "", "// Input %num%", "language version" };
        java.util.ArrayList<java.lang.String> strList16 = new java.util.ArrayList<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList16, strArray15);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList16);
        java.lang.String str19 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType13);
        boolean boolean16 = objectType13.isOrdinaryFunction();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        java.lang.String[] strArray15 = new java.lang.String[] { "STRING hi! 32", "STRING hi! 32", "or", "Unknown class name", "Unknown class name", "// Input %num%", "goog.global", "", "// Input %num%", "language version" };
        java.util.ArrayList<java.lang.String> strList16 = new java.util.ArrayList<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList16, strArray15);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList16);
        boolean boolean19 = compilerOptions0.markAsCompiled;
        compilerOptions0.setLooseTypes(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        int int11 = compiler0.getWarningCount();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.removeTryCatchFinally = false;
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setThrows();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope8 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope8, "Not declared as a constructor", "Unknown class name", 5, 38);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList20 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList20, jSTypeArray19);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createFunctionTypeWithVarArgs(jSType18, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList20);
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry17.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType27.dereference();
        com.google.javascript.rhino.jstype.JSType jSType30 = jSType27.findPropertyType("STRING hi! 32");
        com.google.javascript.rhino.jstype.EnumType enumType31 = jSTypeRegistry2.createEnumType("com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32", jSType27);
        boolean boolean32 = jSType27.isFunctionPrototypeType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(enumType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList11 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList11, warningsGuardArray10);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard13 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList11);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray14 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard9, composeWarningsGuard13 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray14);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup16 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean17 = composeWarningsGuard15.enables(diagnosticGroup16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = null;
        boolean boolean20 = diagnosticGroup18.matches(diagnosticType19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str24 = diagnosticType23.key;
        boolean boolean25 = diagnosticGroup18.matches(diagnosticType23);
        java.lang.String[] strArray30 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make(diagnosticType23, strArray30);
        java.lang.String str32 = jSError31.description;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = composeWarningsGuard15.level(jSError31);
        com.google.javascript.jscomp.CheckLevel checkLevel34 = jSError31.level;
        compilerOptions0.checkFunctions = checkLevel34;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray14);
        org.junit.Assert.assertNotNull(diagnosticGroup16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "STRING hi! 32" + "'", str24.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "STRING hi! 32" + "'", str32.equals("STRING hi! 32"));
        org.junit.Assert.assertNull(checkLevel33);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        compilerOptions0.debugFunctionSideEffectsPath = "goog.exportProperty";
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler0.getErrors();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt12 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt12);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset15);
        jSSourceFile16.clearCachedSource();
        java.lang.String str19 = jSSourceFile16.getLine(0);
        java.nio.charset.Charset charset21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset21);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset24);
        jSSourceFile25.clearCachedSource();
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset28);
        jSSourceFile29.clearCachedSource();
        java.nio.charset.Charset charset32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset32);
        java.nio.charset.Charset charset35 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset35);
        jSSourceFile36.clearCachedSource();
        jSSourceFile36.clearCachedSource();
        com.google.javascript.jscomp.Region region40 = jSSourceFile36.getRegion(0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile16, jSSourceFile22, jSSourceFile25, jSSourceFile29, jSSourceFile33, jSSourceFile36 };
        java.nio.charset.Charset charset43 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset43);
        jSSourceFile44.clearCachedSource();
        java.nio.charset.Charset charset47 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset47);
        jSSourceFile48.clearCachedSource();
        java.nio.charset.Charset charset51 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset51);
        jSSourceFile52.clearCachedSource();
        java.lang.String str55 = jSSourceFile52.getLine(0);
        java.nio.charset.Charset charset57 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile58 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset57);
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset60);
        jSSourceFile61.clearCachedSource();
        jSSourceFile61.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray64 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile44, jSSourceFile48, jSSourceFile52, jSSourceFile58, jSSourceFile61 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions65.removeUnusedVars = true;
        java.lang.String str68 = compilerOptions65.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel70 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType72 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel70, "hi!");
        compilerOptions65.checkRequires = checkLevel70;
        boolean boolean74 = compilerOptions65.removeDeadCode;
        com.google.javascript.jscomp.CheckLevel checkLevel75 = compilerOptions65.checkGlobalNamesLevel;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap76 = null;
        compilerOptions65.cssRenamingMap = cssRenamingMap76;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig78 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions65);
        try {
            com.google.javascript.jscomp.Result result79 = compiler0.compile(jSSourceFileArray41, jSSourceFileArray64, compilerOptions65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNull(region40);
        org.junit.Assert.assertNotNull(jSSourceFileArray41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(jSSourceFile58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray64);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertTrue("'" + checkLevel70 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel70.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder2 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder2.withTemplateName("");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType14 = functionType12.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = null;
        functionPrototypeType14.setPropertyJSDocInfo("", jSDocInfo16, false);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = functionPrototypeType14.getOwnerFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType20 = functionPrototypeType14.getConstructor();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder21 = functionBuilder2.withTypeOfThis((com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType14);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        java.lang.String str30 = functionType29.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType31 = functionType29.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo33 = null;
        functionPrototypeType31.setPropertyJSDocInfo("", jSDocInfo33, false);
        java.util.Set<java.lang.String> strSet36 = functionPrototypeType31.getPropertyNames();
        boolean boolean37 = functionPrototypeType31.isStringValueType();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder38 = functionBuilder2.withInferredReturnType((com.google.javascript.rhino.jstype.JSType) functionPrototypeType31);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode43.addParam("");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode49 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode49.addParam("");
        int int52 = scriptOrFnNode49.getFunctionCount();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        boolean boolean57 = node56.isVarArgs();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(10, (com.google.javascript.rhino.Node) scriptOrFnNode43, (com.google.javascript.rhino.Node) scriptOrFnNode49, node56, node61);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder63 = functionBuilder38.withSourceNode((com.google.javascript.rhino.Node) scriptOrFnNode49);
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(functionPrototypeType14);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(functionType20);
        org.junit.Assert.assertNotNull(functionBuilder21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(functionPrototypeType31);
        org.junit.Assert.assertNotNull(strSet36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(functionBuilder38);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(functionBuilder63);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.String str2 = ecmaError1.getErrorMessage();
        java.lang.String str3 = ecmaError1.toString();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "STRING hi! 32" + "'", str2.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32" + "'", str3.equals("com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        boolean boolean3 = diagnosticGroup1.matches(diagnosticType2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str7 = diagnosticType6.key;
        boolean boolean8 = diagnosticGroup1.matches(diagnosticType6);
        java.lang.String[] strArray13 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray13);
        int int15 = jSError14.lineNumber;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = jSError14.getType();
        boolean boolean17 = diagnosticGroup0.matches(jSError14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.removeUnusedVars = true;
        java.lang.String str21 = compilerOptions18.aliasableGlobals;
        boolean boolean22 = compilerOptions18.checkCaja;
        compilerOptions18.removeEmptyFunctions = false;
        compilerOptions18.checkDuplicateMessages = false;
        boolean boolean27 = jSError14.equals((java.lang.Object) compilerOptions18);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType7.isReturnTypeInferred();
        java.lang.String str22 = functionType7.getReferenceName();
        boolean boolean23 = functionType7.matchesNumberContext();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList29 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList29, jSTypeArray28);
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry26.createFunctionTypeWithVarArgs(jSType27, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList29);
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry26.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList42 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList42, jSTypeArray41);
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createFunctionTypeWithVarArgs(jSType40, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList42);
        java.lang.String str45 = functionType44.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList52 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList52, jSTypeArray51);
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry49.createFunctionTypeWithVarArgs(jSType50, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList52);
        boolean boolean55 = functionType54.isAllType();
        boolean boolean57 = functionType44.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType54, true);
        com.google.javascript.rhino.jstype.JSType jSType59 = jSTypeRegistry26.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType44, "hi!");
        jSTypeRegistry26.identifyEnumName("language version");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry26.getNativeType(jSTypeNative62);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair64 = functionType7.getTypesUnderEquality(jSType63);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(jSType59);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(typePair64);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList11 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList11, jSTypeArray10);
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createFunctionTypeWithVarArgs(jSType9, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList11);
        boolean boolean14 = functionType13.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType16 = functionType13.findPropertyType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str28 = node24.toString(true, false, false);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str36 = node32.toString(true, false, false);
        node32.detachChildren();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newExpr(node39);
        node40.putIntProp(0, (-1));
        node24.addChildAfter(node32, node40);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, false);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList50 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList50, jSTypeArray49);
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry47.createFunctionTypeWithVarArgs(jSType48, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList50);
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry47.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList63 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList63, jSTypeArray62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry60.createFunctionTypeWithVarArgs(jSType61, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList63);
        java.lang.String str66 = functionType65.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry70.createFunctionTypeWithVarArgs(jSType71, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        boolean boolean76 = functionType75.isAllType();
        boolean boolean78 = functionType65.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType75, true);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry47.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType65, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry18.createConstructorType("", node20, node32, (com.google.javascript.rhino.jstype.JSType) functionType65);
        com.google.javascript.rhino.ErrorReporter errorReporter82 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter82, false);
        com.google.javascript.rhino.jstype.JSType jSType85 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry84.createFunctionTypeWithVarArgs(jSType85, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
        boolean boolean90 = functionType89.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType92 = functionType89.findPropertyType("hi!");
        googleCodingConvention0.applySingletonGetter(functionType13, functionType65, (com.google.javascript.rhino.jstype.ObjectType) functionType89);
        java.lang.String str94 = googleCodingConvention0.getExportPropertyFunction();
        boolean boolean96 = googleCodingConvention0.isConstant("");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "STRING hi! 32" + "'", str28.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "STRING hi! 32" + "'", str36.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(jSTypeArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(jSType92);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "goog.exportProperty" + "'", str94.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        boolean boolean8 = compilerOptions0.removeDeadCode;
        boolean boolean9 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.syntheticBlockStartMarker = "Named type with empty name component";
        compilerOptions0.setProcessObjectPropertyString(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        node2.putIntProp(0, (-1));
        node2.setVarArgs(true);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        boolean boolean7 = googleCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        boolean boolean19 = functionType18.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection20 = jSTypeRegistry10.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType18);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        java.lang.String str29 = functionType28.getNormalizedReferenceName();
        boolean boolean30 = functionType28.isCheckedUnknownType();
        boolean boolean31 = functionType28.isStringObjectType();
        boolean boolean32 = functionType28.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, false);
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList38 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList38, jSTypeArray37);
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry35.createFunctionTypeWithVarArgs(jSType36, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList38);
        boolean boolean41 = functionType40.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.jstype.JSType jSType50 = jSTypeRegistry10.createFunctionType((com.google.javascript.rhino.jstype.ObjectType) functionType28, (com.google.javascript.rhino.jstype.JSType) functionType40, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.jstype.JSType jSType51 = functionType28.unboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList57 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList57, jSTypeArray56);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createFunctionTypeWithVarArgs(jSType55, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList57);
        java.lang.String str60 = functionType59.getNormalizedReferenceName();
        boolean boolean61 = functionType59.isCheckedUnknownType();
        boolean boolean62 = functionType59.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable63 = functionType59.getImplementedInterfaces();
        boolean boolean64 = functionType59.isRegexpType();
        boolean boolean65 = functionType59.isConstructor();
        com.google.javascript.rhino.jstype.JSType jSType67 = functionType59.findPropertyType("TypeError: STRING hi! 32");
        com.google.javascript.rhino.jstype.FunctionType functionType68 = functionType59.getConstructor();
        com.google.javascript.rhino.ErrorReporter errorReporter69 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter69, false);
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList74 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList74, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry71.createFunctionTypeWithVarArgs(jSType72, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList74);
        com.google.javascript.rhino.jstype.JSType jSType81 = jSTypeRegistry71.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType82 = jSType81.dereference();
        com.google.javascript.rhino.JSDocInfo jSDocInfo84 = null;
        objectType82.setPropertyJSDocInfo("or", jSDocInfo84, true);
        googleCodingConvention0.applySingletonGetter(functionType28, functionType68, objectType82);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection20);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(jSTypeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSType50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNull(functionType68);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertNotNull(objectType82);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.Node node11 = null;
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str27 = node23.toString(true, false, false);
        node23.detachChildren();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newExpr(node30);
        node31.putIntProp(0, (-1));
        node15.addChildAfter(node23, node31);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean42 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList41, jSTypeArray40);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createFunctionTypeWithVarArgs(jSType39, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList41);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry38.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, false);
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList54 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList54, jSTypeArray53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry51.createFunctionTypeWithVarArgs(jSType52, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList54);
        java.lang.String str57 = functionType56.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        boolean boolean67 = functionType66.isAllType();
        boolean boolean69 = functionType56.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType66, true);
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry38.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType56, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry9.createConstructorType("", node11, node23, (com.google.javascript.rhino.jstype.JSType) functionType56);
        boolean boolean74 = functionType56.hasOwnProperty("goog.global");
        java.util.Set<java.lang.String> strSet75 = functionType56.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.JSType jSType76 = jSTypeRegistry2.createDefaultObjectUnion((com.google.javascript.rhino.jstype.JSType) functionType56);
        com.google.javascript.rhino.jstype.JSType jSType77 = functionType56.getIndexType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "STRING hi! 32" + "'", str27.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNotNull(jSTypeArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(strSet75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertNull(jSType77);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int7 = scriptOrFnNode3.getParamOrVarIndex("(// Input %num%)");
        try {
            scriptOrFnNode3.setSideEffectFlags(22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got BITAND");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList9 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList9, jSTypeArray8);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createFunctionTypeWithVarArgs(jSType7, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList9);
        java.lang.String str12 = functionType11.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType13 = functionType11.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        functionPrototypeType13.setPropertyJSDocInfo("", jSDocInfo15, false);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = functionPrototypeType13.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        java.lang.String str27 = functionType26.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType28 = functionType26.getPrototype();
        boolean boolean29 = functionPrototypeType28.hasCachedValues();
        boolean boolean30 = functionPrototypeType28.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry34.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        boolean boolean46 = functionPrototypeType28.defineDeclaredProperty("STRING hi! 32", jSType44, false);
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry1.createFunctionTypeWithNewReturnType(functionType18, (com.google.javascript.rhino.jstype.JSType) functionPrototypeType28);
        boolean boolean49 = functionPrototypeType28.hasOwnProperty("goog.exportProperty");
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(functionPrototypeType13);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(functionPrototypeType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("bindname");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property bindname");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getGlobalObject();
        boolean boolean3 = googleCodingConvention0.isPrivate("");
        boolean boolean5 = googleCodingConvention0.isPrivate("function (): ?");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("eof");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.checkEs5Strict = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.setReturnsTainted();
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        boolean boolean2 = context0.isGeneratingDebugChanged();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(errorReporter3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType51 = functionType49.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo53 = null;
        functionPrototypeType51.setPropertyJSDocInfo("", jSDocInfo53, false);
        boolean boolean56 = functionPrototypeType51.isNativeObjectType();
        jSTypeRegistry2.registerPropertyOnType("goog.global", (com.google.javascript.rhino.jstype.JSType) functionPrototypeType51);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode58 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        jSTypeRegistry2.setResolveMode(resolveMode58);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention60 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean62 = googleCodingConvention60.isPrivate("STRING hi! 32");
        boolean boolean64 = googleCodingConvention60.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList70 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean71 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList70, jSTypeArray69);
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry67.createFunctionTypeWithVarArgs(jSType68, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList70);
        java.lang.String str73 = functionType72.getNormalizedReferenceName();
        boolean boolean74 = functionType72.isCheckedUnknownType();
        boolean boolean75 = functionType72.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, false);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList81 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList81, jSTypeArray80);
        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry78.createFunctionTypeWithVarArgs(jSType79, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList81);
        boolean boolean84 = functionType83.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType85 = null;
        googleCodingConvention60.applySubclassRelationship(functionType72, functionType83, subclassType85);
        boolean boolean87 = functionType83.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.ObjectType objectType88 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType83);
        boolean boolean90 = functionType83.hasProperty("STRING hi! 32");
        boolean boolean91 = functionType83.isInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(functionPrototypeType51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + resolveMode58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode58.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(jSTypeArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node11 = node5.copyInformationFrom(node10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node14 = node5.clonePropsFrom(node13);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder15 = node5.getJsDocBuilderForNode();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = null;
        boolean boolean19 = diagnosticGroup17.matches(diagnosticType18);
        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel21, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.make("TypeError: STRING hi! 32", checkLevel21, "or");
        java.lang.String str27 = diagnosticType26.key;
        java.lang.String[] strArray28 = null;
        com.google.javascript.jscomp.JSError jSError29 = nodeTraversal3.makeError(node5, diagnosticType26, strArray28);
        com.google.javascript.rhino.Node node30 = nodeTraversal3.getCurrentNode();
        java.lang.String str31 = nodeTraversal3.getSourceName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder15);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TypeError: STRING hi! 32" + "'", str27.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        org.junit.Assert.assertNotNull(context0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.stripNamePrefixes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str9 = node5.toString(true, false, false);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str17 = node13.toString(true, false, false);
        node13.detachChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node20);
        node21.putIntProp(0, (-1));
        node5.addChildAfter(node13, node21);
        com.google.javascript.rhino.Node node26 = node21.getNext();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str34 = node30.toString(true, false, false);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str42 = node38.toString(true, false, false);
        node38.detachChildren();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node46 = com.google.javascript.jscomp.NodeUtil.newExpr(node45);
        node46.putIntProp(0, (-1));
        node30.addChildAfter(node38, node46);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node55 = node30.clonePropsFrom(node54);
        try {
            com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(1, node1, node26, node30, 130, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "STRING hi! 32" + "'", str9.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 32" + "'", str17.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "STRING hi! 32" + "'", str34.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "STRING hi! 32" + "'", str42.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node55);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node8 = node2.copyInformationFrom(node7);
        node2.addSuppression("STRING hi! 32");
        boolean boolean11 = defaultCodingConvention0.isPropertyTestFunction(node2);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        java.lang.String str20 = functionType19.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType21 = functionType19.getPrototype();
        com.google.javascript.rhino.jstype.JSType jSType23 = functionType19.getPropertyType("");
        boolean boolean24 = functionType19.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        java.lang.String str33 = functionType32.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        boolean boolean43 = functionType42.isAllType();
        boolean boolean45 = functionType32.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType42, true);
        boolean boolean46 = functionType19.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList52 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList52, jSTypeArray51);
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry49.createFunctionTypeWithVarArgs(jSType50, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList52);
        java.lang.String str55 = functionType54.getNormalizedReferenceName();
        boolean boolean56 = functionType54.isCheckedUnknownType();
        boolean boolean57 = functionType54.isNumberObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType58 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType19, functionType54, subclassType58);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(functionPrototypeType21);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int6 = scriptOrFnNode3.getFunctionCount();
        int int7 = scriptOrFnNode3.getRegexpCount();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str15 = node11.toString(true, false, false);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str23 = node19.toString(true, false, false);
        node19.detachChildren();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newExpr(node26);
        node27.putIntProp(0, (-1));
        node11.addChildAfter(node19, node27);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (byte) 100, 0, (-1));
        com.google.javascript.rhino.Node node36 = node11.clonePropsFrom(node35);
        boolean boolean37 = node11.isLocalResultCall();
        java.util.Set<java.lang.String> strSet38 = node11.getDirectives();
        scriptOrFnNode3.addChildToFront(node11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "STRING hi! 32" + "'", str15.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "STRING hi! 32" + "'", str23.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(strSet38);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType7.getImplementedInterfaces();
        boolean boolean12 = functionType7.isRegexpType();
        boolean boolean13 = functionType7.isConstructor();
        boolean boolean14 = functionType7.isUnionType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        boolean boolean15 = functionPrototypeType9.isStringValueType();
        boolean boolean16 = functionPrototypeType9.isResolved();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        try {
            java.lang.String str5 = compiler0.toSource(jSModule4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType7.isReturnTypeInferred();
        java.lang.String str22 = functionType7.getReferenceName();
        boolean boolean23 = functionType7.isFunctionType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList9 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList9, jSTypeArray8);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createFunctionTypeWithVarArgs(jSType7, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList9);
        java.lang.String str12 = functionType11.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType13 = functionType11.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        functionPrototypeType13.setPropertyJSDocInfo("", jSDocInfo15, false);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = functionPrototypeType13.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        java.lang.String str27 = functionType26.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType28 = functionType26.getPrototype();
        boolean boolean29 = functionPrototypeType28.hasCachedValues();
        boolean boolean30 = functionPrototypeType28.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry34.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        boolean boolean46 = functionPrototypeType28.defineDeclaredProperty("STRING hi! 32", jSType44, false);
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry1.createFunctionTypeWithNewReturnType(functionType18, (com.google.javascript.rhino.jstype.JSType) functionPrototypeType28);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet49 = jSTypeRegistry1.getTypesWithProperty("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(functionPrototypeType13);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(functionPrototypeType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertNotNull(objectTypeSet49);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = defaultCodingConvention0.isConstant("");
        boolean boolean8 = defaultCodingConvention0.isPrivate("bitnot");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.appNameStr = "hi!";
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        boolean boolean6 = node4.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        compilerOptions0.aliasableGlobals = "<No stack trace available>";
        org.junit.Assert.assertNull(codingConvention3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.setRemoveAbstractMethods(false);
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean10 = compilerOptions0.removeEmptyFunctions;
        boolean boolean11 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        boolean boolean4 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Named type with empty name component)" + "'", str1.equals("(Named type with empty name component)"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.nameReferenceReportPath = "// Input %num%";
        compilerOptions0.setSummaryDetailLevel(0);
        compilerOptions0.decomposeExpressions = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        boolean boolean13 = functionType10.canBeCalled();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList9 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList9, jSTypeArray8);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createFunctionTypeWithVarArgs(jSType7, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList9);
        java.lang.String str12 = functionType11.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType13 = functionType11.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        functionPrototypeType13.setPropertyJSDocInfo("", jSDocInfo15, false);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = functionPrototypeType13.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        java.lang.String str27 = functionType26.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType28 = functionType26.getPrototype();
        boolean boolean29 = functionPrototypeType28.hasCachedValues();
        boolean boolean30 = functionPrototypeType28.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry34.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        boolean boolean46 = functionPrototypeType28.defineDeclaredProperty("STRING hi! 32", jSType44, false);
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry1.createFunctionTypeWithNewReturnType(functionType18, (com.google.javascript.rhino.jstype.JSType) functionPrototypeType28);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, false);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList53 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList53, jSTypeArray52);
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry50.createFunctionTypeWithVarArgs(jSType51, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList53);
        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry50.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61, false);
        com.google.javascript.rhino.jstype.JSType jSType64 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList66 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean67 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList66, jSTypeArray65);
        com.google.javascript.rhino.jstype.FunctionType functionType68 = jSTypeRegistry63.createFunctionTypeWithVarArgs(jSType64, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList66);
        java.lang.String str69 = functionType68.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, false);
        com.google.javascript.rhino.jstype.JSType jSType74 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList76 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean77 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList76, jSTypeArray75);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry73.createFunctionTypeWithVarArgs(jSType74, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList76);
        boolean boolean79 = functionType78.isAllType();
        boolean boolean81 = functionType68.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType78, true);
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry50.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType68, "hi!");
        jSTypeRegistry50.identifyEnumName("language version");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative86 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType87 = jSTypeRegistry50.getNativeType(jSTypeNative86);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair88 = functionType47.getTypesUnderShallowEquality(jSType87);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(functionPrototypeType13);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(functionPrototypeType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertNotNull(jSType60);
        org.junit.Assert.assertNotNull(jSTypeArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(functionType68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertTrue("'" + jSTypeNative86 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative86.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertNotNull(typePair88);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean9 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.nameReferenceGraphPath = "TypeError: STRING hi! 32";
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = null;
        boolean boolean14 = diagnosticGroup12.matches(diagnosticType13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel16, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel16);
        compilerOptions0.checkUnreachableCode = checkLevel16;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.appNameStr;
        boolean boolean6 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.checkTypes = false;
        compilerOptions0.decomposeExpressions = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList9 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList9, jSTypeArray8);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createFunctionTypeWithVarArgs(jSType7, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList9);
        java.lang.String str12 = functionType11.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType13 = functionType11.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        functionPrototypeType13.setPropertyJSDocInfo("", jSDocInfo15, false);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = functionPrototypeType13.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        java.lang.String str27 = functionType26.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType28 = functionType26.getPrototype();
        boolean boolean29 = functionPrototypeType28.hasCachedValues();
        boolean boolean30 = functionPrototypeType28.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry34.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        boolean boolean46 = functionPrototypeType28.defineDeclaredProperty("STRING hi! 32", jSType44, false);
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry1.createFunctionTypeWithNewReturnType(functionType18, (com.google.javascript.rhino.jstype.JSType) functionPrototypeType28);
        boolean boolean48 = functionPrototypeType28.hasReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(functionPrototypeType13);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(functionPrototypeType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        java.lang.String str12 = compilerOptions0.inputDelimiter;
        compilerOptions0.syntheticBlockStartMarker = "STRING hi! 32";
        boolean boolean15 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.SourceMap.Format format16 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "// Input %num%" + "'", str12.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(format16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.renamePrefix;
        compilerOptions0.inlineGetters = true;
        compilerOptions0.prettyPrint = true;
        boolean boolean6 = compilerOptions0.collapseAnonymousFunctions;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = null;
        boolean boolean9 = diagnosticGroup7.matches(diagnosticType8);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel11, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup7, checkLevel11);
        compilerOptions0.checkProvides = checkLevel11;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode5 = null;
        jSTypeRegistry4.setResolveMode(resolveMode5);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList13 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList13, jSTypeArray12);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createFunctionTypeWithVarArgs(jSType11, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList13);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry18.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSType28.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType28 };
        com.google.javascript.rhino.Node node31 = jSTypeRegistry10.createOptionalParameters(jSTypeArray30);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry4.createConstructorType(jSType7, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = functionType32.getParametersNode();
        try {
            boolean boolean34 = googleCodingConvention0.isPropertyTestFunction(node33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray4 = compiler0.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        boolean boolean4 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        boolean boolean14 = functionType12.isCheckedUnknownType();
        boolean boolean15 = functionType12.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        googleCodingConvention0.applySubclassRelationship(functionType12, functionType23, subclassType25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newExpr(node28);
        node29.putIntProp(0, (-1));
        com.google.javascript.rhino.Node node33 = node29.cloneNode();
        com.google.javascript.rhino.Node node34 = node33.removeChildren();
        try {
            boolean boolean35 = googleCodingConvention0.isVarArgsParameter(node33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EXPR_RESULT [label_id_prop: -1] is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(node34);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setDefineToNumberLiteral("STRING hi! 32: hi!", 0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.nameReferenceReportPath = "// Input %num%";
        compilerOptions0.checkMissingGetCssNameBlacklist = "null.prototype";
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.removeUnusedVars = true;
        boolean boolean13 = compilerOptions10.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions10.checkMissingReturn;
        compilerOptions0.checkShadowVars = checkLevel14;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.collapseProperties = true;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(detailLevel11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.String str2 = ecmaError1.sourceName();
        int int3 = ecmaError1.columnNumber();
        ecmaError1.initSourceName("or");
        java.lang.String str6 = ecmaError1.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi! 32" + "'", str6.equals("STRING hi! 32"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Not declared as a constructor)" + "'", str1.equals("(Not declared as a constructor)"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType7.getImplementedInterfaces();
        boolean boolean12 = functionType7.isRegexpType();
        boolean boolean13 = functionType7.isConstructor();
        com.google.javascript.rhino.jstype.JSType jSType15 = functionType7.findPropertyType("TypeError: STRING hi! 32");
        boolean boolean17 = functionType7.hasOwnProperty("STRING hi! 32: hi!");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int6 = scriptOrFnNode3.getFunctionCount();
        scriptOrFnNode3.putBooleanProp(23, false);
        scriptOrFnNode3.setEncodedSourceBounds(4, (int) '4');
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder13 = scriptOrFnNode3.getJsDocBuilderForNode();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder13);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule6, jSModule7);
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        com.google.javascript.jscomp.JSModule jSModule10 = null;
        com.google.javascript.jscomp.JSModule jSModule11 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule9, jSModule10);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNull(jSModule11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        boolean boolean11 = compilerOptions0.removeUnusedVarsInGlobalScope;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray12 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList13 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13, warningsGuardArray12);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(warningsGuardArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(0, 37, 19);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setAllFlags();
        int int4 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        boolean boolean16 = functionPrototypeType9.isPropertyTypeDeclared("com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.removeUnusedVars = true;
        java.lang.String str11 = compilerOptions8.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel13, "hi!");
        compilerOptions8.checkRequires = checkLevel13;
        boolean boolean17 = compilerOptions8.removeDeadCode;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions8.checkGlobalNamesLevel;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy19 = compilerOptions8.anonymousFunctionNaming;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy19;
        boolean boolean21 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy19 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy19.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("STRING hi! 32: hi!", "goog.global", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property STRING hi! 32: hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler0.getErrors();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput13 = compiler0.newExternInput("// Input %num%");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray11);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard3, composeWarningsGuard7 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray8);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean11 = composeWarningsGuard9.enables(diagnosticGroup10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = null;
        boolean boolean14 = diagnosticGroup12.matches(diagnosticType13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str18 = diagnosticType17.key;
        boolean boolean19 = diagnosticGroup12.matches(diagnosticType17);
        java.lang.String[] strArray24 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray24);
        java.lang.String str26 = jSError25.description;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard9.level(jSError25);
        java.lang.String str28 = jSError25.toString();
        int int29 = jSError25.getCharno();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "STRING hi! 32" + "'", str18.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "STRING hi! 32" + "'", str26.equals("STRING hi! 32"));
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "STRING hi! 32. STRING hi! 32 at (unknown source) line (unknown line) : (unknown column)" + "'", str28.equals("STRING hi! 32. STRING hi! 32 at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType7.getImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType12 = functionType7.getReturnType();
        com.google.javascript.rhino.Node node13 = functionType7.getParametersNode();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getLanguageVersion();
        boolean boolean2 = context0.isGeneratingSource();
        context0.setCompileFunctionsWithDynamicScope(true);
        context0.addActivationName("TypeError: STRING hi! 32");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getLanguageVersion();
        boolean boolean2 = context0.isGeneratingSource();
        java.util.Locale locale3 = context0.getLocale();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(locale3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.SourceMap.Format format5 = compilerOptions0.sourceMapFormat;
        compilerOptions0.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.removeUnusedVars = true;
        boolean boolean11 = compilerOptions8.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions8.checkMissingReturn;
        compilerOptions0.checkShadowVars = checkLevel12;
        boolean boolean14 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(format5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        try {
            compiler0.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList11 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList11, jSTypeArray10);
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createFunctionTypeWithVarArgs(jSType9, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList11);
        boolean boolean14 = functionType13.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType16 = functionType13.findPropertyType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str28 = node24.toString(true, false, false);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str36 = node32.toString(true, false, false);
        node32.detachChildren();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newExpr(node39);
        node40.putIntProp(0, (-1));
        node24.addChildAfter(node32, node40);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, false);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList50 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList50, jSTypeArray49);
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry47.createFunctionTypeWithVarArgs(jSType48, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList50);
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry47.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList63 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList63, jSTypeArray62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry60.createFunctionTypeWithVarArgs(jSType61, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList63);
        java.lang.String str66 = functionType65.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry70.createFunctionTypeWithVarArgs(jSType71, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        boolean boolean76 = functionType75.isAllType();
        boolean boolean78 = functionType65.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType75, true);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry47.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType65, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry18.createConstructorType("", node20, node32, (com.google.javascript.rhino.jstype.JSType) functionType65);
        com.google.javascript.rhino.ErrorReporter errorReporter82 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter82, false);
        com.google.javascript.rhino.jstype.JSType jSType85 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry84.createFunctionTypeWithVarArgs(jSType85, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
        boolean boolean90 = functionType89.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType92 = functionType89.findPropertyType("hi!");
        googleCodingConvention0.applySingletonGetter(functionType13, functionType65, (com.google.javascript.rhino.jstype.ObjectType) functionType89);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable94 = functionType89.getParameters();
        com.google.javascript.rhino.Node node95 = functionType89.getSource();
        boolean boolean96 = functionType89.isTemplateType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "STRING hi! 32" + "'", str28.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "STRING hi! 32" + "'", str36.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(jSTypeArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(jSType92);
        org.junit.Assert.assertNotNull(nodeIterable94);
        org.junit.Assert.assertNull(node95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        scriptOrFnNode3.addParam("bitnot");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.appNameStr;
        boolean boolean6 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.checkTypes = false;
        boolean boolean9 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy10 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy10.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str6 = diagnosticType5.key;
        boolean boolean7 = diagnosticGroup0.matches(diagnosticType5);
        java.lang.String[] strArray12 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray12);
        int int14 = jSError13.lineNumber;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup15;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup15;
        boolean boolean18 = jSError13.equals((java.lang.Object) diagnosticGroup15);
        java.lang.String str19 = jSError13.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi! 32" + "'", str6.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32. STRING hi! 32 at (unknown source) line (unknown line) : (unknown column)" + "'", str19.equals("STRING hi! 32. STRING hi! 32 at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createFunctionTypeWithVarArgs(jSType29, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        java.lang.String str34 = functionType33.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType35 = functionType33.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo37 = null;
        functionPrototypeType35.setPropertyJSDocInfo("", jSDocInfo37, false);
        java.util.Set<java.lang.String> strSet40 = functionPrototypeType35.getPropertyNames();
        node4.putProp((int) (byte) -1, (java.lang.Object) strSet40);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str49 = node45.toString(true, false, false);
        boolean boolean50 = node45.isLocalResultCall();
        boolean boolean51 = node45.isOnlyModifiesThisCall();
        try {
            java.lang.String str52 = defaultCodingConvention0.extractClassNameIfRequire(node4, node45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(functionPrototypeType35);
        org.junit.Assert.assertNotNull(strSet40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "STRING hi! 32" + "'", str49.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(31, 3, 30);
        int int4 = scriptOrFnNode3.getBaseLineno();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope8 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope8, "Not declared as a constructor", "Unknown class name", 5, 38);
        com.google.common.base.Predicate<com.google.javascript.rhino.jstype.JSType> jSTypePredicate14 = null;
        boolean boolean15 = jSType13.setValidator(jSTypePredicate14);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getLanguageVersion();
        boolean boolean2 = context0.isGeneratingSource();
        java.util.Locale locale3 = context0.getLocale();
        com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.getErrorReporter();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(locale3);
        org.junit.Assert.assertNull(errorReporter4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "STRING hi! 32", (int) '#');
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode8 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = scriptOrFnNode8.getJsDocBuilderForNode();
        tokenStream4.setFileLevelJsDocBuilder(fileLevelJsDocBuilder9);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder15 = scriptOrFnNode14.new FileLevelJsDocBuilder();
        tokenStream4.setFileLevelJsDocBuilder(fileLevelJsDocBuilder15);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        boolean boolean4 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        boolean boolean14 = functionType12.isCheckedUnknownType();
        boolean boolean15 = functionType12.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        googleCodingConvention0.applySubclassRelationship(functionType12, functionType23, subclassType25);
        boolean boolean27 = functionType23.isReturnTypeInferred();
        com.google.javascript.rhino.Node node28 = functionType23.getParametersNode();
        java.util.Set set29 = functionType23.getOwnPropertyNames();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(set29);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("eof");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        com.google.javascript.rhino.Node node9 = node3.cloneNode();
        node3.putIntProp(6, (-1));
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean18 = googleCodingConvention13.isOptionalParameter(node17);
        boolean boolean19 = node3.hasChild(node17);
        com.google.javascript.rhino.Node node20 = node3.getParent();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isSealed();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode5 = null;
        jSTypeRegistry4.setResolveMode(resolveMode5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList12 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList12, jSTypeArray11);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createFunctionTypeWithVarArgs(jSType10, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList12);
        java.lang.String str15 = functionType14.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType16 = functionType14.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = null;
        functionPrototypeType16.setPropertyJSDocInfo("", jSDocInfo18, false);
        com.google.javascript.rhino.jstype.FunctionType functionType21 = functionPrototypeType16.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        java.lang.String str30 = functionType29.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType31 = functionType29.getPrototype();
        boolean boolean32 = functionPrototypeType31.hasCachedValues();
        boolean boolean33 = functionPrototypeType31.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry37.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        boolean boolean49 = functionPrototypeType31.defineDeclaredProperty("STRING hi! 32", jSType47, false);
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry4.createFunctionTypeWithNewReturnType(functionType21, (com.google.javascript.rhino.jstype.JSType) functionPrototypeType31);
        com.google.javascript.rhino.EvaluatorException evaluatorException54 = new com.google.javascript.rhino.EvaluatorException("hi!", "STRING hi! 32", 5);
        context1.putThreadLocal((java.lang.Object) functionPrototypeType31, (java.lang.Object) "hi!");
        java.util.Set set56 = functionPrototypeType31.getOwnPropertyNames();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(functionPrototypeType16);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(functionPrototypeType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNotNull(set56);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput6 = compiler0.getInput("<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        boolean boolean6 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.collapseProperties = true;
        boolean boolean11 = compilerOptions0.checkDuplicateMessages;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isNativeObjectType();
        com.google.javascript.rhino.jstype.ObjectType objectType10 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType7);
        boolean boolean11 = objectType10.isNumber();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.nameReferenceReportPath = "// Input %num%";
        boolean boolean8 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.generateExports = false;
        java.util.Set<java.lang.String> strSet9 = compilerOptions0.stripTypes;
        boolean boolean10 = compilerOptions0.tightenTypes;
        compilerOptions0.setDefineToBooleanLiteral("goog.global", false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.nameReferenceReportPath = "// Input %num%";
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str9 = compilerOptions8.renamePrefix;
        boolean boolean10 = compilerOptions8.generatePseudoNames;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions8.checkGlobalNamesLevel = checkLevel11;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel11;
        compilerOptions0.setDefineToStringLiteral("goog.exportProperty", "STRING hi! 32. STRING hi! 32 at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "null.prototype", 33, 0);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        boolean boolean4 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node7 = node1.copyInformationFrom(node6);
        com.google.javascript.rhino.Node node8 = node1.getNext();
        com.google.javascript.rhino.jstype.JSType jSType9 = node1.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str17 = node13.toString(true, false, false);
        node13.detachChildren();
        com.google.javascript.rhino.Node node19 = node13.cloneNode();
        node13.putIntProp(6, (-1));
        java.lang.String str23 = node1.checkTreeEquals(node13);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 32" + "'", str17.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER 3.0 32\n\n\nTree2:\nSTRING hi! 32 [temp: -1]\n\n\nSubtree1: NUMBER 3.0 32\n\n\nSubtree2: STRING hi! 32 [temp: -1]\n" + "'", str23.equals("Node tree inequality:\nTree1:\nNUMBER 3.0 32\n\n\nTree2:\nSTRING hi! 32 [temp: -1]\n\n\nSubtree1: NUMBER 3.0 32\n\n\nSubtree2: STRING hi! 32 [temp: -1]\n"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        com.google.javascript.rhino.jstype.JSType jSType21 = functionType7.restrictByNotNullOrUndefined();
        com.google.javascript.rhino.jstype.JSType jSType23 = functionType7.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean24 = jSType23.matchesInt32Context();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.ObjectType objectType9 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType7);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        java.lang.String str18 = functionType17.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        boolean boolean28 = functionType27.isAllType();
        boolean boolean30 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, true);
        boolean boolean32 = functionType17.hasOwnProperty("");
        com.google.javascript.rhino.jstype.JSType.TypePair typePair33 = functionType7.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType17);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(typePair33);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        boolean boolean27 = googleCodingConvention0.isConstant("STRING hi! 32");
        boolean boolean29 = googleCodingConvention0.isSuperClassReference("com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        boolean boolean7 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset3);
        jSSourceFile4.clearCachedSource();
        jSSourceFile4.clearCachedSource();
        com.google.javascript.jscomp.Region region8 = jSSourceFile4.getRegion(150);
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] { jSModule9 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.removeUnusedVars = true;
        compilerOptions11.removeUnusedPrototypeProperties = false;
        compilerOptions11.labelRenaming = false;
        boolean boolean18 = compilerOptions11.optimizeArgumentsArray;
        try {
            com.google.javascript.jscomp.Result result19 = compiler1.compile(jSSourceFile4, jSModuleArray10, compilerOptions11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.nameReferenceReportPath = "// Input %num%";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = compilerOptions0.propertyRenaming;
        compilerOptions0.labelRenaming = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType17.matchesObjectContext();
        boolean boolean22 = functionType17.isNominalType();
        boolean boolean24 = functionType17.hasProperty("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        boolean boolean2 = context0.isSealed();
        boolean boolean3 = context0.isGeneratingDebugChanged();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.ideMode = true;
        com.google.javascript.jscomp.CodingConvention codingConvention7 = compilerOptions4.getCodingConvention();
        try {
            context0.unseal((java.lang.Object) compilerOptions4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(codingConvention7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 30);
        org.junit.Assert.assertNotNull(node1);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
//        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
//        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
//        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
//        boolean boolean21 = functionType20.isNoObjectType();
//        boolean boolean23 = jSTypeRegistry2.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
//        java.lang.String str24 = functionType20.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(jSTypeArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(functionType7);
//        org.junit.Assert.assertNotNull(jSType12);
//        org.junit.Assert.assertNotNull(jSTypeArray17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(functionType20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "function (): {607101244}" + "'", str24.equals("function (): {607101244}"));
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry15.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSType25.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType25 };
        com.google.javascript.rhino.Node node28 = jSTypeRegistry7.createOptionalParameters(jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry1.createConstructorType(jSType4, jSTypeArray27);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry1.createOptionalType(jSType30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(functionType29);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        boolean boolean9 = node4.isLocalResultCall();
        boolean boolean11 = node4.getBooleanProp(47);
        com.google.javascript.rhino.Node node12 = node4.getFirstChild();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode17 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode17.addParam("");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode23 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode23.addParam("");
        int int26 = scriptOrFnNode23.getFunctionCount();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        boolean boolean31 = node30.isVarArgs();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(10, (com.google.javascript.rhino.Node) scriptOrFnNode17, (com.google.javascript.rhino.Node) scriptOrFnNode23, node30, node35);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode40 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode40.addParam("");
        int int43 = scriptOrFnNode40.getFunctionCount();
        scriptOrFnNode40.putBooleanProp(23, false);
        try {
            com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(0, node12, node36, (com.google.javascript.rhino.Node) scriptOrFnNode40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node11 = node5.copyInformationFrom(node10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node14 = node5.clonePropsFrom(node13);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder15 = node5.getJsDocBuilderForNode();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = null;
        boolean boolean19 = diagnosticGroup17.matches(diagnosticType18);
        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel21, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.make("TypeError: STRING hi! 32", checkLevel21, "or");
        java.lang.String str27 = diagnosticType26.key;
        java.lang.String[] strArray28 = null;
        com.google.javascript.jscomp.JSError jSError29 = nodeTraversal3.makeError(node5, diagnosticType26, strArray28);
        com.google.javascript.rhino.Node node30 = nodeTraversal3.getCurrentNode();
        com.google.javascript.rhino.Node node31 = nodeTraversal3.getEnclosingFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder15);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TypeError: STRING hi! 32" + "'", str27.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNull(node31);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        boolean boolean5 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        com.google.javascript.rhino.jstype.FunctionType functionType15 = functionPrototypeType9.getOwnerFunction();
        boolean boolean16 = functionPrototypeType9.isObject();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions0.getDefineReplacements();
        compilerOptions0.collapseAnonymousFunctions = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strMap9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("TypeError: STRING hi! 32");
        java.lang.String str2 = evaluatorException1.details();
        java.io.FilenameFilter filenameFilter3 = null;
        java.lang.String str4 = evaluatorException1.getScriptStackTrace(filenameFilter3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: STRING hi! 32" + "'", str2.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        com.google.javascript.rhino.Node node9 = node3.cloneNode();
        node3.putIntProp(6, (-1));
        com.google.javascript.jscomp.SourceFile.Generator generator15 = null;
        com.google.javascript.jscomp.SourceFile sourceFile16 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator15);
        com.google.javascript.jscomp.JsAst jsAst17 = new com.google.javascript.jscomp.JsAst(sourceFile16);
        node3.putProp((int) (short) 10, (java.lang.Object) sourceFile16);
        node3.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(sourceFile16);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str11 = node7.toString(true, false, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        node15.detachChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newExpr(node22);
        node23.putIntProp(0, (-1));
        node7.addChildAfter(node15, node23);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry1.createConstructorType("", node3, node15, (com.google.javascript.rhino.jstype.JSType) functionType48);
        int int66 = node15.getIntProp(0);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.computeFunctionSideEffects;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.aliasableStrings;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.removeUnusedVars = true;
        java.lang.String str7 = compilerOptions4.aliasableGlobals;
        boolean boolean8 = compilerOptions4.allowLegacyJsMessages;
        boolean boolean9 = compilerOptions4.inlineConstantVars;
        compilerOptions4.reserveRawExports = false;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions4.checkGlobalThisLevel;
        compilerOptions0.checkGlobalNamesLevel = checkLevel12;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node7 = node1.copyInformationFrom(node6);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node16 = node10.copyInformationFrom(node15);
        node10.addSuppression("STRING hi! 32");
        boolean boolean19 = defaultCodingConvention8.isPropertyTestFunction(node10);
        node10.setType((int) '#');
        boolean boolean22 = node6.isEquivalentTo(node10);
        node10.setLineno(47);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        int int11 = loggerErrorManager7.getErrorCount();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        boolean boolean5 = compilerOptions0.foldConstants;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.rewriteFunctionExpressions = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.MessageBundle messageBundle12 = compilerOptions0.messageBundle;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention13 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        defaultCodingConvention13.applySubclassRelationship(functionType14, functionType15, subclassType16);
        boolean boolean19 = defaultCodingConvention13.isConstant("");
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str21 = compiler20.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback22 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal23 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler20, callback22);
        int int24 = nodeTraversal23.getLineNumber();
        com.google.javascript.rhino.Node node25 = null;
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast26 = defaultCodingConvention13.getObjectLiteralCast(nodeTraversal23, node25);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention13);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
        org.junit.Assert.assertNull(cssRenamingMap11);
        org.junit.Assert.assertNull(messageBundle12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(objectLiteralCast26);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.skipAllCompilerPasses();
        boolean boolean8 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "or", false);
        try {
            java.lang.String str11 = compilerInput9.getLine(45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.io.FilenameFilter filenameFilter2 = null;
        java.lang.String str3 = ecmaError1.getScriptStackTrace(filenameFilter2);
        int int4 = ecmaError1.getLineNumber();
        ecmaError1.initLineSource("hi!");
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean9 = functionType7.hasProperty("(// Input %num%)");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        java.lang.String str18 = functionType17.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType19 = functionType17.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo21 = null;
        functionPrototypeType19.setPropertyJSDocInfo("", jSDocInfo21, false);
        java.util.Set<java.lang.String> strSet24 = functionPrototypeType19.getPropertyNames();
        com.google.javascript.rhino.jstype.JSType jSType25 = functionPrototypeType19.unboxesTo();
        com.google.javascript.rhino.jstype.JSType jSType26 = functionType7.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionPrototypeType19);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(functionPrototypeType19);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(jSType26);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.strictMessageReplacement = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        boolean boolean5 = compilerOptions0.foldConstants;
        compilerOptions0.recordFunctionInformation = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup9;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup9;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.ideMode = true;
        boolean boolean16 = compilerOptions13.checkCaja;
        boolean boolean17 = compilerOptions13.removeUnusedPrototypeProperties;
        boolean boolean18 = compilerOptions13.flowSensitiveInlineVariables;
        compilerOptions13.nameReferenceReportPath = "// Input %num%";
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str22 = compilerOptions21.renamePrefix;
        boolean boolean23 = compilerOptions21.generatePseudoNames;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions21.checkGlobalNamesLevel = checkLevel24;
        compilerOptions13.checkMissingGetCssNameLevel = checkLevel24;
        compilerOptions0.setWarningLevel(diagnosticGroup9, checkLevel24);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.setChainCalls(true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("goog.exportProperty", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.generateExports = false;
        java.util.Set<java.lang.String> strSet9 = compilerOptions0.stripTypes;
        boolean boolean10 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setInstructionObserverThreshold(30);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags4 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags4.setMutatesGlobalState();
        try {
            context0.unseal((java.lang.Object) sideEffectFlags4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 12);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, true);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        loggerErrorManager5.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager5.getWarnings();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        java.lang.String str12 = compilerOptions0.inputDelimiter;
        compilerOptions0.syntheticBlockStartMarker = "STRING hi! 32";
        boolean boolean15 = compilerOptions0.smartNameRemoval;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap16 = compilerOptions0.customPasses;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "// Input %num%" + "'", str12.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap16);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        java.lang.String str12 = compilerOptions0.inputDelimiter;
        compilerOptions0.syntheticBlockStartMarker = "STRING hi! 32";
        boolean boolean15 = compilerOptions0.smartNameRemoval;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "// Input %num%" + "'", str12.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.Object obj0 = null;
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString(obj0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null" + "'", str1.equals("null"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList9 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList9, jSTypeArray8);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createFunctionTypeWithVarArgs(jSType7, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList9);
        java.lang.String str12 = functionType11.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType13 = functionType11.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        functionPrototypeType13.setPropertyJSDocInfo("", jSDocInfo15, false);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = functionPrototypeType13.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        java.lang.String str27 = functionType26.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType28 = functionType26.getPrototype();
        boolean boolean29 = functionPrototypeType28.hasCachedValues();
        boolean boolean30 = functionPrototypeType28.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry34.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        boolean boolean46 = functionPrototypeType28.defineDeclaredProperty("STRING hi! 32", jSType44, false);
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry1.createFunctionTypeWithNewReturnType(functionType18, (com.google.javascript.rhino.jstype.JSType) functionPrototypeType28);
        jSTypeRegistry1.forwardDeclareType("function (): ?");
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(functionPrototypeType13);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(functionPrototypeType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(functionType47);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType7.getImplementedInterfaces();
        boolean boolean12 = functionType7.isRegexpType();
        boolean boolean13 = functionType7.isConstructor();
        com.google.javascript.rhino.jstype.JSType jSType15 = functionType7.findPropertyType("TypeError: STRING hi! 32");
        com.google.javascript.rhino.jstype.FunctionType functionType16 = functionType7.getConstructor();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType19 = functionType16.resolve(errorReporter17, jSTypeStaticScope18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNull(functionType16);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList9 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList9, jSTypeArray8);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createFunctionTypeWithVarArgs(jSType7, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList9);
        java.lang.String str12 = functionType11.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType13 = functionType11.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        functionPrototypeType13.setPropertyJSDocInfo("", jSDocInfo15, false);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = functionPrototypeType13.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        java.lang.String str27 = functionType26.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType28 = functionType26.getPrototype();
        boolean boolean29 = functionPrototypeType28.hasCachedValues();
        boolean boolean30 = functionPrototypeType28.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry34.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        boolean boolean46 = functionPrototypeType28.defineDeclaredProperty("STRING hi! 32", jSType44, false);
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry1.createFunctionTypeWithNewReturnType(functionType18, (com.google.javascript.rhino.jstype.JSType) functionPrototypeType28);
        boolean boolean48 = jSTypeRegistry1.shouldTolerateUndefinedValues();
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(functionPrototypeType13);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(functionPrototypeType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        boolean boolean8 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.removeUnusedVars = true;
        java.lang.String str12 = compilerOptions9.aliasableGlobals;
        boolean boolean13 = compilerOptions9.printInputDelimiter;
        boolean boolean14 = compilerOptions9.foldConstants;
        compilerOptions9.recordFunctionInformation = false;
        compilerOptions9.gatherCssNames = false;
        java.lang.String str19 = compilerOptions9.reportPath;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions9.checkMissingGetCssNameLevel;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel20;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean5 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean6 = compilerOptions0.checkCaja;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.collapseAnonymousFunctions = true;
        compilerOptions0.computeFunctionSideEffects = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        boolean boolean12 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkFunctions;
        compilerOptions0.crossModuleCodeMotion = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry2.getNativeType(jSTypeNative38);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        boolean boolean62 = functionType48.isReturnTypeInferred();
        java.lang.String str63 = functionType48.getReferenceName();
        boolean boolean64 = functionType48.isOrdinaryFunction();
        boolean boolean65 = functionType48.isNullable();
        boolean boolean66 = jSTypeRegistry2.declareType("// Input %num%", (com.google.javascript.rhino.jstype.JSType) functionType48);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        boolean boolean2 = context0.isSealed();
        boolean boolean3 = context0.isGeneratingSource();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.collapseProperties = true;
        java.lang.String str11 = compilerOptions0.jsOutputFile;
        com.google.javascript.jscomp.SourceMap.Format format12 = compilerOptions0.sourceMapFormat;
        compilerOptions0.inlineLocalVariables = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(format12);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        boolean boolean5 = compilerOptions0.foldConstants;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.deadAssignmentElimination = false;
        byte[] byteArray15 = new byte[] { (byte) 1, (byte) 10, (byte) -1, (byte) 10, (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray15;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.crossModuleMethodMotion = false;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        boolean boolean27 = googleCodingConvention0.isConstant("STRING hi! 32");
        boolean boolean29 = googleCodingConvention0.isSuperClassReference("BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150\n");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node11 = node5.copyInformationFrom(node10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node14 = node5.clonePropsFrom(node13);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder15 = node5.getJsDocBuilderForNode();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = null;
        boolean boolean19 = diagnosticGroup17.matches(diagnosticType18);
        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel21, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.make("TypeError: STRING hi! 32", checkLevel21, "or");
        java.lang.String str27 = diagnosticType26.key;
        java.lang.String[] strArray28 = null;
        com.google.javascript.jscomp.JSError jSError29 = nodeTraversal3.makeError(node5, diagnosticType26, strArray28);
        java.lang.String str30 = nodeTraversal3.getSourceName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder15);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TypeError: STRING hi! 32" + "'", str27.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        boolean boolean4 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        boolean boolean14 = functionType12.isCheckedUnknownType();
        boolean boolean15 = functionType12.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        googleCodingConvention0.applySubclassRelationship(functionType12, functionType23, subclassType25);
        boolean boolean27 = functionType23.isReturnTypeInferred();
        java.lang.String str28 = functionType23.getNormalizedReferenceName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray5 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError6 = com.google.javascript.jscomp.JSError.make("null.prototype", (-3), 0, checkLevel3, diagnosticType4, strArray5);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(jSError6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int7 = scriptOrFnNode3.getParamOrVarIndex("(// Input %num%)");
        try {
            scriptOrFnNode3.setDouble((double) 36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.Class<?> wildcardClass2 = ecmaError1.getClass();
        java.lang.String str3 = ecmaError1.details();
        java.lang.String str4 = ecmaError1.details();
        int int5 = ecmaError1.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: STRING hi! 32" + "'", str3.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TypeError: STRING hi! 32" + "'", str4.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry15.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSType25.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType25 };
        com.google.javascript.rhino.Node node28 = jSTypeRegistry7.createOptionalParameters(jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry1.createConstructorType(jSType4, jSTypeArray27);
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry1.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.JSType jSType31 = objectType30.restrictByNotNullOrUndefined();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(jSType31);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node10 = node4.copyInformationFrom(node9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node13 = node4.clonePropsFrom(node12);
        try {
            boolean boolean14 = googleCodingConvention0.isPropertyTestFunction(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        com.google.javascript.rhino.Node node9 = node3.cloneNode();
        node3.putIntProp(6, (-1));
        com.google.javascript.jscomp.SourceFile.Generator generator15 = null;
        com.google.javascript.jscomp.SourceFile sourceFile16 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator15);
        com.google.javascript.jscomp.JsAst jsAst17 = new com.google.javascript.jscomp.JsAst(sourceFile16);
        node3.putProp((int) (short) 10, (java.lang.Object) sourceFile16);
        try {
            java.lang.String str20 = sourceFile16.getLine((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(sourceFile16);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType7.getImplementedInterfaces();
        boolean boolean12 = functionType7.isRegexpType();
        boolean boolean13 = functionType7.isConstructor();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType14 = functionType7.getPrototype();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList20 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList20, jSTypeArray19);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createFunctionTypeWithVarArgs(jSType18, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList20);
        java.lang.String str23 = functionType22.getNormalizedReferenceName();
        boolean boolean24 = functionType22.isCheckedUnknownType();
        boolean boolean25 = functionType22.isNumberObjectType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable26 = functionType22.getImplementedInterfaces();
        boolean boolean27 = functionType22.isRegexpType();
        boolean boolean28 = functionType22.isConstructor();
        com.google.javascript.rhino.jstype.JSType jSType30 = functionType22.findPropertyType("TypeError: STRING hi! 32");
        com.google.javascript.rhino.jstype.JSType jSType31 = functionType7.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType22);
        boolean boolean32 = functionType7.isInterface();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(functionPrototypeType14);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node8 = node2.copyInformationFrom(node7);
        node2.addSuppression("STRING hi! 32");
        boolean boolean11 = defaultCodingConvention0.isPropertyTestFunction(node2);
        node2.setType((int) '#');
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.removeUnusedVars = true;
        java.lang.String str18 = compilerOptions15.aliasableGlobals;
        boolean boolean19 = compilerOptions15.ideMode;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions15.checkProvides;
        node2.putProp(22, (java.lang.Object) compilerOptions15);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        compilerOptions0.ideMode = true;
        boolean boolean14 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = null;
        boolean boolean6 = diagnosticGroup4.matches(diagnosticType5);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel8, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup4, checkLevel8);
        compilerOptions0.checkGlobalThisLevel = checkLevel8;
        compilerOptions0.optimizeArgumentsArray = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.ideMode = true;
        boolean boolean7 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setDefineToNumberLiteral("", 20);
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        boolean boolean7 = compilerInput6.isExtern();
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput6.getModule();
        try {
            java.lang.String str9 = compilerInput6.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(jSModule8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        boolean boolean22 = functionType20.isCheckedUnknownType();
        boolean boolean23 = functionType20.isStringObjectType();
        boolean boolean24 = functionType20.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        boolean boolean33 = functionType32.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.ObjectType) functionType20, (com.google.javascript.rhino.jstype.JSType) functionType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        boolean boolean43 = functionType20.isInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.ideMode = true;
        boolean boolean7 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler0.tracker;
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            compiler0.report(jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.removeUnusedVars = true;
        java.lang.String str11 = compilerOptions8.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel13, "hi!");
        compilerOptions8.checkRequires = checkLevel13;
        boolean boolean17 = compilerOptions8.removeDeadCode;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions8.checkGlobalNamesLevel;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy19 = compilerOptions8.anonymousFunctionNaming;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy19;
        com.google.javascript.jscomp.ErrorFormat errorFormat21 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        compilerOptions0.errorFormat = errorFormat21;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy19 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy19.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(errorFormat21);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean9 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str10 = compilerOptions0.aliasStringsBlacklist;
        java.lang.String str11 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        boolean boolean3 = diagnosticGroup0.matches(diagnosticType2);
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING hi! 32");
        java.lang.String str6 = scriptOrFnNode3.getSourceName();
        com.google.javascript.rhino.Node node7 = scriptOrFnNode3.removeFirstChild();
        scriptOrFnNode3.setEndLineno(45);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.labelRenaming;
        compilerOptions0.unaliasableGlobals = "Not declared as a constructor";
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.lineBreak = true;
        com.google.javascript.jscomp.MessageBundle messageBundle13 = null;
        compilerOptions0.messageBundle = messageBundle13;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        int int4 = nodeTraversal3.getLineNumber();
        com.google.javascript.rhino.Node node5 = nodeTraversal3.getEnclosingFunction();
        com.google.javascript.rhino.Node node6 = nodeTraversal3.getCurrentNode();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput7 = nodeTraversal3.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder2 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder2.withTemplateName("");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType14 = functionType12.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = null;
        functionPrototypeType14.setPropertyJSDocInfo("", jSDocInfo16, false);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = functionPrototypeType14.getOwnerFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType20 = functionPrototypeType14.getConstructor();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder21 = functionBuilder2.withTypeOfThis((com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType14);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = functionBuilder2.build();
        boolean boolean23 = functionType22.isUnknownType();
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(functionPrototypeType14);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(functionType20);
        org.junit.Assert.assertNotNull(functionBuilder21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "", true);
        boolean boolean7 = compilerInput6.isExtern();
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput6.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst9 = compilerInput6.getSourceAst();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst9);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(sourceAst9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy9, propertyRenamingPolicy10);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.removeUnusedVars = true;
        boolean boolean16 = compilerOptions13.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions13.checkMissingReturn;
        compilerOptions0.checkShadowVars = checkLevel17;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.disambiguateProperties = false;
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.renamePrefix;
        compilerOptions0.inlineGetters = true;
        boolean boolean4 = compilerOptions0.foldConstants;
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.setEndLineno(20);
        com.google.javascript.rhino.Node node6 = scriptOrFnNode3.getLastChild();
        try {
            com.google.javascript.rhino.Node node7 = node6.removeFirstChild();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.jstype.JSType jSType11 = functionType7.getPropertyType("");
        boolean boolean12 = functionType7.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        boolean boolean34 = functionType7.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType30);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = functionType7.getConstructor();
        try {
            boolean boolean37 = functionType35.isPropertyTypeInferred("BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(functionType35);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.jstype.JSType jSType11 = functionType7.getPropertyType("");
        boolean boolean12 = functionType7.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        boolean boolean34 = functionType7.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType30);
        boolean boolean35 = functionType7.isRecordType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        boolean boolean10 = functionPrototypeType9.matchesNumberContext();
        com.google.javascript.rhino.jstype.JSType jSType11 = functionPrototypeType9.unboxesTo();
        boolean boolean12 = functionPrototypeType9.isFunctionPrototypeType();
        java.util.Set<java.lang.String> strSet13 = functionPrototypeType9.getOwnPropertyNames();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strSet13);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        java.lang.String str12 = compilerOptions0.inputDelimiter;
        compilerOptions0.syntheticBlockStartMarker = "STRING hi! 32";
        compilerOptions0.locale = "()";
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "// Input %num%" + "'", str12.equals("// Input %num%"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("bitnot", "STRING hi! 32");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.removeUnusedVars = true;
        java.lang.String str11 = compilerOptions8.unaliasableGlobals;
        java.lang.String str12 = compilerOptions8.sourceMapOutputPath;
        compilerOptions8.instrumentationTemplate = "";
        compilerOptions8.optimizeArgumentsArray = true;
        try {
            com.google.javascript.jscomp.Result result17 = compiler0.compile(jSSourceFile6, jSSourceFile7, compilerOptions8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean9 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str10 = compilerOptions0.aliasStringsBlacklist;
        java.lang.String str11 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.ignoreCajaProperties = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
        boolean boolean5 = diagnosticGroup3.matches(diagnosticType4);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str9 = diagnosticType8.key;
        boolean boolean10 = diagnosticGroup3.matches(diagnosticType8);
        java.lang.String[] strArray15 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray15);
        java.lang.String str17 = jSError16.description;
        compiler0.report(jSError16);
        try {
            int int19 = compiler0.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "STRING hi! 32" + "'", str9.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 32" + "'", str17.equals("STRING hi! 32"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = jSType12.unboxesTo();
        boolean boolean14 = jSType12.isNullable();
        boolean boolean15 = jSType12.isEnumElementType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("goog.exportProperty", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        context1.addActivationName("Not declared as a constructor");
        context1.setInstructionObserverThreshold(15);
        boolean boolean6 = context1.hasCompileFunctionsWithDynamicScope();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter8 = context1.setErrorReporter(errorReporter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getGlobalObject();
        java.lang.String str2 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str3 = googleCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        boolean boolean3 = compilerOptions0.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingReturn;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy5;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.inlineLocalFunctions = false;
        boolean boolean10 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        boolean boolean4 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        boolean boolean14 = functionType12.isCheckedUnknownType();
        boolean boolean15 = functionType12.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        googleCodingConvention0.applySubclassRelationship(functionType12, functionType23, subclassType25);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str35 = node31.toString(true, false, false);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str43 = node39.toString(true, false, false);
        node39.detachChildren();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newExpr(node46);
        node47.putIntProp(0, (-1));
        node31.addChildAfter(node39, node47);
        java.util.List<java.lang.String> strList52 = googleCodingConvention27.identifyTypeDeclarationCall(node47);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str60 = node56.toString(true, false, false);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str68 = node64.toString(true, false, false);
        node64.detachChildren();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node72 = com.google.javascript.jscomp.NodeUtil.newExpr(node71);
        node72.putIntProp(0, (-1));
        node56.addChildAfter(node64, node72);
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78, false);
        com.google.javascript.rhino.jstype.JSType jSType81 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray82 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList83 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean84 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList83, jSTypeArray82);
        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry80.createFunctionTypeWithVarArgs(jSType81, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList83);
        java.lang.String str86 = functionType85.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType87 = functionType85.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo89 = null;
        functionPrototypeType87.setPropertyJSDocInfo("", jSDocInfo89, false);
        java.util.Set<java.lang.String> strSet92 = functionPrototypeType87.getPropertyNames();
        node56.putProp((int) (byte) -1, (java.lang.Object) strSet92);
        java.lang.String str94 = googleCodingConvention0.extractClassNameIfRequire(node47, node56);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection95 = googleCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "STRING hi! 32" + "'", str35.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "STRING hi! 32" + "'", str43.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(strList52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "STRING hi! 32" + "'", str60.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "STRING hi! 32" + "'", str68.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(jSTypeArray82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(functionType85);
        org.junit.Assert.assertNull(str86);
        org.junit.Assert.assertNotNull(functionPrototypeType87);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection95);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        functionPrototypeType9.setPropertyJSDocInfo("", jSDocInfo11, false);
        java.util.Set<java.lang.String> strSet14 = functionPrototypeType9.getPropertyNames();
        boolean boolean15 = functionPrototypeType9.isEmptyType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        node3.detachChildren();
        com.google.javascript.rhino.Node node9 = node3.cloneNode();
        boolean boolean10 = node3.isUnscopedQualifiedName();
        java.lang.Object obj12 = node3.getProp((int) (byte) -1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("", "Not declared as a constructor", "hi!");
        java.lang.String str4 = sourceFile3.getName();
        java.lang.String str5 = sourceFile3.getName();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        try {
//            com.google.javascript.rhino.Context.reportError("(Not declared as a constructor)");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: (Not declared as a constructor)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            compiler0.init(jSSourceFileArray5, jSModuleArray6, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(jSModuleArray6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        node3.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        boolean boolean10 = functionPrototypeType9.hasCachedValues();
        boolean boolean11 = functionPrototypeType9.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry15.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        boolean boolean27 = functionPrototypeType9.defineDeclaredProperty("STRING hi! 32", jSType25, false);
        boolean boolean28 = functionPrototypeType9.matchesObjectContext();
        com.google.javascript.rhino.jstype.JSType jSType30 = functionPrototypeType9.getPropertyType("(// Input %num%)");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSType30);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        com.google.javascript.rhino.Node node6 = node4.cloneNode();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode9 = null;
        jSTypeRegistry8.setResolveMode(resolveMode9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType32 = jSTypeRegistry22.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType32.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType32 };
        com.google.javascript.rhino.Node node35 = jSTypeRegistry14.createOptionalParameters(jSTypeArray34);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry8.createConstructorType(jSType11, jSTypeArray34);
        com.google.javascript.rhino.Node node37 = functionType36.getParametersNode();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newExpr(node39);
        node40.putIntProp(0, (-1));
        node4.addChildAfter(node37, node40);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        boolean boolean22 = functionType20.isCheckedUnknownType();
        boolean boolean23 = functionType20.isStringObjectType();
        boolean boolean24 = functionType20.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        boolean boolean33 = functionType32.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.ObjectType) functionType20, (com.google.javascript.rhino.jstype.JSType) functionType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList43 = functionType32.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = functionType32.forceResolve(errorReporter44, jSTypeStaticScope45);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(functionTypeList43);
        org.junit.Assert.assertNotNull(jSType46);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        boolean boolean8 = compilerOptions0.removeDeadCode;
        boolean boolean9 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.syntheticBlockStartMarker = "Named type with empty name component";
        byte[] byteArray12 = compilerOptions0.inputPropertyMapSerialized;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(byteArray12);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 16, (int) (short) 10);
        java.util.Set<java.lang.String> strSet4 = node3.getDirectives();
        boolean boolean5 = node3.isQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel5, "hi!");
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.setDefineToDoubleLiteral("language version", (double) ' ');
        compilerOptions0.ideMode = true;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel15 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(detailLevel14);
        org.junit.Assert.assertNotNull(detailLevel15);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int6 = scriptOrFnNode3.getFunctionCount();
        scriptOrFnNode3.putBooleanProp(23, false);
        scriptOrFnNode3.setEncodedSourceBounds(17, 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        boolean boolean4 = diagnosticGroup2.matches(diagnosticType3);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str8 = diagnosticType7.key;
        boolean boolean9 = diagnosticGroup2.matches(diagnosticType7);
        boolean boolean10 = diagnosticGroup0.matches(diagnosticType7);
        java.lang.String str11 = diagnosticType7.key;
        java.lang.String str12 = diagnosticType7.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "STRING hi! 32: STRING hi! 32" + "'", str12.equals("STRING hi! 32: STRING hi! 32"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        com.google.javascript.rhino.jstype.JSType jSType11 = functionType7.getPropertyType("");
        boolean boolean12 = functionType7.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        boolean boolean34 = functionType7.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType30);
        boolean boolean35 = functionType30.isInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType7.isReturnTypeInferred();
        boolean boolean22 = functionType7.isNumber();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable23 = functionType7.getCtorImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable23);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList6 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6, jSModuleArray5);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph8 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList6);
        try {
            com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 140);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.aliasableGlobals = "Named type with empty name component";
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        java.lang.String str26 = googleCodingConvention0.getExportSymbolFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection27 = googleCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        boolean boolean33 = scriptOrFnNode31.hasParamOrVar("STRING hi! 32");
        boolean boolean35 = scriptOrFnNode31.hasParamOrVar("STRING hi! 32");
        boolean boolean36 = scriptOrFnNode31.wasEmptyNode();
        try {
            boolean boolean37 = googleCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "goog.exportSymbol" + "'", str26.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.labelRenaming;
        compilerOptions0.unaliasableGlobals = "Not declared as a constructor";
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int6 = scriptOrFnNode3.getFunctionCount();
        int int7 = scriptOrFnNode3.getRegexpCount();
        int int9 = scriptOrFnNode3.getIntProp(12);
        java.lang.String str10 = scriptOrFnNode3.toStringTree();
        scriptOrFnNode3.setSourceName("null.prototype");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150\n" + "'", str10.equals("BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150\n"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.ErrorFormat errorFormat2 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider3 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat2.toFormatter(sourceExcerptProvider3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = loggerErrorManager7.getWarnings();
        int int9 = loggerErrorManager7.getErrorCount();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler0.getErrors();
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING hi! 32", charset13);
        jSSourceFile14.clearCachedSource();
        com.google.javascript.rhino.Node node16 = compiler0.parse(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(errorFormat2);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNotNull(jSErrorArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(node16);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isStringObjectType();
        boolean boolean11 = functionType7.isNumber();
        java.lang.String str12 = functionType7.getTemplateTypeName();
        boolean boolean13 = functionType7.isString();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType22 = functionType20.getPrototype();
        boolean boolean23 = functionType10.setPrototype(functionPrototypeType22);
        com.google.javascript.rhino.jstype.JSType jSType24 = functionPrototypeType22.unboxesTo();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(functionPrototypeType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(jSType24);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.Class<?> wildcardClass2 = ecmaError1.getClass();
        java.lang.String str3 = ecmaError1.details();
        int int4 = ecmaError1.columnNumber();
        ecmaError1.initLineNumber(42);
        java.lang.String str7 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: STRING hi! 32" + "'", str3.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TypeError: STRING hi! 32" + "'", str7.equals("TypeError: STRING hi! 32"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.matchesObjectContext();
        boolean boolean10 = functionType7.isFunctionPrototypeType();
        boolean boolean11 = functionType7.isString();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSType12.dereference();
        boolean boolean14 = objectType13.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType15 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType13);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry18.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSType28.dereference();
        boolean boolean30 = objectType29.isArrayType();
        boolean boolean31 = objectType13.differsFrom((com.google.javascript.rhino.jstype.JSType) objectType29);
        boolean boolean32 = objectType13.isObject();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder2 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder2.withTemplateName("");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType14 = functionType12.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = null;
        functionPrototypeType14.setPropertyJSDocInfo("", jSDocInfo16, false);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = functionPrototypeType14.getOwnerFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType20 = functionPrototypeType14.getConstructor();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder21 = functionBuilder2.withTypeOfThis((com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType14);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        java.lang.String str30 = functionType29.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType31 = functionType29.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo33 = null;
        functionPrototypeType31.setPropertyJSDocInfo("", jSDocInfo33, false);
        java.util.Set<java.lang.String> strSet36 = functionPrototypeType31.getPropertyNames();
        boolean boolean37 = functionPrototypeType31.isStringValueType();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder38 = functionBuilder2.withInferredReturnType((com.google.javascript.rhino.jstype.JSType) functionPrototypeType31);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder39 = null;
        try {
            com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder40 = functionBuilder38.withParams(functionParamBuilder39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(functionPrototypeType14);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(functionType20);
        org.junit.Assert.assertNotNull(functionBuilder21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(functionPrototypeType31);
        org.junit.Assert.assertNotNull(strSet36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(functionBuilder38);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        com.google.javascript.rhino.jstype.JSType jSType22 = functionType17.findPropertyType("com.google.javascript.rhino.EcmaError: TypeError: STRING hi! 32");
        com.google.javascript.rhino.jstype.JSType jSType23 = functionType17.getReturnType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(jSType23);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        java.lang.Class<?> wildcardClass2 = ecmaError1.getClass();
        java.lang.String str3 = ecmaError1.details();
        java.lang.String str4 = ecmaError1.details();
        int int5 = ecmaError1.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: STRING hi! 32" + "'", str3.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TypeError: STRING hi! 32" + "'", str4.equals("TypeError: STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        boolean boolean11 = compilerOptions0.removeUnusedVarsInGlobalScope;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray12 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList13 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13, warningsGuardArray12);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray16 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList17 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList17, warningsGuardArray16);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard19 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList17);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard15, composeWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean23 = composeWarningsGuard21.enables(diagnosticGroup22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = null;
        boolean boolean26 = diagnosticGroup24.matches(diagnosticType25);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str30 = diagnosticType29.key;
        boolean boolean31 = diagnosticGroup24.matches(diagnosticType29);
        java.lang.String[] strArray36 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType29, strArray36);
        java.lang.String str38 = jSError37.description;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = composeWarningsGuard21.level(jSError37);
        com.google.javascript.jscomp.CheckLevel checkLevel40 = jSError37.level;
        compilerOptions0.reportMissingOverride = checkLevel40;
        boolean boolean42 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(warningsGuardArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "STRING hi! 32" + "'", str30.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "STRING hi! 32" + "'", str38.equals("STRING hi! 32"));
        org.junit.Assert.assertNull(checkLevel39);
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isAllType();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection12 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        boolean boolean22 = functionType20.isCheckedUnknownType();
        boolean boolean23 = functionType20.isStringObjectType();
        boolean boolean24 = functionType20.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        boolean boolean33 = functionType32.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.ObjectType) functionType20, (com.google.javascript.rhino.jstype.JSType) functionType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        boolean boolean43 = functionType32.isNumberObjectType();
        com.google.javascript.rhino.jstype.JSType jSType44 = functionType32.autoboxesTo();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionTypeCollection12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(jSType44);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        compiler1.reportCodeChange();
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = scriptOrFnNode3.getJsDocBuilderForNode();
        fileLevelJsDocBuilder4.append("goog.global");
        fileLevelJsDocBuilder4.append("");
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.lang.String str1 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.rhino.Node node5 = compiler0.getRoot();
        try {
            com.google.javascript.jscomp.Result result6 = compiler0.getResult();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(31, 3, 30);
        int int4 = scriptOrFnNode3.getParamAndVarCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        java.lang.String str2 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isAllType();
        int int9 = functionType7.getPropertiesCount();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        java.lang.String str19 = functionType18.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        boolean boolean29 = functionType28.isAllType();
        boolean boolean31 = functionType18.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType28, true);
        boolean boolean32 = functionType28.matchesObjectContext();
        boolean boolean34 = functionType7.defineDeclaredProperty("STRING hi! 32. STRING hi! 32 at (unknown source) line (unknown line) : (unknown column)", (com.google.javascript.rhino.jstype.JSType) functionType28, true);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = null;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel4, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup8;
        boolean boolean10 = diagnosticGroupWarningsGuard7.disables(diagnosticGroup8);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup8;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        compilerOptions0.errorFormat = errorFormat5;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(errorFormat5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        com.google.javascript.jscomp.CodingConvention codingConvention4 = null;
        compilerOptions0.setCodingConvention(codingConvention4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.removeUnusedVars = true;
        java.lang.String str9 = compilerOptions6.aliasableGlobals;
        boolean boolean10 = compilerOptions6.checkCaja;
        compilerOptions6.aliasExternals = false;
        java.lang.String str13 = compilerOptions6.checkMissingGetCssNameBlacklist;
        compilerOptions6.inlineConstantVars = false;
        java.lang.String str16 = compilerOptions6.inputDelimiter;
        boolean boolean17 = compilerOptions6.removeUnusedVarsInGlobalScope;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray18 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList19 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList19, warningsGuardArray18);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList19);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray26 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard21, composeWarningsGuard25 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean29 = composeWarningsGuard27.enables(diagnosticGroup28);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup30 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = null;
        boolean boolean32 = diagnosticGroup30.matches(diagnosticType31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 32", "STRING hi! 32");
        java.lang.String str36 = diagnosticType35.key;
        boolean boolean37 = diagnosticGroup30.matches(diagnosticType35);
        java.lang.String[] strArray42 = new java.lang.String[] { "TypeError: STRING hi! 32", "eof", "language version", "hi!" };
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType35, strArray42);
        java.lang.String str44 = jSError43.description;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = composeWarningsGuard27.level(jSError43);
        com.google.javascript.jscomp.CheckLevel checkLevel46 = jSError43.level;
        compilerOptions6.reportMissingOverride = checkLevel46;
        compilerOptions0.aggressiveVarCheck = checkLevel46;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "// Input %num%" + "'", str16.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(warningsGuardArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray26);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "STRING hi! 32" + "'", str36.equals("STRING hi! 32"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "STRING hi! 32" + "'", str44.equals("STRING hi! 32"));
        org.junit.Assert.assertNull(checkLevel45);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        boolean boolean3 = compilerOptions0.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingReturn;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy5;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        boolean boolean8 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.groupVariableDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        boolean boolean5 = scriptOrFnNode3.hasParamOrVar("STRING hi! 32");
        boolean boolean7 = scriptOrFnNode3.hasParamOrVar("STRING hi! 32");
        boolean boolean8 = scriptOrFnNode3.isNoSideEffectsCall();
        boolean boolean9 = scriptOrFnNode3.isQualifiedName();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isCheckedUnknownType();
        boolean boolean10 = functionType7.isReturnTypeInferred();
        boolean boolean12 = functionType7.hasProperty("Not declared as a constructor");
        boolean boolean13 = functionType7.isUnionType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        boolean boolean9 = functionType7.isNativeObjectType();
        com.google.javascript.rhino.jstype.ObjectType objectType10 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType7);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        java.lang.String str19 = functionType18.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType20 = functionType18.getPrototype();
        boolean boolean21 = functionPrototypeType20.matchesNumberContext();
        com.google.javascript.rhino.jstype.FunctionType functionType22 = functionPrototypeType20.getOwnerFunction();
        boolean boolean23 = functionType7.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType22);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(functionPrototypeType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.setTemplateTypeName("language version");
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry1.getType("eof");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry1.createUnionType(jSTypeNativeArray9);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setSummaryDetailLevel((-3));
        compilerOptions0.checkTypes = true;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        boolean boolean5 = compilerOptions0.inlineLocalFunctions;
        boolean boolean6 = compilerOptions0.groupVariableDeclarations;
        java.lang.String str7 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        boolean boolean4 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        boolean boolean14 = functionType12.isCheckedUnknownType();
        boolean boolean15 = functionType12.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        googleCodingConvention0.applySubclassRelationship(functionType12, functionType23, subclassType25);
        boolean boolean27 = functionType23.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        boolean boolean64 = functionType48.isFunctionType();
        boolean boolean65 = functionType23.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType48);
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType66 = functionType23.getInstanceType();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.labelRenaming;
        compilerOptions0.unaliasableGlobals = "Not declared as a constructor";
        boolean boolean10 = compilerOptions0.rewriteFunctionExpressions;
        boolean boolean11 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        boolean boolean4 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        boolean boolean14 = functionType12.isCheckedUnknownType();
        boolean boolean15 = functionType12.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        googleCodingConvention0.applySubclassRelationship(functionType12, functionType23, subclassType25);
        boolean boolean28 = googleCodingConvention0.isConstantKey("function (): ?");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str36 = node32.toString(true, false, false);
        node32.detachChildren();
        com.google.javascript.rhino.Node node38 = node32.cloneNode();
        int int39 = node32.getSideEffectFlags();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder44 = scriptOrFnNode43.getJsDocBuilderForNode();
        node32.addChildrenToBack((com.google.javascript.rhino.Node) scriptOrFnNode43);
        boolean boolean46 = scriptOrFnNode43.isUnscopedQualifiedName();
        boolean boolean47 = scriptOrFnNode43.isQualifiedName();
        try {
            boolean boolean48 = googleCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "STRING hi! 32" + "'", str36.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str7 = node3.toString(true, false, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newExpr(node9);
        node10.putIntProp(0, (-1));
        java.lang.String str14 = node3.checkTreeEquals(node10);
        boolean boolean15 = node10.isQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 32" + "'", str7.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n" + "'", str14.equals("Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        boolean boolean5 = googleCodingConvention0.isOptionalParameter(node4);
        boolean boolean7 = googleCodingConvention0.isSuperClassReference("");
        boolean boolean9 = googleCodingConvention0.isValidEnumKey("STRING hi! 32: STRING hi! 32");
        boolean boolean11 = googleCodingConvention0.isSuperClassReference("(Named type with empty name component)");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, true);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = loggerErrorManager5.getWarnings();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder8 = null;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("Not declared as a constructor", 21, 6);
        try {
            compiler7.toSource(codeBuilder8, 0, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNotNull(jSErrorArray6);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType9 = functionType7.getPrototype();
        boolean boolean10 = functionPrototypeType9.matchesNumberContext();
        boolean boolean11 = functionPrototypeType9.hasReferenceName();
        boolean boolean12 = functionPrototypeType9.hasCachedValues();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(functionPrototypeType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("@IMPLEMENTATION.VERSION@", "STRING hi! 32", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard3, composeWarningsGuard7 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray8);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray8);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup11;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = null;
        boolean boolean14 = diagnosticGroup11.matches(diagnosticType13);
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup11;
        boolean boolean16 = composeWarningsGuard10.disables(diagnosticGroup11);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.aliasExternals;
        boolean boolean8 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.removeUnusedVars = true;
        java.lang.String str12 = compilerOptions9.aliasableGlobals;
        boolean boolean13 = compilerOptions9.printInputDelimiter;
        boolean boolean14 = compilerOptions9.foldConstants;
        compilerOptions9.recordFunctionInformation = false;
        compilerOptions9.deadAssignmentElimination = false;
        byte[] byteArray24 = new byte[] { (byte) 1, (byte) 10, (byte) -1, (byte) 10, (byte) 100 };
        compilerOptions9.inputPropertyMapSerialized = byteArray24;
        compilerOptions0.inputVariableMapSerialized = byteArray24;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.ideMode = true;
        boolean boolean30 = compilerOptions27.checkCaja;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = null;
        boolean boolean33 = diagnosticGroup31.matches(diagnosticType32);
        com.google.javascript.jscomp.CheckLevel checkLevel35 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.DiagnosticType.make("STRING hi! 32", checkLevel35, "hi!");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard38 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup31, checkLevel35);
        compilerOptions27.checkGlobalThisLevel = checkLevel35;
        compilerOptions0.checkMethods = checkLevel35;
        boolean boolean41 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.identifyEnumName("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        java.lang.String str50 = functionType49.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType51 = functionType49.getPrototype();
        com.google.javascript.rhino.jstype.EnumType enumType52 = jSTypeRegistry2.createEnumType("TypeError: STRING hi! 32", (com.google.javascript.rhino.jstype.JSType) functionType49);
        boolean boolean53 = enumType52.isNoObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(functionPrototypeType51);
        org.junit.Assert.assertNotNull(enumType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getInstructionObserverThreshold();
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(context2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean9 = jSTypeRegistry2.isForwardDeclaredType("bitnot");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 8);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        int int6 = scriptOrFnNode3.getFunctionCount();
        int int7 = scriptOrFnNode3.getRegexpCount();
        int int9 = scriptOrFnNode3.getIntProp(12);
        scriptOrFnNode3.setBaseLineno(7);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode15 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        com.google.javascript.rhino.Node node16 = scriptOrFnNode3.copyInformationFromForTree((com.google.javascript.rhino.Node) scriptOrFnNode15);
        boolean boolean17 = scriptOrFnNode15.isLocalResultCall();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Named type with empty name component", true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.aliasExternals = false;
        boolean boolean7 = compilerOptions0.labelRenaming;
        compilerOptions0.unaliasableGlobals = "Not declared as a constructor";
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("STRING hi! 32");
        ecmaError1.initLineSource("STRING hi! 32");
        ecmaError1.initColumnNumber(1);
        java.lang.String str6 = ecmaError1.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "<No stack trace available>" + "'", str6.equals("<No stack trace available>"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        boolean boolean4 = compilerOptions0.closurePass;
        compilerOptions0.ideMode = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str8 = node4.toString(true, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        node20.putIntProp(0, (-1));
        node4.addChildAfter(node12, node20);
        java.util.List<java.lang.String> strList25 = googleCodingConvention0.identifyTypeDeclarationCall(node20);
        boolean boolean27 = googleCodingConvention0.isPrivate("STRING hi! 32: STRING hi! 32");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 32" + "'", str8.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str5 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        compilerOptions0.checkCaja = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(46);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler0.tracker;
        com.google.javascript.jscomp.PerformanceTracker performanceTracker4 = null;
        compiler0.tracker = performanceTracker4;
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.renamePrefix;
        boolean boolean2 = compilerOptions0.generatePseudoNames;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.removeEmptyFunctions = false;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.specializeInitialModule = true;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str17 = node13.toString(true, false, false);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str25 = node21.toString(true, false, false);
        node21.detachChildren();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newExpr(node28);
        node29.putIntProp(0, (-1));
        node13.addChildAfter(node21, node29);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        java.lang.String str43 = functionType42.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType44 = functionType42.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = null;
        functionPrototypeType44.setPropertyJSDocInfo("", jSDocInfo46, false);
        java.util.Set<java.lang.String> strSet49 = functionPrototypeType44.getPropertyNames();
        node13.putProp((int) (byte) -1, (java.lang.Object) strSet49);
        compilerOptions0.stripNameSuffixes = strSet49;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 32" + "'", str17.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "STRING hi! 32" + "'", str25.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(functionPrototypeType44);
        org.junit.Assert.assertNotNull(strSet49);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        java.lang.String str8 = functionType7.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        boolean boolean18 = functionType17.isAllType();
        boolean boolean20 = functionType7.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType17, true);
        boolean boolean21 = functionType7.isReturnTypeInferred();
        boolean boolean22 = functionType7.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isNoObjectType();
        boolean boolean32 = functionType7.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType30);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        java.lang.String str4 = compilerOptions0.inputDelimiter;
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "// Input %num%" + "'", str4.equals("// Input %num%"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy5 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy5 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy5.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode3.addParam("");
        scriptOrFnNode3.setBaseLineno(32);
        scriptOrFnNode3.putBooleanProp(23, true);
        int int11 = scriptOrFnNode3.getParamCount();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        com.google.javascript.rhino.Node node8 = node2.copyInformationFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str16 = node12.toString(true, false, false);
        node12.detachChildren();
        com.google.javascript.rhino.Node node18 = node12.cloneNode();
        node12.putIntProp(6, (-1));
        com.google.javascript.jscomp.SourceFile.Generator generator24 = null;
        com.google.javascript.jscomp.SourceFile sourceFile25 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator24);
        com.google.javascript.jscomp.JsAst jsAst26 = new com.google.javascript.jscomp.JsAst(sourceFile25);
        node12.putProp((int) (short) 10, (java.lang.Object) sourceFile25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str35 = node31.toString(true, false, false);
        node31.detachChildren();
        com.google.javascript.rhino.Node node37 = node31.cloneNode();
        int int38 = node31.getSideEffectFlags();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode42 = new com.google.javascript.rhino.ScriptOrFnNode(11, 150, (int) (byte) 1);
        scriptOrFnNode42.addParam("");
        int int45 = scriptOrFnNode42.getFunctionCount();
        int int46 = scriptOrFnNode42.getRegexpCount();
        int int48 = scriptOrFnNode42.getIntProp(12);
        java.lang.String str49 = scriptOrFnNode42.toStringTree();
        scriptOrFnNode42.setSourceName("null.prototype");
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node8, node12, node31, scriptOrFnNode42 };
        try {
            com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(44, nodeArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 32" + "'", str16.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(sourceFile25);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "STRING hi! 32" + "'", str35.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150\n" + "'", str49.equals("BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 150\n"));
        org.junit.Assert.assertNotNull(nodeArray52);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean9 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str10 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) -1);
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.removeUnusedVars = true;
        java.lang.String str12 = compilerOptions9.aliasableGlobals;
        boolean boolean13 = compilerOptions9.allowLegacyJsMessages;
        boolean boolean14 = compilerOptions9.shouldColorizeErrorOutput();
        boolean boolean15 = compilerOptions9.checkCaja;
        byte[] byteArray22 = new byte[] { (byte) 1, (byte) -1, (byte) 100, (byte) 1, (byte) 0, (byte) 1 };
        compilerOptions9.inputPropertyMapSerialized = byteArray22;
        compilerOptions0.inputVariableMapSerialized = byteArray22;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray22);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry2.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        java.lang.String str21 = functionType20.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        boolean boolean31 = functionType30.isAllType();
        boolean boolean33 = functionType20.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType30, true);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry2.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType20, "hi!");
        jSTypeRegistry2.identifyEnumName("language version");
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry2.getType("Node tree inequality:\nTree1:\nSTRING hi! 32\n\n\nTree2:\nEXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n\n\nSubtree1: STRING hi! 32\n\n\nSubtree2: EXPR_RESULT [label_id_prop: -1]\n    NUMBER 3.0\n");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNull(jSType39);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str11 = node7.toString(true, false, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 32, 0);
        java.lang.String str19 = node15.toString(true, false, false);
        node15.detachChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 3);
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newExpr(node22);
        node23.putIntProp(0, (-1));
        node7.addChildAfter(node15, node23);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry1.createConstructorType("", node3, node15, (com.google.javascript.rhino.jstype.JSType) functionType48);
        boolean boolean66 = functionType48.hasOwnProperty("goog.global");
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry70.createFunctionTypeWithVarArgs(jSType71, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry70.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType81 = jSType80.dereference();
        boolean boolean82 = objectType81.isArrayType();
        com.google.javascript.rhino.jstype.ObjectType objectType83 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType81);
        boolean boolean85 = functionType48.defineInferredProperty("null.prototype", (com.google.javascript.rhino.jstype.JSType) objectType83, true);
        functionType48.clearResolved();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 32" + "'", str11.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "STRING hi! 32" + "'", str19.equals("STRING hi! 32"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(objectType83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode2 = null;
        jSTypeRegistry1.setResolveMode(resolveMode2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry15.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSType25.dereference();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType25 };
        com.google.javascript.rhino.Node node28 = jSTypeRegistry7.createOptionalParameters(jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry1.createConstructorType(jSType4, jSTypeArray27);
        com.google.javascript.rhino.Node node30 = functionType29.getParametersNode();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry34.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.jstype.ObjectType objectType45 = jSType44.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList52 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList52, jSTypeArray51);
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry49.createFunctionTypeWithVarArgs(jSType50, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList52);
        boolean boolean55 = functionType54.isNoObjectType();
        boolean boolean57 = objectType45.defineInferredProperty("Unknown class name", (com.google.javascript.rhino.jstype.JSType) functionType54, true);
        boolean boolean58 = functionType54.hasReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        java.lang.String str67 = functionType66.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType68 = functionType66.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo70 = null;
        functionPrototypeType68.setPropertyJSDocInfo("", jSDocInfo70, false);
        boolean boolean73 = functionPrototypeType68.isNativeObjectType();
        boolean boolean74 = functionType54.setPrototype(functionPrototypeType68);
        node30.putProp((-1), (java.lang.Object) functionPrototypeType68);
        java.lang.String str76 = functionPrototypeType68.getReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(objectType45);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(functionPrototypeType68);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "null.prototype" + "'", str76.equals("null.prototype"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        boolean boolean4 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.SourceMap.Format format5 = compilerOptions0.sourceMapFormat;
        compilerOptions0.inlineLocalVariables = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(format5);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder3.withTemplateName("");
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList11 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList11, jSTypeArray10);
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createFunctionTypeWithVarArgs(jSType9, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList11);
        java.lang.String str14 = functionType13.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType15 = functionType13.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = null;
        functionPrototypeType15.setPropertyJSDocInfo("", jSDocInfo17, false);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = functionPrototypeType15.getOwnerFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType21 = functionPrototypeType15.getConstructor();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder22 = functionBuilder3.withTypeOfThis((com.google.javascript.rhino.jstype.ObjectType) functionPrototypeType15);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        java.lang.String str31 = functionType30.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType32 = functionType30.getPrototype();
        com.google.javascript.rhino.JSDocInfo jSDocInfo34 = null;
        functionPrototypeType32.setPropertyJSDocInfo("", jSDocInfo34, false);
        java.util.Set<java.lang.String> strSet37 = functionPrototypeType32.getPropertyNames();
        boolean boolean38 = functionPrototypeType32.isStringValueType();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder39 = functionBuilder3.withInferredReturnType((com.google.javascript.rhino.jstype.JSType) functionPrototypeType32);
        com.google.javascript.rhino.Context context40 = new com.google.javascript.rhino.Context();
        long long41 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context40);
        boolean boolean42 = context40.isGeneratingDebugChanged();
        java.lang.Object obj43 = context40.getDebuggerContextData();
        try {
            java.lang.String str44 = com.google.javascript.rhino.ScriptRuntime.getMessage2("", (java.lang.Object) functionPrototypeType32, (java.lang.Object) context40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(functionPrototypeType15);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(functionType21);
        org.junit.Assert.assertNotNull(functionBuilder22);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(functionPrototypeType32);
        org.junit.Assert.assertNotNull(strSet37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionBuilder39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(obj43);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isPrivate("STRING hi! 32");
        boolean boolean4 = googleCodingConvention0.isValidEnumKey("STRING hi! 32");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        java.lang.String str13 = functionType12.getNormalizedReferenceName();
        boolean boolean14 = functionType12.isCheckedUnknownType();
        boolean boolean15 = functionType12.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isNoObjectType();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        googleCodingConvention0.applySubclassRelationship(functionType12, functionType23, subclassType25);
        boolean boolean27 = functionType23.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry30.createNamedType("Not declared as a constructor", "hi!", 0, (int) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        java.lang.String str49 = functionType48.getNormalizedReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        boolean boolean59 = functionType58.isAllType();
        boolean boolean61 = functionType48.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType58, true);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry30.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType48, "hi!");
        boolean boolean64 = functionType48.isFunctionType();
        boolean boolean65 = functionType23.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType48);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable66 = functionType48.getAllImplementedInterfaces();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable66);
    }
}

