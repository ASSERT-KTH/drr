import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripNamePrefixes = strSet2;
        compilerOptions0.exportTestFunctions = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "function (): function (this:me, {864805963}): me");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        jSSourceFile2.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule5 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7, jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = jSModule9.getByName("");
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph16 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13);
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule20 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule21 = jSModuleGraph16.getDeepestCommonDependencyInclusive(jSModule18, jSModule20);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList22 = jSModule20.getDependencies();
        java.util.List<java.lang.String> strList23 = jSModule20.getRequires();
        com.google.javascript.jscomp.JSModule[] jSModuleArray24 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList25 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList25, jSModuleArray24);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph27 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList25);
        com.google.javascript.jscomp.JSModule jSModule29 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray30 = new com.google.javascript.jscomp.JSModule[] { jSModule29 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList31 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList31, jSModuleArray30);
        com.google.javascript.jscomp.JSModule jSModule33 = jSModuleGraph27.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList31);
        com.google.javascript.jscomp.JSModule[] jSModuleArray34 = new com.google.javascript.jscomp.JSModule[] { jSModule9, jSModule20, jSModule33 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph35 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray34);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph36 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray34);
        com.google.javascript.jscomp.JSModule[] jSModuleArray37 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList38, jSModuleArray37);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph40 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList38);
        com.google.javascript.jscomp.JSModule[] jSModuleArray41 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList42 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList42, jSModuleArray41);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph44 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList42);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph45 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList42);
        com.google.javascript.jscomp.JSModule jSModule47 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule49 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule50 = jSModuleGraph45.getDeepestCommonDependencyInclusive(jSModule47, jSModule49);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList51 = jSModule49.getDependencies();
        com.google.javascript.jscomp.SourceFile.Generator generator53 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile54 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator53);
        com.google.javascript.jscomp.CompilerInput compilerInput55 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile54);
        jSModule49.addFirst(compilerInput55);
        com.google.javascript.jscomp.JSModule[] jSModuleArray57 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList58 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList58, jSModuleArray57);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph60 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList58);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph61 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList58);
        com.google.javascript.jscomp.JSModule jSModule63 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule65 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule66 = jSModuleGraph61.getDeepestCommonDependencyInclusive(jSModule63, jSModule65);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList67 = jSModule65.getDependencies();
        com.google.javascript.jscomp.SourceFile.Generator generator69 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile70 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator69);
        com.google.javascript.jscomp.CompilerInput compilerInput71 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile70);
        jSModule65.addFirst(compilerInput71);
        com.google.javascript.jscomp.JSModule jSModule73 = jSModuleGraph40.getDeepestCommonDependencyInclusive(jSModule49, jSModule65);
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList75 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean76 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList75, jSModuleArray74);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph77 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList75);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph78 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList75);
        com.google.javascript.jscomp.JSModule jSModule80 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule82 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule83 = jSModuleGraph78.getDeepestCommonDependencyInclusive(jSModule80, jSModule82);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList84 = jSModule82.getDependencies();
        try {
            boolean boolean85 = jSModuleGraph36.dependsOn(jSModule73, jSModule82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jSModule9);
        org.junit.Assert.assertNull(compilerInput11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jSModule21);
        org.junit.Assert.assertNotNull(jSModuleList22);
        org.junit.Assert.assertNotNull(strList23);
        org.junit.Assert.assertNotNull(jSModuleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSModuleArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(jSModule33);
        org.junit.Assert.assertNotNull(jSModuleArray34);
        org.junit.Assert.assertNotNull(jSModuleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSModuleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(jSModule50);
        org.junit.Assert.assertNotNull(jSModuleList51);
        org.junit.Assert.assertNotNull(jSSourceFile54);
        org.junit.Assert.assertNotNull(jSModuleArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(jSModule66);
        org.junit.Assert.assertNotNull(jSModuleList67);
        org.junit.Assert.assertNotNull(jSSourceFile70);
        org.junit.Assert.assertNull(jSModule73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(jSModule83);
        org.junit.Assert.assertNotNull(jSModuleList84);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.flowSensitiveInlineVariables = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.unaliasableGlobals = "function (): function (this:me, {327460564}): me";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder1.withParams(functionParamBuilder3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder6 = functionBuilder4.withTypeOfThis(objectType5);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder7 = null;
        try {
            com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder8 = functionBuilder4.withParams(functionParamBuilder7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(functionBuilder6);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair18 = jSType7.getTypesUnderShallowInequality(jSType17);
        boolean boolean19 = jSType17.isNumberObjectType();
        boolean boolean20 = jSType17.isCheckedUnknownType();
        com.google.javascript.rhino.jstype.JSType jSType22 = jSType17.getRestrictedTypeGivenToBooleanOutcome(false);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(typePair18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(jSType22);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph4.getDeepestCommonDependencyInclusive(jSModule6, jSModule8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        jSModule8.add(jSSourceFile12);
        com.google.javascript.jscomp.SourceFile.Generator generator15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator15);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.JSModule jSModule18 = compilerInput17.getModule();
        java.lang.String str19 = compilerInput17.getName();
        com.google.javascript.jscomp.JSModule jSModule20 = compilerInput17.getModule();
        jSModule8.addFirst(compilerInput17);
        try {
            com.google.javascript.jscomp.Region region23 = compilerInput17.getRegion(23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNull(jSModule18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNull(jSModule20);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        boolean boolean7 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy9 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions8.propertyRenaming = propertyRenamingPolicy9;
        com.google.javascript.jscomp.SourceMap.Format format11 = null;
        compilerOptions8.sourceMapFormat = format11;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.reportUnknownTypes;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel13;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.jsOutputFile = "function (): function (this:me, {159411242}): me";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy9.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry2.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.createUnionType(jSTypeArray17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry21.createUnionType(jSTypeArray22);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] { jSType23 };
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry16.createUnionType(jSTypeArray24);
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry31.createUnionType(jSTypeArray32);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry28.createOptionalType(jSType33);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry37.createUnionType(jSTypeArray38);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry43.createUnionType(jSTypeArray44);
        boolean boolean46 = jSTypeRegistry37.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType45);
        com.google.javascript.rhino.Node node50 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        node50.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry28.createFunctionType(jSType45, node50);
        java.lang.String str55 = functionType54.toString();
        boolean boolean56 = functionType54.matchesStringContext();
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry16.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType54);
        com.google.javascript.rhino.jstype.JSType jSType58 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry2.createFunctionTypeWithNewReturnType(functionType54, jSType58);
        jSTypeRegistry2.clearTemplateTypeName();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "function (): None" + "'", str55.equals("function (): None"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(functionType59);
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test12");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry23.createUnionType(jSTypeArray24);
//        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry20.createOptionalType(jSType25);
//        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry29.createUnionType(jSTypeArray30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.createUnionType(jSTypeArray36);
//        boolean boolean38 = jSTypeRegistry29.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType37);
//        com.google.javascript.rhino.Node node42 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
//        node42.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry20.createFunctionType(jSType37, node42);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList47 = functionType46.getSubTypes();
//        java.util.Set<java.lang.String> strSet48 = functionType46.getPropertyNames();
//        java.lang.String str49 = functionType46.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = functionType46.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry53.createUnionType(jSTypeArray54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry61.createUnionType(jSTypeArray62);
//        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry58.createOptionalType(jSType63);
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray68 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry67.createUnionType(jSTypeArray68);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry73.createUnionType(jSTypeArray74);
//        boolean boolean76 = jSTypeRegistry67.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType75);
//        com.google.javascript.rhino.Node node80 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType81 = node80.getJSType();
//        node80.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry58.createFunctionType(jSType75, node80);
//        boolean boolean85 = jSType55.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType84);
//        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry11.createFunctionTypeWithNewThisType(functionType46, (com.google.javascript.rhino.jstype.ObjectType) functionType84);
//        com.google.javascript.rhino.jstype.ObjectType objectType87 = functionType46.getImplicitPrototype();
//        com.google.javascript.rhino.jstype.JSType jSType88 = jSType8.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType46);
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray24);
//        org.junit.Assert.assertNotNull(jSType25);
//        org.junit.Assert.assertNotNull(jSType26);
//        org.junit.Assert.assertNotNull(jSTypeArray30);
//        org.junit.Assert.assertNotNull(jSType31);
//        org.junit.Assert.assertNotNull(jSTypeArray36);
//        org.junit.Assert.assertNotNull(jSType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(node42);
//        org.junit.Assert.assertNull(jSType43);
//        org.junit.Assert.assertNotNull(functionType46);
//        org.junit.Assert.assertNull(functionTypeList47);
//        org.junit.Assert.assertNotNull(strSet48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "function (): function (this:me, {1514858477}): me" + "'", str49.equals("function (): function (this:me, {1514858477}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable50);
//        org.junit.Assert.assertNotNull(jSTypeArray54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray62);
//        org.junit.Assert.assertNotNull(jSType63);
//        org.junit.Assert.assertNotNull(jSType64);
//        org.junit.Assert.assertNotNull(jSTypeArray68);
//        org.junit.Assert.assertNotNull(jSType69);
//        org.junit.Assert.assertNotNull(jSTypeArray74);
//        org.junit.Assert.assertNotNull(jSType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertNotNull(node80);
//        org.junit.Assert.assertNull(jSType81);
//        org.junit.Assert.assertNotNull(functionType84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(functionType86);
//        org.junit.Assert.assertNotNull(objectType87);
//        org.junit.Assert.assertNotNull(jSType88);
//    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("@IMPLEMENTATION.VERSION@", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry4.createUnionType(jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] { jSType11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry4.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry4.getNativeObjectType(jSTypeNative14);
        com.google.javascript.jscomp.Scope scope16 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.createUnionType(jSTypeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.createUnionType(jSTypeArray25);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry19.createUnionType(jSTypeArray27);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.getNativeObjectType(jSTypeNative29);
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray31 = new com.google.javascript.rhino.jstype.ObjectType[] { objectType30 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32, objectTypeArray31);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry4, scope16, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32);
        java.lang.String str35 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean38 = closureCodingConvention0.isExported("function (): function (this:me, {849350231}): me", true);
        boolean boolean40 = closureCodingConvention0.isValidEnumKey("");
        boolean boolean42 = closureCodingConvention0.isValidEnumKey("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(objectTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "goog.abstractMethod" + "'", str35.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        com.google.javascript.jscomp.ErrorManager errorManager45 = compiler1.getErrorManager();
        compiler1.disableThreads();
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
        org.junit.Assert.assertNotNull(errorManager45);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.sourceMapOutputPath = "ASSIGN_MOD  9\n";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        boolean boolean29 = jSTypeRegistry20.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType28);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
//        node33.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry11.createFunctionType(jSType28, node33);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
//        java.util.Set<java.lang.String> strSet39 = functionType37.getPropertyNames();
//        java.lang.String str40 = functionType37.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = functionType37.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry49.createOptionalType(jSType54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.createUnionType(jSTypeArray59);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.createUnionType(jSTypeArray65);
//        boolean boolean67 = jSTypeRegistry58.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType66);
//        com.google.javascript.rhino.Node node71 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
//        node71.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry49.createFunctionType(jSType66, node71);
//        boolean boolean76 = jSType46.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType75);
//        com.google.javascript.rhino.jstype.ObjectType objectType78 = functionType37.getImplicitPrototype();
//        boolean boolean79 = functionType37.isCheckedUnknownType();
//        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet80 = functionType37.getPossibleToBooleanOutcomes();
//        boolean boolean81 = functionType37.isNativeObjectType();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNull(jSType34);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(functionTypeList38);
//        org.junit.Assert.assertNotNull(strSet39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): function (this:me, {133581424}): me" + "'", str40.equals("function (): function (this:me, {133581424}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray45);
//        org.junit.Assert.assertNotNull(jSType46);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertNotNull(objectType78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertTrue("'" + booleanLiteralSet80 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet80.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.inlineVariables = true;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.locale = "TypeError: function (): None";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
//        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
//        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
//        node24.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
//        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
//        java.lang.String str31 = functionType28.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable32 = functionType28.getAllImplementedInterfaces();
//        boolean boolean33 = functionType28.isStringValueType();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray12);
//        org.junit.Assert.assertNotNull(jSType13);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(node24);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(functionType28);
//        org.junit.Assert.assertNull(functionTypeList29);
//        org.junit.Assert.assertNotNull(strSet30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "function (): function (this:me, {1696950029}): me" + "'", str31.equals("function (): function (this:me, {1696950029}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        com.google.javascript.jscomp.ErrorManager errorManager45 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSError[] jSErrorArray46 = compiler1.getWarnings();
        int int47 = compiler1.getErrorCount();
        compiler1.reportCodeChange();
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
        org.junit.Assert.assertNotNull(errorManager45);
        org.junit.Assert.assertNotNull(jSErrorArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        node12.setType((int) 'a');
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 1, node8, node12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat21 = diagnosticType20.format;
        java.lang.String[] strArray22 = null;
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("hi!", node12, diagnosticType20, strArray22);
        java.text.MessageFormat messageFormat24 = diagnosticType20.format;
        java.lang.String[] strArray25 = null;
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("function (): function (this:me, {1422249602}): me", (int) (short) 0, 47, diagnosticType20, strArray25);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(messageFormat21);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(messageFormat24);
        org.junit.Assert.assertNotNull(jSError26);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("goog.abstractMethod", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        compilerOptions0.sourceMapOutputPath = "hi!";
        compilerOptions0.checkDuplicateMessages = true;
        compilerOptions0.aliasExternals = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripNamePrefixes = strSet2;
        compilerOptions0.exportTestFunctions = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.checkCaja = false;
        compilerOptions0.inputDelimiter = "ASSIGN_MOD  9\n";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripNamePrefixes = strSet2;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.optimizeArgumentsArray = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback3);
        com.google.javascript.rhino.Node node5 = nodeTraversal4.getCurrentNode();
        com.google.javascript.rhino.Node node6 = nodeTraversal4.getEnclosingFunction();
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkRequires;
        compilerOptions0.printInputDelimiter = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions6.propertyRenaming = propertyRenamingPolicy7;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str11 = compilerOptions10.sourceMapOutputPath;
        boolean boolean12 = compilerOptions10.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        compilerOptions10.checkGlobalThisLevel = checkLevel13;
        java.lang.String[] strArray20 = new java.lang.String[] { "ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n", "hi!", "ASSIGN_MOD  9\n" };
        java.util.ArrayList<java.lang.String> strList21 = new java.util.ArrayList<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList21, strArray20);
        compilerOptions10.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList21);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList21);
        compilerOptions0.aliasableGlobals = "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n";
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str28 = compilerOptions27.sourceMapOutputPath;
        boolean boolean29 = compilerOptions27.collapseProperties;
        boolean boolean30 = compilerOptions27.collapseProperties;
        compilerOptions27.checkUnusedPropertiesEarly = true;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions27.brokenClosureRequiresLevel;
        compilerOptions0.reportUnknownTypes = checkLevel33;
        boolean boolean35 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        compilerOptions0.reportPath = "function (): function (this:me, {1964500819}): me";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 1, node5, node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat18 = diagnosticType17.format;
        java.lang.String[] strArray19 = null;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("hi!", node9, diagnosticType17, strArray19);
        java.io.PrintStream printStream21 = null;
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler(printStream21);
        com.google.javascript.rhino.Node node23 = compiler22.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator25 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator25);
        com.google.javascript.jscomp.CompilerInput compilerInput27 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile26);
        com.google.javascript.jscomp.SourceFile.Generator generator29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator29);
        com.google.javascript.jscomp.SourceFile.Generator generator32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator32);
        com.google.javascript.jscomp.SourceFile.Generator generator35 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator35);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile26, jSSourceFile30, jSSourceFile33, jSSourceFile36 };
        com.google.javascript.jscomp.JSModule jSModule39 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray40 = new com.google.javascript.jscomp.JSModule[] { jSModule39 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str42 = compilerOptions41.sourceMapOutputPath;
        boolean boolean43 = compilerOptions41.allowLegacyJsMessages;
        compilerOptions41.removeUnusedPrototypePropertiesInExterns = true;
        compiler22.init(jSSourceFileArray37, jSModuleArray40, compilerOptions41);
        compilerOptions41.aliasAllStrings = true;
        boolean boolean49 = jSError20.equals((java.lang.Object) compilerOptions41);
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = jSError20.getType();
        com.google.javascript.jscomp.CheckLevel checkLevel51 = diagnosticType50.level;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(messageFormat18);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertNotNull(jSModuleArray40);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1967691932}): me", 2, 20);
        functionNode3.setEncodedSourceBounds(27, (int) (byte) 100);
        boolean boolean7 = functionNode3.getIgnoreDynamicScope();
        int int8 = functionNode3.getBaseLineno();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1967691932}): me", 2, 20);
        functionNode3.setEncodedSourceBounds(27, (int) (byte) 100);
        functionNode3.removeParamOrVar("function (): function (this:me, {1311234794}): me");
        functionNode3.setBaseLineno((int) (byte) 100);
        functionNode3.setSourceName("function (): function (this:me, {1967691932}): me");
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup22, checkLevel23);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard27 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup25, checkLevel26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel29);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard33 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup31, checkLevel32);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup34, checkLevel35);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup37, checkLevel38);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray40 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard24, diagnosticGroupWarningsGuard27, diagnosticGroupWarningsGuard30, diagnosticGroupWarningsGuard33, diagnosticGroupWarningsGuard36, diagnosticGroupWarningsGuard39 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard41 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        node51.setType((int) 'a');
        boolean boolean55 = node51.hasOneChild();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) 1, node47, node51);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat60 = diagnosticType59.format;
        java.lang.String[] strArray61 = null;
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("hi!", node51, diagnosticType59, strArray61);
        com.google.javascript.jscomp.CheckLevel checkLevel63 = composeWarningsGuard41.level(jSError62);
        com.google.javascript.jscomp.CheckLevel checkLevel64 = composeWarningsGuard21.level(jSError62);
        compiler1.report(jSError62);
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroup34);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertNotNull(warningsGuardArray40);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(messageFormat60);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(checkLevel63);
        org.junit.Assert.assertNull(checkLevel64);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkFunctions = checkLevel11;
        compilerOptions0.allowLegacyJsMessages = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule5 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7, jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        java.lang.String str10 = jSModule9.getName();
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList12 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList12, jSModuleArray11);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph14 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList12);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList12);
        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule19 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule20 = jSModuleGraph15.getDeepestCommonDependencyInclusive(jSModule17, jSModule19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        jSModule19.add(jSSourceFile23);
        jSSourceFile23.clearCachedSource();
        jSModule9.add(jSSourceFile23);
        java.io.PrintStream printStream27 = null;
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler(printStream27);
        com.google.javascript.rhino.Node node29 = compiler28.getRoot();
        com.google.javascript.rhino.Node node30 = compiler28.getRoot();
        jSModule9.sortInputsByDeps(compiler28);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jSModule9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str10.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(jSModule20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertNull(node30);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule5 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7, jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        java.lang.String str10 = jSModule9.getName();
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList12 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList12, jSModuleArray11);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph14 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList12);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList12);
        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule19 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule20 = jSModuleGraph15.getDeepestCommonDependencyInclusive(jSModule17, jSModule19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        jSModule19.add(jSSourceFile23);
        jSSourceFile23.clearCachedSource();
        jSModule9.add(jSSourceFile23);
        java.lang.String str27 = jSSourceFile23.getName();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jSModule9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str10.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(jSModule20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ASSIGN_MOD  9\n" + "'", str27.equals("ASSIGN_MOD  9\n"));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 1, node5, node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat18 = diagnosticType17.format;
        java.lang.String[] strArray19 = null;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("hi!", node9, diagnosticType17, strArray19);
        com.google.javascript.jscomp.CheckLevel checkLevel21 = jSError20.level;
        java.lang.String str22 = jSError20.description;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(messageFormat18);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test39");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
//        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
//        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 10 };
//        compilerOptions0.inputPropertyMapSerialized = byteArray6;
//        compilerOptions0.gatherCssNames = true;
//        boolean boolean10 = compilerOptions0.aliasExternals;
//        compilerOptions0.skipAllCompilerPasses();
//        boolean boolean12 = compilerOptions0.closurePass;
//        compilerOptions0.rewriteFunctionExpressions = false;
//        boolean boolean15 = compilerOptions0.optimizeParameters;
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry18.createUnionType(jSTypeArray19);
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry23.createUnionType(jSTypeArray24);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] { jSType25 };
//        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry18.createUnionType(jSTypeArray26);
//        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope29 = null;
//        com.google.javascript.rhino.jstype.JSType jSType30 = jSType27.resolve(errorReporter28, jSTypeStaticScope29);
//        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry36.createUnionType(jSTypeArray37);
//        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry33.createOptionalType(jSType38);
//        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry42.createUnionType(jSTypeArray43);
//        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType50 = jSTypeRegistry48.createUnionType(jSTypeArray49);
//        boolean boolean51 = jSTypeRegistry42.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType50);
//        com.google.javascript.rhino.Node node55 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType56 = node55.getJSType();
//        node55.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry33.createFunctionType(jSType50, node55);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList60 = functionType59.getSubTypes();
//        java.util.Set<java.lang.String> strSet61 = functionType59.getPropertyNames();
//        java.lang.String str62 = functionType59.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable63 = functionType59.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType64 = jSType27.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) functionType59);
//        java.util.Set set65 = functionType59.getOwnPropertyNames();
//        compilerOptions0.stripTypePrefixes = set65;
//        org.junit.Assert.assertNull(str1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(byteArray6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray19);
//        org.junit.Assert.assertNotNull(jSType20);
//        org.junit.Assert.assertNotNull(jSTypeArray24);
//        org.junit.Assert.assertNotNull(jSType25);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertNotNull(jSType27);
//        org.junit.Assert.assertNotNull(jSType30);
//        org.junit.Assert.assertNotNull(jSTypeArray37);
//        org.junit.Assert.assertNotNull(jSType38);
//        org.junit.Assert.assertNotNull(jSType39);
//        org.junit.Assert.assertNotNull(jSTypeArray43);
//        org.junit.Assert.assertNotNull(jSType44);
//        org.junit.Assert.assertNotNull(jSTypeArray49);
//        org.junit.Assert.assertNotNull(jSType50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(node55);
//        org.junit.Assert.assertNull(jSType56);
//        org.junit.Assert.assertNotNull(functionType59);
//        org.junit.Assert.assertNull(functionTypeList60);
//        org.junit.Assert.assertNotNull(strSet61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "function (): function (this:me, {148390231}): me" + "'", str62.equals("function (): function (this:me, {148390231}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable63);
//        org.junit.Assert.assertNotNull(jSType64);
//        org.junit.Assert.assertNotNull(set65);
//    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkRequires;
        compilerOptions0.printInputDelimiter = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions6.propertyRenaming = propertyRenamingPolicy7;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str11 = compilerOptions10.sourceMapOutputPath;
        boolean boolean12 = compilerOptions10.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        compilerOptions10.checkGlobalThisLevel = checkLevel13;
        java.lang.String[] strArray20 = new java.lang.String[] { "ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n", "hi!", "ASSIGN_MOD  9\n" };
        java.util.ArrayList<java.lang.String> strList21 = new java.util.ArrayList<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList21, strArray20);
        compilerOptions10.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList21);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList21);
        compilerOptions0.setChainCalls(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        context1.setGeneratingSource(false);
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setType((int) 'a');
        boolean boolean9 = node5.hasOneChild();
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        node13.setType((int) 'a');
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        node5.addChildAfter(node13, node20);
        com.google.javascript.rhino.Node node23 = functionParamBuilder1.newParameterFromNode(node13);
        com.google.javascript.rhino.Node node24 = node13.cloneNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        node28.setType((int) 'a');
        boolean boolean32 = node28.hasOneChild();
        com.google.javascript.rhino.Node node36 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType37 = node36.getJSType();
        java.lang.String str38 = node28.checkTreeEquals(node36);
        com.google.javascript.rhino.Node node39 = node28.getLastChild();
        com.google.javascript.rhino.Node node43 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType44 = node43.getJSType();
        node43.setType((int) 'a');
        boolean boolean47 = node43.hasOneChild();
        com.google.javascript.rhino.Node node51 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        java.lang.String str53 = node43.checkTreeEquals(node51);
        node43.addSuppression("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        node24.addChildAfter(node28, node43);
        boolean boolean57 = node43.hasChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str38.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertNull(node39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(jSType44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str53.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        loggerErrorManager2.generateReport();
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1967691932}): me", 2, 20);
        boolean[] booleanArray4 = functionNode3.getParamAndVarConst();
        org.junit.Assert.assertNotNull(booleanArray4);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator4);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile9, jSSourceFile12, jSSourceFile15 };
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] { jSModule18 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str21 = compilerOptions20.sourceMapOutputPath;
        boolean boolean22 = compilerOptions20.allowLegacyJsMessages;
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = true;
        compiler1.init(jSSourceFileArray16, jSModuleArray19, compilerOptions20);
        java.lang.String str26 = compiler1.toSource();
        java.io.PrintStream printStream27 = null;
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler(printStream27);
        com.google.javascript.rhino.Node node29 = compiler28.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.SourceFile.Generator generator35 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator35);
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator38);
        com.google.javascript.jscomp.SourceFile.Generator generator41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator41);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile36, jSSourceFile39, jSSourceFile42 };
        com.google.javascript.jscomp.JSModule jSModule45 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray46 = new com.google.javascript.jscomp.JSModule[] { jSModule45 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str48 = compilerOptions47.sourceMapOutputPath;
        boolean boolean49 = compilerOptions47.allowLegacyJsMessages;
        compilerOptions47.removeUnusedPrototypePropertiesInExterns = true;
        compiler28.init(jSSourceFileArray43, jSModuleArray46, compilerOptions47);
        com.google.javascript.jscomp.JSModule[] jSModuleArray53 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList54 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList54, jSModuleArray53);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph56 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList54);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph57 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList54);
        com.google.javascript.jscomp.JSModule jSModule59 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule61 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule62 = jSModuleGraph57.getDeepestCommonDependencyInclusive(jSModule59, jSModule61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray63 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList64 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList64, jSModuleArray63);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph66 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList64);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph67 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList64);
        com.google.javascript.jscomp.JSModule jSModule69 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule71 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule72 = jSModuleGraph67.getDeepestCommonDependencyInclusive(jSModule69, jSModule71);
        com.google.javascript.jscomp.JSModule[] jSModuleArray73 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList74 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList74, jSModuleArray73);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph76 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList74);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph77 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList74);
        com.google.javascript.jscomp.JSModule jSModule79 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule81 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule82 = jSModuleGraph77.getDeepestCommonDependencyInclusive(jSModule79, jSModule81);
        int int83 = jSModule79.getDepth();
        com.google.javascript.jscomp.JSModule[] jSModuleArray84 = new com.google.javascript.jscomp.JSModule[] { jSModule59, jSModule71, jSModule79 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = null;
        try {
            compiler1.init(jSSourceFileArray43, jSModuleArray84, compilerOptions85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSModuleArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertNotNull(jSModuleArray46);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(jSModuleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(jSModule62);
        org.junit.Assert.assertNotNull(jSModuleArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(jSModule72);
        org.junit.Assert.assertNotNull(jSModuleArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(jSModule82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(jSModuleArray84);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        java.util.logging.Logger logger5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.parsing.ParserRunner.parse("function (): function (this:me, {1967691932}): me", "function (): function (this:me, {1967691932}): me", config3, errorReporter4, logger5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.lang.String str5 = compilerInput3.getName();
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup20, checkLevel21);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup23, checkLevel24);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray26 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19, diagnosticGroupWarningsGuard22, diagnosticGroupWarningsGuard25 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel29);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard33 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup31, checkLevel32);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup34, checkLevel35);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup37, checkLevel38);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup40 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard42 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup40, checkLevel41);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup43 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard45 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup43, checkLevel44);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray46 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard30, diagnosticGroupWarningsGuard33, diagnosticGroupWarningsGuard36, diagnosticGroupWarningsGuard39, diagnosticGroupWarningsGuard42, diagnosticGroupWarningsGuard45 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard47 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray46);
        com.google.javascript.rhino.Node node53 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node57 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType58 = node57.getJSType();
        node57.setType((int) 'a');
        boolean boolean61 = node57.hasOneChild();
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (short) 1, node53, node57);
        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat66 = diagnosticType65.format;
        java.lang.String[] strArray67 = null;
        com.google.javascript.jscomp.JSError jSError68 = com.google.javascript.jscomp.JSError.make("hi!", node57, diagnosticType65, strArray67);
        com.google.javascript.jscomp.CheckLevel checkLevel69 = composeWarningsGuard47.level(jSError68);
        com.google.javascript.jscomp.CheckLevel checkLevel70 = composeWarningsGuard27.level(jSError68);
        compiler7.report(jSError68);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        com.google.javascript.jscomp.SourceMap sourceMap73 = compiler7.getSourceMap();
        try {
            java.lang.String str76 = compiler7.getSourceLine("", 130);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
        org.junit.Assert.assertNotNull(diagnosticGroup23);
        org.junit.Assert.assertNotNull(warningsGuardArray26);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroup34);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertNotNull(diagnosticGroup40);
        org.junit.Assert.assertNotNull(diagnosticGroup43);
        org.junit.Assert.assertNotNull(warningsGuardArray46);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(diagnosticType65);
        org.junit.Assert.assertNotNull(messageFormat66);
        org.junit.Assert.assertNotNull(jSError68);
        org.junit.Assert.assertNull(checkLevel69);
        org.junit.Assert.assertNull(checkLevel70);
        org.junit.Assert.assertNull(sourceMap73);
    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test50");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
//        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
//        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
//        node24.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
//        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
//        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry33.createUnionType(jSTypeArray34);
//        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry38.createUnionType(jSTypeArray39);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { jSType40 };
//        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry33.createUnionType(jSTypeArray41);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
//        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry33.getNativeObjectType(jSTypeNative43);
//        com.google.javascript.rhino.jstype.JSType jSType45 = functionType28.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) objectType44);
//        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry51.createUnionType(jSTypeArray52);
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry48.createOptionalType(jSType53);
//        boolean boolean55 = jSType53.isStringObjectType();
//        boolean boolean56 = jSType45.canTestForShallowEqualityWith(jSType53);
//        java.lang.String str57 = jSType53.toDebugHashCodeString();
//        boolean boolean58 = jSType53.canBeCalled();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray12);
//        org.junit.Assert.assertNotNull(jSType13);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(node24);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(functionType28);
//        org.junit.Assert.assertNull(functionTypeList29);
//        org.junit.Assert.assertNotNull(strSet30);
//        org.junit.Assert.assertNotNull(jSTypeArray34);
//        org.junit.Assert.assertNotNull(jSType35);
//        org.junit.Assert.assertNotNull(jSTypeArray39);
//        org.junit.Assert.assertNotNull(jSType40);
//        org.junit.Assert.assertNotNull(jSTypeArray41);
//        org.junit.Assert.assertNotNull(jSType42);
//        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
//        org.junit.Assert.assertNotNull(objectType44);
//        org.junit.Assert.assertNotNull(jSType45);
//        org.junit.Assert.assertNotNull(jSTypeArray52);
//        org.junit.Assert.assertNotNull(jSType53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "function (this:me, {975792634}): me" + "'", str57.equals("function (this:me, {975792634}): me"));
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkFunctions = checkLevel11;
        boolean boolean13 = compilerOptions0.decomposeExpressions;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap14 = compilerOptions0.customPasses;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "setelem");
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType17.defaultLevel;
        compilerOptions0.checkUndefinedProperties = checkLevel18;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("function (): function (this:me, {1311234794}): me", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean4 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.closurePass = false;
        boolean boolean7 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        boolean boolean5 = compilerOptions0.gatherCssNames;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap6 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strMap6);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setType((int) 'a');
        boolean boolean9 = node5.hasOneChild();
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        node13.setType((int) 'a');
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        node5.addChildAfter(node13, node20);
        com.google.javascript.rhino.Node node23 = functionParamBuilder1.newParameterFromNode(node13);
        com.google.javascript.rhino.Node node24 = node13.cloneNode();
        node24.detachChildren();
        java.lang.String str26 = node24.toString();
        com.google.javascript.rhino.Node node27 = node24.cloneTree();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ASSIGN_MOD  9" + "'", str26.equals("ASSIGN_MOD  9"));
        org.junit.Assert.assertNotNull(node27);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("function (): function (this:me, {1967691932}): me", "function (): function (this:me, {293602210}): me");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("function (): function (this:me, {1964500819}): me");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        java.lang.String str7 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str9 = compilerOptions8.sourceMapOutputPath;
        compilerOptions8.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions8.reportMissingOverride;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel12;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test59");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.createUnionType(jSTypeArray11);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] { jSType12 };
//        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry5.createUnionType(jSTypeArray13);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope16 = null;
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSType14.resolve(errorReporter15, jSTypeStaticScope16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry23.createUnionType(jSTypeArray24);
//        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry20.createOptionalType(jSType25);
//        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry29.createUnionType(jSTypeArray30);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.createUnionType(jSTypeArray36);
//        boolean boolean38 = jSTypeRegistry29.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType37);
//        com.google.javascript.rhino.Node node42 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
//        node42.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry20.createFunctionType(jSType37, node42);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList47 = functionType46.getSubTypes();
//        java.util.Set<java.lang.String> strSet48 = functionType46.getPropertyNames();
//        java.lang.String str49 = functionType46.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = functionType46.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType51 = jSType14.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) functionType46);
//        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType59 = jSTypeRegistry57.createUnionType(jSTypeArray58);
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry54.createOptionalType(jSType59);
//        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray64 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType65 = jSTypeRegistry63.createUnionType(jSTypeArray64);
//        com.google.javascript.rhino.ErrorReporter errorReporter67 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter67, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray70 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry69.createUnionType(jSTypeArray70);
//        boolean boolean72 = jSTypeRegistry63.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType71);
//        com.google.javascript.rhino.Node node76 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType77 = node76.getJSType();
//        node76.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry54.createFunctionType(jSType71, node76);
//        java.lang.String str81 = functionType80.toString();
//        boolean boolean82 = functionType80.matchesStringContext();
//        com.google.javascript.rhino.jstype.JSType jSType83 = jSType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType80);
//        com.google.javascript.rhino.jstype.JSType jSType84 = jSTypeRegistry2.createNullableType(jSType14);
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSTypeArray11);
//        org.junit.Assert.assertNotNull(jSType12);
//        org.junit.Assert.assertNotNull(jSTypeArray13);
//        org.junit.Assert.assertNotNull(jSType14);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray24);
//        org.junit.Assert.assertNotNull(jSType25);
//        org.junit.Assert.assertNotNull(jSType26);
//        org.junit.Assert.assertNotNull(jSTypeArray30);
//        org.junit.Assert.assertNotNull(jSType31);
//        org.junit.Assert.assertNotNull(jSTypeArray36);
//        org.junit.Assert.assertNotNull(jSType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(node42);
//        org.junit.Assert.assertNull(jSType43);
//        org.junit.Assert.assertNotNull(functionType46);
//        org.junit.Assert.assertNull(functionTypeList47);
//        org.junit.Assert.assertNotNull(strSet48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "function (): function (this:me, {1783660677}): me" + "'", str49.equals("function (): function (this:me, {1783660677}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable50);
//        org.junit.Assert.assertNotNull(jSType51);
//        org.junit.Assert.assertNotNull(jSTypeArray58);
//        org.junit.Assert.assertNotNull(jSType59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray64);
//        org.junit.Assert.assertNotNull(jSType65);
//        org.junit.Assert.assertNotNull(jSTypeArray70);
//        org.junit.Assert.assertNotNull(jSType71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertNotNull(node76);
//        org.junit.Assert.assertNull(jSType77);
//        org.junit.Assert.assertNotNull(functionType80);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "function (): None" + "'", str81.equals("function (): None"));
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(jSType83);
//        org.junit.Assert.assertNotNull(jSType84);
//    }

//    @Test
//    public void test60() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test60");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        boolean boolean29 = jSTypeRegistry20.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType28);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
//        node33.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry11.createFunctionType(jSType28, node33);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
//        java.util.Set<java.lang.String> strSet39 = functionType37.getPropertyNames();
//        java.lang.String str40 = functionType37.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = functionType37.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry49.createOptionalType(jSType54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.createUnionType(jSTypeArray59);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.createUnionType(jSTypeArray65);
//        boolean boolean67 = jSTypeRegistry58.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType66);
//        com.google.javascript.rhino.Node node71 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
//        node71.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry49.createFunctionType(jSType66, node71);
//        boolean boolean76 = jSType46.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType75);
//        boolean boolean78 = functionType37.isUnknownType();
//        boolean boolean79 = functionType37.isRecordType();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNull(jSType34);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(functionTypeList38);
//        org.junit.Assert.assertNotNull(strSet39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): function (this:me, {431048220}): me" + "'", str40.equals("function (): function (this:me, {431048220}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray45);
//        org.junit.Assert.assertNotNull(jSType46);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.NO_DUPLICATE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.createUnionType(jSTypeArray11);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] { jSType12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry5.createUnionType(jSTypeArray13);
        com.google.javascript.rhino.Node node15 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray13);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray17 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16 };
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry2.createUnionType(jSTypeNativeArray17);
        boolean boolean19 = jSType18.isTemplateType();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        boolean boolean3 = closureCodingConvention0.isSuperClassReference(": hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry6.createOptionalType(jSType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry15.createUnionType(jSTypeArray16);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry21.createUnionType(jSTypeArray22);
        boolean boolean24 = jSTypeRegistry15.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        node28.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry6.createFunctionType(jSType23, node28);
        java.lang.String str33 = closureCodingConvention0.identifyTypeDefAssign(node28);
        int int34 = node28.getLineno();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.inlineFunctions = true;
        boolean boolean14 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean16 = compilerOptions0.lineBreak;
        boolean boolean17 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry4.createUnionType(jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] { jSType11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry4.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry4.getNativeObjectType(jSTypeNative14);
        com.google.javascript.jscomp.Scope scope16 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.createUnionType(jSTypeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.createUnionType(jSTypeArray25);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry19.createUnionType(jSTypeArray27);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.getNativeObjectType(jSTypeNative29);
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray31 = new com.google.javascript.rhino.jstype.ObjectType[] { objectType30 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32, objectTypeArray31);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry4, scope16, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32);
        jSTypeRegistry4.setTemplateTypeName("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry42.createUnionType(jSTypeArray43);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType49 = jSTypeRegistry47.createUnionType(jSTypeArray48);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] { jSType49 };
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry42.createUnionType(jSTypeArray50);
        com.google.javascript.rhino.Node node52 = jSTypeRegistry39.createParametersWithVarArgs(jSTypeArray50);
        com.google.javascript.rhino.Node node53 = jSTypeRegistry4.createParameters(jSTypeArray50);
        boolean boolean55 = jSTypeRegistry4.hasNamespace("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(objectTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator4);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile9, jSSourceFile12, jSSourceFile15 };
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] { jSModule18 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str21 = compilerOptions20.sourceMapOutputPath;
        boolean boolean22 = compilerOptions20.allowLegacyJsMessages;
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = true;
        compiler1.init(jSSourceFileArray16, jSModuleArray19, compilerOptions20);
        compilerOptions20.aliasAllStrings = true;
        boolean boolean28 = compilerOptions20.shouldColorizeErrorOutput();
        boolean boolean29 = compilerOptions20.convertToDottedProperties;
        java.lang.String str30 = compilerOptions20.locale;
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSModuleArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        int int7 = node3.getCharno();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node11.children();
        com.google.javascript.rhino.jstype.JSType jSType14 = node11.getJSType();
        boolean boolean15 = node3.checkTreeEqualsSilent(node11);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 29);
        compilerOptions0.closurePass = true;
        boolean boolean12 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention45 = compiler1.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
    }

//    @Test
//    public void test73() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test73");
//        try {
//            com.google.javascript.rhino.Context.reportError("function (): function (this:me, {1258761796}): me");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: function (): function (this:me, {1258761796}): me");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.createUnionType(jSTypeArray9);
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry5.createOptionalType(jSType10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
        boolean boolean23 = jSTypeRegistry14.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType22);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        node27.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry5.createFunctionType(jSType22, node27);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList32 = functionType31.getSubTypes();
        java.util.Set<java.lang.String> strSet33 = functionType31.getPropertyNames();
        compilerOptions0.stripNamePrefixes = strSet33;
        boolean boolean35 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertNull(functionTypeList32);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("ASSIGN_MOD  9\n", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        java.io.PrintStream printStream45 = null;
        com.google.javascript.jscomp.Compiler compiler46 = new com.google.javascript.jscomp.Compiler(printStream45);
        com.google.javascript.rhino.Node node47 = compiler46.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator49 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator49);
        com.google.javascript.jscomp.CompilerInput compilerInput51 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile50);
        com.google.javascript.jscomp.SourceFile.Generator generator53 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile54 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator53);
        com.google.javascript.jscomp.SourceFile.Generator generator56 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator56);
        com.google.javascript.jscomp.SourceFile.Generator generator59 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator59);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile50, jSSourceFile54, jSSourceFile57, jSSourceFile60 };
        com.google.javascript.jscomp.JSModule jSModule63 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] { jSModule63 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str66 = compilerOptions65.sourceMapOutputPath;
        boolean boolean67 = compilerOptions65.allowLegacyJsMessages;
        compilerOptions65.removeUnusedPrototypePropertiesInExterns = true;
        compiler46.init(jSSourceFileArray61, jSModuleArray64, compilerOptions65);
        compiler1.initOptions(compilerOptions65);
        boolean boolean72 = compilerOptions65.inlineConstantVars;
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
        org.junit.Assert.assertNull(node47);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSSourceFile54);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNamePrefixes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        compilerOptions0.instrumentForCoverage = true;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        java.lang.String str8 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.aliasStringsBlacklist = "function (): function (this:me, {1783660677}): me";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.checkSymbols = false;
        compilerOptions0.unaliasableGlobals = "hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkMissingReturn;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test80");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }
}

