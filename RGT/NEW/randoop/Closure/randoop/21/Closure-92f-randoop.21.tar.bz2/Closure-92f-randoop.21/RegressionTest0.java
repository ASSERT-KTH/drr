import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(16, node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node1, callback2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("hi!", "hi!", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_EXPRESSION_STATEMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_VAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setString("");
        com.google.javascript.rhino.Node node8 = null;
        try {
            com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(16, node4, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            boolean boolean6 = jSModuleGraph3.dependsOn(jSModule4, jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        try {
            ecmaError2.initColumnNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("hi!");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: hi!");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setString("");
        com.google.javascript.rhino.Node node7 = node3.removeFirstChild();
        try {
            boolean boolean9 = node7.getBooleanProp((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str2 = compilerOptions1.sourceMapOutputPath;
        boolean boolean3 = compilerOptions1.checkDuplicateMessages;
        java.lang.RuntimeException runtimeException4 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) (byte) 0, (java.lang.Object) boolean3);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(runtimeException4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node6 = null;
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        try {
            com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(100, node4, node6, node10, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "hi!", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setString("");
        com.google.javascript.rhino.Node node7 = node3.removeFirstChild();
        try {
            node7.putIntProp((int) (short) 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node5 = null;
        try {
            com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(38, node4, node5, (int) (byte) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str2 = compilerOptions1.sourceMapOutputPath;
        boolean boolean3 = compilerOptions1.checkDuplicateMessages;
        boolean boolean4 = compilerOptions1.checkCaja;
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) boolean4, (java.lang.Object) 100.0d);
        java.lang.Object[] objArray7 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.rhino.EcmaError ecmaError13 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        com.google.javascript.rhino.EcmaError ecmaError16 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        ecmaError13.addSuppressed((java.lang.Throwable) ecmaError16);
        try {
            java.lang.String str18 = com.google.javascript.rhino.ScriptRuntime.getMessage4("hi!", (java.lang.Object) runtimeException6, (java.lang.Object) objArray7, (java.lang.Object) checkLevel9, (java.lang.Object) ecmaError16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(ecmaError13);
        org.junit.Assert.assertNotNull(ecmaError16);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule4, jSModule5);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        try {
            com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        node4.setCharno(160);
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        node15.setType((int) 'a');
        boolean boolean19 = node15.hasOneChild();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 1, node11, node15);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        boolean boolean28 = node24.hasOneChild();
        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node37 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        node37.setType((int) 'a');
        boolean boolean41 = node37.hasOneChild();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 1, node33, node37);
        com.google.javascript.rhino.Node node46 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType47 = node46.getJSType();
        com.google.javascript.rhino.Node node48 = node46.getFirstChild();
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] { node4, node11, node24, node33, node48 };
        try {
            com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 1, nodeArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNull(node48);
        org.junit.Assert.assertNotNull(nodeArray49);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, false);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setType((int) 'a');
        boolean boolean8 = node4.hasOneChild();
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        node12.setType((int) 'a');
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType20 = node19.getJSType();
        node4.addChildAfter(node12, node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        node25.setString("");
        com.google.javascript.rhino.Node node29 = node25.removeFirstChild();
        try {
            com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1), node12, node29, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNull(node29);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setString("");
        com.google.javascript.rhino.Node node15 = node11.removeFirstChild();
        try {
            com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(10, node4, node7, node15, 160, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        boolean boolean3 = compilerOptions0.disambiguateProperties;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSError jSError2 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel3 = compiler1.getErrorLevel(jSError2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setString("");
        com.google.javascript.rhino.Node node7 = node3.removeFirstChild();
        try {
            node7.setWasEmptyNode(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "hi!", config3, errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        node8.setType((int) 'a');
        boolean boolean12 = node8.hasOneChild();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 1, node4, node8);
        com.google.javascript.rhino.Node node14 = node8.removeChildren();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.allowLegacyJsMessages;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str4 = compilerOptions3.sourceMapOutputPath;
        boolean boolean5 = compilerOptions3.isExternExportsEnabled();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str7 = compilerOptions6.sourceMapOutputPath;
        boolean boolean8 = compilerOptions6.collapseProperties;
        boolean boolean9 = compilerOptions6.aliasKeywords;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions6.checkGlobalNamesLevel;
        compilerOptions3.checkProvides = checkLevel10;
        com.google.javascript.jscomp.JSError jSError12 = null;
        try {
            loggerErrorManager2.report(checkLevel10, jSError12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        node8.setType((int) 'a');
        boolean boolean12 = node8.hasOneChild();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 1, node4, node8);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        node17.setType((int) 'a');
        boolean boolean21 = node17.hasOneChild();
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        node25.setType((int) 'a');
        com.google.javascript.rhino.Node node32 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        node17.addChildAfter(node25, node32);
        com.google.javascript.rhino.Node node35 = node4.copyInformationFrom(node17);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node35);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.SourceFile.Generator generator13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        com.google.javascript.jscomp.SourceFile.Generator generator17 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator17);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18);
        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator21);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray23 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile10, jSSourceFile14, jSSourceFile18, jSSourceFile22 };
        com.google.javascript.jscomp.JSModule jSModule24 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray25 = new com.google.javascript.jscomp.JSModule[] { jSModule24 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = null;
        try {
            compiler1.init(jSSourceFileArray23, jSModuleArray25, compilerOptions26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFileArray23);
        org.junit.Assert.assertNotNull(jSModuleArray25);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        java.lang.String str13 = node3.checkTreeEquals(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        node17.setString("");
        com.google.javascript.rhino.Node node21 = node17.removeFirstChild();
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        node25.setString("");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
        boolean boolean31 = node25.hasChild(node30);
        try {
            node3.addChildBefore(node21, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str13.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "hi!", "hi!");
        java.lang.String str5 = sourceFile3.getLine(0);
        java.lang.String str6 = sourceFile3.getName();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        try {
            java.util.Collection<java.lang.String> strCollection4 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            boolean boolean2 = compiler1.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy2 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions1.propertyRenaming = propertyRenamingPolicy2;
        com.google.javascript.jscomp.SourceMap.Format format4 = null;
        compilerOptions1.sourceMapFormat = format4;
        compilerOptions1.setDefineToStringLiteral("", "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        java.lang.Object obj9 = null;
        try {
            java.lang.String str10 = com.google.javascript.rhino.ScriptRuntime.getMessage2("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", (java.lang.Object) compilerOptions1, obj9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy2.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        boolean boolean3 = compilerOptions0.checkCaja;
        compilerOptions0.checkDuplicateMessages = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.removeDeadCode = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat6 = null;
        compilerOptions0.errorFormat = errorFormat6;
        compilerOptions0.checkEs5Strict = true;
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_PARAMETER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        compilerOptions0.lineBreak = false;
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 1, node5, node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat18 = diagnosticType17.format;
        java.lang.String[] strArray19 = null;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("hi!", node9, diagnosticType17, strArray19);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node9.siblings();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(messageFormat18);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNotNull(nodeIterable21);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.Result result2 = compiler1.getResult();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        ecmaError2.initSourceName("");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str2 = compilerOptions1.sourceMapOutputPath;
        boolean boolean3 = compilerOptions1.collapseProperties;
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet7 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet7, strArray6);
        compilerOptions1.stripNameSuffixes = strSet7;
        compilerOptions1.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions1.checkRequires;
        try {
            java.lang.String str13 = com.google.javascript.rhino.ScriptRuntime.getMessage1("ASSIGN_MOD  9\n", (java.lang.Object) compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ASSIGN_MOD  9\n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        try {
//            com.google.javascript.rhino.Context.reportError("ASSIGN_MOD  9\n");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ASSIGN_MOD  9\n");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.enableExternExports(false);
        compilerOptions0.setDefineToBooleanLiteral("hi!", false);
        compilerOptions0.nameReferenceGraphPath = "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("", '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.removeDeadCode = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat6 = null;
        compilerOptions0.errorFormat = errorFormat6;
        boolean boolean8 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.strictMessageReplacement = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        boolean boolean9 = compilerOptions7.collapseProperties;
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet13 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet13, strArray12);
        compilerOptions7.stripNameSuffixes = strSet13;
        compilerOptions7.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions7.checkRequires;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel18;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        try {
            com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.copyFromOtherFunction(functionType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        boolean boolean9 = node3.hasChild(node8);
        com.google.javascript.rhino.Node node10 = null;
        try {
            com.google.javascript.rhino.Node node11 = node3.clonePropsFrom(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap3 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap3;
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean4 = compilerOptions0.checkCaja;
        compilerOptions0.strictMessageReplacement = true;
        boolean boolean7 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        try {
            double double2 = node1.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING  is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        node16.setType((int) 'a');
        boolean boolean20 = node16.hasOneChild();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 1, node12, node16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str23 = compilerOptions22.sourceMapOutputPath;
        boolean boolean24 = compilerOptions22.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap25 = null;
        compilerOptions22.cssRenamingMap = cssRenamingMap25;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.reportUnknownTypes;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str31 = diagnosticType30.toString();
        java.lang.String[] strArray33 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("hi!", node12, checkLevel27, diagnosticType30, strArray33);
        java.lang.String[] strArray36 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("ASSIGN_MOD  9\n", (int) '#', 7, diagnosticType30, strArray36);
        try {
            com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(": hi!", (-2), (int) (short) 0, diagnosticType3, strArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + ": hi!" + "'", str31.equals(": hi!"));
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(36);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "setelem" + "'", str1.equals("setelem"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator4);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        try {
            com.google.javascript.rhino.Node node7 = compiler1.parse(jSSourceFile5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createOptionalNullableType(jSType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkFunctions = checkLevel11;
        java.util.Set<java.lang.String> strSet13 = null;
        compilerOptions0.stripNameSuffixes = strSet13;
        compilerOptions0.setOutputCharset("setelem");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        boolean boolean3 = compilerOptions0.checkCaja;
        compilerOptions0.specializeInitialModule = false;
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean3 = compilerOptions0.ideMode;
        compilerOptions0.deadAssignmentElimination = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            java.lang.String str5 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        ecmaError2.addSuppressed((java.lang.Throwable) ecmaError5);
        java.lang.String str7 = ecmaError2.getName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        try {
            java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection10 = jSTypeRegistry2.getDirectImplementors(objectType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        try {
            com.google.javascript.jscomp.JSModule jSModule7 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str3 = diagnosticType2.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType2.level;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ": hi!" + "'", str3.equals(": hi!"));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        java.lang.String str3 = ecmaError2.getName();
        java.lang.String str4 = ecmaError2.sourceName();
        ecmaError2.initColumnNumber((int) (byte) 1);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.checkCaja = true;
        boolean boolean9 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        compilerOptions0.sourceMapOutputPath = "hi!";
        compilerOptions0.checkDuplicateMessages = true;
        boolean boolean9 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        try {
            java.lang.String str5 = compilerInput3.getLine((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray6;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str9 = compilerOptions8.sourceMapOutputPath;
        boolean boolean10 = compilerOptions8.collapseProperties;
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        compilerOptions8.stripNameSuffixes = strSet14;
        compilerOptions8.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions8.checkRequires;
        compilerOptions8.inlineFunctions = true;
        java.util.Set<java.lang.String> strSet22 = compilerOptions8.stripNamePrefixes;
        compilerOptions0.stripTypes = strSet22;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet22);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setType((int) 'a');
        boolean boolean8 = node4.hasOneChild();
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        node12.setType((int) 'a');
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType20 = node19.getJSType();
        node4.addChildAfter(node12, node19);
        try {
            boolean boolean22 = closureCodingConvention0.isPropertyTestFunction(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(jSType20);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup22, checkLevel23);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard27 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup25, checkLevel26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel29);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard33 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup31, checkLevel32);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup34, checkLevel35);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup37, checkLevel38);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray40 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard24, diagnosticGroupWarningsGuard27, diagnosticGroupWarningsGuard30, diagnosticGroupWarningsGuard33, diagnosticGroupWarningsGuard36, diagnosticGroupWarningsGuard39 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard41 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        node51.setType((int) 'a');
        boolean boolean55 = node51.hasOneChild();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) 1, node47, node51);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat60 = diagnosticType59.format;
        java.lang.String[] strArray61 = null;
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("hi!", node51, diagnosticType59, strArray61);
        com.google.javascript.jscomp.CheckLevel checkLevel63 = composeWarningsGuard41.level(jSError62);
        com.google.javascript.jscomp.CheckLevel checkLevel64 = composeWarningsGuard21.level(jSError62);
        compiler1.report(jSError62);
        try {
            boolean boolean66 = compiler1.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroup34);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertNotNull(warningsGuardArray40);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(messageFormat60);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(checkLevel63);
        org.junit.Assert.assertNull(checkLevel64);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        boolean boolean9 = node3.hasChild(node8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        node13.setString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        boolean boolean19 = node13.hasChild(node18);
        com.google.javascript.rhino.Node node20 = null;
        try {
            node8.replaceChildAfter(node18, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        try {
//            com.google.javascript.rhino.Context.reportError("setelem", "", 36, ": hi!", 38);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: setelem (#36)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager2.getWarnings();
        org.junit.Assert.assertNotNull(jSErrorArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (short) -1);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("", "setelem", "ASSIGN_MOD  9\n", "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            boolean boolean2 = compiler1.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.lang.String str5 = compilerInput3.getName();
        boolean boolean6 = compilerInput3.isExtern();
        try {
            java.lang.String str7 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node5 = node3.getFirstChild();
        int int6 = node3.getCharno();
        node3.setCharno(32);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        boolean boolean9 = jSType7.isStringObjectType();
        boolean boolean10 = jSType7.canBeCalled();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setType((int) 'a');
        boolean boolean8 = node4.hasOneChild();
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        java.lang.String str14 = node4.checkTreeEquals(node12);
        node4.addSuppression("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        try {
            boolean boolean17 = closureCodingConvention0.isPropertyTestFunction(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str14.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager2.getErrors();
        org.junit.Assert.assertNotNull(jSErrorArray3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 1, node5, node9);
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node18.setString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        boolean boolean24 = node18.hasChild(node23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        node28.setString("");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        boolean boolean34 = node28.hasChild(node33);
        try {
            com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) 10, node5, node18, node28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((-2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 38, (java.lang.Object) (-1L), (java.lang.Object) node10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        node15.setType((int) 'a');
        boolean boolean19 = node15.hasOneChild();
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        java.lang.String str25 = node15.checkTreeEquals(node23);
        boolean boolean26 = node10.isEquivalentTo(node15);
        node3.addChildToBack(node10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
        node39.setType((int) 'a');
        com.google.javascript.rhino.Node node46 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType47 = node46.getJSType();
        node31.addChildAfter(node39, node46);
        java.lang.String str49 = node39.toStringTree();
        try {
            node3.addChildrenToBack(node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str25.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ASSIGN_MOD  9\n" + "'", str49.equals("ASSIGN_MOD  9\n"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.lang.String str5 = compilerInput3.getName();
        try {
            java.lang.String str6 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray6;
        compilerOptions0.gatherCssNames = true;
        boolean boolean10 = compilerOptions0.aliasExternals;
        boolean boolean11 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder1.withParams(functionParamBuilder3);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType5 = functionBuilder4.build();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(functionBuilder4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node3.addChildAfter(node11, node18);
        java.lang.String str21 = node11.toStringTree();
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        node25.setType((int) 'a');
        boolean boolean29 = node25.hasOneChild();
        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
        node33.setType((int) 'a');
        com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        node25.addChildAfter(node33, node40);
        boolean boolean43 = node11.checkTreeTypeAwareEqualsSilent(node33);
        node33.setType(1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ASSIGN_MOD  9\n" + "'", str21.equals("ASSIGN_MOD  9\n"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setDefineToNumberLiteral(": hi!", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup22, checkLevel23);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard27 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup25, checkLevel26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel29);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard33 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup31, checkLevel32);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup34, checkLevel35);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup37, checkLevel38);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray40 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard24, diagnosticGroupWarningsGuard27, diagnosticGroupWarningsGuard30, diagnosticGroupWarningsGuard33, diagnosticGroupWarningsGuard36, diagnosticGroupWarningsGuard39 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard41 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        node51.setType((int) 'a');
        boolean boolean55 = node51.hasOneChild();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) 1, node47, node51);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat60 = diagnosticType59.format;
        java.lang.String[] strArray61 = null;
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("hi!", node51, diagnosticType59, strArray61);
        com.google.javascript.jscomp.CheckLevel checkLevel63 = composeWarningsGuard41.level(jSError62);
        com.google.javascript.jscomp.CheckLevel checkLevel64 = composeWarningsGuard21.level(jSError62);
        compiler1.report(jSError62);
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroup34);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertNotNull(warningsGuardArray40);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(messageFormat60);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(checkLevel63);
        org.junit.Assert.assertNull(checkLevel64);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder5 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry4);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder6 = functionBuilder3.withParams(functionParamBuilder5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        node10.setType((int) 'a');
        boolean boolean14 = node10.hasOneChild();
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node18.setType((int) 'a');
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        node10.addChildAfter(node18, node25);
        java.lang.String str28 = node18.toStringTree();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder29 = functionBuilder6.withParamsNode(node18);
        try {
            java.lang.String str30 = closureCodingConvention0.getSingletonGetterClassName(node18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(functionBuilder6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ASSIGN_MOD  9\n" + "'", str28.equals("ASSIGN_MOD  9\n"));
        org.junit.Assert.assertNotNull(functionBuilder29);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard3 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup1, checkLevel2);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup1;
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.createUnionType(jSTypeArray9);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry13.createUnionType(jSTypeArray14);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] { jSType15 };
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry8.createUnionType(jSTypeArray16);
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        node21.setType((int) 'a');
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        node29.setType((int) 'a');
        com.google.javascript.rhino.Node node36 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType37 = node36.getJSType();
        node21.addChildAfter(node29, node36);
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean40 = compilerOptions39.collapseVariableDeclarations;
        java.util.Set<java.lang.String> strSet41 = null;
        compilerOptions39.stripNamePrefixes = strSet41;
        compilerOptions39.exportTestFunctions = false;
        compilerOptions39.instrumentForCoverageOnly = false;
        compilerOptions39.setRemoveAbstractMethods(true);
        try {
            java.lang.String str49 = com.google.javascript.rhino.ScriptRuntime.getMessage4("ASSIGN_MOD  9\n", (java.lang.Object) diagnosticGroup1, (java.lang.Object) jSTypeArray16, (java.lang.Object) node21, (java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ASSIGN_MOD  9\n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.String[] strArray0 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 1, node5, node9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str16 = compilerOptions15.sourceMapOutputPath;
        boolean boolean17 = compilerOptions15.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions15.cssRenamingMap = cssRenamingMap18;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions15.reportUnknownTypes;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str24 = diagnosticType23.toString();
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("hi!", node5, checkLevel20, diagnosticType23, strArray26);
        int int28 = jSError27.lineNumber;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + ": hi!" + "'", str24.equals(": hi!"));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node3.addChildAfter(node11, node18);
        java.lang.String str21 = node11.toStringTree();
        node11.setVarArgs(false);
        com.google.javascript.rhino.Node node24 = node11.getFirstChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ASSIGN_MOD  9\n" + "'", str21.equals("ASSIGN_MOD  9\n"));
        org.junit.Assert.assertNull(node24);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup22, checkLevel23);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard27 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup25, checkLevel26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel29);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard33 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup31, checkLevel32);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup34, checkLevel35);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup37, checkLevel38);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray40 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard24, diagnosticGroupWarningsGuard27, diagnosticGroupWarningsGuard30, diagnosticGroupWarningsGuard33, diagnosticGroupWarningsGuard36, diagnosticGroupWarningsGuard39 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard41 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        node51.setType((int) 'a');
        boolean boolean55 = node51.hasOneChild();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) 1, node47, node51);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat60 = diagnosticType59.format;
        java.lang.String[] strArray61 = null;
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("hi!", node51, diagnosticType59, strArray61);
        com.google.javascript.jscomp.CheckLevel checkLevel63 = composeWarningsGuard41.level(jSError62);
        com.google.javascript.jscomp.CheckLevel checkLevel64 = composeWarningsGuard21.level(jSError62);
        compiler1.report(jSError62);
        try {
            java.lang.String str66 = compiler1.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroup34);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertNotNull(warningsGuardArray40);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(messageFormat60);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(checkLevel63);
        org.junit.Assert.assertNull(checkLevel64);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("ASSIGN_MOD  9\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str2 = compilerOptions1.sourceMapOutputPath;
        compilerOptions1.setNameAnonymousFunctionsOnly(false);
        boolean boolean5 = compilerOptions1.inlineLocalFunctions;
        compilerOptions1.closurePass = false;
        boolean boolean8 = compilerOptions1.inlineVariables;
        compilerOptions1.reportPath = "setelem";
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy12 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions11.propertyRenaming = propertyRenamingPolicy12;
        boolean boolean14 = compilerOptions11.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions11.reportMissingOverride;
        compilerOptions1.checkGlobalThisLevel = checkLevel15;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel15);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy12 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy12.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("goog.global", checkLevel1, "");
        org.junit.Assert.assertNotNull(diagnosticType3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean7 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        compilerOptions0.inlineLocalFunctions = false;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ASSIGN_MOD  9\n");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean6 = compilerOptions0.closurePass;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        try {
            int int3 = compiler1.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        node8.setType((int) 'a');
        boolean boolean12 = node8.hasOneChild();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 1, node4, node8);
        boolean boolean14 = node8.isLocalResultCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        boolean boolean9 = jSType7.isStringObjectType();
        boolean boolean10 = jSType7.isEmptyType();
        boolean boolean12 = jSType7.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 38, (java.lang.Object) (-1L), (java.lang.Object) node9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        node14.setType((int) 'a');
        boolean boolean18 = node14.hasOneChild();
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        java.lang.String str24 = node14.checkTreeEquals(node22);
        boolean boolean25 = node9.isEquivalentTo(node14);
        com.google.javascript.rhino.Node node26 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.createUnionType(jSTypeArray33);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry29.createOptionalType(jSType34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry41.createUnionType(jSTypeArray42);
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry38.createOptionalType(jSType43);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair45 = jSType34.getTypesUnderShallowInequality(jSType44);
        boolean boolean46 = jSType44.isStringValueType();
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry2.createConstructorType("ASSIGN_MOD  9\n", node14, node26, jSType44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str24.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(typePair45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str15 = compilerOptions14.sourceMapOutputPath;
        boolean boolean16 = compilerOptions14.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = null;
        compilerOptions14.checkGlobalThisLevel = checkLevel17;
        java.lang.String[] strArray24 = new java.lang.String[] { "ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n", "hi!", "ASSIGN_MOD  9\n" };
        java.util.ArrayList<java.lang.String> strList25 = new java.util.ArrayList<java.lang.String>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList25, strArray24);
        compilerOptions14.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList25);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList25);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        compilerOptions0.inlineLocalFunctions = false;
        boolean boolean5 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        java.lang.String str3 = ecmaError2.getName();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str5 = compilerOptions4.sourceMapOutputPath;
        compilerOptions4.setNameAnonymousFunctionsOnly(false);
        boolean boolean8 = compilerOptions4.inlineLocalFunctions;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) ecmaError2, (java.lang.Object) compilerOptions4, (java.lang.Object) jSTypeNative9);
        try {
            ecmaError2.initLineNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN));
        org.junit.Assert.assertNotNull(runtimeException10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup3;
        try {
            boolean boolean5 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", ": hi!", 0, ": hi!", 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        boolean boolean15 = node11.hasOneChild();
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType20 = node19.getJSType();
        node19.setType((int) 'a');
        com.google.javascript.rhino.Node node26 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        node11.addChildAfter(node19, node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        node32.setCharno(160);
        com.google.javascript.rhino.Node node38 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable40 = node38.children();
        com.google.javascript.rhino.jstype.JSType jSType41 = node38.getJSType();
        try {
            com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(12, node4, node19, node32, node38, 9, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(nodeIterable40);
        org.junit.Assert.assertNull(jSType41);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        java.lang.String str3 = ecmaError2.getName();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str5 = compilerOptions4.sourceMapOutputPath;
        compilerOptions4.setNameAnonymousFunctionsOnly(false);
        boolean boolean8 = compilerOptions4.inlineLocalFunctions;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) ecmaError2, (java.lang.Object) compilerOptions4, (java.lang.Object) jSTypeNative9);
        compilerOptions4.jsOutputFile = ": hi!";
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN));
        org.junit.Assert.assertNotNull(runtimeException10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSType11.resolve(errorReporter12, jSTypeStaticScope13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.createUnionType(jSTypeArray23);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] { jSType24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry17.createUnionType(jSTypeArray25);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope28 = null;
        com.google.javascript.rhino.jstype.JSType jSType29 = jSType26.resolve(errorReporter27, jSTypeStaticScope28);
        boolean boolean30 = jSType11.canTestForEqualityWith(jSType29);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean4 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.closurePass = false;
        boolean boolean7 = compilerOptions0.inlineVariables;
        boolean boolean8 = compilerOptions0.inlineAnonymousFunctionExpressions;
        boolean boolean9 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph4.getDeepestCommonDependencyInclusive(jSModule6, jSModule8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        jSModule8.add(jSSourceFile12);
        try {
            java.lang.String str14 = jSModule8.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkRequires;
        compilerOptions0.printInputDelimiter = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions6.propertyRenaming = propertyRenamingPolicy7;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy7;
        boolean boolean10 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        node8.setType((int) 'a');
        boolean boolean12 = node8.hasOneChild();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 1, node4, node8);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node4.siblings();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(nodeIterable14);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule5 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7, jSModuleArray6);
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = jSModule9.getByName("");
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jSModule9);
        org.junit.Assert.assertNull(compilerInput11);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
        boolean boolean12 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.createUnionType(jSTypeArray9);
        boolean boolean11 = jSTypeRegistry2.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType10);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope12 = null;
        jSTypeRegistry2.resolveTypesInScope(jSTypeStaticScope12);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        compilerOptions0.inlineLocalFunctions = false;
        boolean boolean5 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        node10.setType((int) 'a');
        boolean boolean14 = node10.hasOneChild();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 1, node6, node10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat19 = diagnosticType18.format;
        java.lang.String[] strArray20 = null;
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("hi!", node10, diagnosticType18, strArray20);
        boolean boolean22 = diagnosticGroup0.matches(jSError21);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(messageFormat19);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.setDefineToNumberLiteral("", (int) (short) 0);
        boolean boolean7 = compilerOptions0.removeEmptyFunctions;
        boolean boolean8 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkFunctions = checkLevel11;
        java.util.Set<java.lang.String> strSet13 = null;
        compilerOptions0.stripNameSuffixes = strSet13;
        boolean boolean15 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean16 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator4);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile9, jSSourceFile12, jSSourceFile15 };
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] { jSModule18 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str21 = compilerOptions20.sourceMapOutputPath;
        boolean boolean22 = compilerOptions20.allowLegacyJsMessages;
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = true;
        compiler1.init(jSSourceFileArray16, jSModuleArray19, compilerOptions20);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder26 = null;
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
        java.lang.String str41 = node31.checkTreeEquals(node39);
        int int42 = node39.getChildCount();
        compiler1.toSource(codeBuilder26, (int) (byte) 100, node39);
        boolean boolean44 = compiler1.isTypeCheckingEnabled();
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSModuleArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str41.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setType((int) 'a');
        boolean boolean9 = node5.hasOneChild();
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        node13.setType((int) 'a');
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        node5.addChildAfter(node13, node20);
        com.google.javascript.rhino.Node node23 = functionParamBuilder1.newParameterFromNode(node13);
        com.google.javascript.rhino.Node node24 = functionParamBuilder1.build();
        com.google.javascript.rhino.Node node30 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        java.lang.RuntimeException runtimeException31 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 38, (java.lang.Object) (-1L), (java.lang.Object) node30);
        com.google.javascript.rhino.Node node35 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        node35.setType((int) 'a');
        boolean boolean39 = node35.hasOneChild();
        com.google.javascript.rhino.Node node43 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType44 = node43.getJSType();
        java.lang.String str45 = node35.checkTreeEquals(node43);
        boolean boolean46 = node30.isEquivalentTo(node35);
        com.google.javascript.rhino.Node node50 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        node50.setString("");
        try {
            node24.replaceChild(node35, node50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(runtimeException31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(jSType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str45.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("function (): function (this:me, {1311234794}): me", "setelem", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        try {
            com.google.javascript.jscomp.JSModule[] jSModuleArray5 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkFunctions = checkLevel11;
        compilerOptions0.markAsCompiled = true;
        boolean boolean15 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7, jSModuleArray6);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph10 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        com.google.javascript.jscomp.JSModule jSModule12 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule14 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule15 = jSModuleGraph10.getDeepestCommonDependencyInclusive(jSModule12, jSModule14);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        jSModule14.add(jSSourceFile18);
        try {
            compilerInput3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jSModule15);
        org.junit.Assert.assertNotNull(jSSourceFile18);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        boolean boolean9 = node3.hasChild(node8);
        boolean boolean11 = node8.getBooleanProp((int) (byte) 1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        node12.setType((int) 'a');
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 1, node8, node12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str19 = compilerOptions18.sourceMapOutputPath;
        boolean boolean20 = compilerOptions18.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap21 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap21;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.reportUnknownTypes;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str27 = diagnosticType26.toString();
        java.lang.String[] strArray29 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("hi!", node8, checkLevel23, diagnosticType26, strArray29);
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("ASSIGN_MOD  9\n", (int) '#', 7, diagnosticType26, strArray32);
        java.lang.String str34 = jSError33.sourceName;
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + ": hi!" + "'", str27.equals(": hi!"));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ASSIGN_MOD  9\n" + "'", str34.equals("ASSIGN_MOD  9\n"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripNamePrefixes = strSet2;
        compilerOptions0.exportTestFunctions = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str9 = compilerOptions8.sourceMapOutputPath;
        compilerOptions8.setNameAnonymousFunctionsOnly(false);
        boolean boolean12 = compilerOptions8.inlineLocalFunctions;
        compilerOptions8.closurePass = false;
        boolean boolean15 = compilerOptions8.inlineVariables;
        compilerOptions8.reportPath = "setelem";
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy19 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions18.propertyRenaming = propertyRenamingPolicy19;
        boolean boolean21 = compilerOptions18.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions18.reportMissingOverride;
        compilerOptions8.checkGlobalThisLevel = checkLevel22;
        compilerOptions0.checkUnreachableCode = checkLevel22;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy19.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.createUnionType(jSTypeArray9);
        boolean boolean11 = jSTypeRegistry2.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType10);
        boolean boolean12 = jSType10.isStringValueType();
        com.google.javascript.rhino.jstype.JSType jSType13 = jSType10.autoboxesTo();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(jSType13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard8 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup9, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel13);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel16);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray18 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2, diagnosticGroupWarningsGuard5, diagnosticGroupWarningsGuard8, diagnosticGroupWarningsGuard11, diagnosticGroupWarningsGuard14, diagnosticGroupWarningsGuard17 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard19 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        try {
            boolean boolean21 = composeWarningsGuard19.enables(diagnosticGroup20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertNotNull(warningsGuardArray18);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "");
        java.lang.String str3 = ecmaError2.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        ecmaError2.addSuppressed((java.lang.Throwable) ecmaError5);
        ecmaError2.initLineSource("ASSIGN_MOD  9\n");
        java.io.FilenameFilter filenameFilter9 = null;
        java.lang.String str10 = ecmaError2.getScriptStackTrace(filenameFilter9);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "<No stack trace available>" + "'", str10.equals("<No stack trace available>"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        boolean boolean5 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        boolean boolean30 = functionType28.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat6 = diagnosticType5.format;
        java.lang.String[] strArray7 = null;
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(": hi!", (int) '4', (int) (byte) 0, diagnosticType5, strArray7);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(messageFormat6);
        org.junit.Assert.assertNotNull(jSError8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 1, node5, node9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str16 = compilerOptions15.sourceMapOutputPath;
        boolean boolean17 = compilerOptions15.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions15.cssRenamingMap = cssRenamingMap18;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions15.reportUnknownTypes;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str24 = diagnosticType23.toString();
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("hi!", node5, checkLevel20, diagnosticType23, strArray26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        com.google.javascript.rhino.Node node38 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        node38.setString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        boolean boolean44 = node38.hasChild(node43);
        node5.addChildAfter(node31, node38);
        boolean boolean46 = node31.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + ": hi!" + "'", str24.equals(": hi!"));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        com.google.javascript.rhino.Node node7 = node3.removeFirstChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setString("");
        com.google.javascript.rhino.Node node15 = node11.removeFirstChild();
        try {
            node3.addChildToBack(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry33.createUnionType(jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry38.createUnionType(jSTypeArray39);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { jSType40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry33.createUnionType(jSTypeArray41);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry33.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType28.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) objectType44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue47 = objectType44.testForEquality(jSType46);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(ternaryValue47);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String str2 = compiler1.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.collapseProperties;
        com.google.javascript.jscomp.MessageBundle messageBundle4 = null;
        compilerOptions0.messageBundle = messageBundle4;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        java.lang.String str7 = compilerOptions0.jsOutputFile;
        boolean boolean8 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String[] strArray2 = compiler1.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard8 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup9, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel13);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel16);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray18 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2, diagnosticGroupWarningsGuard5, diagnosticGroupWarningsGuard8, diagnosticGroupWarningsGuard11, diagnosticGroupWarningsGuard14, diagnosticGroupWarningsGuard17 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard19 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup20, checkLevel21);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup23, checkLevel24);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard28 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup26, checkLevel27);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup29 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard31 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup29, checkLevel30);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup32 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard34 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup32, checkLevel33);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup35 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard37 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup35, checkLevel36);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray38 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard22, diagnosticGroupWarningsGuard25, diagnosticGroupWarningsGuard28, diagnosticGroupWarningsGuard31, diagnosticGroupWarningsGuard34, diagnosticGroupWarningsGuard37 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard39 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray38);
        com.google.javascript.rhino.Node node45 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node49 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType50 = node49.getJSType();
        node49.setType((int) 'a');
        boolean boolean53 = node49.hasOneChild();
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (short) 1, node45, node49);
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat58 = diagnosticType57.format;
        java.lang.String[] strArray59 = null;
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make("hi!", node49, diagnosticType57, strArray59);
        com.google.javascript.jscomp.CheckLevel checkLevel61 = composeWarningsGuard39.level(jSError60);
        com.google.javascript.jscomp.CheckLevel checkLevel62 = composeWarningsGuard19.level(jSError60);
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = jSError60.getType();
        java.lang.String str64 = jSError60.sourceName;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertNotNull(warningsGuardArray18);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
        org.junit.Assert.assertNotNull(diagnosticGroup23);
        org.junit.Assert.assertNotNull(diagnosticGroup26);
        org.junit.Assert.assertNotNull(diagnosticGroup29);
        org.junit.Assert.assertNotNull(diagnosticGroup32);
        org.junit.Assert.assertNotNull(diagnosticGroup35);
        org.junit.Assert.assertNotNull(warningsGuardArray38);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(jSType50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertNotNull(messageFormat58);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNull(checkLevel61);
        org.junit.Assert.assertNull(checkLevel62);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap3 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap3;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.inlineFunctions = true;
        java.util.Set<java.lang.String> strSet14 = compilerOptions0.stripNamePrefixes;
        boolean boolean15 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.syntheticBlockEndMarker = "goog.abstractMethod";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str4 = diagnosticType3.toString();
        boolean boolean5 = diagnosticGroup0.matches(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": hi!" + "'", str4.equals(": hi!"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph4.getDeepestCommonDependencyInclusive(jSModule6, jSModule8);
        int int10 = jSModule6.getDepth();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.rhino.Node node3 = compiler1.getRoot();
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        boolean boolean7 = compilerOptions0.reserveRawExports;
        compilerOptions0.checkEs5Strict = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node5 = node3.getFirstChild();
        int int6 = node3.getCharno();
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable12 = node10.children();
        boolean boolean13 = node10.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = null;
        try {
            node3.replaceChild(node10, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(nodeIterable12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        compilerInput3.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager1.getWarnings();
        org.junit.Assert.assertNotNull(jSErrorArray3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry31.createUnionType(jSTypeArray32);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry36.createUnionType(jSTypeArray37);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] { jSType38 };
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry31.createUnionType(jSTypeArray39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope42 = null;
        com.google.javascript.rhino.jstype.JSType jSType43 = jSType40.resolve(errorReporter41, jSTypeStaticScope42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.createUnionType(jSTypeArray50);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry46.createOptionalType(jSType51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry55.createUnionType(jSTypeArray56);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry61.createUnionType(jSTypeArray62);
        boolean boolean64 = jSTypeRegistry55.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType63);
        com.google.javascript.rhino.Node node68 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType69 = node68.getJSType();
        node68.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry46.createFunctionType(jSType63, node68);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList73 = functionType72.getSubTypes();
        java.util.Set<java.lang.String> strSet74 = functionType72.getPropertyNames();
        boolean boolean75 = functionType72.isInstanceType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] { jSType40, functionType72 };
        com.google.javascript.rhino.Node node77 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray76);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(jSTypeArray62);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(jSType69);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertNull(functionTypeList73);
        org.junit.Assert.assertNotNull(strSet74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(node77);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        boolean boolean9 = jSType8.isCheckedUnknownType();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str4 = compilerOptions3.sourceMapOutputPath;
        compilerOptions3.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions3.reportMissingOverride;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard8 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel7);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context1.isActivationNeeded("function (): function (this:me, {1311234794}): me");
        boolean boolean4 = context1.isSealed();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.enableRuntimeTypeCheck("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.createUnionType(jSTypeArray17);
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry13.createOptionalType(jSType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.createUnionType(jSTypeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry28.createUnionType(jSTypeArray29);
        boolean boolean31 = jSTypeRegistry22.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType30);
        com.google.javascript.rhino.Node node35 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        node35.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry13.createFunctionType(jSType30, node35);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList40 = functionType39.getSubTypes();
        java.util.Set<java.lang.String> strSet41 = functionType39.getPropertyNames();
        compilerOptions0.stripTypes = strSet41;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNull(functionTypeList40);
        org.junit.Assert.assertNotNull(strSet41);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        ecmaError2.addSuppressed((java.lang.Throwable) ecmaError5);
        java.lang.String str7 = ecmaError2.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.createUnionType(jSTypeArray11);
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry7.createOptionalType(jSType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.createUnionType(jSTypeArray17);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.createUnionType(jSTypeArray23);
        boolean boolean25 = jSTypeRegistry16.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType24);
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        node29.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry7.createFunctionType(jSType24, node29);
        boolean boolean34 = jSType4.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.jstype.JSType jSType36 = functionType33.getPropertyType("");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(jSType36);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str2 = compilerOptions1.sourceMapOutputPath;
        boolean boolean3 = compilerOptions1.allowLegacyJsMessages;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel4 = null;
        compilerOptions1.sourceMapDetailLevel = detailLevel4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions1.checkGlobalNamesLevel;
        context0.removeThreadLocal((java.lang.Object) compilerOptions1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        ecmaError2.addSuppressed((java.lang.Throwable) ecmaError5);
        ecmaError2.initLineSource("ASSIGN_MOD  9\n");
        java.lang.String str9 = ecmaError2.getLineSource();
        java.lang.String str10 = ecmaError2.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ASSIGN_MOD  9\n" + "'", str9.equals("ASSIGN_MOD  9\n"));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        compilerOptions0.sourceMapOutputPath = "hi!";
        compilerOptions0.checkDuplicateMessages = true;
        boolean boolean9 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkFunctions = checkLevel11;
        java.util.Set<java.lang.String> strSet13 = null;
        compilerOptions0.stripNameSuffixes = strSet13;
        boolean boolean15 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str17 = compilerOptions16.sourceMapOutputPath;
        boolean boolean18 = compilerOptions16.collapseProperties;
        boolean boolean19 = compilerOptions16.collapseProperties;
        compilerOptions16.checkUnusedPropertiesEarly = true;
        java.util.Set<java.lang.String> strSet22 = compilerOptions16.stripTypePrefixes;
        compilerOptions0.stripTypes = strSet22;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strSet22);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        try {
            com.google.javascript.rhino.jstype.EnumType enumType7 = jSTypeRegistry2.createEnumType("function (): function (this:me, {1311234794}): me", jSType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry34.createUnionType(jSTypeArray35);
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry31.createOptionalType(jSType36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry40.createUnionType(jSTypeArray41);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.createUnionType(jSTypeArray47);
        boolean boolean49 = jSTypeRegistry40.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType48);
        com.google.javascript.rhino.Node node53 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        node53.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry31.createFunctionType(jSType48, node53);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList58 = functionType57.getSubTypes();
        java.util.Set<java.lang.String> strSet59 = functionType57.getPropertyNames();
        node24.setDirectives(strSet59);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(functionTypeList58);
        org.junit.Assert.assertNotNull(strSet59);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.lang.String str5 = compilerInput3.getName();
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup20, checkLevel21);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup23, checkLevel24);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray26 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19, diagnosticGroupWarningsGuard22, diagnosticGroupWarningsGuard25 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel29);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard33 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup31, checkLevel32);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup34, checkLevel35);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup37, checkLevel38);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup40 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard42 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup40, checkLevel41);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup43 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard45 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup43, checkLevel44);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray46 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard30, diagnosticGroupWarningsGuard33, diagnosticGroupWarningsGuard36, diagnosticGroupWarningsGuard39, diagnosticGroupWarningsGuard42, diagnosticGroupWarningsGuard45 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard47 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray46);
        com.google.javascript.rhino.Node node53 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node57 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType58 = node57.getJSType();
        node57.setType((int) 'a');
        boolean boolean61 = node57.hasOneChild();
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (short) 1, node53, node57);
        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat66 = diagnosticType65.format;
        java.lang.String[] strArray67 = null;
        com.google.javascript.jscomp.JSError jSError68 = com.google.javascript.jscomp.JSError.make("hi!", node57, diagnosticType65, strArray67);
        com.google.javascript.jscomp.CheckLevel checkLevel69 = composeWarningsGuard47.level(jSError68);
        com.google.javascript.jscomp.CheckLevel checkLevel70 = composeWarningsGuard27.level(jSError68);
        compiler7.report(jSError68);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        com.google.javascript.jscomp.SourceMap sourceMap73 = compiler7.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager74 = compiler7.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
        org.junit.Assert.assertNotNull(diagnosticGroup23);
        org.junit.Assert.assertNotNull(warningsGuardArray26);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroup34);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertNotNull(diagnosticGroup40);
        org.junit.Assert.assertNotNull(diagnosticGroup43);
        org.junit.Assert.assertNotNull(warningsGuardArray46);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(diagnosticType65);
        org.junit.Assert.assertNotNull(messageFormat66);
        org.junit.Assert.assertNotNull(jSError68);
        org.junit.Assert.assertNull(checkLevel69);
        org.junit.Assert.assertNull(checkLevel70);
        org.junit.Assert.assertNull(sourceMap73);
        org.junit.Assert.assertNotNull(errorManager74);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("function (): None");
        ecmaError1.initColumnNumber(29);
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str3 = diagnosticType2.toString();
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray4 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType2 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray4);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ": hi!" + "'", str3.equals(": hi!"));
        org.junit.Assert.assertNotNull(diagnosticTypeArray4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.rhino.Node node3 = compiler1.getRoot();
        try {
            boolean boolean4 = compiler1.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 1, node5, node9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str16 = compilerOptions15.sourceMapOutputPath;
        boolean boolean17 = compilerOptions15.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions15.cssRenamingMap = cssRenamingMap18;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions15.reportUnknownTypes;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str24 = diagnosticType23.toString();
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("hi!", node5, checkLevel20, diagnosticType23, strArray26);
        node5.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + ": hi!" + "'", str24.equals(": hi!"));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setString("");
        com.google.javascript.rhino.Node node7 = node3.removeFirstChild();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder9 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        node13.setType((int) 'a');
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        node21.setType((int) 'a');
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        node13.addChildAfter(node21, node28);
        com.google.javascript.rhino.Node node31 = functionParamBuilder9.newParameterFromNode(node21);
        com.google.javascript.rhino.Node node32 = node21.cloneNode();
        com.google.javascript.rhino.Node node36 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType37 = node36.getJSType();
        node36.setType((int) 'a');
        boolean boolean40 = node36.hasOneChild();
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        java.lang.String str46 = node36.checkTreeEquals(node44);
        com.google.javascript.rhino.Node node47 = node36.getLastChild();
        com.google.javascript.rhino.Node node51 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        node51.setType((int) 'a');
        boolean boolean55 = node51.hasOneChild();
        com.google.javascript.rhino.Node node59 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        java.lang.String str61 = node51.checkTreeEquals(node59);
        node51.addSuppression("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        node32.addChildAfter(node36, node51);
        try {
            node3.addChildToFront(node51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str46.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str61.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap3 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap3;
        compilerOptions0.setChainCalls(false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        com.google.javascript.jscomp.ErrorManager errorManager45 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSError[] jSErrorArray46 = compiler1.getWarnings();
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
        org.junit.Assert.assertNotNull(errorManager45);
        org.junit.Assert.assertNotNull(jSErrorArray46);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.collapseProperties;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context1.isActivationNeeded("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        boolean boolean4 = context1.hasCompileFunctionsWithDynamicScope();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        boolean boolean3 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkFunctions = checkLevel11;
        compilerOptions0.markAsCompiled = true;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard20 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup18, checkLevel19);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard23 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup21, checkLevel22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard26 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup24, checkLevel25);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard29 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup27, checkLevel28);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup30 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard32 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup30, checkLevel31);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray33 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard17, diagnosticGroupWarningsGuard20, diagnosticGroupWarningsGuard23, diagnosticGroupWarningsGuard26, diagnosticGroupWarningsGuard29, diagnosticGroupWarningsGuard32 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard34 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray33);
        com.google.javascript.rhino.Node node40 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        node44.setType((int) 'a');
        boolean boolean48 = node44.hasOneChild();
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 1, node40, node44);
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat53 = diagnosticType52.format;
        java.lang.String[] strArray54 = null;
        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("hi!", node44, diagnosticType52, strArray54);
        com.google.javascript.jscomp.CheckLevel checkLevel56 = composeWarningsGuard34.level(jSError55);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard34);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertNotNull(diagnosticGroup24);
        org.junit.Assert.assertNotNull(diagnosticGroup27);
        org.junit.Assert.assertNotNull(diagnosticGroup30);
        org.junit.Assert.assertNotNull(warningsGuardArray33);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertNotNull(messageFormat53);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNull(checkLevel56);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.collapseProperties;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode7 = null;
        compilerOptions0.tracer = tracerMode7;
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.inlineFunctions = true;
        compilerOptions0.devirtualizePrototypeMethods = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 23");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
        boolean boolean31 = functionType28.isEnumElementType();
        boolean boolean32 = functionType28.isRegexpType();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkRequires;
        compilerOptions0.printInputDelimiter = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions6.propertyRenaming = propertyRenamingPolicy7;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str11 = compilerOptions10.sourceMapOutputPath;
        boolean boolean12 = compilerOptions10.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        compilerOptions10.checkGlobalThisLevel = checkLevel13;
        java.lang.String[] strArray20 = new java.lang.String[] { "ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n", "hi!", "ASSIGN_MOD  9\n" };
        java.util.ArrayList<java.lang.String> strList21 = new java.util.ArrayList<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList21, strArray20);
        compilerOptions10.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList21);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList21);
        compilerOptions0.aliasableGlobals = "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n";
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str28 = compilerOptions27.sourceMapOutputPath;
        boolean boolean29 = compilerOptions27.collapseProperties;
        boolean boolean30 = compilerOptions27.collapseProperties;
        compilerOptions27.checkUnusedPropertiesEarly = true;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions27.brokenClosureRequiresLevel;
        compilerOptions0.reportUnknownTypes = checkLevel33;
        compilerOptions0.syntheticBlockEndMarker = "";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.coalesceVariableNames;
        com.google.javascript.jscomp.JSModule[] jSModuleArray3 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList4 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList4, jSModuleArray3);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph6 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList4);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList13 = jSModule11.getDependencies();
        java.util.List<java.lang.String> strList14 = jSModule11.getRequires();
        compilerOptions0.setReplaceStringsConfiguration("goog.global", strList14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSModuleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSModule12);
        org.junit.Assert.assertNotNull(jSModuleList13);
        org.junit.Assert.assertNotNull(strList14);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
        org.junit.Assert.assertNotNull(charArray1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.convertToDottedProperties = true;
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean3 = compilerOptions0.checkSuspiciousCode;
        boolean boolean4 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.WARNING;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap3 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap3;
        compilerOptions0.setChainCalls(false);
        boolean boolean7 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        compilerOptions0.instrumentForCoverage = true;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.checkTypes = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE));
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        boolean boolean29 = jSTypeRegistry20.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType28);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
//        node33.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry11.createFunctionType(jSType28, node33);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
//        java.util.Set<java.lang.String> strSet39 = functionType37.getPropertyNames();
//        java.lang.String str40 = functionType37.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = functionType37.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry49.createOptionalType(jSType54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.createUnionType(jSTypeArray59);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.createUnionType(jSTypeArray65);
//        boolean boolean67 = jSTypeRegistry58.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType66);
//        com.google.javascript.rhino.Node node71 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
//        node71.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry49.createFunctionType(jSType66, node71);
//        boolean boolean76 = jSType46.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType75);
//        boolean boolean79 = functionType77.isPropertyInExterns("ASSIGN_MOD  9\n");
//        boolean boolean81 = functionType77.hasOwnProperty("");
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNull(jSType34);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(functionTypeList38);
//        org.junit.Assert.assertNotNull(strSet39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): function (this:me, {1975058800}): me" + "'", str40.equals("function (): function (this:me, {1975058800}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray45);
//        org.junit.Assert.assertNotNull(jSType46);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("function (): function (this:me, {1311234794}): me");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
        jSTypeRegistry2.setTemplateTypeName("");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode14 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES;
        jSTypeRegistry2.setResolveMode(resolveMode14);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + resolveMode14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES + "'", resolveMode14.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.inlineFunctions = true;
        boolean boolean14 = compilerOptions0.checkTypes;
        compilerOptions0.setDefineToDoubleLiteral("function (): None", 0.0d);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        com.google.javascript.jscomp.ErrorManager errorManager45 = compiler1.getErrorManager();
        java.lang.String str46 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) errorManager45);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
        org.junit.Assert.assertNotNull(errorManager45);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.setSummaryDetailLevel(150);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard8 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup9, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel13);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel16);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray18 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2, diagnosticGroupWarningsGuard5, diagnosticGroupWarningsGuard8, diagnosticGroupWarningsGuard11, diagnosticGroupWarningsGuard14, diagnosticGroupWarningsGuard17 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard19 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray18);
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        node29.setType((int) 'a');
        boolean boolean33 = node29.hasOneChild();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (short) 1, node25, node29);
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat38 = diagnosticType37.format;
        java.lang.String[] strArray39 = null;
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("hi!", node29, diagnosticType37, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = composeWarningsGuard19.level(jSError40);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup42 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup42;
        try {
            boolean boolean44 = composeWarningsGuard19.disables(diagnosticGroup42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertNotNull(warningsGuardArray18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(messageFormat38);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNull(checkLevel41);
        org.junit.Assert.assertNotNull(diagnosticGroup42);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.UnionType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkMissingReturn;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback3);
        java.util.List<com.google.javascript.rhino.Node> nodeList5 = null;
        try {
            nodeTraversal4.traverseRoots(nodeList5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context1.isActivationNeeded("function (): function (this:me, {1311234794}): me");
        context1.setCompileFunctionsWithDynamicScope(true);
        int int6 = context1.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        boolean boolean30 = functionType28.isInstanceType();
        com.google.javascript.rhino.jstype.JSType jSType31 = functionType28.getParameterType();
        boolean boolean32 = functionType28.matchesObjectContext();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(jSType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
//        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry4.createOptionalType(jSType9);
//        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.createUnionType(jSTypeArray17);
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry13.createOptionalType(jSType18);
//        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.createUnionType(jSTypeArray23);
//        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry28.createUnionType(jSTypeArray29);
//        boolean boolean31 = jSTypeRegistry22.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType30);
//        com.google.javascript.rhino.Node node35 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
//        node35.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry13.createFunctionType(jSType30, node35);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList40 = functionType39.getSubTypes();
//        java.util.Set<java.lang.String> strSet41 = functionType39.getPropertyNames();
//        java.lang.String str42 = functionType39.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = functionType39.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.createUnionType(jSTypeArray47);
//        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry54.createUnionType(jSTypeArray55);
//        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry51.createOptionalType(jSType56);
//        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray61 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType62 = jSTypeRegistry60.createUnionType(jSTypeArray61);
//        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray67 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeRegistry66.createUnionType(jSTypeArray67);
//        boolean boolean69 = jSTypeRegistry60.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType68);
//        com.google.javascript.rhino.Node node73 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType74 = node73.getJSType();
//        node73.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry51.createFunctionType(jSType68, node73);
//        boolean boolean78 = jSType48.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType77);
//        com.google.javascript.rhino.jstype.FunctionType functionType79 = jSTypeRegistry4.createFunctionTypeWithNewThisType(functionType39, (com.google.javascript.rhino.jstype.ObjectType) functionType77);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList80 = functionType79.getSubTypes();
//        try {
//            boolean boolean81 = functionParamBuilder1.addVarArgs((com.google.javascript.rhino.jstype.JSType) functionType79);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSTypeArray8);
//        org.junit.Assert.assertNotNull(jSType9);
//        org.junit.Assert.assertNotNull(jSType10);
//        org.junit.Assert.assertNotNull(jSTypeArray17);
//        org.junit.Assert.assertNotNull(jSType18);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertNotNull(jSTypeArray23);
//        org.junit.Assert.assertNotNull(jSType24);
//        org.junit.Assert.assertNotNull(jSTypeArray29);
//        org.junit.Assert.assertNotNull(jSType30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(node35);
//        org.junit.Assert.assertNull(jSType36);
//        org.junit.Assert.assertNotNull(functionType39);
//        org.junit.Assert.assertNull(functionTypeList40);
//        org.junit.Assert.assertNotNull(strSet41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "function (): function (this:me, {1755988693}): me" + "'", str42.equals("function (): function (this:me, {1755988693}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable43);
//        org.junit.Assert.assertNotNull(jSTypeArray47);
//        org.junit.Assert.assertNotNull(jSType48);
//        org.junit.Assert.assertNotNull(jSTypeArray55);
//        org.junit.Assert.assertNotNull(jSType56);
//        org.junit.Assert.assertNotNull(jSType57);
//        org.junit.Assert.assertNotNull(jSTypeArray61);
//        org.junit.Assert.assertNotNull(jSType62);
//        org.junit.Assert.assertNotNull(jSTypeArray67);
//        org.junit.Assert.assertNotNull(jSType68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertNotNull(node73);
//        org.junit.Assert.assertNull(jSType74);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(functionType79);
//        org.junit.Assert.assertNull(functionTypeList80);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph4.getDeepestCommonDependencyInclusive(jSModule6, jSModule8);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList10 = jSModule8.getDependencies();
        com.google.javascript.jscomp.SourceFile.Generator generator12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator12);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        jSModule8.addFirst(compilerInput14);
        java.lang.String str16 = jSModule8.toString();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNotNull(jSModuleList10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str16.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        boolean boolean29 = jSTypeRegistry20.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType28);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
//        node33.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry11.createFunctionType(jSType28, node33);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
//        java.util.Set<java.lang.String> strSet39 = functionType37.getPropertyNames();
//        java.lang.String str40 = functionType37.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = functionType37.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry49.createOptionalType(jSType54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.createUnionType(jSTypeArray59);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.createUnionType(jSTypeArray65);
//        boolean boolean67 = jSTypeRegistry58.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType66);
//        com.google.javascript.rhino.Node node71 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
//        node71.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry49.createFunctionType(jSType66, node71);
//        boolean boolean76 = jSType46.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType75);
//        boolean boolean78 = functionType37.isOrdinaryFunction();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNull(jSType34);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(functionTypeList38);
//        org.junit.Assert.assertNotNull(strSet39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): function (this:me, {1615835461}): me" + "'", str40.equals("function (): function (this:me, {1615835461}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray45);
//        org.junit.Assert.assertNotNull(jSType46);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair18 = jSType7.getTypesUnderShallowInequality(jSType17);
        boolean boolean19 = jSType17.isStringValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.createUnionType(jSTypeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry27.createUnionType(jSTypeArray28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry22.createUnionType(jSTypeArray30);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope33 = null;
        com.google.javascript.rhino.jstype.JSType jSType34 = jSType31.resolve(errorReporter32, jSTypeStaticScope33);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSType31.forceResolve(errorReporter35, jSTypeStaticScope36);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair38 = jSType17.getTypesUnderEquality(jSType31);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(typePair18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(typePair38);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        ecmaError1.initLineNumber(12);
        int int4 = ecmaError1.columnNumber();
        java.lang.String str5 = ecmaError1.details();
        java.lang.String str6 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TypeError: hi!" + "'", str5.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TypeError: hi!" + "'", str6.equals("TypeError: hi!"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder1.withParams(functionParamBuilder3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        node8.setType((int) 'a');
        boolean boolean12 = node8.hasOneChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        node16.setType((int) 'a');
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        node8.addChildAfter(node16, node23);
        java.lang.String str26 = node16.toStringTree();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder27 = functionBuilder4.withParamsNode(node16);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable28 = node16.siblings();
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ASSIGN_MOD  9\n" + "'", str26.equals("ASSIGN_MOD  9\n"));
        org.junit.Assert.assertNotNull(functionBuilder27);
        org.junit.Assert.assertNotNull(nodeIterable28);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.collapseProperties;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str2 = compilerOptions1.sourceMapOutputPath;
        boolean boolean3 = compilerOptions1.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions1.cssRenamingMap = cssRenamingMap4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions1.reportUnknownTypes;
        boolean boolean7 = compilerOptions1.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        compilerOptions1.errorFormat = errorFormat8;
        boolean boolean10 = compilerOptions1.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions1.checkUnreachableCode;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("function (): function (this:me, {293602210}): me", checkLevel11, "function (): None");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 1, node5, node9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str16 = compilerOptions15.sourceMapOutputPath;
        boolean boolean17 = compilerOptions15.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions15.cssRenamingMap = cssRenamingMap18;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions15.reportUnknownTypes;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str24 = diagnosticType23.toString();
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("hi!", node5, checkLevel20, diagnosticType23, strArray26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        com.google.javascript.rhino.Node node38 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        node38.setString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        boolean boolean44 = node38.hasChild(node43);
        node5.addChildAfter(node31, node38);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable46 = node5.siblings();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + ": hi!" + "'", str24.equals(": hi!"));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(nodeIterable46);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray6;
        compilerOptions0.gatherCssNames = true;
        java.lang.String str10 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean3 = compilerOptions0.checkSuspiciousCode;
        boolean boolean4 = compilerOptions0.markAsCompiled;
        java.lang.String str5 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        boolean boolean29 = jSTypeRegistry20.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType28);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
//        node33.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry11.createFunctionType(jSType28, node33);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
//        java.util.Set<java.lang.String> strSet39 = functionType37.getPropertyNames();
//        java.lang.String str40 = functionType37.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = functionType37.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry49.createOptionalType(jSType54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.createUnionType(jSTypeArray59);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.createUnionType(jSTypeArray65);
//        boolean boolean67 = jSTypeRegistry58.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType66);
//        com.google.javascript.rhino.Node node71 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
//        node71.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry49.createFunctionType(jSType66, node71);
//        boolean boolean76 = jSType46.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType75);
//        com.google.javascript.rhino.Node node78 = functionType75.getSource();
//        boolean boolean80 = functionType75.isPropertyTypeDeclared("function (): function (this:me, {695033205}): me");
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNull(jSType34);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(functionTypeList38);
//        org.junit.Assert.assertNotNull(strSet39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): function (this:me, {327460564}): me" + "'", str40.equals("function (): function (this:me, {327460564}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray45);
//        org.junit.Assert.assertNotNull(jSType46);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertNull(node78);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 38, (java.lang.Object) (-1L), (java.lang.Object) node5);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags7 = null;
        try {
            node5.setSideEffectFlags(sideEffectFlags7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(runtimeException6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("function (): function (this:me, {701863736}): me");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph8 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule12 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule13 = jSModuleGraph8.getDeepestCommonDependencyInclusive(jSModule10, jSModule12);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList14 = jSModule12.getDependencies();
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator16);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17);
        jSModule12.addFirst(compilerInput18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph24 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule26 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule28 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule29 = jSModuleGraph24.getDeepestCommonDependencyInclusive(jSModule26, jSModule28);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList30 = jSModule28.getDependencies();
        com.google.javascript.jscomp.SourceFile.Generator generator32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator32);
        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
        jSModule28.addFirst(compilerInput34);
        com.google.javascript.jscomp.JSModule jSModule36 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule12, jSModule28);
        boolean boolean38 = jSModule28.removeByName("function (): function (this:me, {709495838}): me");
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule13);
        org.junit.Assert.assertNotNull(jSModuleList14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule29);
        org.junit.Assert.assertNotNull(jSModuleList30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNull(jSModule36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.collapseProperties;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.removeUnusedVarsInGlobalScope = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput3.getModule();
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "hi!", "hi!");
        java.lang.String str11 = sourceFile9.getLine(0);
        try {
            compilerInput3.setSourceFile(sourceFile9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(jSModule5);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator4);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile9, jSSourceFile12, jSSourceFile15 };
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] { jSModule18 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str21 = compilerOptions20.sourceMapOutputPath;
        boolean boolean22 = compilerOptions20.allowLegacyJsMessages;
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = true;
        compiler1.init(jSSourceFileArray16, jSModuleArray19, compilerOptions20);
        java.lang.String str26 = compilerOptions20.syntheticBlockEndMarker;
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSModuleArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node3.children();
        boolean boolean6 = node3.wasEmptyNode();
        node3.removeProp(33);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(nodeIterable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("function (): None");
        java.lang.String str2 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: function (): None" + "'", str2.equals("TypeError: function (): None"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry4.createUnionType(jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] { jSType11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry4.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry4.getNativeObjectType(jSTypeNative14);
        com.google.javascript.jscomp.Scope scope16 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.createUnionType(jSTypeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.createUnionType(jSTypeArray25);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry19.createUnionType(jSTypeArray27);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.getNativeObjectType(jSTypeNative29);
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray31 = new com.google.javascript.rhino.jstype.ObjectType[] { objectType30 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32, objectTypeArray31);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry4, scope16, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry37.createUnionType(jSTypeArray38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry42.createUnionType(jSTypeArray43);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] { jSType44 };
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry37.createUnionType(jSTypeArray45);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative47 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSTypeRegistry37.getNativeObjectType(jSTypeNative47);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection49 = jSTypeRegistry4.getDirectImplementors(objectType48);
        boolean boolean50 = objectType48.isDateType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(objectTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative47 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative47.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType48);
        org.junit.Assert.assertNotNull(functionTypeCollection49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.enableExternExports(false);
        boolean boolean6 = compilerOptions0.prettyPrint;
        compilerOptions0.rewriteFunctionExpressions = false;
        compilerOptions0.labelRenaming = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str12 = compilerOptions11.sourceMapOutputPath;
        boolean boolean13 = compilerOptions11.allowLegacyJsMessages;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = null;
        compilerOptions11.sourceMapDetailLevel = detailLevel14;
        compilerOptions11.sourceMapOutputPath = "hi!";
        compilerOptions11.checkDuplicateMessages = true;
        com.google.javascript.jscomp.SourceMap.Format format20 = compilerOptions11.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format20;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(format20);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str4 = compilerOptions3.sourceMapOutputPath;
        boolean boolean5 = compilerOptions3.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions3.checkRequires;
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        node16.setType((int) 'a');
        boolean boolean20 = node16.hasOneChild();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 1, node12, node16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str23 = compilerOptions22.sourceMapOutputPath;
        boolean boolean24 = compilerOptions22.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap25 = null;
        compilerOptions22.cssRenamingMap = cssRenamingMap25;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.reportUnknownTypes;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.lang.String str31 = diagnosticType30.toString();
        java.lang.String[] strArray33 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("hi!", node12, checkLevel27, diagnosticType30, strArray33);
        java.lang.String[] strArray40 = new java.lang.String[] { "ASSIGN_MOD  9\n", "function (): None", "function (): function (this:me, {1311234794}): me", "Not declared as a constructor", "function (this:me, {450531040}): me" };
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("function (): function (this:me, {1615835461}): me", 13, 25, checkLevel6, diagnosticType30, strArray40);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + ": hi!" + "'", str31.equals(": hi!"));
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jSError41);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context1.isActivationNeeded("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        try {
            context1.setLanguageVersion(24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 24");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.lang.String str29 = functionType28.toString();
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType30 = functionType28.getSuperClassConstructor();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "function (): None" + "'", str29.equals("function (): None"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        java.lang.String str7 = compilerOptions0.aliasableGlobals;
        compilerOptions0.generateExports = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        com.google.javascript.jscomp.SourceMap.Format format3 = null;
        compilerOptions0.sourceMapFormat = format3;
        java.lang.String str5 = compilerOptions0.inputDelimiter;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "// Input %num%" + "'", str5.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkGlobalThisLevel = checkLevel3;
        java.lang.String[] strArray10 = new java.lang.String[] { "ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n", "hi!", "ASSIGN_MOD  9\n" };
        java.util.ArrayList<java.lang.String> strList11 = new java.util.ArrayList<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList11, strArray10);
        compilerOptions0.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList11);
        boolean boolean14 = compilerOptions0.decomposeExpressions;
        compilerOptions0.syntheticBlockEndMarker = "language version";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph4.getDeepestCommonDependencyInclusive(jSModule6, jSModule8);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList10 = jSModule8.getDependencies();
        java.util.List<java.lang.String> strList11 = jSModule8.getRequires();
        jSModule8.clearAsts();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNotNull(jSModuleList10);
        org.junit.Assert.assertNotNull(strList11);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.inlineFunctions = true;
        boolean boolean14 = compilerOptions0.checkTypes;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripNameSuffixes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strSet15);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        boolean boolean6 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setType((int) 'a');
        boolean boolean9 = node5.hasOneChild();
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        node13.setType((int) 'a');
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        node5.addChildAfter(node13, node20);
        com.google.javascript.rhino.Node node23 = functionParamBuilder1.newParameterFromNode(node13);
        node23.setType(16);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isSealed();
        context1.setGeneratingSource(false);
        int int5 = context1.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        try {
            com.google.javascript.jscomp.JSModule[] jSModuleArray4 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripNamePrefixes = strSet2;
        compilerOptions0.exportTestFunctions = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.aliasExternals = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        boolean boolean3 = compilerOptions0.checkCaja;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.removeUnusedVarsInGlobalScope = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        try {
//            com.google.javascript.rhino.Context.reportError("// Input %num%", "setelem", 11, "function (): function (this:me, {159411242}): me", (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap3 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap3;
        boolean boolean5 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph4.getDeepestCommonDependencyInclusive(jSModule6, jSModule8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        jSModule8.add(jSSourceFile12);
        boolean boolean15 = jSModule8.removeByName("function (): function (this:me, {701863736}): me");
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
        boolean boolean12 = jSType11.isNullType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap3 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap3;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        boolean boolean6 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        compilerOptions0.errorFormat = errorFormat7;
        compilerOptions0.exportTestFunctions = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(errorFormat7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkGlobalThisLevel = checkLevel3;
        boolean boolean5 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node3.addChildAfter(node11, node18);
        boolean boolean21 = node11.isQuotedString();
        node11.addSuppression("function (): function (this:me, {1975058800}): me");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray6;
        compilerOptions0.setColorizeErrorOutput(false);
        compilerOptions0.rewriteFunctionExpressions = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
        boolean boolean31 = functionType28.isInstanceType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable32 = functionType28.getAllImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable32);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        boolean boolean5 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap3 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap3;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        boolean boolean6 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        compilerOptions0.errorFormat = errorFormat7;
        compilerOptions0.convertToDottedProperties = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(errorFormat7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry4.createUnionType(jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] { jSType11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry4.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry4.getNativeObjectType(jSTypeNative14);
        com.google.javascript.jscomp.Scope scope16 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.createUnionType(jSTypeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.createUnionType(jSTypeArray25);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry19.createUnionType(jSTypeArray27);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.getNativeObjectType(jSTypeNative29);
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray31 = new com.google.javascript.rhino.jstype.ObjectType[] { objectType30 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32, objectTypeArray31);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry4, scope16, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32);
        java.lang.String str35 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) 'a');
        java.lang.String str40 = closureCodingConvention0.extractClassNameIfProvide(node37, node39);
        boolean boolean42 = closureCodingConvention0.isSuperClassReference("function (): function (this:me, {849350231}): me");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(objectTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "goog.abstractMethod" + "'", str35.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str4 = compilerOptions3.sourceMapOutputPath;
        boolean boolean5 = compilerOptions3.flowSensitiveInlineVariables;
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) boolean2, (java.lang.Object) compilerOptions3);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(runtimeException6);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node3.addChildAfter(node11, node18);
        try {
            node3.setDouble((double) 120);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: ASSIGN_MOD  9 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.checkSymbols = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean13 = compilerOptions0.removeUnusedVars;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.ErrorFormat errorFormat3 = compilerOptions0.errorFormat;
        java.io.PrintStream printStream4 = null;
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler(printStream4);
        com.google.javascript.rhino.Node node6 = compiler5.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal8 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler5, callback7);
        com.google.javascript.jscomp.ErrorManager errorManager9 = compiler5.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = errorFormat3.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(errorFormat3);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(errorManager9);
        org.junit.Assert.assertNotNull(messageFormatter11);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1967691932}): me", 2, 20);
        functionNode3.setEncodedSourceBounds(27, (int) (byte) 100);
        functionNode3.removeParamOrVar("function (): function (this:me, {1311234794}): me");
        java.lang.Object obj9 = null;
        try {
            functionNode3.setCompilerData(obj9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet6 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet6, strArray5);
        compilerOptions0.stripNameSuffixes = strSet6;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.inlineFunctions = true;
        java.lang.String str14 = compilerOptions0.locale;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.checkDuplicateMessages;
        compilerOptions0.setSummaryDetailLevel(100);
        java.lang.String str5 = compilerOptions0.locale;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeDeadCode;
        boolean boolean2 = compilerOptions0.reserveRawExports;
        compilerOptions0.reportPath = "<No stack trace available>";
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        org.junit.Assert.assertNotNull(jSModuleList2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        com.google.javascript.jscomp.SourceMap.Format format3 = null;
        compilerOptions0.sourceMapFormat = format3;
        compilerOptions0.setDefineToStringLiteral("", "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        boolean boolean8 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        boolean boolean15 = node11.hasOneChild();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 1, node7, node11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat20 = diagnosticType19.format;
        java.lang.String[] strArray21 = null;
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("hi!", node11, diagnosticType19, strArray21);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = jSError22.level;
        boolean boolean24 = diagnosticGroup0.matches(jSError22);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(messageFormat20);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        try {
//            com.google.javascript.rhino.Context.reportError("");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        boolean boolean7 = compilerOptions0.reserveRawExports;
        compilerOptions0.aliasExternals = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry4.createUnionType(jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] { jSType11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry4.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry4.getNativeObjectType(jSTypeNative14);
        com.google.javascript.jscomp.Scope scope16 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.createUnionType(jSTypeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.createUnionType(jSTypeArray25);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry19.createUnionType(jSTypeArray27);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.getNativeObjectType(jSTypeNative29);
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray31 = new com.google.javascript.rhino.jstype.ObjectType[] { objectType30 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32, objectTypeArray31);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry4, scope16, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32);
        java.util.Map<java.lang.String, com.google.javascript.rhino.jstype.JSType> strMap35 = null;
        try {
            com.google.javascript.rhino.jstype.RecordType recordType36 = jSTypeRegistry4.createRecordType(strMap35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(objectTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.lang.String str29 = functionType28.toString();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = functionType28.toObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "function (): None" + "'", str29.equals("function (): None"));
        org.junit.Assert.assertNotNull(objectType30);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1967691932}): me", 2, 20);
        com.google.javascript.rhino.FunctionNode functionNode4 = null;
        try {
            int int5 = functionNode3.addFunction(functionNode4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        boolean boolean30 = functionType28.matchesObjectContext();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        java.lang.String str3 = ecmaError2.getName();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str5 = compilerOptions4.sourceMapOutputPath;
        compilerOptions4.setNameAnonymousFunctionsOnly(false);
        boolean boolean8 = compilerOptions4.inlineLocalFunctions;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) ecmaError2, (java.lang.Object) compilerOptions4, (java.lang.Object) jSTypeNative9);
        compilerOptions4.checkSuspiciousCode = false;
        compilerOptions4.decomposeExpressions = true;
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN));
        org.junit.Assert.assertNotNull(runtimeException10);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        java.lang.String str3 = ecmaError2.sourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("function (): function (this:me, {1953892259}): me", "TypeError: hi!", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripTypes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions7.reportMissingOverride;
        compilerOptions0.checkFunctions = checkLevel11;
        compilerOptions0.markAsCompiled = true;
        java.lang.String str15 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String str1 = diagnosticType0.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "setelem");
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        int int6 = diagnosticType0.compareTo(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str1.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-30) + "'", int6 == (-30));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("function (): function (this:me, {849350231}): me", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
//        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
//        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
//        node24.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
//        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
//        java.lang.String str31 = functionType28.toDebugHashCodeString();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo33 = null;
//        functionType28.setPropertyJSDocInfo("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSDocInfo33, true);
//        boolean boolean36 = functionType28.isNoObjectType();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray12);
//        org.junit.Assert.assertNotNull(jSType13);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(node24);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(functionType28);
//        org.junit.Assert.assertNull(functionTypeList29);
//        org.junit.Assert.assertNotNull(strSet30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "function (): function (this:me, {2019643492}): me" + "'", str31.equals("function (): function (this:me, {2019643492}): me"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
//        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
//        com.google.javascript.rhino.jstype.JSType jSType14 = jSType11.resolve(errorReporter12, jSTypeStaticScope13);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry17.createOptionalType(jSType22);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.createUnionType(jSTypeArray33);
//        boolean boolean35 = jSTypeRegistry26.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType34);
//        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
//        node39.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry17.createFunctionType(jSType34, node39);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList44 = functionType43.getSubTypes();
//        java.util.Set<java.lang.String> strSet45 = functionType43.getPropertyNames();
//        java.lang.String str46 = functionType43.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = functionType43.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType48 = jSType11.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) functionType43);
//        java.util.Set set49 = functionType43.getOwnPropertyNames();
//        com.google.javascript.rhino.Node node50 = functionType43.getSource();
//        org.junit.Assert.assertNotNull(jSTypeArray3);
//        org.junit.Assert.assertNotNull(jSType4);
//        org.junit.Assert.assertNotNull(jSTypeArray8);
//        org.junit.Assert.assertNotNull(jSType9);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(jSType11);
//        org.junit.Assert.assertNotNull(jSType14);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSType23);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertNotNull(jSTypeArray33);
//        org.junit.Assert.assertNotNull(jSType34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertNull(jSType40);
//        org.junit.Assert.assertNotNull(functionType43);
//        org.junit.Assert.assertNull(functionTypeList44);
//        org.junit.Assert.assertNotNull(strSet45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "function (): function (this:me, {1470528857}): me" + "'", str46.equals("function (): function (this:me, {1470528857}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable47);
//        org.junit.Assert.assertNotNull(jSType48);
//        org.junit.Assert.assertNotNull(set49);
//        org.junit.Assert.assertNull(node50);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str2 = compilerOptions1.sourceMapOutputPath;
        boolean boolean3 = compilerOptions1.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions1.checkRequires;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkFunctions;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel5, "");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType7);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
//        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
//        com.google.javascript.rhino.jstype.JSType jSType14 = jSType11.resolve(errorReporter12, jSTypeStaticScope13);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry17.createOptionalType(jSType22);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.createUnionType(jSTypeArray33);
//        boolean boolean35 = jSTypeRegistry26.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType34);
//        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
//        node39.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry17.createFunctionType(jSType34, node39);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList44 = functionType43.getSubTypes();
//        java.util.Set<java.lang.String> strSet45 = functionType43.getPropertyNames();
//        java.lang.String str46 = functionType43.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = functionType43.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType48 = jSType11.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) functionType43);
//        java.util.Set set49 = functionType43.getOwnPropertyNames();
//        boolean boolean50 = functionType43.isInstanceType();
//        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter54 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter54, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry56.createUnionType(jSTypeArray57);
//        com.google.javascript.rhino.jstype.JSType jSType59 = jSTypeRegistry53.createOptionalType(jSType58);
//        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry62.createUnionType(jSTypeArray63);
//        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry68.createUnionType(jSTypeArray69);
//        boolean boolean71 = jSTypeRegistry62.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType70);
//        com.google.javascript.rhino.Node node75 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType76 = node75.getJSType();
//        node75.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType79 = jSTypeRegistry53.createFunctionType(jSType70, node75);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList80 = functionType79.getSubTypes();
//        java.util.Set<java.lang.String> strSet81 = functionType79.getPropertyNames();
//        java.lang.String str82 = functionType79.toDebugHashCodeString();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo84 = null;
//        functionType79.setPropertyJSDocInfo("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSDocInfo84, true);
//        boolean boolean87 = functionType43.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType79);
//        org.junit.Assert.assertNotNull(jSTypeArray3);
//        org.junit.Assert.assertNotNull(jSType4);
//        org.junit.Assert.assertNotNull(jSTypeArray8);
//        org.junit.Assert.assertNotNull(jSType9);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(jSType11);
//        org.junit.Assert.assertNotNull(jSType14);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSType23);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertNotNull(jSTypeArray33);
//        org.junit.Assert.assertNotNull(jSType34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertNull(jSType40);
//        org.junit.Assert.assertNotNull(functionType43);
//        org.junit.Assert.assertNull(functionTypeList44);
//        org.junit.Assert.assertNotNull(strSet45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "function (): function (this:me, {1712864909}): me" + "'", str46.equals("function (): function (this:me, {1712864909}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable47);
//        org.junit.Assert.assertNotNull(jSType48);
//        org.junit.Assert.assertNotNull(set49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray57);
//        org.junit.Assert.assertNotNull(jSType58);
//        org.junit.Assert.assertNotNull(jSType59);
//        org.junit.Assert.assertNotNull(jSTypeArray63);
//        org.junit.Assert.assertNotNull(jSType64);
//        org.junit.Assert.assertNotNull(jSTypeArray69);
//        org.junit.Assert.assertNotNull(jSType70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertNotNull(node75);
//        org.junit.Assert.assertNull(jSType76);
//        org.junit.Assert.assertNotNull(functionType79);
//        org.junit.Assert.assertNull(functionTypeList80);
//        org.junit.Assert.assertNotNull(strSet81);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "function (): function (this:me, {1577009293}): me" + "'", str82.equals("function (): function (this:me, {1577009293}): me"));
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        com.google.javascript.jscomp.ErrorManager errorManager45 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSError[] jSErrorArray46 = compiler1.getWarnings();
        int int47 = compiler1.getErrorCount();
        boolean boolean48 = compiler1.isTypeCheckingEnabled();
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
        org.junit.Assert.assertNotNull(errorManager45);
        org.junit.Assert.assertNotNull(jSErrorArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph8 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule12 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule13 = jSModuleGraph8.getDeepestCommonDependencyInclusive(jSModule10, jSModule12);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList14 = jSModule12.getDependencies();
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator16);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17);
        jSModule12.addFirst(compilerInput18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph24 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule26 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule28 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule29 = jSModuleGraph24.getDeepestCommonDependencyInclusive(jSModule26, jSModule28);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList30 = jSModule28.getDependencies();
        com.google.javascript.jscomp.SourceFile.Generator generator32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator32);
        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
        jSModule28.addFirst(compilerInput34);
        com.google.javascript.jscomp.JSModule jSModule36 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule12, jSModule28);
        com.google.javascript.jscomp.JSModule[] jSModuleArray37 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList38, jSModuleArray37);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph40 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList38);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph41 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList38);
        try {
            com.google.javascript.jscomp.JSModule jSModule42 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList38);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule13);
        org.junit.Assert.assertNotNull(jSModuleList14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule29);
        org.junit.Assert.assertNotNull(jSModuleList30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNull(jSModule36);
        org.junit.Assert.assertNotNull(jSModuleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1967691932}): me", 2, 20);
        functionNode3.setEncodedSourceBounds(27, (int) (byte) 100);
        boolean[] booleanArray7 = functionNode3.getParamAndVarConst();
        org.junit.Assert.assertNotNull(booleanArray7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node3.addChildAfter(node11, node18);
        boolean boolean21 = node11.isQuotedString();
        java.lang.Object obj23 = node11.getProp(1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("function (): function (this:me, {2019643492}): me");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.lang.String str29 = functionType28.toString();
        boolean boolean30 = functionType28.canBeCalled();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "function (): None" + "'", str29.equals("function (): None"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        boolean boolean3 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.foldConstants = true;
        compilerOptions0.renamePrefix = "";
        compilerOptions0.setDefineToBooleanLiteral("goog.abstractMethod", true);
        compilerOptions0.jsOutputFile = "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context1.isActivationNeeded("function (): function (this:me, {1311234794}): me");
        context1.setCompileFunctionsWithDynamicScope(true);
        context1.addActivationName("goog.abstractMethod");
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.createUnionType(jSTypeArray11);
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry7.createOptionalType(jSType12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry16.createUnionType(jSTypeArray17);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.createUnionType(jSTypeArray23);
        boolean boolean25 = jSTypeRegistry16.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType24);
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        node29.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry7.createFunctionType(jSType24, node29);
        boolean boolean34 = jSType4.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType33);
        boolean boolean35 = functionType33.hasReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig3 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        java.lang.String str4 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("", "function (): function (this:me, {1399344290}): me", "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        boolean boolean9 = node3.hasChild(node8);
        int int10 = node8.getCharno();
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str12 = compilerOptions11.sourceMapOutputPath;
        boolean boolean13 = compilerOptions11.collapseProperties;
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet17 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet17, strArray16);
        compilerOptions11.stripNameSuffixes = strSet17;
        node8.setDirectives((java.util.Set<java.lang.String>) strSet17);
        int int21 = node8.getChildCount();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setType((int) 'a');
        boolean boolean9 = node5.hasOneChild();
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        node13.setType((int) 'a');
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        node5.addChildAfter(node13, node20);
        com.google.javascript.rhino.Node node23 = functionParamBuilder1.newParameterFromNode(node13);
        com.google.javascript.rhino.Node node24 = node13.cloneNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        node28.setString("");
        java.lang.String str32 = node24.checkTreeEquals(node28);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str32.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "");
        int int3 = ecmaError2.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkRequires;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy13 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions12.propertyRenaming = propertyRenamingPolicy13;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy13;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy13.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.collapseProperties;
        com.google.javascript.jscomp.MessageBundle messageBundle4 = null;
        compilerOptions0.messageBundle = messageBundle4;
        boolean boolean6 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.aliasKeywords = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        com.google.javascript.jscomp.ErrorManager errorManager45 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSError[] jSErrorArray46 = compiler1.getWarnings();
        int int47 = compiler1.getErrorCount();
        com.google.javascript.jscomp.SourceFile.Generator generator49 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator49);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        com.google.javascript.jscomp.SourceFile.Generator generator55 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile56 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator55);
        com.google.javascript.jscomp.CompilerInput compilerInput57 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile56);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray61 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList62, jSModuleArray61);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph64 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList62);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph65 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList62);
        com.google.javascript.jscomp.JSModule jSModule67 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule69 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule jSModule70 = jSModuleGraph65.getDeepestCommonDependencyInclusive(jSModule67, jSModule69);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile73 = com.google.javascript.jscomp.JSSourceFile.fromCode("ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n");
        jSModule69.add(jSSourceFile73);
        com.google.javascript.jscomp.SourceFile.Generator generator76 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile77 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator76);
        com.google.javascript.jscomp.CompilerInput compilerInput78 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile77);
        com.google.javascript.jscomp.CompilerInput compilerInput80 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile77, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray81 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile50, jSSourceFile53, jSSourceFile56, jSSourceFile60, jSSourceFile73, jSSourceFile77 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList82 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean83 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList82, jSSourceFileArray81);
        com.google.javascript.jscomp.JSModule[] jSModuleArray84 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList85 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean86 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList85, jSModuleArray84);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph87 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList85);
        com.google.javascript.jscomp.CompilerOptions compilerOptions88 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str89 = compilerOptions88.sourceMapOutputPath;
        boolean boolean90 = compilerOptions88.allowLegacyJsMessages;
        compilerOptions88.removeUnusedPrototypePropertiesInExterns = true;
        compiler1.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList82, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList85, compilerOptions88);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
        org.junit.Assert.assertNotNull(errorManager45);
        org.junit.Assert.assertNotNull(jSErrorArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(jSSourceFile56);
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNotNull(jSModuleArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(jSModule70);
        org.junit.Assert.assertNotNull(jSSourceFile73);
        org.junit.Assert.assertNotNull(jSSourceFile77);
        org.junit.Assert.assertNotNull(jSSourceFileArray81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(jSModuleArray84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback3);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler1.getErrorManager();
        java.lang.Class<?> wildcardClass6 = compiler1.getClass();
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard21 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        node31.setType((int) 'a');
        boolean boolean35 = node31.hasOneChild();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 1, node27, node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat40 = diagnosticType39.format;
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", node31, diagnosticType39, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = composeWarningsGuard21.level(jSError42);
        compiler1.report(jSError42);
        com.google.javascript.jscomp.ErrorManager errorManager45 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSError[] jSErrorArray46 = compiler1.getWarnings();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker47 = null;
        compiler1.tracker = performanceTracker47;
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(messageFormat40);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNull(checkLevel43);
        org.junit.Assert.assertNotNull(errorManager45);
        org.junit.Assert.assertNotNull(jSErrorArray46);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        boolean boolean10 = node4.hasChild(node9);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = googleCodingConvention0.getDelegateRelationship(node4);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.createUnionType(jSTypeArray9);
        boolean boolean11 = jSTypeRegistry2.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry14.createOptionalType(jSType19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry23.createUnionType(jSTypeArray24);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry29.createUnionType(jSTypeArray30);
        boolean boolean32 = jSTypeRegistry23.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType37 = node36.getJSType();
        node36.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry14.createFunctionType(jSType31, node36);
        boolean boolean42 = jSTypeRegistry2.canPropertyBeDefined(jSType31, "");
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope43, "", "function (): function (this:me, {1975058800}): me", (int) (short) 10, 48);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(jSType48);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, ": hi!", true);
        try {
            java.util.Collection<java.lang.String> strCollection9 = compilerInput8.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(jSModule5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.lang.String str29 = functionType28.toString();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        try {
            boolean boolean31 = functionType28.hasEqualCallType(functionType30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "function (): None" + "'", str29.equals("function (): None"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry4.createUnionType(jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry9.createUnionType(jSTypeArray10);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] { jSType11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry4.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry4.getNativeObjectType(jSTypeNative14);
        com.google.javascript.jscomp.Scope scope16 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry19.createUnionType(jSTypeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry24.createUnionType(jSTypeArray25);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry19.createUnionType(jSTypeArray27);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry19.getNativeObjectType(jSTypeNative29);
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray31 = new com.google.javascript.rhino.jstype.ObjectType[] { objectType30 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32, objectTypeArray31);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry4, scope16, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList32);
        java.lang.String str35 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean38 = closureCodingConvention0.isExported("function (): function (this:me, {849350231}): me", true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder40 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry39);
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        node44.setType((int) 'a');
        boolean boolean48 = node44.hasOneChild();
        com.google.javascript.rhino.Node node52 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType53 = node52.getJSType();
        node52.setType((int) 'a');
        com.google.javascript.rhino.Node node59 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        node44.addChildAfter(node52, node59);
        com.google.javascript.rhino.Node node62 = functionParamBuilder40.newParameterFromNode(node52);
        com.google.javascript.rhino.Node node63 = functionParamBuilder40.build();
        java.lang.String str64 = closureCodingConvention0.identifyTypeDefAssign(node63);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable65 = node63.siblings();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(objectTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "goog.abstractMethod" + "'", str35.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(jSType53);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(nodeIterable65);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getSourceName();
        try {
            ecmaError1.initColumnNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
//        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
//        com.google.javascript.rhino.jstype.JSType jSType14 = jSType11.resolve(errorReporter12, jSTypeStaticScope13);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry17.createOptionalType(jSType22);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.createUnionType(jSTypeArray33);
//        boolean boolean35 = jSTypeRegistry26.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType34);
//        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
//        node39.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry17.createFunctionType(jSType34, node39);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList44 = functionType43.getSubTypes();
//        java.util.Set<java.lang.String> strSet45 = functionType43.getPropertyNames();
//        java.lang.String str46 = functionType43.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = functionType43.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType48 = jSType11.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) functionType43);
//        java.util.Set set49 = functionType43.getOwnPropertyNames();
//        boolean boolean50 = functionType43.isInstanceType();
//        com.google.javascript.rhino.Node node51 = functionType43.getSource();
//        org.junit.Assert.assertNotNull(jSTypeArray3);
//        org.junit.Assert.assertNotNull(jSType4);
//        org.junit.Assert.assertNotNull(jSTypeArray8);
//        org.junit.Assert.assertNotNull(jSType9);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(jSType11);
//        org.junit.Assert.assertNotNull(jSType14);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSType23);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertNotNull(jSTypeArray33);
//        org.junit.Assert.assertNotNull(jSType34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertNull(jSType40);
//        org.junit.Assert.assertNotNull(functionType43);
//        org.junit.Assert.assertNull(functionTypeList44);
//        org.junit.Assert.assertNotNull(strSet45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "function (): function (this:me, {1660270634}): me" + "'", str46.equals("function (): function (this:me, {1660270634}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable47);
//        org.junit.Assert.assertNotNull(jSType48);
//        org.junit.Assert.assertNotNull(set49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNull(node51);
//    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        boolean boolean29 = jSTypeRegistry20.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType28);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
//        node33.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry11.createFunctionType(jSType28, node33);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
//        java.util.Set<java.lang.String> strSet39 = functionType37.getPropertyNames();
//        java.lang.String str40 = functionType37.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = functionType37.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry49.createOptionalType(jSType54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.createUnionType(jSTypeArray59);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.createUnionType(jSTypeArray65);
//        boolean boolean67 = jSTypeRegistry58.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType66);
//        com.google.javascript.rhino.Node node71 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
//        node71.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry49.createFunctionType(jSType66, node71);
//        boolean boolean76 = jSType46.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType75);
//        boolean boolean78 = functionType37.isEmptyType();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNull(jSType34);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(functionTypeList38);
//        org.junit.Assert.assertNotNull(strSet39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): function (this:me, {818185898}): me" + "'", str40.equals("function (): function (this:me, {818185898}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray45);
//        org.junit.Assert.assertNotNull(jSType46);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isSealed();
        java.lang.String str3 = context1.getImplementationVersion();
        boolean boolean4 = context1.isSealed();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder1.withParams(functionParamBuilder3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        node8.setType((int) 'a');
        boolean boolean12 = node8.hasOneChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        node16.setType((int) 'a');
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        node8.addChildAfter(node16, node23);
        java.lang.String str26 = node16.toStringTree();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder27 = functionBuilder4.withParamsNode(node16);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType32 = jSTypeRegistry30.createUnionType(jSTypeArray31);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry35.createUnionType(jSTypeArray36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] { jSType37 };
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry30.createUnionType(jSTypeArray38);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType41 = jSTypeRegistry30.getNativeObjectType(jSTypeNative40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.createUnionType(jSTypeArray50);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] { jSType51 };
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry44.createUnionType(jSTypeArray52);
        com.google.javascript.rhino.ErrorReporter errorReporter54 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter54, false);
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry59.createUnionType(jSTypeArray60);
        com.google.javascript.rhino.jstype.JSType jSType62 = jSTypeRegistry56.createOptionalType(jSType61);
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType67 = jSTypeRegistry65.createUnionType(jSTypeArray66);
        com.google.javascript.rhino.ErrorReporter errorReporter69 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter69, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry71.createUnionType(jSTypeArray72);
        boolean boolean74 = jSTypeRegistry65.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType73);
        com.google.javascript.rhino.Node node78 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType79 = node78.getJSType();
        node78.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry56.createFunctionType(jSType73, node78);
        java.lang.String str83 = functionType82.toString();
        boolean boolean84 = functionType82.matchesStringContext();
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry44.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType82);
        com.google.javascript.rhino.jstype.JSType jSType86 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry30.createFunctionTypeWithNewReturnType(functionType82, jSType86);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder88 = functionBuilder4.withInferredReturnType(jSType86);
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ASSIGN_MOD  9\n" + "'", str26.equals("ASSIGN_MOD  9\n"));
        org.junit.Assert.assertNotNull(functionBuilder27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType41);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(jSTypeArray60);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(jSType62);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNull(jSType79);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "function (): None" + "'", str83.equals("function (): None"));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertNotNull(functionBuilder88);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("function (): function (this:me, {977480980}): me");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType7 = node6.getJSType();
        node6.setType((int) 'a');
        boolean boolean10 = node6.hasOneChild();
        com.google.javascript.rhino.Node node14 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        java.lang.String str16 = node6.checkTreeEquals(node14);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry22.createUnionType(jSTypeArray23);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry19.createOptionalType(jSType24);
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry28.createUnionType(jSTypeArray29);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry34.createUnionType(jSTypeArray35);
        boolean boolean37 = jSTypeRegistry28.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType36);
        com.google.javascript.rhino.Node node41 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType42 = node41.getJSType();
        node41.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry19.createFunctionType(jSType36, node41);
        com.google.javascript.rhino.Node node50 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node54 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType55 = node54.getJSType();
        node54.setType((int) 'a');
        boolean boolean58 = node54.hasOneChild();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) (short) 1, node50, node54);
        int int60 = node54.getCharno();
        com.google.javascript.rhino.Node node61 = node41.clonePropsFrom(node54);
        com.google.javascript.rhino.Node node62 = node6.copyInformationFrom(node41);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship63 = googleCodingConvention0.getClassesDefinedByCall(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str16.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(jSType55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str2 = compilerOptions1.sourceMapOutputPath;
        boolean boolean3 = compilerOptions1.collapseProperties;
        boolean boolean4 = compilerOptions1.collapseProperties;
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) jSTypeNative0, (java.lang.Object) boolean4, (java.lang.Object) sourceFile6);
        try {
            java.io.Reader reader8 = sourceFile6.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(runtimeException7);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.lang.String str29 = functionType28.toString();
        boolean boolean30 = functionType28.matchesStringContext();
        java.util.Set<java.lang.String> strSet31 = functionType28.getPropertyNames();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "function (): None" + "'", str29.equals("function (): None"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strSet31);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        node24.setType((int) (short) 1);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
        boolean boolean31 = functionType28.isEnumElementType();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry34.createUnionType(jSTypeArray35);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry39.createUnionType(jSTypeArray40);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { jSType41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry34.createUnionType(jSTypeArray42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        com.google.javascript.rhino.jstype.JSType jSType46 = jSType43.resolve(errorReporter44, jSTypeStaticScope45);
        boolean boolean47 = functionType28.isSubtype(jSType46);
        boolean boolean48 = functionType28.isReturnTypeInferred();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node3.addChildAfter(node11, node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.Node node28 = node24.removeFirstChild();
        boolean boolean29 = node3.isEquivalentTo(node24);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder31 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry30);
        com.google.javascript.rhino.Node node35 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        node35.setType((int) 'a');
        boolean boolean39 = node35.hasOneChild();
        com.google.javascript.rhino.Node node43 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType44 = node43.getJSType();
        node43.setType((int) 'a');
        com.google.javascript.rhino.Node node50 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        node35.addChildAfter(node43, node50);
        com.google.javascript.rhino.Node node53 = functionParamBuilder31.newParameterFromNode(node43);
        com.google.javascript.rhino.Node node54 = functionParamBuilder31.build();
        node3.addChildrenToFront(node54);
        boolean boolean56 = node54.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(jSType44);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator4);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile9, jSSourceFile12, jSSourceFile15 };
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] { jSModule18 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str21 = compilerOptions20.sourceMapOutputPath;
        boolean boolean22 = compilerOptions20.allowLegacyJsMessages;
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = true;
        compiler1.init(jSSourceFileArray16, jSModuleArray19, compilerOptions20);
        compilerOptions20.aliasAllStrings = true;
        boolean boolean28 = compilerOptions20.shouldColorizeErrorOutput();
        compilerOptions20.inlineLocalVariables = false;
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSModuleArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkFunctions;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        com.google.javascript.jscomp.SourceMap.Format format3 = null;
        compilerOptions0.sourceMapFormat = format3;
        compilerOptions0.setDefineToStringLiteral("", "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkProvides;
        java.util.Set<java.lang.String> strSet9 = compilerOptions0.stripNamePrefixes;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel11);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) diagnosticGroupWarningsGuard12);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
        boolean boolean31 = functionType28.matchesStringContext();
        boolean boolean32 = functionType28.isNumber();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.createUnionType(jSTypeArray3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry7.createUnionType(jSTypeArray8);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] { jSType9 };
//        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry2.createUnionType(jSTypeArray10);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
//        com.google.javascript.rhino.jstype.JSType jSType14 = jSType11.resolve(errorReporter12, jSTypeStaticScope13);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry17.createOptionalType(jSType22);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.createUnionType(jSTypeArray33);
//        boolean boolean35 = jSTypeRegistry26.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType34);
//        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
//        node39.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry17.createFunctionType(jSType34, node39);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList44 = functionType43.getSubTypes();
//        java.util.Set<java.lang.String> strSet45 = functionType43.getPropertyNames();
//        java.lang.String str46 = functionType43.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = functionType43.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType48 = jSType11.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) functionType43);
//        boolean boolean49 = functionType43.hasCachedValues();
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType59 = jSTypeRegistry57.createUnionType(jSTypeArray58);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] { jSType59 };
//        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry52.createUnionType(jSTypeArray60);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
//        com.google.javascript.rhino.jstype.JSType jSType64 = jSType61.resolve(errorReporter62, jSTypeStaticScope63);
//        com.google.javascript.rhino.jstype.JSType jSType65 = functionType43.getLeastSupertype(jSType61);
//        org.junit.Assert.assertNotNull(jSTypeArray3);
//        org.junit.Assert.assertNotNull(jSType4);
//        org.junit.Assert.assertNotNull(jSTypeArray8);
//        org.junit.Assert.assertNotNull(jSType9);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(jSType11);
//        org.junit.Assert.assertNotNull(jSType14);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSType23);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertNotNull(jSTypeArray33);
//        org.junit.Assert.assertNotNull(jSType34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertNull(jSType40);
//        org.junit.Assert.assertNotNull(functionType43);
//        org.junit.Assert.assertNull(functionTypeList44);
//        org.junit.Assert.assertNotNull(strSet45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "function (): function (this:me, {1200655114}): me" + "'", str46.equals("function (): function (this:me, {1200655114}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable47);
//        org.junit.Assert.assertNotNull(jSType48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSTypeArray58);
//        org.junit.Assert.assertNotNull(jSType59);
//        org.junit.Assert.assertNotNull(jSTypeArray60);
//        org.junit.Assert.assertNotNull(jSType61);
//        org.junit.Assert.assertNotNull(jSType64);
//        org.junit.Assert.assertNotNull(jSType65);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        boolean boolean29 = jSTypeRegistry20.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType28);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
//        node33.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry11.createFunctionType(jSType28, node33);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
//        java.util.Set<java.lang.String> strSet39 = functionType37.getPropertyNames();
//        java.lang.String str40 = functionType37.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = functionType37.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry49.createOptionalType(jSType54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.createUnionType(jSTypeArray59);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.createUnionType(jSTypeArray65);
//        boolean boolean67 = jSTypeRegistry58.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType66);
//        com.google.javascript.rhino.Node node71 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
//        node71.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry49.createFunctionType(jSType66, node71);
//        boolean boolean76 = jSType46.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType75);
//        com.google.javascript.rhino.jstype.ObjectType objectType78 = functionType37.getImplicitPrototype();
//        boolean boolean79 = functionType37.isCheckedUnknownType();
//        boolean boolean80 = functionType37.isNativeObjectType();
//        boolean boolean81 = functionType37.isNullable();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNull(jSType34);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(functionTypeList38);
//        org.junit.Assert.assertNotNull(strSet39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): function (this:me, {1986274017}): me" + "'", str40.equals("function (): function (this:me, {1986274017}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray45);
//        org.junit.Assert.assertNotNull(jSType46);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertNotNull(objectType78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkFunctions;
        com.google.javascript.jscomp.SourceMap.Format format5 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy1;
        com.google.javascript.jscomp.SourceMap.Format format3 = null;
        compilerOptions0.sourceMapFormat = format3;
        java.lang.String str5 = compilerOptions0.inputDelimiter;
        boolean boolean6 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "// Input %num%" + "'", str5.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        node10.setType((int) 'a');
        boolean boolean14 = node10.hasOneChild();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 1, node6, node10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat19 = diagnosticType18.format;
        java.lang.String[] strArray20 = null;
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("hi!", node10, diagnosticType18, strArray20);
        java.io.PrintStream printStream22 = null;
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler(printStream22);
        com.google.javascript.rhino.Node node24 = compiler23.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator26);
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27);
        com.google.javascript.jscomp.SourceFile.Generator generator30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator30);
        com.google.javascript.jscomp.SourceFile.Generator generator33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator33);
        com.google.javascript.jscomp.SourceFile.Generator generator36 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator36);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray38 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile27, jSSourceFile31, jSSourceFile34, jSSourceFile37 };
        com.google.javascript.jscomp.JSModule jSModule40 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray41 = new com.google.javascript.jscomp.JSModule[] { jSModule40 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str43 = compilerOptions42.sourceMapOutputPath;
        boolean boolean44 = compilerOptions42.allowLegacyJsMessages;
        compilerOptions42.removeUnusedPrototypePropertiesInExterns = true;
        compiler23.init(jSSourceFileArray38, jSModuleArray41, compilerOptions42);
        compilerOptions42.aliasAllStrings = true;
        boolean boolean50 = jSError21.equals((java.lang.Object) compilerOptions42);
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = jSError21.getType();
        boolean boolean52 = diagnosticGroup0.matches(jSError21);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(messageFormat19);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNotNull(jSSourceFileArray38);
        org.junit.Assert.assertNotNull(jSModuleArray41);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry33.createUnionType(jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry38.createUnionType(jSTypeArray39);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { jSType40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry33.createUnionType(jSTypeArray41);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry33.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType28.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) objectType44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, false);
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry51.createUnionType(jSTypeArray52);
        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry48.createOptionalType(jSType53);
        boolean boolean55 = jSType53.isStringObjectType();
        boolean boolean56 = jSType45.canTestForShallowEqualityWith(jSType53);
        boolean boolean57 = jSType53.isResolved();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isSealed();
        java.lang.Object obj3 = context1.getDebuggerContextData();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1967691932}): me", 2, 20);
        functionNode3.setEncodedSourceBounds(27, (int) (byte) 100);
        functionNode3.removeParamOrVar("function (): function (this:me, {1311234794}): me");
        functionNode3.setBaseLineno((int) (byte) 100);
        try {
            java.lang.String str12 = functionNode3.getParamOrVarName((-3));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: -3 ∉ [0, 0)");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        java.lang.String str5 = compilerInput3.getName();
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup17, checkLevel18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup20, checkLevel21);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup23, checkLevel24);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray26 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard10, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard19, diagnosticGroupWarningsGuard22, diagnosticGroupWarningsGuard25 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel29);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard33 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup31, checkLevel32);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup34, checkLevel35);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup37, checkLevel38);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup40 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard42 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup40, checkLevel41);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup43 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard45 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup43, checkLevel44);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray46 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard30, diagnosticGroupWarningsGuard33, diagnosticGroupWarningsGuard36, diagnosticGroupWarningsGuard39, diagnosticGroupWarningsGuard42, diagnosticGroupWarningsGuard45 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard47 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray46);
        com.google.javascript.rhino.Node node53 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node57 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType58 = node57.getJSType();
        node57.setType((int) 'a');
        boolean boolean61 = node57.hasOneChild();
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (short) 1, node53, node57);
        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat66 = diagnosticType65.format;
        java.lang.String[] strArray67 = null;
        com.google.javascript.jscomp.JSError jSError68 = com.google.javascript.jscomp.JSError.make("hi!", node57, diagnosticType65, strArray67);
        com.google.javascript.jscomp.CheckLevel checkLevel69 = composeWarningsGuard47.level(jSError68);
        com.google.javascript.jscomp.CheckLevel checkLevel70 = composeWarningsGuard27.level(jSError68);
        compiler7.report(jSError68);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        compiler7.reportCodeChange();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
        org.junit.Assert.assertNotNull(diagnosticGroup23);
        org.junit.Assert.assertNotNull(warningsGuardArray26);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroup34);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertNotNull(diagnosticGroup40);
        org.junit.Assert.assertNotNull(diagnosticGroup43);
        org.junit.Assert.assertNotNull(warningsGuardArray46);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(diagnosticType65);
        org.junit.Assert.assertNotNull(messageFormat66);
        org.junit.Assert.assertNotNull(jSError68);
        org.junit.Assert.assertNull(checkLevel69);
        org.junit.Assert.assertNull(checkLevel70);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setType((int) 'a');
        boolean boolean9 = node5.hasOneChild();
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        node13.setType((int) 'a');
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        node5.addChildAfter(node13, node20);
        com.google.javascript.rhino.Node node23 = functionParamBuilder1.newParameterFromNode(node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo24 = node13.getJSDocInfo();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSDocInfo24);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry14.createUnionType(jSTypeArray15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry11.createOptionalType(jSType16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry20.createUnionType(jSTypeArray21);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeArray27);
//        boolean boolean29 = jSTypeRegistry20.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType28);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
//        node33.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry11.createFunctionType(jSType28, node33);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
//        java.util.Set<java.lang.String> strSet39 = functionType37.getPropertyNames();
//        java.lang.String str40 = functionType37.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = functionType37.getAllImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry44.createUnionType(jSTypeArray45);
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry52.createUnionType(jSTypeArray53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry49.createOptionalType(jSType54);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry58.createUnionType(jSTypeArray59);
//        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry64.createUnionType(jSTypeArray65);
//        boolean boolean67 = jSTypeRegistry58.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType66);
//        com.google.javascript.rhino.Node node71 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
//        node71.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry49.createFunctionType(jSType66, node71);
//        boolean boolean76 = jSType46.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType75);
//        boolean boolean78 = functionType37.isUnknownType();
//        java.lang.String str79 = functionType37.getTemplateTypeName();
//        boolean boolean80 = functionType37.isArrayType();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(jSType16);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(jSType22);
//        org.junit.Assert.assertNotNull(jSTypeArray27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNull(jSType34);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(functionTypeList38);
//        org.junit.Assert.assertNotNull(strSet39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): function (this:me, {1964500819}): me" + "'", str40.equals("function (): function (this:me, {1964500819}): me"));
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray45);
//        org.junit.Assert.assertNotNull(jSType46);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(jSType60);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNull(str79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1967691932}): me", 2, 20);
        functionNode3.setEncodedSourceBounds(27, (int) (byte) 100);
        functionNode3.removeParamOrVar("function (): function (this:me, {1311234794}): me");
        int int10 = functionNode3.addVar("function (this:me, {450531040}): me");
        boolean boolean11 = functionNode3.getIgnoreDynamicScope();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
        boolean boolean31 = functionType28.isInstanceType();
        boolean boolean33 = functionType28.isPropertyTypeInferred("function (): function (this:me, {2041641234}): me");
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback3);
        java.lang.String str5 = nodeTraversal4.getSourceName();
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setType((int) 'a');
        boolean boolean13 = node9.hasOneChild();
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        java.lang.String str19 = node9.checkTreeEquals(node17);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry25.createUnionType(jSTypeArray26);
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry22.createOptionalType(jSType27);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry31.createUnionType(jSTypeArray32);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry37.createUnionType(jSTypeArray38);
        boolean boolean40 = jSTypeRegistry31.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType39);
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        node44.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry22.createFunctionType(jSType39, node44);
        com.google.javascript.rhino.Node node53 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node57 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType58 = node57.getJSType();
        node57.setType((int) 'a');
        boolean boolean61 = node57.hasOneChild();
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (short) 1, node53, node57);
        int int63 = node57.getCharno();
        com.google.javascript.rhino.Node node64 = node44.clonePropsFrom(node57);
        com.google.javascript.rhino.Node node65 = node9.copyInformationFrom(node44);
        com.google.javascript.jscomp.DiagnosticType diagnosticType68 = com.google.javascript.jscomp.DiagnosticType.warning("function (): function (this:me, {1975058800}): me", "function (): function (this:me, {695033205}): me");
        java.lang.String[] strArray69 = null;
        try {
            nodeTraversal4.report(node65, diagnosticType68, strArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n" + "'", str19.equals("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n"));
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(diagnosticType68);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkGlobalThisLevel = checkLevel3;
        java.lang.String[] strArray10 = new java.lang.String[] { "ASSIGN_MOD  9\n", "ASSIGN_MOD  9\n", "hi!", "ASSIGN_MOD  9\n" };
        java.util.ArrayList<java.lang.String> strList11 = new java.util.ArrayList<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList11, strArray10);
        compilerOptions0.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList11);
        compilerOptions0.setColorizeErrorOutput(false);
        com.google.javascript.rhino.EcmaError ecmaError18 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        java.lang.String str19 = ecmaError18.getName();
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str21 = compilerOptions20.sourceMapOutputPath;
        compilerOptions20.setNameAnonymousFunctionsOnly(false);
        boolean boolean24 = compilerOptions20.inlineLocalFunctions;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN;
        java.lang.RuntimeException runtimeException26 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) ecmaError18, (java.lang.Object) compilerOptions20, (java.lang.Object) jSTypeNative25);
        java.lang.String str27 = compilerOptions20.sourceMapOutputPath;
        compilerOptions20.inlineFunctions = true;
        boolean boolean30 = compilerOptions20.inlineFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str32 = compilerOptions31.sourceMapOutputPath;
        boolean boolean33 = compilerOptions31.checkDuplicateMessages;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap34 = null;
        compilerOptions31.cssRenamingMap = cssRenamingMap34;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = compilerOptions31.reportUnknownTypes;
        compilerOptions20.reportUnknownTypes = checkLevel36;
        compilerOptions0.reportMissingOverride = checkLevel36;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(ecmaError18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN));
        org.junit.Assert.assertNotNull(runtimeException26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.createUnionType(jSTypeArray11);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] { jSType12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry5.createUnionType(jSTypeArray13);
        com.google.javascript.rhino.Node node15 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray13);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder16 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.Node node17 = functionParamBuilder16.build();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("function (): function (this:me, {1927451982}): me", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("function (): function (this:me, {1399344290}): me");
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        boolean boolean29 = jSType19.isCheckedUnknownType();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setType((int) 'a');
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setType((int) 'a');
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        node3.addChildAfter(node11, node18);
        java.lang.String str21 = node11.toStringTree();
        boolean boolean22 = node11.isQualifiedName();
        com.google.javascript.rhino.Node node23 = node11.getNext();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ASSIGN_MOD  9\n" + "'", str21.equals("ASSIGN_MOD  9\n"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(node23);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator4);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile9, jSSourceFile12, jSSourceFile15 };
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] { jSModule18 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str21 = compilerOptions20.sourceMapOutputPath;
        boolean boolean22 = compilerOptions20.allowLegacyJsMessages;
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = true;
        compiler1.init(jSSourceFileArray16, jSModuleArray19, compilerOptions20);
        java.lang.String str26 = compiler1.toSource();
        java.io.PrintStream printStream27 = null;
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler(printStream27);
        com.google.javascript.rhino.Node node29 = compiler28.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.SourceFile.Generator generator35 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator35);
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator38);
        com.google.javascript.jscomp.SourceFile.Generator generator41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator41);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile36, jSSourceFile39, jSSourceFile42 };
        com.google.javascript.jscomp.JSModule jSModule45 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray46 = new com.google.javascript.jscomp.JSModule[] { jSModule45 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str48 = compilerOptions47.sourceMapOutputPath;
        boolean boolean49 = compilerOptions47.allowLegacyJsMessages;
        compilerOptions47.removeUnusedPrototypePropertiesInExterns = true;
        compiler28.init(jSSourceFileArray43, jSModuleArray46, compilerOptions47);
        java.io.PrintStream printStream53 = null;
        com.google.javascript.jscomp.Compiler compiler54 = new com.google.javascript.jscomp.Compiler(printStream53);
        com.google.javascript.rhino.Node node55 = compiler54.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator57 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile58 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator57);
        com.google.javascript.jscomp.CompilerInput compilerInput59 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile58);
        com.google.javascript.jscomp.SourceFile.Generator generator61 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator61);
        com.google.javascript.jscomp.SourceFile.Generator generator64 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator64);
        com.google.javascript.jscomp.SourceFile.Generator generator67 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile68 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator67);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray69 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile58, jSSourceFile62, jSSourceFile65, jSSourceFile68 };
        com.google.javascript.jscomp.JSModule jSModule71 = new com.google.javascript.jscomp.JSModule("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n");
        com.google.javascript.jscomp.JSModule[] jSModuleArray72 = new com.google.javascript.jscomp.JSModule[] { jSModule71 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions73 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str74 = compilerOptions73.sourceMapOutputPath;
        boolean boolean75 = compilerOptions73.allowLegacyJsMessages;
        compilerOptions73.removeUnusedPrototypePropertiesInExterns = true;
        compiler54.init(jSSourceFileArray69, jSModuleArray72, compilerOptions73);
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str80 = compilerOptions79.sourceMapOutputPath;
        boolean boolean81 = compilerOptions79.allowLegacyJsMessages;
        com.google.javascript.jscomp.CheckLevel checkLevel82 = compilerOptions79.checkRequires;
        compilerOptions79.printInputDelimiter = true;
        com.google.javascript.jscomp.Result result85 = compiler1.compile(jSSourceFileArray43, jSModuleArray72, compilerOptions79);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSModuleArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertNotNull(jSModuleArray46);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNotNull(jSSourceFile58);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(jSSourceFile68);
        org.junit.Assert.assertNotNull(jSSourceFileArray69);
        org.junit.Assert.assertNotNull(jSModuleArray72);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + checkLevel82 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel82.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result85);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard8 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup9, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel13);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel16);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray18 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2, diagnosticGroupWarningsGuard5, diagnosticGroupWarningsGuard8, diagnosticGroupWarningsGuard11, diagnosticGroupWarningsGuard14, diagnosticGroupWarningsGuard17 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard19 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray18);
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        node29.setType((int) 'a');
        boolean boolean33 = node29.hasOneChild();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (short) 1, node25, node29);
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.DiagnosticType.disabled("", "hi!");
        java.text.MessageFormat messageFormat38 = diagnosticType37.format;
        java.lang.String[] strArray39 = null;
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("hi!", node29, diagnosticType37, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = composeWarningsGuard19.level(jSError40);
        int int42 = jSError40.lineNumber;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertNotNull(warningsGuardArray18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(messageFormat38);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNull(checkLevel41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
//        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
//        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
//        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
//        node24.setType((int) 'a');
//        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
//        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
//        java.lang.String str31 = functionType28.toDebugHashCodeString();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo33 = null;
//        functionType28.setPropertyJSDocInfo("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSDocInfo33, true);
//        boolean boolean37 = functionType28.isPropertyTypeInferred("");
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSTypeArray12);
//        org.junit.Assert.assertNotNull(jSType13);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(node24);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(functionType28);
//        org.junit.Assert.assertNull(functionTypeList29);
//        org.junit.Assert.assertNotNull(strSet30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "function (): function (this:me, {84917265}): me" + "'", str31.equals("function (): function (this:me, {84917265}): me"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList29 = functionType28.getSubTypes();
        java.util.Set<java.lang.String> strSet30 = functionType28.getPropertyNames();
        boolean boolean31 = functionType28.matchesStringContext();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry37.createUnionType(jSTypeArray38);
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry34.createOptionalType(jSType39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry46.createUnionType(jSTypeArray47);
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry51.createUnionType(jSTypeArray52);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] { jSType53 };
        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry46.createUnionType(jSTypeArray54);
        com.google.javascript.rhino.Node node56 = jSTypeRegistry43.createParametersWithVarArgs(jSTypeArray54);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder57 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry43);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray61 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType62 = jSTypeRegistry60.createUnionType(jSTypeArray61);
        com.google.javascript.rhino.Node node63 = jSTypeRegistry43.createParametersWithVarArgs(jSTypeArray61);
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry34.createUnionType(jSTypeArray61);
        boolean boolean65 = functionType28.canAssignTo(jSType64);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(functionTypeList29);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(jSTypeArray54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(jSTypeArray61);
        org.junit.Assert.assertNotNull(jSType62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean4 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.closurePass = false;
        boolean boolean7 = compilerOptions0.inlineVariables;
        compilerOptions0.reportPath = "setelem";
        boolean boolean10 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.collapseProperties;
        com.google.javascript.jscomp.MessageBundle messageBundle4 = null;
        compilerOptions0.messageBundle = messageBundle4;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        java.lang.String str7 = compilerOptions0.jsOutputFile;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.checkProvides = checkLevel8;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.createUnionType(jSTypeArray6);
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.createOptionalType(jSType7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry11.createUnionType(jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.createUnionType(jSTypeArray18);
        boolean boolean20 = jSTypeRegistry11.declareType("Node tree inequality:\nTree1:\nASSIGN_MOD  9\n\n\nTree2:\nNAME  9\n\n\nSubtree1: ASSIGN_MOD  9\n\n\nSubtree2: NAME  9\n", jSType19);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("", 9, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        node24.setType((int) 'a');
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry2.createFunctionType(jSType19, node24);
        java.lang.String str29 = functionType28.toString();
        boolean boolean31 = functionType28.isPropertyInExterns("function (): function (this:me, {327460564}): me");
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "function (): None" + "'", str29.equals("function (): None"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.sourceMapOutputPath;
        boolean boolean2 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        compilerOptions0.sourceMapOutputPath = "hi!";
        compilerOptions0.checkDuplicateMessages = true;
        compilerOptions0.debugFunctionSideEffectsPath = "function (): function (this:me, {977480980}): me";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

