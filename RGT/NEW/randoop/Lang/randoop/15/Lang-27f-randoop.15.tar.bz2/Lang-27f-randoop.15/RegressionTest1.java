import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("###############################################################################################################################################", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("hi!", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", "", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("US", "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java Virtual Machine Specification", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j" + "'", str2.equals("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "java Platform API Specification", "Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.0", (int) (short) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion", "tiklooTCWL.xsocam.twawl.nus");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("aaaa.7aaaa", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("en", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/Home/jre" + "'", str2.equals("s/Home/jre"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                               Oracle Corporation" + "'", str2.equals("                                                                               Oracle Corporation"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Or#cle Corpor#tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Or#cle Corpor#tion" + "'", str1.equals("Or#cle Corpor#tion"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ion", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ion" + "'", str2.equals("ion"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                           /Users/sophie                                            ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 10.0f, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 156 + "'", int1 == 156);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "24.80-b11" + "'", str0.equals("24.80-b11"));
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 143, (float) (short) 1, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 143.0f + "'", float3 == 143.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                           /Users/sophie                                            ", 18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects" + "'", str1.equals("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "51.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "ion", 44);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion" + "'", str3.equals("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mac OS X", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("\n", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("US", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US " + "'", str2.equals("US "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java(TM) SE Runtime Environment", "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jv(TM)SERF-Ev-F" + "'", str3.equals("Jv(TM)SERF-Ev-F"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("jAVA pLATFORM api sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: jAVA pLATFORM api sPECIFICATION is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("   HI!    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("\n", "UTF-8", "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "or cle corpor tion", "1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 3, "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "615" + "'", str3.equals("615"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Or#cle Corpor#tion", "615", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Or#cle Corpor#tion" + "'", str3.equals("Or#cle Corpor#tion"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaa.7aaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", "oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.isJavaAwtHeadless();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.Object[] objArray2 = new java.lang.Object[] { "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (short) -1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray2, '4');
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "hi", 10, (int) (short) 0);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "tionacle CorporaOr", 143);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str3.equals("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_2000;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 100, (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("tionacle CorporaOr", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("24.80-b11", "Or#cle Corpor#tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("en");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("   hi!    ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   hi!    " + "'", str3.equals("   hi!    "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_EXT_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str0.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 7, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Orcle Corportion", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orcle Corportion" + "'", str2.equals("Orcle Corportion"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Java(TM) SE Runtime Environment", "Orcle Corportion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Mac OS X");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", "o");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                                                                               Oracle Corporation", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("or cle corpor tion", "1.7", "hi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie                                                                                       " + "'", str2.equals("/Users/sophie                                                                                       "));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "US ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10, (double) 35.0f, (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("###############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################################################################################################################################" + "'", str1.equals("###############################################################################################################################################"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 217 + "'", int1 == 217);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str1.equals(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java Virtual Machine Specification", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("615", (long) 156);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 615L + "'", long2 == 615L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "                                                                                                 ", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.14.3", "Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("java Platform API Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str2.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("jAVA pLATFORM api sPECIFICATION", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str3.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("US", "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", 0, 170);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10" + "'", str4.equals("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7d + "'", double2 == 1.7d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", 31, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("    !IH   ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    !IH   " + "'", str2.equals("    !IH   "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specification", 3, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a V" + "'", str3.equals("a V"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Java HotSpot(TM) 64-Bit Server VM", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("o", "", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "o" + "'", str3.equals("o"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("o", "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", "51.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        byte[] byteArray0 = new byte[] {};
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("   HI!    ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("or cle corpor tion", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", "o");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Jv(TM)SERF-Ev-F");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("Jv(TM)SERF-Ev-F", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle Corporation", 143, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "Oracle Corporation", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0.equals((-1)));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("1.7", "stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1", "/Users/sophie                                                                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("-1a10", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("\n", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("o", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    o     " + "'", str3.equals("    o     "));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hi!", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         hi!" + "'", str2.equals("                                         hi!"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 143);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", charSequence2.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("   HI!    ", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   HI!    " + "'", str2.equals("   HI!    "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("    o     ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    o     " + "'", str2.equals("    o     "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str2.equals(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", "US ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Platform API Specification" + "'", str1.equals("java Platform API Specification"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("UTF-8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 7, 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Java Virtual Machine Specification", "Jv(TM)SERF-Ev-F", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_TIMEZONE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10.14.3", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "615");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkit", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str5.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10.14.3", 155);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 97);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Oracle Corporation", "615", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", "   hi!    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_ZERO;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0.equals((byte) 0));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophie", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("###############################################################################################################################################", (int) (short) 10, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################################################################################################################" + "'", str3.equals("###############################################################################################################################################"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Or#cle Corpor#tion", "o", (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "opor#tion" + "'", str4.equals("opor#tion"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Platform API Specification", "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION" + "'", str1.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/..." + "'", str2.equals("/Users/..."));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(69, (int) '4', 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                 ", (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie                                                                                       ", 6, "    o     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie                                                                                       " + "'", str3.equals("/Users/sophie                                                                                       "));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(".7", 18, 155);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("jAVA pLATFORM api sPECIFICATION", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-FTU" + "'", str1.equals("8-FTU"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "Or#cle Corpor#tion", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Or#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tion" + "'", str3.equals("Or#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tion"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("HI!", "sun.lwawt.macosx.LWCToolkit", 6, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI!sun.lwawt.macosx.LWCToolkit" + "'", str4.equals("HI!sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("o", "1.7.0_80");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "/Users/sophie                                                                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", 1, "tionacle CorporaOr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10.14.3", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("615");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(97, (int) (short) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                                 ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                 " + "'", str4.equals("                                                                                                 "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hi", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1), 143.0f, (float) 31);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion" + "'", str2.equals("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.LWCToolkitaaaa.7aaaaOr cle Corpor tion", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitaaaa.7aaaaOr cle Corpor tion" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitaaaa.7aaaaOr cle Corpor tion"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("opor#tion", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (int) (byte) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1a10", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 10" + "'", str3.equals("-1 10"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("x86_64", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "    !IH   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "615", "ion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", ":", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("US", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.String[] strArray5 = new java.lang.String[] { "sun.lwawt.macosx.LWCToolkit", "10.14.3", "o", "UTF-8" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", ".7", (int) (short) -1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("o", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, (int) (short) 10, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("sun.lwawt.macosx.LWCToolkitaaaa.7aaaaOr cle Corpor tion", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double[] doubleArray3 = new double[] { 100.0f, 1.0f, (short) 10 };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + "'", str3.equals("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Mac OS X", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", "   HI!    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/...", "o");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("opor#tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "opor#tion" + "'", str1.equals("opor#tion"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", 217);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("s/Home/jre", (int) (byte) 0, "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s/Home/jre" + "'", str3.equals("s/Home/jre"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String[] strArray9 = new java.lang.String[] { "sun.lwawt.macosx.LWCToolkit", "Or cle Corpor tion" };
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "HI!");
        java.lang.String[] strArray14 = new java.lang.String[] { "sun.lwawt.macosx.LWCToolkit", "Or cle Corpor tion" };
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "HI!");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion", strArray9, strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray16);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.startsWithAny("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", strArray16);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.startsWithAny("1.7.0_80-b15", strArray16);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion" + "'", str17.equals("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("615", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_GRAPHICSENV;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str0.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Or cle Corpor tion", "Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.CPrinterJob", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("opor#tion", "oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "opor#tion" + "'", str2.equals("opor#tion"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("ion", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516", "aaaa.7aaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 10, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: http://java.oracle.com/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("or cle corpor tion", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cle corpor tion" + "'", str2.equals("cle corpor tion"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("615");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "615" + "'", str1.equals("615"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("opor#tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "opor#tion" + "'", str1.equals("opor#tion"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "8-FTU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation", "###############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Jv(TM)SERF-Ev-F", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM)SERF-Ev-F" + "'", str2.equals("Jv(TM)SERF-Ev-F"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("tionacle CorporaOr", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Or#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tion", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "hi", 10, (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 1, 0);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", strArray3);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray16);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!", '4');
        int int23 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", strArray22);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEach("10.14.3", strArray16, strArray22);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray22, ".7", (int) (short) -1, (int) (short) -1);
        try {
            java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEach("    !IH   ", strArray3, strArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Oracle Corporation" + "'", str17.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10.14.3" + "'", str24.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects" + "'", str2.equals("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("sun.lwawt.macosx.LWCToolkit", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Or#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tion", "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 69, (int) ' ');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi", "                                           /Users/sophie                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "aaaa.7aaaa", "ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Or cle Corpor tion", (int) (byte) 1, 0);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                               Oracle Corporation", '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("a V", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("8-FTU", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8-FTU" + "'", str2.equals("8-FTU"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 44, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "1.", 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION", "US ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 3, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Or#cle Corpor#tion" + "'", str5.equals("Or#cle Corpor#tion"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1 10", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("tiklooTCWL.xsocam.twawl.nus", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava" + "'", str2.equals("Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sun.lwawt.macosx.CPrinterJob", "Orcle Corportion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", (double) 217);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 217.0d + "'", double2 == 217.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("or cle corpor tion", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", "                                         hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "o");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "ion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("S");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"S\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str2.equals("//java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaa.7aaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', (double) 'a', (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", "mixed mode", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt./acSsS.LWCTSSlkut1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrpSrStuSn" + "'", str3.equals("sun.lwawt./acSsS.LWCTSSlkut1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrpSrStuSn"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "Java Platform API Specification", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 18, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1.7", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("opor#tion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"opor#tion\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1a10", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, (long) (byte) 100, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("   hi!    ", 156, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                            hi!                                                                             " + "'", str3.equals("                                                                            hi!                                                                             "));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIKLOOtcwl.XSOCAM.TWAWL.NUS" + "'", str1.equals("TIKLOOtcwl.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "or cle corpor tion", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 10, (double) 7, (double) 155);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, (float) '4', (float) 44);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "1.7.0_80", 217);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion", "tionacle CorporaOr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US ", "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USr" + "'", str3.equals("USr"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/..." + "'", str1.equals("/Users/..."));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "Jv(TM)SERF-Ev-F", 155);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporation", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("hi", "USr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("en", "en", 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "enen" + "'", str4.equals("enen"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("o", (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Jv(TM)SERF-Ev-F");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Jv(TM)SERF-Ev-F", "cle corpor tion");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "opor#tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100, (double) 10L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.7f + "'", float1 == 1.7f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("S", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("enen", "ion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enen" + "'", str2.equals("enen"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Mac OS X", "###############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Platform API Specification", 18);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("sun.lwawt.macosx.CPrinterJob", strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", strArray5, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/                                                                                                                                                   " + "'", str2.equals("http://java.oracle.com/                                                                                                                                                   "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("a V", "                                                                            hi!                                                                             ", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi", 69, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("s/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s/home/jre" + "'", str1.equals("s/home/jre"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("s/Home/jre", "aaaa.7aaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("jAVA pLATFORM api sPECIFICATION", "                                         hi!", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA pLATFORM api sPECIFICATION" + "'", str1.equals("JAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie", "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("s/Home/jre", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/Home/jre" + "'", str2.equals("s/Home/jre"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                               Oracle Corporation", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("a V");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aV" + "'", str1.equals("aV"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Jv(TM)SERF-Ev-F", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "-1a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!", '4');
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("10.14.3", strArray4, strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", '#');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray14, strArray17);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oracle Corporation" + "'", str5.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.14.3" + "'", str12.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str18.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "enen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enen" + "'", str1.equals("enen"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "    !IH   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    !IH   " + "'", str2.equals("    !IH   "));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("enen", "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Or#cle Corpor#tion", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Java Virtual Machine Specification", ":", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Or#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tion", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) ' ', "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tiklooTCWL.xsocam.twawl.nustiklo" + "'", str3.equals("tiklooTCWL.xsocam.twawl.nustiklo"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("###############################################################################################################################################", "opor#tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################################################################################################################################" + "'", str2.equals("###############################################################################################################################################"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!", 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("tionacle CorporaOr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tionacle CorporaOr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("mixed mode", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("8-FTU", "8-FTU", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification6aJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10" + "'", str4.equals("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification6aJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("51.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 51.0f + "'", float1 == 51.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", "   hi!    ", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.awt.CGraphicsEnvironment", "Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation", "oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.cGraphicsEnvironment" + "'", str3.equals("sun.awt.cGraphicsEnvironment"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mode");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("enen", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("USr", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USr" + "'", str2.equals("USr"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("mixed mode", 156);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("ion", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("   hi!    ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_OS2;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "USr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "08_0.7.1" + "'", str1.equals("08_0.7.1"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("opor#tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "s/Home/jre", "hi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("enen", (int) (byte) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enen" + "'", str3.equals("enen"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("//java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.LWCToolkit", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "kit" + "'", str2.equals("kit"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Orcle Corportion", "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 1, 44);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("615");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("615", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "615" + "'", str2.equals("615"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("1.7.0_80-b15", "USr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Or cle Corpor tion", (int) (byte) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concatWith("Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "OrSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavacle CorporSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavation" + "'", str10.equals("OrSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavacle CorporSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavation"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("10.14.3", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Or#cle Corpor#tion", (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "hi", 10, (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concatWith("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516", (java.lang.Object[]) strArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("o", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation" + "'", str11.equals("Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7", "Orcle Corportion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("enen", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enen" + "'", str3.equals("enen"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("   hi!    ", 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  hi!    " + "'", str3.equals("  hi!    "));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) ":", (java.lang.CharSequence) "-1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1a10", 69, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server V-1a10Java HotSpot(TM) 64-Bit Server V" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server V-1a10Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("hi", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

