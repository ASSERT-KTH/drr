import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(".7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7" + "'", str1.equals(".7"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "Oracle Corporation", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("1.7", (java.lang.Object[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7" + "'", str7.equals("1.7"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "tionacle CorporaOr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion", "08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 97L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("java Platform API Specification");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java Platform API Specification" + "'", str3.equals("java Platform API Specification"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java(TM) SE Runtime Environment", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)4SE4Runtime4Environment" + "'", str3.equals("Java(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("o", "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie                                                                                       ", 31, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), 155, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt./acSsS.LWCTSSlkut1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrpSrStuSn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt./acSsS.LWCTSSlkut1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrpSrStuSn" + "'", str1.equals("sun.lwawt./acSsS.LWCTSSlkut1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrpSrStuSn"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", "stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-xJvPAPISJvPAPISJvPAPISJvPAPIS" + "'", str3.equals("-xJvPAPISJvPAPISJvPAPISJvPAPIS"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("    o     ", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    o     " + "'", str3.equals("    o     "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String[] strArray4 = new java.lang.String[] { "sun.lwawt.macosx.LWCToolkit", "Or cle Corpor tion" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "HI!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", (java.lang.Object[]) strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", "Or cle Corpor tion", (int) '#');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                 ", strArray6, strArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion" + "'", str7.equals("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion" + "'", str9.equals("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion" + "'", str11.equals("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion"));
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Jv(TM)SERF-Ev-F", "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 0, (float) (-1L), 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKIToR CLE cORPOR TION" + "'", str1.equals("SUN.LWAWT.MACOSX.lwctOOLKIToR CLE cORPOR TION"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516", (int) 'a', (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".../run_randoop.pl_10208_1560228516" + "'", str3.equals(".../run_randoop.pl_10208_1560228516"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/...", "    o     ", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/..." + "'", str3.equals("/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/..."));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "SUN.LWAWT.MACOSX.lwctOOLKIToR CLE cORPOR TION", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ".../run_randoop.pl_10208_1560228516", "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "###############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", charSequence2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("HI!", 156);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.concat(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nustiklo", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie                                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                       eihpos/sresU/" + "'", str1.equals("                                                                                       eihpos/sresU/"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Java HotSpot(TM) 64-Bit Server V-1a10Java HotSpot(TM) 64-Bit Server V", "-xJvPAPISJvPAPISJvPAPISJvPAPIS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Jv(TM)SERF-Ev-F", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jv(TM)SERF-Ev-F" + "'", str3.equals("Jv(TM)SERF-Ev-F"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 10);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                 ", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 13 vs 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("tionacle CorporaOr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionacle CorporaOr" + "'", str1.equals("tionacle CorporaOr"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie", "aV", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/..." + "'", str2.equals("/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/..."));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "###############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server VM", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "s/home/jre", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                         hi!", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "JAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie                                                                                       ", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie                                                                                       " + "'", str2.equals("/Users/sophie                                                                                       "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                                                       eihpos/sresU/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) ".../run_randoop.pl_10208_1560228516");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aV", 51.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.0f + "'", float2 == 51.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("opor#tion", "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Orcle Corportion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "615");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion", strArray9, strArray12);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion", strArray3, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation" + "'", str8.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion" + "'", str13.equals("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("kit", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaakit" + "'", str3.equals("aaaaaaakit"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Jv(TM)SERF-Ev-F");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Platform API Specification", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Java Platform API Specification" + "'", str6.equals("Java Platform API Specification"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi", "-xJvPAPISJvPAPISJvPAPISJvPAPIS");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!" + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0L, 7.0d, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("or cle corpor tion", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Or cle Corpor tion", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("s/home/jre", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(".7");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7d + "'", double1 == 0.7d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("http://java.oracle.com/                                                                                                                                                   ", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/                                                                                                                                                   " + "'", str2.equals("http://java.oracle.com/                                                                                                                                                   "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("s/home/jre", "http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "8-FTU", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "8-FTU" + "'", charSequence2.equals("8-FTU"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("-1 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 10" + "'", str1.equals("-1 10"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("08_0.7.1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "cle corpor tion", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 157 + "'", int2 == 157);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("   HI!    ", "JAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.CPrinterJob", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("s/Home/jre", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/Home/jre" + "'", str2.equals("s/Home/jre"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("08_0.7.1", (int) (byte) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(".../run_randoop.pl_10208_1560228516");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".../run_randoop.pl_10208_1560228516\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion", 143);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 7.0d, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("java Platform API Specification", "/Users/...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j" + "'", str1.equals("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "Oracle Corporation", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("1.7", (java.lang.Object[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7" + "'", str6.equals("1.7"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava", 0, "                                         hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava" + "'", str3.equals("Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2, (double) (short) 100, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("HI!sun.lwawt.macosx.LWCToolkit", "sun.lwawt./acSsS.LWCTSSlkut1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrpSrStuSn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ion", 69, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444ion" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444ion"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("US ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("08_0.7.1", "Or#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.1" + "'", str2.equals("08_0.7.1"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JAVA pLATFORM api sPECIFICATION", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt.macosx.LWCToolkitaaaa.7aaaaOr cle Corpor tion", "\n", "s/home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitaaaa.7aaaaOr cle Corpor tion" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitaaaa.7aaaaOr cle Corpor tion"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "08_0.7.1", 157);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mixed mode", "Mac OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedamode" + "'", str3.equals("mixedamode"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.awt.CGraphicsEnvironment", (int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("s/home/jre", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", 2, 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aV", 0, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aV" + "'", str3.equals("aV"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/..." + "'", str1.equals("/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/..."));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "s/Home/jre", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...", ":", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "o");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int[] intArray4 = new int[] { 170, (byte) 100, 1, (byte) 100 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 170 + "'", int5 == 170);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 170 + "'", int6 == 170);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/", "aaaa.7aaaa", (int) (byte) 10, 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/aaaa.7aaaa" + "'", str4.equals("/aaaa.7aaaa"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java HotSpot(TM) 64-Bit Server V-1a10Java HotSpot(TM) 64-Bit Server V", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification6aJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", "US ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification6aJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10" + "'", str2.equals("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification6aJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("Java HotSpot(TM) 64-Bit Server VM", (java.lang.Object[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion" + "'", str8.equals("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Orcle Corporclecle CorporCorporcle Corportion"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "OrJava HotSpot(TM) 64-Bit Server VMcle CorporJava HotSpot(TM) 64-Bit Server VMtion" + "'", str9.equals("OrJava HotSpot(TM) 64-Bit Server VMcle CorporJava HotSpot(TM) 64-Bit Server VMtion"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", (java.lang.CharSequence) "                                                                                       eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava" + "'", str2.equals("Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        long[] longArray2 = new long[] { 217, (byte) 0 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("mixed mode");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "444444444444444444444444444444444444444444444444444444444444444444ion");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed444444444444444444444444444444444444444444444444444444444444444444ion 444444444444444444444444444444444444444444444444444444444444444444ionmode" + "'", str3.equals("mixed444444444444444444444444444444444444444444444444444444444444444444ion 444444444444444444444444444444444444444444444444444444444444444444ionmode"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Or#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tionOr#cle Corpor#tion", 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("US ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us " + "'", str1.equals("us "));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("SUN.LWAWT.MACOSX.lwctOOLKIToR CLE cORPOR TION", 4, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKIToR CLE cORPOR TION" + "'", str3.equals("SUN.LWAWT.MACOSX.lwctOOLKIToR CLE cORPOR TION"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification6aJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXJAVA PLATFORM API SPECIFICATION86JAVA PLATFORM API SPECIFICATION_JAVA PLATFORM API SPECIFICATION6AJAVA PLATFORM API SPECIFICATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10" + "'", str1.equals("-1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXJAVA PLATFORM API SPECIFICATION86JAVA PLATFORM API SPECIFICATION_JAVA PLATFORM API SPECIFICATION6AJAVA PLATFORM API SPECIFICATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("US ", "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US " + "'", str2.equals("US "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/", "aaaaaaakit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ion", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", (int) (byte) 0, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/aaaa.7aaaa", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("//java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"//java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "-1a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "   HI!    ", 156);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!    " + "'", str3.equals("   HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!    "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("tionacle CorporaOr", "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionacle CorporaOr" + "'", str2.equals("tionacle CorporaOr"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification6aJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("615", 69, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################615#################################" + "'", str3.equals("#################################615#################################"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        long[] longArray4 = new long[] { (byte) 100, (short) 10, (byte) 10, (short) 1 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                           /Users/sophie                                            ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("   HI!    ", strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j" + "'", str2.equals("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("en", (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Or#cle Corpor#tion", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXJAVA PLATFORM API SPECIFICATION86JAVA PLATFORM API SPECIFICATION_JAVA PLATFORM API SPECIFICATION6AJAVA PLATFORM API SPECIFICATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("hi", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, 0L, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) -1, 100L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("SUN.LWAWT.MACOSX.lwctOOLKIToR CLE cORPOR TION", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "cle corpor tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Jv(TM)SERF-Ev-F", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM)SERF-Ev-F" + "'", str2.equals("Jv(TM)SERF-Ev-F"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-1a10", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a10" + "'", str2.equals("-1a10"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("    o     ", "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "###############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    o     " + "'", str3.equals("    o     "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("08_0.7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10.14.3", "                                                                                       eihpos/sresU/", "Mac OS X", 14);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.14.3" + "'", str4.equals("10.14.3"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, (float) ' ', (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + "'", str1.equals("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION", "615");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPROc ELCARo" + "'", str1.equals("NOITAROPROc ELCARo"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("tiklooTCWL.xsocam.twawl.nustiklo");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("OrSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavacle CorporSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavation", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "or cle corpor tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("TIKLOOtcwl.XSOCAM.TWAWL.NUS", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + "'", str2.equals("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "//java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 189 + "'", int2 == 189);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("   hi!    ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(35L, 0L, (long) 155);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 155L + "'", long3 == 155L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                 ", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nustiklo");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                         hi!", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cle corpor tion", "Orcle Corportion", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("s/Home/jre", "", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s/Home/jre" + "'", str3.equals("s/Home/jre"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(".7", ".7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("   hi!    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', 100, 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion", 143);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "    o     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.awt.CGraphicsEnvironment", (long) 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ion", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ion" + "'", str2.equals("ion"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("    !IH   ", "oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    !IH   " + "'", str2.equals("    !IH   "));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaa.7aaaa", charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("mixed mode", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaa.7aaaa", "/", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO" + "'", str1.equals("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "o");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O" + "'", str1.equals("O"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oRACLE cORPORATION", (int) (byte) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE cORPORATION" + "'", str3.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1a10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "enen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects" + "'", str2.equals("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java(TM)4SE4Runtime4Environment", "us ", "a V");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)4SE4Runtime4Environment" + "'", str3.equals("Java(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                         hi!", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         hi!" + "'", str2.equals("                                         hi!"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("USr", "us ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", "sun.lwawt.macosx.CPrinterJob", 170);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("8-FTU");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", 155);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Orcle Corportion", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Orcle Corportion" + "'", str3.equals("Orcle Corportion"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80-b15", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sun.awt.cGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "http://java.oracle.com/", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(".7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "Java(TM) SE Runtime Environment", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("or cle corpor tion");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!", '4');
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("10.14.3", strArray3, strArray9);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "sophie", (int) (byte) 0, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corporation" + "'", str4.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.14.3" + "'", str11.equals("10.14.3"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("s/Home/jre");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("java Platform API Specification", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Orcle Corportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444444444444444444444444444444444444444444444444444444444444444444ion", "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "OrSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavacle CorporSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444ion" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444ion"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("sun.lwawt.macosx.LWCToolkithttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/Or cle Corpor tion", "-1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXJAVA PLATFORM API SPECIFICATION86JAVA PLATFORM API SPECIFICATION_JAVA PLATFORM API SPECIFICATION6AJAVA PLATFORM API SPECIFICATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (int) (byte) 1, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str3.equals("6158220651_80201_lp.poodn4r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaakit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("kit", "kit", 31);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (short) 1, 3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "a" + "'", str7.equals("a"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 217, (float) (short) -1, (float) 32L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.awt.cGraphicsEnvironment", (java.lang.CharSequence) "OrJava HotSpot(TM) 64-Bit Server VMcle CorporJava HotSpot(TM) 64-Bit Server VMtion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("   hi!    ", "aaaaaaakit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("    !IH   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    !IH   " + "'", str2.equals("    !IH   "));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(170);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sophie", "-1 10");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt./acSsS.LWCTSSlkut1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrpSrStuSn", 44, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrp..." + "'", str3.equals("...71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrp..."));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ion" + "'", str1.equals("ion"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("sun.lwawt.macosx.LWCToolkit1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!Or cle Corpor tion", "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(100L, (-1L), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("HI!", "aaaaaaakit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("//java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "                                         hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1.7.0_80", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(156, 31, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                           /Users/sophie                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a", "Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hi", 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("s/home/jre", "#################################615#################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 31L, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                           /Users/sophie                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("en", "Or/Users/sophiecle Corpor/Users/sophietion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) 157, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("S", "10.14.3");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "   HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Orcle Corportion", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                               Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/", "51.0", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("   HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!    ", "sun.lwawt.macosx.LWCToolkithttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/Or cle Corpor tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!    " + "'", str2.equals("   HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!    "));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("OrSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavacle CorporSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavation", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OrSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavacle CorporSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavation" + "'", str2.equals("OrSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavacle CorporSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavation"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "-1 10", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(".7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("US ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion" + "'", str1.equals("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation", "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 69, (long) 97, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 3, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("a V");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a V" + "'", str1.equals("a V"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("aaaa.7aaaa", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("8-FTU", "US ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8-FTU" + "'", str2.equals("8-FTU"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("615");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "615" + "'", str1.equals("615"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US", "444444444444444444444444444444444444444444444444444444444444444444ion", "SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("tionacle CorporaOr", "x86_64", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("  hi!    ", 157, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("tiklooTCWL.xsocam.twawl.nus", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 2, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "   HI!    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!" + "'", str1.equals("hI!"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/aaaa.7aaaa", "OrJava HotSpot(TM) 64-Bit Server VMcle CorporJava HotSpot(TM) 64-Bit Server VMtion", 189);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("opor#tion", "USr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation", (java.lang.CharSequence) "/aaaa.7aaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironment", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String[] strArray3 = new java.lang.String[] { "sun.lwawt.macosx.LWCToolkit", "Or cle Corpor tion" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "HI!");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.7");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion" + "'", str9.equals("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray9 = new char[] { ' ', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Or cle Corpor tion", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("sun.awt.cGraphicsEnvironment", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Users/...", "Or e rpr ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION", "mixedamode", 217);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("sun.lwawt.macosx.LWCToolkitaaaa.7aaaaOr cle Corpor tion", (java.lang.Object[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "US");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Virtual Machine Specification", "tiklooTCWL.xsocam.twawl.nustiklo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(217.0f, (float) 2, (float) 14);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "USr", 1, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "USr" + "'", str4.equals("USr"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hI!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                 ", (int) '#', "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("enen", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enen                                                                                             " + "'", str2.equals("enen                                                                                             "));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("51.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int[] intArray3 = new int[] { 10, (byte) 10, (short) 0 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "a V");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("08_0.7.1", "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "    o     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { ' ', '#', '4', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray7);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion");
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Jv(TM)SERF-Ev-F", strArray14);
        java.lang.Object[] objArray16 = new java.lang.Object[] { charArray7, "aaaa.7aaaa", strArray14 };
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "sun.lwawt.macosx.LWCToolkitOr cle Corpor tion" + "'", str17.equals("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", 0, "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("OrJava HotSpot(TM) 64-Bit Server VMcle CorporJava HotSpot(TM) 64-Bit Server VMtion", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-xJvPAPISJvPAPISJvPAPISJvPAPIS", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-xJvPAPISJvPAPISJvPAPISJvPAPIS" + "'", str2.equals("-xJvPAPISJvPAPISJvPAPISJvPAPIS"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("HI!sun.lwawt.macosx.LWCToolkit", "    !IH   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    !IH   " + "'", str2.equals("    !IH   "));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "   HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 690 + "'", int1 == 690);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("tionacle CorporaOr", ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (int) 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "tionacle CorporaOr" + "'", str4.equals("tionacle CorporaOr"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("s/Home/jre", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/Home/jre" + "'", str2.equals("s/Home/jre"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sophie", "US ", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophieUS sophieUS sophieUS sophieUS sophieUS sophie" + "'", str3.equals("sophieUS sophieUS sophieUS sophieUS sophieUS sophie"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("OrSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavacle CorporSpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa API Platform Specification64Java API Platform Specification_Java API Platform Specification86Java API Platform aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJavation", "###############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444ion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444ion" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444ion"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("   HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!       HI!    ", "s/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("444444444444444444444444444444444444444444444444444444444444444444ion", "                                           /Users/sophie                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444ion" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444ion"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("US", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(":", "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Or cle Corpor tion", (int) (byte) 1, 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "mixed mode");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaa.7aaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10", "0", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("mixed444444444444444444444444444444444444444444444444444444444444444444ion 444444444444444444444444444444444444444444444444444444444444444444ionmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edomnoi444444444444444444444444444444444444444444444444444444444444444444 noi444444444444444444444444444444444444444444444444444444444444444444dexim" + "'", str1.equals("edomnoi444444444444444444444444444444444444444444444444444444444444444444 noi444444444444444444444444444444444444444444444444444444444444444444dexim"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(143.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("java Platform API Specification", "x86_64", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXJAVA PLATFORM API SPECIFICATION86JAVA PLATFORM API SPECIFICATION_JAVA PLATFORM API SPECIFICATION6AJAVA PLATFORM API SPECIFICATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXJAVA PLATFORM API SPECIFICATION86JAVA PLATFORM API SPECIFICATION_JAVA PLATFORM API SPECIFICATION6AJAVA PLATFORM API SPECIFICATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10" + "'", str1.equals("-1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXJAVA PLATFORM API SPECIFICATION86JAVA PLATFORM API SPECIFICATION_JAVA PLATFORM API SPECIFICATION6AJAVA PLATFORM API SPECIFICATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, (int) (short) -1, 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(".7", 155L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 155L + "'", long2 == 155L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("edomnoi444444444444444444444444444444444444444444444444444444444444444444 noi444444444444444444444444444444444444444444444444444444444444444444dexim", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edomnoi444444444444444444444444444444444444444444444444444444444444444444 noi444444444444444444444444444444444444444444444444444444444444444444dexim" + "'", str2.equals("edomnoi444444444444444444444444444444444444444444444444444444444444444444 noi444444444444444444444444444444444444444444444444444444444444444444dexim"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Ta/v" + "'", str2.equals("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Ta/v"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("615", 156, "SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "615SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TIONSUN.LWAW" + "'", str3.equals("615SUN.LWAWT.MACOSX.LWCTOOLKIT1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71HI!OR CLE CORPOR TIONSUN.LWAW"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("enen                                                                                             ", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enen                                                                                             " + "'", str2.equals("enen                                                                                             "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str3.equals("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 217, 217.0d, (double) 155);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 155.0d + "'", double3 == 155.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "NOITAROPROc ELCARo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("USr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USr" + "'", str1.equals("USr"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", 0, "/Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...    o     /Users/...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + "'", str3.equals("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "TIKLOOtcwl.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tIKLOOtcwl.XSOCAM.TWAWL.NUS" + "'", str1.equals("tIKLOOtcwl.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("oRACLE cORPORATION", "cle corpor tion", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATION" + "'", str3.equals("oRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATIONcle corpor tionoRACLE cORPORATION"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion", "NOITAROPROc ELCARo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("java Platform API Specification", "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 217, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################################################################################################################################################################################################################" + "'", str3.equals("#########################################################################################################################################################################################################################"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "en", "                                                                            hi!                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10" + "'", str1.equals("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("tionacle CorporaOr", 31, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionacle CorporaOr4444444444444" + "'", str3.equals("tionacle CorporaOr4444444444444"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sophieUS sophieUS sophieUS sophieUS sophieUS sophie");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "    !IH   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double[] doubleArray2 = new double[] { 615L, 0.0f };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "Oracle/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10208_1560228516Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO" + "'", charSequence2.equals("noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/elcarO"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.CPrinterJob", "ionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionionion", "TIKLOOtcwl.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "suK.lwawt.macIsx.CPrTKterJIb" + "'", str3.equals("suK.lwawt.macIsx.CPrTKterJIb"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_UNIX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("sun.lwawt.macosx.LWCToolkithttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/Or cle Corpor tion", "tiklooTCWL.xsocam.twawl.nustiklo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32, (double) 32L, 31.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("en", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("08_0.7.1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java(TM) SE Runtime Environment", "aV");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T4-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "hi", 10, (int) (short) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 1, 0);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("stcefed/stnemucoD/eihpos/sresU/elcarO4stcefed/stnemucoD/eihpos/sresU/ 6158220651_80201_lp.poodnar_nur/pmt/j4noitaroproC6158220651_80201_lp.poodnar_nur/pmt/j", strArray2);
        java.lang.Class<?> wildcardClass12 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 69 + "'", int11 == 69);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("opor#tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noit#ropo" + "'", str1.equals("noit#ropo"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaa.7aaaa", "sun.lwawt.macosx.LWCToolkit/Or cle Corpor tion", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSiiSiS PSoft  API farfrSort6iSiS PSoft  API farfrSortiSiS PSoft  API farfrSort64iSiS PSoft  API farfrSortSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "                                         hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie                                                                                       ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.LWCToolkitOr cle Corpor tion", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("oracle/users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects4j/tmp/run_randoop.pl_10208_1560228516corporation", "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects" + "'", str2.equals("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("j/tmp/run_randoop.pl_10208_1560228516Corporation4j/tmp/run_randoop.pl_10208_1560228516 /Users/sophie/Documents/defects4Oracle/Users/sophie/Documents/defects", "opor#tion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "oracle/users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516 /users/sophie/documents/defects j/tmp/run_randoop.pl_10208_1560228516corporation", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("enen                                                                                             ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java HotSpot(TM) 64-Bit Server VM", 189);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "enen", "6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!", '4');
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hi!", strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("10.14.3", strArray3, strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray13);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corporation" + "'", str4.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.14.3" + "'", str11.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("suK.lwawt.macIsx.CPrTKterJIb", 100, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "suK.lwawt.macIsx.CPrTKterJIb                                                                        " + "'", str3.equals("suK.lwawt.macIsx.CPrTKterJIb                                                                        "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("6158220651_80201_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "0", "-1 10");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("###############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################################################################################################################################" + "'", str1.equals("###############################################################################################################################################"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaxJava Platform API Specification86Java Platform API Specification_Java Platform API Specification64Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaakit");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("1.7.0_80-b15", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Oracle Corporation", "SUN.LWAWT.MACOSX.lwctOOLKIToR CLE cORPOR TION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sun.lwawt./acSsS.LWCTSSlkut1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71hu!OrSclESCSrpSrStuSn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nustiklo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TiklooTCWL.xsocam.twawl.nustiklo" + "'", str1.equals("TiklooTCWL.xsocam.twawl.nustiklo"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "NOITAROPROc ELCARo", "a", (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                       eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("615", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("enen                                                                                             ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("o", "x86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                               Oracle Corporation", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle Corporation" + "'", str2.equals("racle Corporation"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolkithttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/Or cle Corpor tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkithttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/Or cle Corpor tion" + "'", str1.equals("sun.lwawt.macosx.LWCToolkithttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/Or cle Corpor tion"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}

