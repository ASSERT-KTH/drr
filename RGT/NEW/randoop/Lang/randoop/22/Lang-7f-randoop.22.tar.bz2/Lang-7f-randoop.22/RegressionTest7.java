import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10 97", (java.lang.CharSequence) "-1a100a1a0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.0432.04-1.0", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...DEXIM/M", (java.lang.CharSequence) "TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("JavaPlatformAPISpecification", 54);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             JavaPlatformAPISpecification             " + "'", str2.equals("             JavaPlatformAPISpecification             "));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("   1.7    ", "44100 ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   1.7    " + "'", str3.equals("   1.7    "));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("::", "sers/sophie/Users/sophie", "################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::" + "'", str3.equals("::"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("97.0#1.0#-1.0#0.0#5.0#-1.0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0#1.0#-1.0#0.0#5.0#-1.0" + "'", str2.equals("97.0#1.0#-1.0#0.0#5.0#-1.0"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "######################################################", (java.lang.CharSequence) "100a-1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#", "1.7.0_80/library/java/javavirtua");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("a4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("            mixed mode             Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanEDOM DEXIM/MOC.ELCAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            mixed mode             Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("            mixed mode             Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spe", "aaaaaaaaa.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaa." + "'", str2.equals("aaaaaaaaa."));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan", (java.lang.CharSequence) "10#-1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/U            mixed mode             1779_156027899", "1.51.31.41.81.81.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/U            mixed mode             1779_156027899" + "'", str2.equals("/U            mixed mode             1779_156027899"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("################################-1a10a1a0a-1a97");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/" + "'", str2.equals("http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("a1.4a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "AAA1.4AAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("AAA1.4AAAA", (float) 31);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.awt.cgraphicsenvironment", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wt.cgraphicsenvironment" + "'", str2.equals("wt.cgraphicsenvironment"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10#-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1", 96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("44 ", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.Class<?> wildcardClass6 = doubleArray3.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 32.0 -1.0" + "'", str8.equals("10.0 32.0 -1.0"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        short[] shortArray2 = new short[] { (short) 10, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        java.lang.Class<?> wildcardClass6 = shortArray2.getClass();
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10 -1" + "'", str5.equals("10 -1"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                           ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                    :         sers/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998", "-1.0a0.0a100.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    :         sers/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998" + "'", str2.equals("                    :         sers/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "101.51.51.51.");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.awt.cgraphicsenvironment");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SU", charSequence1, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/8998720651_97715_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10#-1", (java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCO /EIHPOS/SRESu/:SESSALC/TEGRAT/8998720651_97715_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCO /EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "14140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A42141401404041");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "J#v# HotSpot(TM) 64-Bit Server VM", charSequence1, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Hi!ava(tm) se runtime :                       .:                       :        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray3);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100 1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.4", "10.14.3                                                                                             ", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "class [Cclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("          1779_156027899", "4444444444444444444444444444444444Java(TM) SE RunpJava(TM) SE Runt4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          1779_156027899" + "'", str2.equals("          1779_156027899"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.0", "   1.7    ", "mixed mode/mixed modeLmixed modeimixed modebmixed modermixed modeamixed modermixed modeymixed mode/mixed modeJmixed modeamixed modevmixed modeamixed mode/mixed modeJmixed modeamixed modevmixed modeamixed modeVmixed modeimixed modermixed modetmixed modeumixed modeamixed modelmixed modeMmixed modeamixed modecmixed modehmixed modeimixed modenmixed modeemixed modesmixed mode/mixed modejmixed modedmixed modekmixed mode1mixed mode.mixed mode7mixed mode.mixed mode0mixed mode_mixed mode8mixed mode0mixed mode.mixed modejmixed modedmixed modekmixed mode/mixed modeCmixed modeomixed modenmixed modetmixed modeemixed modenmixed modetmixed modesmixed mode/mixed modeHmixed modeomixed modemmixed modeemixed mode/mixed modejmixed modermixed modeemixed mode", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaandaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaandaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan" + "'", str1.equals("maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaandaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "Hi!ava(tm) se runtime environment", "24.80-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1#10#1#0#-1#97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "\na4.1a", (java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/ ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("###", "hi!                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###" + "'", str2.equals("###"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "100 1 1", (java.lang.CharSequence) "Hi!ava(tm) se runtime :                       .:                       :        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1" + "'", str1.equals("7.1"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        long[] longArray3 = new long[] { (byte) 100, (-1), 10L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a-1a10" + "'", str7.equals("100a-1a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004-1410" + "'", str9.equals("1004-1410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100a1", "                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1" + "'", str2.equals("100a1"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("145");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 145 + "'", number1.equals(145));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "aaa1.4aaaa", "wt.cgraphicsenvironment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7.0_8...", (java.lang.CharSequence) "a4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1a", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "24A.A80A-ABA11", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("N", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "N" + "'", str2.equals("N"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spec", (java.lang.CharSequence) "                                                                                             xdhd");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.00.0100.0", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '4', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":         ", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "X86_64", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 10, 2);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "44 " + "'", str14.equals("44 "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(35L, (long) 32, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                       aaaaaaaaa.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaa." + "'", str1.equals("aaaaaaaaa."));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("NEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUS", 214, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUS" + "'", str3.equals("NEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUS"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_8...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_8..." + "'", str1.equals("1.7.0_8..."));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob                                                                        ", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        short[] shortArray3 = new short[] { (byte) 100, (byte) 1, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 35);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 0, 1);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100 1 1" + "'", str9.equals("100 1 1"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100" + "'", str14.equals("100"));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTH", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTH" + "'", str2.equals("EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTH"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "        24.80-b110 10 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophie", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32.0f, (double) 97.0f, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1a10a1a0a-1a97", "#######################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.9", 3937, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(14.0f, (float) (short) 1, 14.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray8);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4a " + "'", str15.equals("4a "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4# " + "'", str17.equals("4# "));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                     aaa1.4aaaa                     ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        " + "'", str2.equals("        "));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100#1", "100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a--1.040.04100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####100###", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        short[] shortArray2 = new short[] { (short) 100, (short) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100 1" + "'", str5.equals("100 1"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#1" + "'", str8.equals("100#1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#1" + "'", str10.equals("100#1"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        short[] shortArray2 = new short[] { (short) 100, (short) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 0, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100#1" + "'", str9.equals("100#1"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10 97", (java.lang.CharSequence) "AAA1.4AAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                                                             xdhd", "hi1Ua7a-1aUa1UU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                             xdhd" + "'", str2.equals("                                                                                             xdhd"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "0.0432.04-1.0", "10a-1");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "14140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A42141401404041");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "     10 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "7.1", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "mixed mode Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "4# ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("10 97 -1 0 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 97 -1 0 100" + "'", str1.equals("10 97 -1 0 100"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::", "14140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A4214140140404111ABA-A08A.A42141401404041");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4A                                 ", "\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\n24.80-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4A                                 " + "'", str2.equals("4A                                 "));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                  32.0 0.0", "an", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "###", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.4", "::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::", 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "         :");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "1.0 -1.0 10.0 0.0 -1.0 -1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 80, 27);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 26, 0);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "4# " + "'", str23.equals("4# "));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("j/framework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4/Users/sophie/Documents/defects");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"j/framework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4/Users/sophie/Documents/defects\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "/Users/sophie", 10);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "9", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sers/sophie/Users/sophie", "hi4!", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                              en", "hicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 100, 0.0f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                       aaaaaaaaa.", (java.lang.CharSequence) "10a97a-1a0a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Hi!ava(tm) se runtime :                       .:                       :        ", 3937);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!ava(tm) se runtime :                       .:                       :        " + "'", str2.equals("Hi!ava(tm) se runtime :                       .:                       :        "));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     ", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     " + "'", str2.equals("TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10.14.3" + "'", charSequence2.equals("10.14.3"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("        24.80-b110 10 10", 31, "Java HotSJava Platform API Specificationot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jav        24.80-b110 10 10Java" + "'", str3.equals("Jav        24.80-b110 10 10Java"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4444 ", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("http://j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://j" + "'", str1.equals("http://j"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("a1.4a", "", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4a" + "'", str3.equals("a1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4a"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "####100###");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4444444444444444444444444Java(TM) S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10 97 -1 0 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 97 -1 0 100" + "'", str1.equals("10 97 -1 0 100"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        int[] intArray1 = new int[] { 97 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "97" + "'", str5.equals("97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1" + "'", str3.equals("100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1100a1"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                             xdhd", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("100a1a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a1a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa.", 80, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa.                   " + "'", str3.equals("                   EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa.                   "));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("140404104141");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.40404097E11f + "'", float1.equals(1.40404097E11f));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "n", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaHTTP://JAVA.ORACLE.COM/aaaaaa", "hi!ava(tm) se runtime environment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "############Mac OS X############", (java.lang.CharSequence) "N");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10.0432.04-1.0");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "SUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMEN", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        double[] doubleArray6 = new double[] { 1.0d, (-1.0d), 10.0d, 0, (-1.0d), (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.04-1.0410.040.04-1.04-1.0" + "'", str10.equals("1.04-1.0410.040.04-1.04-1.0"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("10a97a-1a0a100", "0 10 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a97a-1a0a100" + "'", str2.equals("10a97a-1a0a100"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("###################################################################################################X", (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("XDHD", "24.80-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XDHD" + "'", str2.equals("XDHD"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#################################################################################################", "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "/Users/sophie", 10);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a97a-1a0a10", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "XDHD");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        long[] longArray5 = new long[] { 10L, 'a', (byte) -1, 0L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) '4', 35);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) (byte) 10, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a97a-1a0a100" + "'", str8.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("su::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::su");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", "class [Cclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaa", "n/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("00404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A42004041");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"00404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A42004041\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0a0.0a100.0", (java.lang.CharSequence) "44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "####################################################", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray5 = new char[] { '4', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', (int) 'a', (int) (byte) 0);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10a97a-1a0a100", charArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "   1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7    ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1.0f), (double) 5L, (double) 155L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 155.0d + "'", double3 == 155.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "class [Cclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", 54);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("24#.#80#-#b#11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24#.#80#-#b#11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(".04-1.0410.040.04-1.04-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":         ", "US", 145);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         " + "'", str3.equals(":         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        short[] shortArray2 = new short[] { (short) 10, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "               1.7                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998", "#####################aaaaaaaaa.#####################", "0404104-1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "hi4!", ".1a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0a0a10a-1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("24a35a5a32a-1a27");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24a35a5a32a-1a27" + "'", str1.equals("24a35a5a32a-1a27"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\n140404104141");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Hi!ava(tm) se runtime :                       .:                       :        ", 27, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar-/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("hTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hTTP://JAVA.ORACLE.COM/" + "'", str1.equals("hTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) ":         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0.0432.04-1.0", "maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaandaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ \n /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998 Java Virtual Machine Specification /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0432.04-1.0" + "'", str3.equals("0.0432.04-1.0"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10 -1", "-1a100a1a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("     10 -1", 80, ":                       .:                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":                       .:              10 -1:                       .:         " + "'", str3.equals(":                       .:              10 -1:                       .:         "));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("7.1");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Mac OS X", "4# ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...DEXIM/MOC.ELCARO.AVAJ//:PT...", (java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/ ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24a.a80a-aba11", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24a.a80a-aba11" + "'", str2.equals("24a.a80a-aba11"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("#############################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#############################################" + "'", str1.equals("#############################################"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("############Mac OS X############", "hi!                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############Mac OS X############" + "'", str2.equals("############Mac OS X############"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("x86_64", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("          1779_156027899");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1779_156027899" + "'", str1.equals("1779_156027899"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("     10 -1", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 10" + "'", str2.equals("-1 10"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion3.atLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                ", 9, "1 0 0 10 1 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                " + "'", str3.equals("                                                                                "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', (int) '#', (int) (byte) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', 80, (int) '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', 35, 0);
        double double19 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double20 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double21 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 32.0d + "'", double19 == 32.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 32.0d + "'", double20 == 32.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.0d + "'", double21 == 32.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        int[] intArray1 = new int[] { 97 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 100, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, 0);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97" + "'", str4.equals("97"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", "140404104141");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 29, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4a", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("24.80-b1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("nvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "44100 ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        short[] shortArray3 = new short[] { (byte) 100, (byte) 1, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 35);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004141" + "'", str9.equals("1004141"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 1 + "'", short13 == (short) 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (byte) 100, 65);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100" + "'", str14.equals("100"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaaaa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaa..." + "'", str1.equals("aaaaaaa..."));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        double[] doubleArray6 = new double[] { 1.0d, (-1.0d), 10.0d, 0, (-1.0d), (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.04-1.0410.040.04-1.04-1.0" + "'", str9.equals("1.04-1.0410.040.04-1.04-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0 -1.0 10.0 0.0 -1.0 -1.0" + "'", str12.equals("1.0 -1.0 10.0 0.0 -1.0 -1.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 14, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        long[] longArray4 = new long[] { 0, 'a', 'a', 97L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 14, 13);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "                                    sun.awt.cgraphicsenvironment                                    ", ":               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "class [D class [C class [D");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(":         ", 29, 80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("su");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\n24.80-b1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("...DEXIM/M");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...DEXIM/M\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "7.1", (java.lang.CharSequence) "4444 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4A                                 ", "10.14.3                                                                                             ");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1.0 0.0 100.0", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0 0.0 100.0" + "'", str5.equals("-1.0 0.0 100.0"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        int[] intArray6 = new int[] { (short) -1, 10, (short) 1, 0, (short) -1, 'a' };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1 10 1 0 -1 97" + "'", str12.equals("-1 10 1 0 -1 97"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 31, (double) 6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Oracle Corporation", "1http://java.oracle.com/", "i4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "7.1", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1" + "'", str3.equals("7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100#1#1", "::", 80);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 214, 0);
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java(TM) SE RunpJava(TM) SE Runt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA(tm) se rUNPjAVA(tm) se rUNT" + "'", str1.equals("jAVA(tm) se rUNPjAVA(tm) se rUNT"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10.14.3                                                                                             ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaa", "                                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V...", (java.lang.CharSequence) "################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/U            mixed mode             1779_1560278998                                                ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/U            mixed mode             1779_1560278998                                                " + "'", str2.equals("/U            mixed mode             1779_1560278998                                                "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(" ", "sumixed mode/mixed modeLmixed modeimixed modebmixed modermixed modeamixed modermixed modeymixed mode/mixed modeJmixed modeamixed modevmixed modeamixed mode/mixed modeJmixed modeamixed modevmixed modeamixed modeVmixed modeimixed modermixed modetmixed modeumixed modeamixed modelmixed modeMmixed modeamixed modecmixed modehmixed modeimixed modenmixed modeemixed modesmixed mode/mixed modejmixed modedmixed modekmixed mode1mixed mode.mixed mode7mixed mode.mixed mode0mixed mode_mixed mode8mixed mode0mixed mode.mixed modejmixed modedmixed modekmixed mode/mixed modeCmixed modeomixed modenmixed modetmixed modeemixed modenmixed modetmixed modesmixed mode/mixed modeHmixed modeomixed modemmixed modeemixed mode/mixed modejmixed modermixed modeemixed mode.lwawt.macosx.CPrimixed mode/mixed modeLmixed modeimixed modebmixed modermixed modeamixed modermixed modeymixed mode/mixed modeJmixed modeamixed modevmixed modeamixed mode/mixed modeJmixed modeamixed modevmixed modeamixed modeVmixed modeimixed modermixed modetmixed modeumixed modeamixed modelmixed modeMmixed modeamixed modecmixed modehmixed modeimixed modenmixed modeemixed modesmixed mode/mixed modejmixed modedmixed modekmixed mode1mixed mode.mixed mode7mixed mode.mixed mode0mixed mode_mixed mode8mixed mode0mixed mode.mixed modejmixed modedmixed modekmixed mode/mixed modeCmixed modeomixed modenmixed modetmixed modeemixed modenmixed modetmixed modesmixed mode/mixed modeHmixed modeomixed modemmixed modeemixed mode/mixed modejmixed modermixed modeemixed modeterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#-1" + "'", str1.equals("10#-1"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/U            mixed mode             1779_1560278998", 5, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "n/generation/randoop-current.jar", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        double[] doubleArray6 = new double[] { 1.0d, (-1.0d), 10.0d, 0, (-1.0d), (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("jAVA hOTsjAVA pLATFORM api sPECIFICATIONOT(tm) 64-bIT sERVER vm", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsjAVA pLATFORM pi sPECIFICATIONOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsjAVA pLATFORM pi sPECIFICATIONOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("########################", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java(TM) S", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "32.0 0.0", (java.lang.CharSequence) "4a                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1", 3937);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      " + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      "));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("n", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0a0a10a-1", (int) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/U            mixed mode             1779_156027899");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0a0a10a-1", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...DEXIM/MOC.ELCARO.AVAJ//:PT...", 9, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1.equals(10.0d));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("a4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1a", "-1a100a1a0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                           ", (java.lang.CharSequence) "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("             edom dexim            ", (long) 12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        long[] longArray3 = new long[] { (byte) 0, 1, (byte) -1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.4");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a--1.040.04100.0");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        long[] longArray5 = new long[] { 10L, 'a', (byte) -1, 0L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a97a-1a0a100" + "'", str8.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a97a-1a0a100" + "'", str10.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("100a1a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a1a1" + "'", str1.equals("100a1a1"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        float[] floatArray1 = new float[] { 80 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 80.0f + "'", float2 == 80.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 80.0f + "'", float3 == 80.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 80.0f + "'", float4 == 80.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-1#10#1#0#-1#9", (java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Oracle Corporation" + "'", str7.equals("Oracle Corporation"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, 0.0f, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("sun.awt.CGraphicsEnvironment", strArray2, strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "jAVA(tm) se rUNPjAVA(tm) se rUNT");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str5.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24#.#80#-#b#11" + "'", str8.equals("24#.#80#-#b#11"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100#1", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# " + "'", str1.equals("4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# "));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("            mixed mode             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Hi!ava(tm) se runtime environment", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar-/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", 12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "100 1 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-141041404-1497");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed mode\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "hi!ava(TM) SE Runtime Environment                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("7.1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.1d + "'", double1.equals(7.1d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "100a1", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100a1" + "'", charSequence2.equals("100a1"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        int[] intArray1 = new int[] { 97 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (short) 10, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 214, (int) ' ');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', 14, 80);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(":", "1.7.0_80-b15", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0404104-1", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":" + "'", str5.equals(":"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("pJava(TM) SE Runt", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pJava(TM) SE Runt" + "'", str3.equals("pJava(TM) SE Runt"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a", (int) (byte) 10, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a" + "'", str3.equals("\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        float[] floatArray3 = new float[] { (-1.0f), 0.0f, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', (int) '4', 0);
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0a0.0a100.0" + "'", str6.equals("-1.0a0.0a100.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.040.04100.0" + "'", str9.equals("-1.040.04100.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 100.0f + "'", float15 == 100.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.O...", "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "             edom dexim            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 214.0f, (float) 29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(".04-1.0410.040.04-1.04-1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1", "###################################################################################################X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1" + "'", str2.equals("100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24A.A80A-ABA11", (java.lang.CharSequence) "0a0a10a-1", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4a                                 ", 93, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                          4a                                 " + "'", str3.equals("                                                          4a                                 "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "un.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironm", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Hi!ava(tm) se runtime environment", (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("  aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("AAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, 97L, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "           97#97#5#5#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("###########hi4!############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###########hi4!###########" + "'", str1.equals("###########hi4!###########"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        long[] longArray5 = new long[] { 10L, 'a', (byte) -1, 0L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', 0, 2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', 97, (int) '4');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a97a-1a0a100" + "'", str8.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a97a-1a0a100" + "'", str10.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10 97" + "'", str14.equals("10 97"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("145", 1414001.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 145.0d + "'", double2 == 145.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Hi!ava(tm) se runtime :                       .:                       :        ", (java.lang.CharSequence) "4444444444444444444444444444444444Java(TM)SERunpJava(TM)SERunt4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1.0a24.0a52.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", "/Users/sophie");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                    sun.awt.cgraphicsenvironment                                    ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENT" + "'", str1.equals("jAVA(tm) se rUNTIME eNVIRONMENT"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 32, 12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("  aaaaaaaaaaaaaaaaaaaaaaaaaaa", 214, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                              aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                             " + "'", str3.equals("                                                                                              aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                             "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100a1", (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "  ", (java.lang.CharSequence) "jAVA hOTsjAVA pLATFORM pi sPECIFICATIONOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(".04-1.0410.040.04-1.04-1.0", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".04-1.0410.040.04-1.04-1.0" + "'", str3.equals(".04-1.0410.040.04-1.04-1.0"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "hi!ava(TM) SE Runtime Environment                                               ", " 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::", "", "100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1100 1 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::" + "'", str3.equals("::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0 32.0 -1.0", "a4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("0.91.81.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.91.81.5" + "'", str1.equals("0.91.81.5"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("100 1", "4a ", (int) '4', 210);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100 14a " + "'", str4.equals("100 14a "));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        int[] intArray1 = new int[] { 97 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 10, 2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97" + "'", str4.equals("97"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97" + "'", str10.equals("97"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#################################################################################################", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("4A                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4A" + "'", str1.equals("4A"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanEDOM DEXIM/MOC.ELCAR", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa..." + "'", str2.equals("aa..."));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 32, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi!ava(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!ava(tm) se runtime environment" + "'", str1.equals("hi!ava(tm) se runtime environment"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4444444444444444444444444444444444Java(TM) SE RunpJava(TM) SE Runt4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/U            mixed mode             1779_1560278998                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/U            mixed mode             1779_1560278998                                                " + "'", str1.equals("/U            mixed mode             1779_1560278998                                                "));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                                                                                                                           0 10 10", "EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTH");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "i4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100", charSequence1, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMEN", "-1.0a0.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMEN" + "'", str2.equals("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMEN"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("   1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7    ", "1.7", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#####################aaaaaaaaa.#####################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"####################aaaaaaaaa.#####################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "hi!ava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5, 3.0d, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4# ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("\n", 145, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "an");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "::::::::::::::::::::::::", (java.lang.CharSequence) "10#-1                          ", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/U            mixed mode             1779_1560278998", charSequence1, 145);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, 47, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0", "/Users/sophie", "4444444444444444444444444Java(TM) S");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1", 14, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi1Ua7a-1aUa1UU", (int) '#', "-1.040.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.040.041hi1Ua7a-1aUa1UU-1.040.041" + "'", str3.equals("-1.040.041hi1Ua7a-1aUa1UU-1.040.041"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(".1a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("::::::::::::::::::::::::", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "n");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("hicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun", "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun" + "'", str2.equals("hicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        int[] intArray6 = new int[] { (short) -1, 10, (short) 1, 0, (short) -1, 'a' };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', (int) (byte) 100, 65);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1#10#1#0#-1#97", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 5, 2);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hTTP://JAVA.ORACLE.COM/", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaandaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan", 210);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaandaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan                                                                            " + "'", str2.equals("maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaandaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan                                                                            "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mode/mixed modeLmixed modeimixed modebmixed modermixed modeamixed modermixed modeymixed mode/mixed modeJmixed modeamixed modevmixed modeamixed mode/mixed modeJmixed modeamixed modevmixed modeamixed modeVmixed modeimixed modermixed modetmixed modeumixed modeamixed modelmixed modeMmixed modeamixed modecmixed modehmixed modeimixed modenmixed modeemixed modesmixed mode/mixed modejmixed modedmixed modekmixed mode1mixed mode.mixed mode7mixed mode.mixed mode0mixed mode_mixed mode8mixed mode0mixed mode.mixed modejmixed modedmixed modekmixed mode/mixed modeCmixed modeomixed modenmixed modetmixed modeemixed modenmixed modetmixed modesmixed mode/mixed modeHmixed modeomixed modemmixed modeemixed mode/mixed modejmixed modermixed modeemixed mode", (int) (byte) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification", (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("sun.awt.CGraphicsEnvironment", strArray3, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hi!");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "10a97a-1a0a100", (int) (byte) 10, (int) (byte) 0);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, ":                       ");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1004141", (java.lang.CharSequence[]) strArray14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa." + "'", str1.equals("EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa."));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("#################################################################################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2, (double) 1.7f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                             AAA1.4AAAA                                             ", (int) (short) 10, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        short[] shortArray3 = new short[] { (byte) 100, (byte) 1, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 35);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) '4', 3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004141" + "'", str9.equals("1004141"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "i4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("a4.1a", "mixed modehttp://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("n", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/a/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/Users/sophie/Users/sophie/Users/sophie/Users/sophie", 35, 210);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sers/sophie/Users/sophie", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/a/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sers/sophie/Users/sophie" + "'", charSequence2.equals("sers/sophie/Users/sophie"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.0#-1.0#10.0#0.0#-1.0#-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#-1.0#10.0#0.0#-1.0#-1.0" + "'", str1.equals("1.0#-1.0#10.0#0.0#-1.0#-1.0"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(65, 80, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("100a1a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a1a1" + "'", str1.equals("100a1a1"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray5 = new char[] { '4', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100 1", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4a " + "'", str10.equals("4a "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4a " + "'", str12.equals("4a "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hi!ava(tm) se runtime ", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        int[] intArray6 = new int[] { (short) -1, 10, (short) 1, 0, (short) -1, 'a' };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) (byte) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        int[] intArray1 = new int[] { 97 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97" + "'", str4.equals("97"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97" + "'", str8.equals("97"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                   EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa.                   ", "Java HotSpot(TM) 64-Bit Server V...", ":                       .:                       ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\n");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("::::::::::::::::::::::::", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("1414001", strArray3, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ \n /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998 Java Virtual Machine Specification /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1414001" + "'", str7.equals("1414001"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ US /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998 Java Virtual Machine Specification /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998" + "'", str10.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ US /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998 Java Virtual Machine Specification /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("#", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.LWCToolkit", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanEDOM DEXIM/MOC.ELCAR", "1.0 -1.0 10.0 0.0 -1.0 -1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                   EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa.                   ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "-1.00.0100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "Java(TM) S");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java(TM) S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("UTF-8", "mixed mode");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                         24A.A80A-ABA11                                          ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 32.0 -1.0" + "'", str8.equals("10.0 32.0 -1.0"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "http://java.oracle.com/mixed mode", "        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15" + "'", str3.equals("170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "101.51.51.51.", (java.lang.CharSequence) "http://javaoracleacom/mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/", "pJava(TM) SE Runt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/" + "'", str2.equals("http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-141041404-1497", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("n", ":         sers/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998", 14);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "SUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMEN", (int) '#', 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray4 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3 };
        org.apache.commons.lang3.SystemUtils systemUtils5 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils6 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils7 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils8 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray9 = new org.apache.commons.lang3.SystemUtils[] { systemUtils5, systemUtils6, systemUtils7, systemUtils8 };
        org.apache.commons.lang3.SystemUtils systemUtils10 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils11 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils12 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils13 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray14 = new org.apache.commons.lang3.SystemUtils[] { systemUtils10, systemUtils11, systemUtils12, systemUtils13 };
        org.apache.commons.lang3.SystemUtils systemUtils15 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils16 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils17 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils18 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray19 = new org.apache.commons.lang3.SystemUtils[] { systemUtils15, systemUtils16, systemUtils17, systemUtils18 };
        org.apache.commons.lang3.SystemUtils systemUtils20 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils21 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils22 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils23 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray24 = new org.apache.commons.lang3.SystemUtils[] { systemUtils20, systemUtils21, systemUtils22, systemUtils23 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray25 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray4, systemUtilsArray9, systemUtilsArray14, systemUtilsArray19, systemUtilsArray24 };
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray25);
        org.junit.Assert.assertNotNull(systemUtilsArray4);
        org.junit.Assert.assertNotNull(systemUtilsArray9);
        org.junit.Assert.assertNotNull(systemUtilsArray14);
        org.junit.Assert.assertNotNull(systemUtilsArray19);
        org.junit.Assert.assertNotNull(systemUtilsArray24);
        org.junit.Assert.assertNotNull(systemUtilsArray25);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray7 = new char[] {};
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence6, charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi1Ua7a-1aUa1UU", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0 -1.0 10.0 0.0 -1.0 -1.0", charArray7);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V...", charArray7);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                              en", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                              en" + "'", str2.equals("                                                                              en"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("00404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A42004041", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A42004041" + "'", str2.equals("00404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A42004041"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 80, "p");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp" + "'", str3.equals("pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("########################", "   1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7    ", "http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########################" + "'", str3.equals("########################"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E0.91.81.5Ehi!E");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 26.0f, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("################################################hi4!################################################", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################hi4!################################################" + "'", str2.equals("################################################hi4!################################################"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "            mixed mode             Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.00.0100.0", 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "24A.A80A-ABA11", 2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("US", strArray4, strArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "US" + "'", str13.equals("US"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(".", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "####100###", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "101.51.51.51.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie", 100, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("x", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x" + "'", str2.equals("x"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '4', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "            mixed mode             ", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                       aaaaaaaaa.", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java Virtual Machine Specification", "http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        long[] longArray5 = new long[] { 10L, 'a', (byte) -1, 0L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) '4', 35);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a97a-1a0a100" + "'", str8.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("10#97#-1#0#100", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#97#-1#0#100" + "'", str2.equals("10#97#-1#0#100"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("http:", 210);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http:" + "'", str2.equals("http:"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("###########hi4!###########", "hi!ava(TM) SE Runtime Environment                                               ", 31, 39);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###########hi4!###########hi!ava(TM) SE Runtime Environment                                               " + "'", str4.equals("###########hi4!###########hi!ava(TM) SE Runtime Environment                                               "));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("X86_64", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_6 " + "'", str3.equals("X86_6 "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '4', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":         ", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, 0);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8998720651_97715_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (java.lang.CharSequence) ".3410.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '4', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100 1", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1004-141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/users/sophie/documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.O...", "10 -1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                    ", 145);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                 " + "'", str2.equals("                                                                                                                                                 "));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x" + "'", str3.equals("x"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("7.1");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("145");
        java.math.BigDecimal[] bigDecimalArray4 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray4);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimalArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7.1145" + "'", str5.equals("7.1145"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10a97a-1a0a10", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray6 = new char[] {};
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.51.31.41.81.81.1", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hi!ava(tm) se runtime environment", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("\n140404104141", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 210, 210);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str3.equals("80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100" + "'", str2.equals("hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1.040.041hi1Ua7a-1aUa1UU-1.040.041");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.040.041hi1Ua7a-1aUa1UU-1.040.041\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                         24A.A80A-ABA11                                          ", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         24A.A80A-ABA11                                          " + "'", str2.equals("                                         24A.A80A-ABA11                                          "));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("X", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XXXXXXXXXXXX" + "'", str2.equals("XXXXXXXXXXXX"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    ", "...DEXIM/MOC.ELCARO.AVAJ//:PT...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.04-1.0410.040.04-1.04-1.0", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0" + "'", str2.equals("1.0"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/MIXED MODE", (java.lang.CharSequence) "170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15170_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("ass [Cclass [D", "njAVA hOTs");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', 8, 0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0432.04-1.0" + "'", str7.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a4.1a", (java.lang.CharSequence) "http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 2, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1", "j/framework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4/Users/sophie/Documents/defects", "aaaaaaHTTP://JAVA.ORACLE.COM/aaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64", "\n");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "x86_64" + "'", str6.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "x86_64" + "'", str7.equals("x86_64"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(":                       .:              10 -1:                       .:         ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Ehi!E", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ', 24, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1 10 1 0 -1 97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 10 1 0 -1 97" + "'", str1.equals("-1 10 1 0 -1 97"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "          ", 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("            mixed mode             Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::", (java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/MIXED MODE", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray4);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi1Ua7a-1aUa1UU", charArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 97, "ass [Cclass [D");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [" + "'", str3.equals("ass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass ["));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0404104-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0404104-1" + "'", str1.equals("0404104-1"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/!ihT/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/" + "'", str1.equals("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/!ihT/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaa1.4aaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.5", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1.040.041hi1Ua7a-1aUa1UU-1.040.041");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("java HotSJava Platform API Specificationot(TM) 64-Bit Server VM", "...xed modeimixed mod...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSJava Platform API Specificationot(TM) 64-Bit Server VM" + "'", str2.equals("java HotSJava Platform API Specificationot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                          0.0432.04-1.0                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("        ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        " + "'", str2.equals("        "));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 80, 27);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray8);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray8, '#', 54, 29);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Oracle Corporation", ":         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/8998720651_97715_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/", (java.lang.CharSequence) "10a97a-1a0a10", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("444444444444444444444444444Hi4!4444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444Hi4!444444" + "'", str1.equals("444444444444444444444444444Hi4!444444"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8998720651_97715_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("jAVA(tm) se rUNTIME eNVIRONMENT", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENT" + "'", str3.equals("jAVA(tm) se rUNTIME eNVIRONMENT"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.Class<?> wildcardClass4 = javaVersion3.getClass();
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
        boolean boolean11 = javaVersion0.atLeast(javaVersion7);
        java.lang.Class<?> wildcardClass12 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, (long) 12, 65L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 65L + "'", long3 == 65L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100L, (float) 57L, 3937.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 57.0f + "'", float3 == 57.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a', (int) '#', 7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a', (int) (short) 100, 80);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0432.04-1.0" + "'", str7.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "32.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaa.", "p", 54);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "100 1", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        short[][] shortArray0 = new short[][] {};
        short[][] shortArray1 = new short[][] {};
        short[][] shortArray2 = new short[][] {};
        short[][] shortArray3 = new short[][] {};
        short[][] shortArray4 = new short[][] {};
        short[][] shortArray5 = new short[][] {};
        short[][][] shortArray6 = new short[][][] { shortArray0, shortArray1, shortArray2, shortArray3, shortArray4, shortArray5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray6);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.4");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 93, (float) 65, (float) 210L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 210.0f + "'", float3 == 210.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        short[] shortArray2 = new short[] { (short) 10, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) (short) 100, 27);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 214, (int) (byte) 10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10 -1" + "'", str5.equals("10 -1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10 -1" + "'", str15.equals("10 -1"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#############################################", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############################################" + "'", str3.equals("#############################################"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.9", "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a100");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ":                       ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    /Users/sophie                                    sun.awt.CGraphicsEnvironment                                    ");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                    :         sers/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":                       .:                       " + "'", str5.equals(":                       .:                       "));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "100 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("################################################hi4!################################################", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################################hi4!################################################" + "'", str3.equals("################################################hi4!################################################"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                    10 97 -1 0 100                    ", " 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 97 -1 0 100" + "'", str2.equals("10 97 -1 0 100"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 100, 14.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "10a-1", (java.lang.CharSequence) "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10a-1" + "'", charSequence2.equals("10a-1"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "class [D class [C class [D", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1004-1410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "class [Cclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [D", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }
}

