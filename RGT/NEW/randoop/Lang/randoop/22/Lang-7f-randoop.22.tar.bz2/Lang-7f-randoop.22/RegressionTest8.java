import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/mixed mode", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sumixed mode/mixed modeLmixed modeimixed modebmixed modermixed modeamixed modermixed modeymixed mode/mixed modeJmixed modeamixed modevmixed modeamixed mode/mixed modeJmixed modeamixed modevmixed modeamixed modeVmixed modeimixed modermixed modetmixed modeumixed modeamixed modelmixed modeMmixed modeamixed modecmixed modehmixed modeimixed modenmixed modeemixed modesmixed mode/mixed modejmixed modedmixed modekmixed mode1mixed mode.mixed mode7mixed mode.mixed mode0mixed mode_mixed mode8mixed mode0mixed mode.mixed modejmixed modedmixed modekmixed mode/mixed modeCmixed modeomixed modenmixed modetmixed modeemixed modenmixed modetmixed modesmixed mode/mixed modeHmixed modeomixed modemmixed modeemixed mode/mixed modejmixed modermixed modeemixed mode.lwawt.macosx.CPrimixed mode/mixed modeLmixed modeimixed modebmixed modermixed modeamixed modermixed modeymixed mode/mixed modeJmixed modeamixed modevmixed modeamixed mode/mixed modeJmixed modeamixed modevmixed modeamixed modeVmixed modeimixed modermixed modetmixed modeumixed modeamixed modelmixed modeMmixed modeamixed modecmixed modehmixed modeimixed modenmixed modeemixed modesmixed mode/mixed modejmixed modedmixed modekmixed mode1mixed mode.mixed mode7mixed mode.mixed mode0mixed mode_mixed mode8mixed mode0mixed mode.mixed modejmixed modedmixed modekmixed mode/mixed modeCmixed modeomixed modenmixed modetmixed modeemixed modenmixed modetmixed modesmixed mode/mixed modeHmixed modeomixed modemmixed modeemixed mode/mixed modejmixed modermixed modeemixed modeterJob", (float) 7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "...DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT...", (java.lang.CharSequence) "#############################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixed mode/mixed modeLmixed modeimixed modebmixed modermixed modeamixed modermixed modeymixed mode/mixed modeJmixed modeamixed modevmixed modeamixed mode/mixed modeJmixed modeamixed modevmixed modeamixed modeVmixed modeimixed modermixed modetmixed modeumixed modeamixed modelmixed modeMmixed modeamixed modecmixed modehmixed modeimixed modenmixed modeemixed modesmixed mode/mixed modejmixed modedmixed modekmixed mode1mixed mode.mixed mode7mixed mode.mixed mode0mixed mode_mixed mode8mixed mode0mixed mode.mixed modejmixed modedmixed modekmixed mode/mixed modeCmixed modeomixed modenmixed modetmixed modeemixed modenmixed modetmixed modesmixed mode/mixed modeHmixed modeomixed modemmixed modeemixed mode/mixed modejmixed modermixed modeemixed mode", "          ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "###");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixed###mode/mixed###modeLmixed###modeimixed###modebmixed###modermixed###modeamixed###modermixed###modeymixed###mode/mixed###modeJmixed###modeamixed###modevmixed###modeamixed###mode/mixed###modeJmixed###modeamixed###modevmixed###modeamixed###modeVmixed###modeimixed###modermixed###modetmixed###modeumixed###modeamixed###modelmixed###modeMmixed###modeamixed###modecmixed###modehmixed###modeimixed###modenmixed###modeemixed###modesmixed###mode/mixed###modejmixed###modedmixed###modekmixed###mode1mixed###mode.mixed###mode7mixed###mode.mixed###mode0mixed###mode_mixed###mode8mixed###mode0mixed###mode.mixed###modejmixed###modedmixed###modekmixed###mode/mixed###modeCmixed###modeomixed###modenmixed###modetmixed###modeemixed###modenmixed###modetmixed###modesmixed###mode/mixed###modeHmixed###modeomixed###modemmixed###modeemixed###mode/mixed###modejmixed###modermixed###modeemixed###mode" + "'", str4.equals("mixed###mode/mixed###modeLmixed###modeimixed###modebmixed###modermixed###modeamixed###modermixed###modeymixed###mode/mixed###modeJmixed###modeamixed###modevmixed###modeamixed###mode/mixed###modeJmixed###modeamixed###modevmixed###modeamixed###modeVmixed###modeimixed###modermixed###modetmixed###modeumixed###modeamixed###modelmixed###modeMmixed###modeamixed###modecmixed###modehmixed###modeimixed###modenmixed###modeemixed###modesmixed###mode/mixed###modejmixed###modedmixed###modekmixed###mode1mixed###mode.mixed###mode7mixed###mode.mixed###mode0mixed###mode_mixed###mode8mixed###mode0mixed###mode.mixed###modejmixed###modedmixed###modekmixed###mode/mixed###modeCmixed###modeomixed###modenmixed###modetmixed###modeemixed###modenmixed###modetmixed###modesmixed###mode/mixed###modeHmixed###modeomixed###modemmixed###modeemixed###mode/mixed###modejmixed###modermixed###modeemixed###mode"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "-1#10#1#0#-1#9", 57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "a1.4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        int[] intArray1 = new int[] { 97 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 10, 2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97" + "'", str4.equals("97"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97" + "'", str10.equals("97"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97" + "'", str12.equals("97"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    ", "SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        " + "'", str2.equals("                                                                        "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray9 = new char[] { '4', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence6, charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a4.1a", charArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4a " + "'", str16.equals("4a "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4  " + "'", str19.equals("4  "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", "####100###", "un.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java HotSpot(TM) 64-Bit Server V...", "tionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server V..." + "'", str2.equals("Java HotSpot(TM) 64-Bit Server V..."));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("100 1", "http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 1" + "'", str3.equals("100 1"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.0", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        float[] floatArray6 = new float[] { 97L, 1, (-1.0f), (byte) 0, 5, (short) -1 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97.0a1.0a-1.0a0.0a5.0a-1.0" + "'", str9.equals("97.0a1.0a-1.0a0.0a5.0a-1.0"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("100#1#1", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#1#1" + "'", str2.equals("100#1#1"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a", "\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\n24.80-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', (int) (short) 1, 96);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1004141", "1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!ava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44" + "'", str1.equals("44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("24#.#80#-#b#11", "                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.LWCToolkit", "1.0 -1.0 10.0 0.0 -1.0 -1.0", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed mode");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 3837, (float) 5L, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(" A                                 ", (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(39.0f, (float) (byte) -1, (float) 210);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        short[] shortArray3 = new short[] { (byte) 100, (byte) 1, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 35);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004141" + "'", str9.equals("1004141"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100#1#1" + "'", str15.equals("100#1#1"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "UShi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironment" + "'", str3.equals("sun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironmentsun.Uwt.CGrUphicsEnvironment"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "            mixed mode             ", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "   1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7    ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                          ...", (java.lang.CharSequence) "4# ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("145", (long) 65);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 145L + "'", long2 == 145L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("100", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100a1a1##########################################################################################", "                                                                                              aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                             ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("\n140404104141", "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n140404104141" + "'", str2.equals("\n140404104141"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
        java.lang.String str9 = javaVersion6.toString();
        boolean boolean10 = javaVersion0.atLeast(javaVersion6);
        java.lang.String str11 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.5" + "'", str9.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.8" + "'", str11.equals("1.8"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100a1a1##########################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a1a1##########################################################################################" + "'", str1.equals("100a1a1##########################################################################################"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                              aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                             ", "", 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                             aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                             " + "'", str4.equals("                                                                                             aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                             "));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("44 ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("XDHD");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XDHD" + "'", str1.equals("XDHD"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("AAAAAAAAAAAAAAAAAAAAAAAAAAA", "/U            mixed mode             1779_156027899");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "32.0 0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7", 0, "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("24a35a5a32a-1a27", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4a35a5a32a-1a27" + "'", str2.equals("4a35a5a32a-1a27"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray6 = new char[] {};
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.51.31.41.81.81.1", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1", charArray6);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                        ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern(".", "        ", "10 -1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "." + "'", str3.equals("."));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1.040.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.040.04100.0" + "'", str1.equals("-1.040.04100.0"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.9f, (float) 12, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java(TM) SE Runtime Environment", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "SUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMENTSUNuAWTucgRAPHICSeNVIRONMEN", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '4', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":         ", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("::", "un.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironm", (int) (byte) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaa...", strArray2, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "aaaaaaa..." + "'", str7.equals("aaaaaaa..."));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1004-141", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", charArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ', 12, (int) (short) 10);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        short[] shortArray3 = new short[] { (byte) 100, (byte) 1, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 35);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004141" + "'", str9.equals("1004141"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 1 1" + "'", str13.equals("100 1 1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100 1 1" + "'", str15.equals("100 1 1"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 100 + "'", short16 == (short) 100);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(".1a");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.3", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1#10#1#0#-1#9", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                           ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!ava(TM) SE Runtime Environment                                               ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("44 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1414001.0d, (double) 1, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (byte) -1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "44.44.4" + "'", str9.equals("44.44.4"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("########################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ######################## is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ".", (java.lang.CharSequence) "32.0 0.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100, 5.0d, (double) 7.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', (int) 'a', 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0432.04-1.0" + "'", str7.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0 32.0 -1.0" + "'", str14.equals("10.0 32.0 -1.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "jAVA hOTsjAVA pLATFORM api sPECIFICATIONOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sophie", "                                 /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        short[] shortArray2 = new short[] { (short) 10, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) (short) 100, 27);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 214, (int) (byte) 10);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10 -1" + "'", str5.equals("10 -1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 10 + "'", short14 == (short) 10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("############Mac OS X############", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sophie", "                                                                                ", 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie" + "'", str3.equals("sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("HTTP://JAVA.ORACLE.COM/MIXED MODE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HTTP:/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("####100###", (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi!                             ", "hi!ava(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        short[] shortArray2 = new short[] { (short) 100, (short) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 0, 0);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4444444444444444444444444Java(TM) S", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444Java(TM) S" + "'", str2.equals("4444444444444444444444444Java(TM) S"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(26, (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15" + "'", str1.equals("80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "AAA1.4AAAA", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 80, 27);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 26, 0);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 54, (int) (byte) 1);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3                                                                                             ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 5, (int) (short) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/" + "'", str10.equals("/"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     ", "444444444444444444444444444Hi4!444444444444-1#10#1#0#-1#9444444444444444444444444444Hi4!444444444444", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4a ", 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10#97#-1#0#100", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     10#97#-1#0#100" + "'", str2.equals("                     10#97#-1#0#100"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.3", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sers/sophie/Users/sophie", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java Platform API Specification", charSequence1, 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("   1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7    ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7    " + "'", str2.equals("   1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7    "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/Users/sophie/Users/sophie/Users/sophie/Users/sophie", (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0432.04-1.0" + "'", str7.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0432.04-1.0" + "'", str9.equals("10.0432.04-1.0"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("varfolders_v6v597zmn4_ ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java HotSpot(TM) 64-Bit Server V...", (int) (short) 1, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava Ho" + "'", str3.equals("ava Ho"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "10 -11http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10 -11http://java.oracle.com/" + "'", charSequence2.equals("10 -11http://java.oracle.com/"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.14.3                                                                                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 10.14.3                                                                                             is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(14.0d, (double) 14.0f, (double) 80);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.0d + "'", double3 == 14.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0404104-1", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0404104-1" + "'", str2.equals("0404104-1"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) ":                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-1.040.04100.0SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "             JavaPlatformAPISpecification             ", (java.lang.CharSequence) "-141041404-1497");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "            mixed mode             ", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sophie");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 0, (byte) 0, (byte) 10, (byte) 1, (byte) 1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 10, 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "140404104141" + "'", str13.equals("140404104141"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1 0 0 10 1 1" + "'", str15.equals("1 0 0 10 1 1"));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 0 + "'", byte16 == (byte) 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "SU");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "SU" + "'", charSequence2.equals("SU"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/U            mixed mode             1779_1560278998                                                ", "1.7.0_8...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/U            mixed mode             1779_1560278998                                                " + "'", str2.equals("/U            mixed mode             1779_1560278998                                                "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "xdhd");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp" + "'", str3.equals("pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8" + "'", str1.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun" + "'", str2.equals("un.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 24, 210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 210 + "'", int3 == 210);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("jAVA hOTsjAVA pLATFORM api sPECIFICATIONOT(tm) 64-bIT sERVER vm", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 96, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a", "10.0a32.0a-1.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "   1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7       1.7    ", (java.lang.CharSequence) "10a-1", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        int[] intArray4 = new int[] { (short) 0, (byte) 0, 10, (-1) };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 10, 0);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     ", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     " + "'", str4.equals("TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     "));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "TTP:   1.7    A   1.7    A   1.7    ORA   1.7    E   1.7    O   1.7     ", 145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spec", "aaaaaaa...", "1.0 -1.0 10.0 0.0 -1.0 -1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spec" + "'", str3.equals("51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spec"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 6, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "HTTP://JAVA.ORACLE.COM/", (int) '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "10 97 -1 0 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :" + "'", str3.equals(":               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1404041");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        float[] floatArray6 = new float[] { 97L, 1, (-1.0f), (byte) 0, 5, (short) -1 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97.0#1.0#-1.0#0.0#5.0#-1.0" + "'", str9.equals("97.0#1.0#-1.0#0.0#5.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97.0 1.0 -1.0 0.0 5.0 -1.0" + "'", str11.equals("97.0 1.0 -1.0 0.0 5.0 -1.0"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sun.lwawt.macosx.LWCToolkit", "Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi4!", (java.lang.CharSequence) "                     aaa1.4aaaa                     ", 39);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("###########hi4!###########", 39, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "/U            mixed mode             1779_156027899");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4a", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4a" + "'", str2.equals("4a"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        long[] longArray5 = new long[] { 10L, 'a', (byte) -1, 0L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a97a-1a0a100" + "'", str8.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a97a-1a0a100" + "'", str10.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10 97 -1 0 100" + "'", str13.equals("10 97 -1 0 100"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaa...", (double) 39.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 39.0d + "'", double2 == 39.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Ehi!E");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("j/framework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4/Users/sophie/Documents/defects", "class [D class [C class [D");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "ava Ho", (java.lang.CharSequence) "su");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44100 ", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44100 " + "'", str4.equals("44100 "));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "4a35a5a32a-1a27");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", charSequence2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.LWCToolkit", 0, "http://java.oracle.com/mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "             edom dexim            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 26, 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("su", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "su" + "'", str2.equals("su"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        short[] shortArray2 = new short[] { (short) 100, (short) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100 1" + "'", str5.equals("100 1"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("hi!ava(TM) SE Runtime Environment", "44 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!ava(TM) SE Runtime Environment" + "'", str2.equals("hi!ava(TM) SE Runtime Environment"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("100 1 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 1 1" + "'", str1.equals("100 1 1"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(":                       .:                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        long[] longArray5 = new long[] { 10L, 'a', (byte) -1, 0L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) '4', 35);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', 2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a97a-1a0a100" + "'", str8.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        int[] intArray1 = new int[] { 97 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "97" + "'", str5.equals("97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97" + "'", str10.equals("97"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("J#v# HotSpot(TM) 64-Bit Server VM", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "             JavaPlatformAPISpecification             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) 31, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                     aaa1.4aaaa                     ", "hTTP://JAVA.ORACLE.COM/", "/U            mixed mode             1779_1560278998                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     aaa1.4aaaa                     " + "'", str3.equals("                     aaa1.4aaaa                     "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "un.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironm", 210, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10a97a-1a0a10", (-1), "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a97a-1a0a10" + "'", str3.equals("10a97a-1a0a10"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        long[] longArray5 = new long[] { 10L, 'a', (byte) -1, 0L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.Class<?> wildcardClass13 = longArray5.getClass();
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a97a-1a0a100" + "'", str8.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a97a-1a0a100" + "'", str10.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "            mixed mode             Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "-1.040.04100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        long[] longArray3 = new long[] { 96, 5, 32 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5L + "'", long4 == 5L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "96#5#32" + "'", str6.equals("96#5#32"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10 97", 214.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 214.0f + "'", float2 == 214.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "44 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        int[] intArray6 = new int[] { (short) -1, 10, (short) 1, 0, (short) -1, 'a' };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 96, 13);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1 10 1 0 -1 97", (java.lang.CharSequence) "97.0a1.0a-1.0a0.0a5.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(13L, (long) 14, (long) 57);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 57L + "'", long3 == 57L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Jav        24.80-b110 10 10Java", (int) (short) 0, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                             xdhd");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                             xdhd" + "'", str1.equals("                                                                                             xdhd"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) (short) -1, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '4', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 54, 1);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "32.0 0.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1", 3, ":::::...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(":                       .:                       ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("         :");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":         " + "'", str1.equals(":         "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, '4', 6, 3937);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                                                                                 ", ".1a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                 " + "'", str2.equals("                                                                                                                                                 "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("140404104141");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "140404104141" + "'", str1.equals("140404104141"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.0", "-1.040.041hi1Ua7a-1aUa1UU-1.040.041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.040.041hi1Ua7a-1aUa1UU-1.040.041" + "'", str2.equals("-1.040.041hi1Ua7a-1aUa1UU-1.040.041"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(54, 32, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "########################", (java.lang.CharSequence) " A                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("XXXXXXXXXXXX", 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("     10 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-1" + "'", str1.equals("10-1"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        double[] doubleArray6 = new double[] { 1.0d, (-1.0d), 10.0d, 0, (-1.0d), (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 8, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0#-1.0#10.0#0.0#-1.0#-1.0" + "'", str9.equals("1.0#-1.0#10.0#0.0#-1.0#-1.0"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.7.0_8...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             " + "'", str2.equals("                             "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "        ", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi4!", 6, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " hi4! " + "'", str3.equals(" hi4! "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("100a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a1" + "'", str1.equals("100a1"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!ava(tm) se runtime environment");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", 1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie", "", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', (int) '#', (int) (byte) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', 80, (int) '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', 35, 0);
        double double19 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 32.0d + "'", double19 == 32.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10.0432.04-1.0" + "'", str21.equals("10.0432.04-1.0"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("        24.80-b110 10 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b110 10 10" + "'", str1.equals("24.80-b110 10 10"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("hi!ava(TM) SE Runtime Environment                                               ", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!ava(TM) SE Runtime Environment                                               " + "'", str2.equals("hi!ava(TM) SE Runtime Environment                                               "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_ ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("sun.awt.CGraphicsEnvironment", strArray5, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        java.lang.String[] strArray11 = null;
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray5, strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "            mixed mode             ", (java.lang.CharSequence[]) strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach(":         ", strArray11, strArray15);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", strArray15, strArray20);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, '#');
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str8.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Oracle Corporation" + "'", str12.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + ":         " + "'", str17.equals(":         "));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen" + "'", str21.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi#!" + "'", str23.equals("hi#!"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [" + "'", str1.equals("ass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass [Dass [Cclass ["));
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test220");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
//        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
//        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean12 = javaVersion8.atLeast(javaVersion11);
//        boolean boolean13 = javaVersion5.atLeast(javaVersion8);
//        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
//        boolean boolean15 = javaVersion0.atLeast(javaVersion8);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", 145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 145 + "'", int2 == 145);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                         24A.A80A-ABA11                                          ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         24A.A80A-ABA11                                          " + "'", str2.equals("                                         24A.A80A-ABA11                                          "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("4a35a5a32a-1a27", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        int[] intArray1 = new int[] { 97 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 100, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97" + "'", str4.equals("97"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97" + "'", str11.equals("97"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " hi4! ", (java.lang.CharSequence) "\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sophie", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0a32.0a-1.0" + "'", str8.equals("10.0a32.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a32.0a-1.0" + "'", str11.equals("10.0a32.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.0d + "'", double12 == 32.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 80 + "'", int1 == 80);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "     10 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("NEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUSTNEMNORIVNeSCIHPARgcuTWAuNUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24a.a80a-aba11", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                          0.0432.04-1.0                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0432.04-1.0" + "'", str1.equals("0.0432.04-1.0"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "            mixed mode             Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "4444444444444444444444444Java(TM) S");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                        " + "'", str1.equals("                                                                        "));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        double[] doubleArray6 = new double[] { 1.0d, (-1.0d), 10.0d, 0, (-1.0d), (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', 1, 1);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "     10 -1", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0a0a10a-1", "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a0a10a-1" + "'", str2.equals("0a0a10a-1"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi1Ua7a-1aUa1UU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi1Ua7a-1aUa1UU" + "'", str1.equals("hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi1Ua7a-1aUa1UU"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "24.80-b1", (java.lang.CharSequence) "24a.a80a-aba11######################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie", (java.lang.CharSequence) "mixed###mode/mixed###modeLmixed###modeimixed###modebmixed###modermixed###modeamixed###modermixed###modeymixed###mode/mixed###modeJmixed###modeamixed###modevmixed###modeamixed###mode/mixed###modeJmixed###modeamixed###modevmixed###modeamixed###modeVmixed###modeimixed###modermixed###modetmixed###modeumixed###modeamixed###modelmixed###modeMmixed###modeamixed###modecmixed###modehmixed###modeimixed###modenmixed###modeemixed###modesmixed###mode/mixed###modejmixed###modedmixed###modekmixed###mode1mixed###mode.mixed###mode7mixed###mode.mixed###mode0mixed###mode_mixed###mode8mixed###mode0mixed###mode.mixed###modejmixed###modedmixed###modekmixed###mode/mixed###modeCmixed###modeomixed###modenmixed###modetmixed###modeemixed###modenmixed###modetmixed###modesmixed###mode/mixed###modeHmixed###modeomixed###modemmixed###modeemixed###mode/mixed###modejmixed###modermixed###modeemixed###mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaana1.4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/U            mixed mode             1779_1560278998                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        short[] shortArray2 = new short[] { (short) 10, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) (short) 100, 27);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 214, (int) (byte) 10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', 39, 0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10 -1" + "'", str5.equals("10 -1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10a-1" + "'", str15.equals("10a-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10a-1" + "'", str17.equals("10a-1"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.040.04100.0", (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) " 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 300 + "'", int2 == 300);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("-1 10", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10" + "'", str2.equals("-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10-1 10"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi1Ua7a-1aUa1UU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI1uA7A-1AuA1uu" + "'", str1.equals("HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI4!HI1uA7A-1AuA1uu"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(":");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spec", "sun.lwawt");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) 'a', 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1#0#0#10#1#1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1#0#0#10#1#1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        long[] longArray5 = new long[] { 10L, 'a', (byte) -1, 0L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', 2, (int) (short) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long20 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long21 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long22 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a97a-1a0a100" + "'", str8.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a97a-1a0a100" + "'", str10.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10 97 -1 0 100" + "'", str13.equals("10 97 -1 0 100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10a97a-1a0a100" + "'", str19.equals("10a97a-1a0a100"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("            mixed mode             Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "1.7.0_80-b15");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            mixed mode             Home/jre/li/ext:/Lirary/Java/Extensions:/Network/Lirary/Java/Extensions:/System/Lirary/Java/Extensions:/usr/li/java" + "'", str3.equals("            mixed mode             Home/jre/li/ext:/Lirary/Java/Extensions:/Network/Lirary/Java/Extensions:/System/Lirary/Java/Extensions:/usr/li/java"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_8...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\na4.1a", "UShi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi10a97a-1a0a10", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("             edom dexim            ", "###########hi4!############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             edom dexim            " + "'", str2.equals("             edom dexim            "));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "24.80-b1", charSequence1, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80/library/java/javavirtua", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ US /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998 Java Virtual Machine Specification /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998", 214);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                 /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "a1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4aa1.4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("                                 /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1.0a0.0a100.", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.Class<?> wildcardClass6 = doubleArray3.getClass();
        java.lang.CharSequence charSequence7 = null;
        char[] charArray10 = new char[] { '4', ' ' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence7, charArray10);
        java.lang.Class<?> wildcardClass12 = charArray10.getClass();
        double[] doubleArray16 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray16, '4');
        java.lang.Class<?> wildcardClass19 = doubleArray16.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray20 = new java.lang.reflect.AnnotatedElement[] { wildcardClass6, wildcardClass12, wildcardClass19 };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray20);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10.0432.04-1.0" + "'", str18.equals("10.0432.04-1.0"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(annotatedElementArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "class [Dclass [Cclass [D" + "'", str21.equals("class [Dclass [Cclass [D"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "class [Dclass [Cclass [D" + "'", str22.equals("class [Dclass [Cclass [D"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1" + "'", str1.equals("7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        float[] floatArray2 = new float[] { ' ', (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32.0 0.0" + "'", str4.equals("32.0 0.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32.0 0.0" + "'", str6.equals("32.0 0.0"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        int[] intArray4 = new int[] { (short) 0, (byte) 0, 10, (-1) };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 10, 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 27, 155);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.0432.04-1.0", (java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "24.80-b11" + "'", str6.equals("24.80-b11"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals("SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        short[] shortArray3 = new short[] { (byte) 100, (byte) 1, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 35);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 0, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004141" + "'", str9.equals("1004141"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSJava Platform API Specificationot(TM) 64-Bit Server VM", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24a.a80a-aba11", '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("hi!", "", (-1));
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/...", strArray9, strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, 'a', 97, 80);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", strArray14, strArray18);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Users/..." + "'", str15.equals("/Users/..."));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str23.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU" + "'", str1.equals("SU"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                              aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                             ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".3410.1", "n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi1Ua7a-1aUa1UU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.14.3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.14.3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.Number[] numberArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(numberArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/" + "'", str3.equals("http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 " + "'", str2.equals("44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        long[] longArray3 = new long[] { (byte) 100, (-1), 10L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a-1a10" + "'", str6.equals("100a-1a10"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', (int) 'a', 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0432.04-1.0" + "'", str7.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4A                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4A                                 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "a4.1a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi4!hi1Ua7a-1aUa1UU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ US /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998 Java Virtual Machine Specification /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998", (java.lang.CharSequence) "maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand maaaaaaaaaaaaaaaaaaaaaaaaaaaaaaandaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) 100, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a100a-1" + "'", str6.equals("100a100a-1"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://javaoracleacom/mixe", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie                                                                                sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("00404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A4200404BA-A08A.A42004041", "97.0a1.0a-1.0a0.0a5.0a-1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0" + "'", str2.equals("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 214);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                    10 97 -1 0 100                    ", "an");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("          1779_156027899", (long) 57);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 57L + "'", long2 == 57L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".1a", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aa...", "                                                                                                 4a ", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " hi4! ", (java.lang.CharSequence) "                                 /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 39);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sophie", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "24.80-b110 10 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("97.0a1.0a-1.0a0.0a5.0a-1.0", 0, "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/!ihT/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "97.0a1.0a-1.0a0.0a5.0a-1.0" + "'", str3.equals("97.0a1.0a-1.0a0.0a5.0a-1.0"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1004-1410", 29, "jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA(tm) s1004-1410jAVA(tm) s" + "'", str3.equals("jAVA(tm) s1004-1410jAVA(tm) s"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0A0.0A100.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "xdhd", 35, 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/foldxdhd1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str4.equals("/var/foldxdhd1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/10.14.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.04-1.0410.040.04-1.04-1.0", 93, 57);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.04-1.0410.040.04-1.04-1.0" + "'", str3.equals("1.04-1.0410.040.04-1.04-1.0"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("x", "/U            mixed mode             1779_156027899");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x" + "'", str2.equals("x"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("jAVA hOTsjAVA pLATFORM api sPECIFICATIONOT(tm) 64-bIT sERVER vm", (double) 39);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 39.0d + "'", double2 == 39.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdks.7.n_8n.jdk/Contents/Home/jre/lib/endorsed", "################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "24.80-b1", (java.lang.CharSequence) ".1a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "0.0432.04-1.0", "10a-1");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 1.4f, 7.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 13, (long) 26, 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("en", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Java HotSJava Platform API Specificationot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "en" + "'", str4.equals("en"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.3", "Hi!ava(tm) se runtime ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", 39);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ".1a", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "#############################################");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4444 ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ', (int) ' ', 2);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "###########hi4!###########", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4a " + "'", str15.equals("4a "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4# " + "'", str17.equals("4# "));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        long[] longArray3 = new long[] { (byte) 100, (-1), 10L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a-1a10" + "'", str7.equals("100a-1a10"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(":         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(":", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                ", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10#97#-1#0#100", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("        ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "96#5#32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                              en", (java.lang.CharSequence) "un.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.O...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.O..." + "'", str2.equals("::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.O..."));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi#!", 210, 155);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        long[] longArray3 = new long[] { (byte) 100, (-1), 10L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        java.lang.Class<?> wildcardClass10 = longArray3.getClass();
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a-1a10" + "'", str7.equals("100a-1a10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004-1410" + "'", str9.equals("1004-1410"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HTTP://JAVA.ORACLE.COM/MIXED MODE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(":         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         US:         ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444" + "'", str2.equals("44444444444444444444444444"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!ava(TM) SE Runtime Environment                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 0, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", (java.lang.CharSequence) "\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', 29, 39);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" A                                 ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan", "             JavaPlatformAPISpecification             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " A                                 " + "'", str3.equals(" A                                 "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0a0a10a-1", "ass [Cclass [D");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("http://javaoracleacom/mixed modehttp://javaoracleacom/mixed modehttp:/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://javaoracleacom/mixedmodehttp://javaoracleacom/mixedmodehttp:/" + "'", str1.equals("http://javaoracleacom/mixedmodehttp://javaoracleacom/mixedmodehttp:/"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1aa4.1a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.91.81.5", "::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::HTTP://JAVA.ORACLE.COM/MIXED MODE::::::::::::::::::::::::");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", "/Users/...", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15/Users/...1.7.0_80-b15"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Librry/Jv/JvVirtulMchines/_80.jdk/Contents/Home/jre", (long) 3837);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3837L + "'", long2 == 3837L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanEDOM DEXIM/MOC.ELCAR", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Ehi!E", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ehi!E" + "'", str2.equals("Ehi!E"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ".3410.1", (java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 27, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("J#v# HotSpot(TM) 64-Bit Server VM", 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v# HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("J#v# HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { '4', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', (int) 'a', (int) (byte) 0);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "               1.7                 ", charArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "44 " + "'", str12.equals("44 "));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, 6.0f, (float) 1004141L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("               1.7                 ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               1.7                 " + "'", str2.equals("               1.7                 "));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aa...", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa..." + "'", str2.equals("aa..."));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '4', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 80, 27);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 26, 0);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        try {
            java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) ' ', 214);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4# " + "'", str22.equals("4# "));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24a.a80a-aba11" + "'", str3.equals("24a.a80a-aba11"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "24.80-b11" + "'", str5.equals("24.80-b11"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "jAVA(tm) s1004-1410jAVA(tm) s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.00.0100.0", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "n", (java.lang.CharSequence) "::");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("100 1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 1" + "'", str2.equals("100 1"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("24.80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1" + "'", str1.equals("24.80-b1"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10#-1                          ", (java.lang.CharSequence) "        24.80-b110 10 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::", "1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::" + "'", str2.equals("::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::http://java.oracle.com/mixed mode::::::::::::::::::::::::"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spec", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spec" + "'", str3.equals("51.0Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Spec"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 13, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_8...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_8..." + "'", str1.equals("1.7.0_8..."));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a-1a10100a--1.040.04100.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :               1.7                 :", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444444444444444444444444444Java(TM) SE RunpJava(TM) SE Runt4444444444444444444444444444444444", 14, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10 -11http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 -11http://java.oracle.com" + "'", str1.equals("10 -11http://java.oracle.com"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                             ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             " + "'", str2.equals("                             "));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1", "", "mixed###mode/mixed###modeLmixed###modeimixed###modebmixed###modermixed###modeamixed###modermixed###modeymixed###mode/mixed###modeJmixed###modeamixed###modevmixed###modeamixed###mode/mixed###modeJmixed###modeamixed###modevmixed###modeamixed###modeVmixed###modeimixed###modermixed###modetmixed###modeumixed###modeamixed###modelmixed###modeMmixed###modeamixed###modecmixed###modehmixed###modeimixed###modenmixed###modeemixed###modesmixed###mode/mixed###modejmixed###modedmixed###modekmixed###mode1mixed###mode.mixed###mode7mixed###mode.mixed###mode0mixed###mode_mixed###mode8mixed###mode0mixed###mode.mixed###modejmixed###modedmixed###modekmixed###mode/mixed###modeCmixed###modeomixed###modenmixed###modetmixed###modeemixed###modenmixed###modetmixed###modesmixed###mode/mixed###modeHmixed###modeomixed###modemmixed###modeemixed###mode/mixed###modejmixed###modermixed###modeemixed###mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("njAVA hOTs", (int) (byte) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "njAVA hOTs                                                                                          " + "'", str3.equals("njAVA hOTs                                                                                          "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ava Ho");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("SU");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SU\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi#!", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT                                    /USERS/SOPHIE                                    SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "10.14.3", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHEDOM DEXIM/MOC.ELCARO.AVAJ//:PTTH");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "-1.0 0.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "\na4.1a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10 97 -1 0 100", charArray8);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 35, 80);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Hi!ava(tm) se runtime ", (java.lang.CharSequence) "sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("sun.awt.CGraphicsEnvironment", strArray3, strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("hi!ava(tm) se runtime environment", "EDOM DEXIM/MOC.ELCARO.AVAJ//:PTTHaaaaaaaa.", (int) ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach(":                       .:              10 -1:                       .:         ", strArray3, strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + ":                       v:              10 se1:                       v:         " + "'", str12.equals(":                       v:              10 se1:                       v:         "));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4444444444444444444444444Java(TM) S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51779_1560278998/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100", (java.lang.CharSequence[]) strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ', 5, (int) (short) 0);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a\na4.1a", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.04-1.0410.040.04-1.04-1.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("7.1", "####################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4a35a5a32a-1a27", "/Users/sophie", 39);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4a35a5a32a-1a27" + "'", str3.equals("4a35a5a32a-1a27"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.0-1.010.00.0-1.0-1.0", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray4);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Thi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', (int) (short) 10, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(" 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44" + "'", str2.equals(" 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44 44"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMEN", (java.lang.CharSequence) "1http://java.oracle.com/", 300);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str1.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("UTF-8", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1", (java.lang.CharSequence) "100a1a1##########################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!ava(TM) SE Runtime Environment                                               ", "           97#97#5#5#100", 145);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11", "...DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT......DEXIM/MOC.ELCARO.AVAJ//:PT...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("::::::::::::::::::::::::", "", "-1a10a1a0a-1a97");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::::::::::::::::::" + "'", str3.equals("::::::::::::::::::::::::"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10.14.3                                                                                             ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0 -1.0 10.0 0.0 -1.0 -1.0", " hi4! ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com/", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        double[] doubleArray3 = new double[] { (byte) 10, ' ', (-1) };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', (int) '#', (int) (byte) 1);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0432.04-1.0" + "'", str5.equals("10.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0 32.0 -1.0" + "'", str13.equals("10.0 32.0 -1.0"));
    }
}

