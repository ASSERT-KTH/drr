import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", (int) ' ', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       Oracle Corporation       " + "'", str3.equals("       Oracle Corporation       "));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", "/", "0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w" + "'", str3.equals("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MacOSX                                                                                              ");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1Mac OS X0.0", 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/uSERS/SOPHIE", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("7_8", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("7_8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"7_8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("##############################################################################################en", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################################################################################en" + "'", str2.equals("############################################################################################en"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("                                               100.0                                                ", "###############################################################Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("noitacificepS#enihcaM#lautriV#avaJ###############################################################", "", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", " 24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", "7_8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi", 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("7_8", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                            MacOSX 1.7.0_80-b15", "s");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            MacOSX 1.7.0_80-b15" + "'", str3.equals("                            MacOSX 1.7.0_80-b15"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("cOScOS", ".0_80", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cOScOS" + "'", str3.equals("cOScOS"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(5.41d, (double) 458, (double) 144.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.41d + "'", double3 == 5.41d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sun.lw", "hi!", "                            MacOSX 1.7.0_80-b15");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("...5.415.415.415.415.415.415.415");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...5.415.415.415.415.415.415.415" + "'", str1.equals("...5.415.415.415.415.415.415.415"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        long[] longArray4 = new long[] { (-1L), (byte) 1, (short) 10, 458 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 458L + "'", long5 == 458L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 458L + "'", long6 == 458L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 458L + "'", long7 == 458L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 458L + "'", long9 == 458L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 458L + "'", long10 == 458L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(" OS c OS ", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("##############################################################Java#Virtual#Machine#Specificatio", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "########" + "'", str2.equals("########"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("McOSX", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "jAVA pL...", 143);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..." + "'", str3.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..."));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("jAVA pLATFORM api sPECIFICATION", "                                                                                                :");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "       Oracle Corporation       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(".0_8                                                                                                ", "", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        float[] floatArray6 = new float[] { 8, 7, (short) -1, 0, (-1.0f), 8L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 8.0f + "'", float8 == 8.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", "mACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 8, (double) 32L, 18.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 96, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwa...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                            MacOSX ", 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "oracle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("24#######");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_80-b15", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-b15" + "'", str2.equals("-b15"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80", 32, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80" + "'", str3.equals(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4444444444444444444444444444444444444444444c OS c OS ", 100, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str1.equals("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("!ih", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("COX", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "COX" + "'", str3.equals("COX"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 3, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { 'a', '4' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" MacOSX ", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX " + "'", str2.equals(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("C os xAmC os xAmC os xAm", 8L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("c OS c OS ", 144);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   c OS c OS                                                                    " + "'", str2.equals("                                                                   c OS c OS                                                                    "));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(144, 16, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" OS c OS ", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        OS c OS " + "'", str2.equals("                        OS c OS "));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "7_8", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(461, 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 461 + "'", int3 == 461);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("MACOSX", 0, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "MACosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophi1.7.0_80/Users/sophi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str4.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2", "44cO4X4444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2" + "'", str2.equals(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "jAVA pLATFORM api sPECIFICATION", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification" + "'", str3.equals("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Platform API Specification", (int) (short) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Oracle Corporation", "1Mac OS X0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("s", ".0_8                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, (int) (byte) 10, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 3, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "MACosx");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MACosx" + "'", str1.equals("MACosx"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 144 + "'", int1 == 144);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("O  c  C          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O  c  C          " + "'", str1.equals("O  c  C          "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "c OS Xa...                                     100.0                                                ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 111 + "'", int2 == 111);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mACosx", (java.lang.CharSequence) "c#OS#Xa...#####################################100.0################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(":", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL.." + "'", str1.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL.."));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { 'a', '4' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie", 143, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "08_0...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION" + "'", str2.equals("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("1.7", "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("sun.lw", "       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Userssophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "userssophie" + "'", str1.equals("userssophie"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 100, (int) (byte) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("cOScOS", "1.7", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cOScOS" + "'", str3.equals("cOScOS"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "macosxmacosx" + "'", str1.equals("macosxmacosx"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", 144);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM" + "'", str2.equals("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..", 16, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                               Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("COX", "                            MacOSX 1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 16, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { 'a', '4' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                                                                                                :", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w" + "'", str3.equals("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("                        OS c OS ", "44cO4X4444444444444444444444444444...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        " + "'", str2.equals("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("7_8", "COX", (int) (short) 1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "hi!");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("                                                5.41                                                ", strArray5, strArray15);
        java.lang.String[] strArray17 = null;
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("Java Vi...", strArray5, strArray17);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", (int) (short) 10, (-1));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "                                                5.41                                                " + "'", str16.equals("                                                5.41                                                "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Java Vi..." + "'", str18.equals("Java Vi..."));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("US10.14.3", " MacOSX                             MacOSX ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US10.14.3" + "'", str2.equals("US10.14.3"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "noitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(97.0f, (float) 100L, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                               100.0                                                ", "x86_64", "24.80-B11");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, 0.0d, (double) 170);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("noitacificepS#enihcaM#lautriV#avaJ##############################################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str2.equals("noitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("OS c OS", "10.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OS c OS" + "'", str2.equals("OS c OS"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwa...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("userssophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("hi!", "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                " + "'", str1.equals("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("MACOSX", "7_8", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (byte) 0, (int) (short) 0);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny(":", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2, (double) ' ', (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                5.41                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                 5.41                                                 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 608 + "'", int1 == 608);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                               Java Virtual Machine Specification", "noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               Java Virtual Machine " + "'", str2.equals("                                                               Java Virtual Machine "));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44cO4X4444444444444444444444444444...", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', 3L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi", "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ", " 24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "OS c OS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.awt.CGraphicsEnvironment", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                    Userssophie                     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Userssophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!", 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MacOSX                                                                                              ", (java.lang.CharSequence) "5.41");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("noitacificepS#enihcaM#lautriV#avaJ##############################################################", (int) (byte) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str3.equals("noitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415", "########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("c OS Xa...", (int) '4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 461);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/", "08_0...");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" MacOSX ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MacOSX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "24#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("       Oracle Corporation       ", "http://java.oracle.com/", "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("c OS c OS ", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS c OS " + "'", str3.equals("c OS c OS "));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "cOX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", (int) 'a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR" + "'", str3.equals("pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("c OS Xa...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "NoitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", " MacOSX ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1Mac OS X0.0", "", 461);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.lw", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("mACosx                                                                                              ", "1Mac OS X0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mACosx                                                                                              " + "'", str2.equals("mACosx                                                                                              "));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("OS c OS", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oracle corporation", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "C os xAm");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("hi!1Mac OS X0.0hi!", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSXMacOSX" + "'", str1.equals("MacOSXMacOSX"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("              24.80-b11              ", ".0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              24.80-b11              " + "'", str2.equals("              24.80-b11              "));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("c OS Xa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cOSXa..." + "'", str1.equals("cOSXa..."));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', (int) '4', 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                   c OS c OS                                                                    ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                5.41                                                ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("       Oracle Corporation       ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("jAVA pLATFORM api sPECIFICATION", "Java(TM) SE Runtime Environment", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit", 16, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                            MacOSX 1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("24.80-B11", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("mACosx", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Cosx" + "'", str2.equals("Cosx"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("macosxmacosx", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("oracle corporation", "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("10.14.3", " 24.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str2.equals("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwa...", 458, 111);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("mACosx                                                                                              ", "                    Userssophie                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mACosx                                                                                              " + "'", str2.equals("mACosx                                                                                              "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80                                                                                            " + "'", str2.equals("1.7.0_80                                                                                            "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("MacOSX                  1.7MacOSX                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX                  1.7MacOSX" + "'", str1.equals("MacOSX                  1.7MacOSX"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("h/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h/users/sophie" + "'", str1.equals("h/users/sophie"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 5, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str4.equals("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("US10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US10.14.3" + "'", str1.equals("US10.14.3"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MacOSXMacOSX", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                ", "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("sun.lwa...", "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", "!ih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("51.0", " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", " MacOSX                             MacOSX ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str1.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("OS c OS", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", "1Mac OS X0.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION", 97, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("McOSX", ".0_8                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double[] doubleArray1 = new double[] { 10 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("############################################################################################en", 167);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("cOX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cOX" + "'", str1.equals("cOX"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                   c OS c OS                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                   C os C os                                                                    " + "'", str1.equals("                                                                   C os C os                                                                    "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", " #P#latform# #A...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                   C os C os                                                                    ", (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                    Userssophie                     ", "                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.7.0_80                                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION", "soph:sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("mixed mode", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("51.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1, 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophi1.7.0_80/Users/sophi", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi1.7.0_80/Users/sophi" + "'", str2.equals("/Users/sophi1.7.0_80/Users/sophi"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("5.41sun.l", "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5.41sun.l" + "'", str2.equals("5.41sun.l"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-b15", "                        OS c OS ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-b15" + "'", str3.equals("-b15"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("h/Users/sophie", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(8L, (long) 6, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) " OS c OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " OS c OS " + "'", str1.equals(" OS c OS "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r", 100);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ECIFICATIO" + "'", str2.equals("ECIFICATIO"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("7_8", "COX", (int) (short) 1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "hi!");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("                                                5.41                                                ", strArray4, strArray14);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", 111, 2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "                                                5.41                                                " + "'", str15.equals("                                                5.41                                                "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) (byte) 0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(".0_80", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 144, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, (int) '4', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 37, 32.0d, 144.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("jAVA pLATFORM api sPECIFICATION", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("MacOSX", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "acOSX" + "'", str2.equals("acOSX"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", ".");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80", "c OS XaM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MacOSX                  1.7MacOSX                                                                                                              ", "ECIFICATIO", 461);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("cOSXa...", "C os xAmC os xAmC os xAm", 6, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "C os xAmC os xAmC os xAm.." + "'", str4.equals("C os xAmC os xAmC os xAm.."));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mACosx                                                                                              ", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mACosx                                                                                              " + "'", str2.equals("mACosx                                                                                              "));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih" + "'", str2.equals("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MACOSX", ".0_8                                                                                                ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MACOSX" + "'", str3.equals("MACOSX"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "sun.lw");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("##############################################################################################en", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################################################################en" + "'", str3.equals("##############################################################################################en"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "       Oracle Corporation       ", (java.lang.CharSequence) "US10.14.3");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "       Oracle Corporation       " + "'", charSequence2.equals("       Oracle Corporation       "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                ", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("C os xAmC os xAmC os xAm..", "jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("c OS c OS ", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("MacOSX                                                                                              ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.Object[] objArray1 = new java.lang.Object[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(objArray1, "c OS c OS ");
        java.lang.Class<?> wildcardClass4 = objArray1.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(objArray1, '#');
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0" + "'", str6.equals("100.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 8, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.", (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("cOScOS", " 24.80-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cOScOS" + "'", str2.equals("cOScOS"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:  Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, (float) 144, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "cOX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon" + "'", str2.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("##############################################################################################en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##############################################################################################en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "cOSXa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str1.equals("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oracle corporation", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "C os xAm");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "racle corporation" + "'", str6.equals("racle corporation"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" 24.8", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("mACosx                          ...#####################################100.0################################################ac#OS#X", "McOSX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 458);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    "));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("...#####################################100.0################################################ac#OS#X", "cOSXa...", 111);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              " + "'", str1.equals("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", (long) 458);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 458L + "'", long2 == 458L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "c#os#xAm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ".0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("##############################################################################################en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################################################################################en" + "'", str1.equals("##############################################################################################en"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Userssophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Userssophie" + "'", str1.equals("Userssophie"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "C os xAmC os xAmC os xAm..", (java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", "...#####################################100.0################################################ac#OS#X", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi!1Mac OS X0.0hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!1Mac OS X0.0hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4, (double) 1, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                               Java Virtual Machine Specification", "c OS XaM", (int) (short) 100);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", (int) (byte) 1, 461);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 32, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("C os xAmC os xAmC os xAm", "/Users/sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(" 24.80-B11", "1.7.0_80                                                                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("              24.80-b11              ", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              24.80-b11              " + "'", str3.equals("              24.80-b11              "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2", (-1), 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 24.80-..." + "'", str3.equals(" 24.80-..."));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(".0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8_0." + "'", str1.equals("8_0."));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie", (long) 143);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 143L + "'", long2 == 143L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", "08_0...", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" 24.80-...", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 24.80-..." + "'", str2.equals(" 24.80-..."));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Oracle Corporation", "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("!ih", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!ih" + "'", str2.equals("!ih"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw", strArray2, strArray5);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw" + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ", (java.lang.CharSequence) "24#######");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "c#os#xAm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C#os#xAm" + "'", str1.equals("C#os#xAm"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...5.415.415.415.415.415.415.415", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...5.415.415.415.415.415.415.415" + "'", str2.equals("...5.415.415.415.415.415.415.415"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("MACOSX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MACOSX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_80                                                                                            ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", "                            MacOSX 1.7.0_80-b15", " 24.80-B11");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "mACosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwa...", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwa..." + "'", str3.equals("sun.lwa..."));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", " OS c OS ", "cOSXa...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, (int) ' ', 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("5.41");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 0, 144);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("O  c  C          ", (int) '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444O  c  C          444444444444444444" + "'", str3.equals("44444444444444444O  c  C          444444444444444444"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "c OS XaM", "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(18.0d, (double) 5, (double) 167);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 167.0d + "'", double3 == 167.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str1.equals("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Oracle Corporation", (int) (short) -1, 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("MACOSX", (int) (short) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Cor" + "'", str2.equals("Oracle Cor"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "8_0.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "hi!", 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("c OS XaM", strArray4, strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "c OS XaM" + "'", str7.equals("c OS XaM"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("mACosx                          ...#####################################100.0################################################ac#OS#X", (int) ' ', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', ' ', '4', '4', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("h/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/Users/sophie" + "'", str2.equals("h/Users/sophie"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "0", (java.lang.CharSequence) "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0" + "'", charSequence2.equals("0"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, (long) 16, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 16L + "'", long3 == 16L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-B11", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ification" + "'", str2.equals("ification"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "C#os#xAm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..." + "'", str1.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..."));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "44444444444444444O  c  C          444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44cO4X4444444444444444444444444444...", "1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", "_8", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("oracle corporation", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporation" + "'", str2.equals("oracle corporation"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str2.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(16, 18, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification" + "'", str1.equals("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                            MacOSX 1.7.0_80-b15", "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            MacOSX 1.7.0_80-b15" + "'", str3.equals("                            MacOSX 1.7.0_80-b15"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("c OS c OS ", "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ", 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '4', (-1), (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(8.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 96, (double) 16L, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 96.0d + "'", double3 == 96.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", "ification", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("5.41", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("MacOSX1.7MacOSX");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("cOX", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 111);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                            MacOSX ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("24.80-B11", " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("noitacificepS#enihcaM#lautriV#avaJ###############################################################", 7, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ficepS#enih" + "'", str3.equals("ficepS#enih"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("       ", "MACOSX", "sun.lwawt.macosx.CPrinterJob", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "       " + "'", str4.equals("       "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lw");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.l" + "'", str1.equals("sun.l"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwa...", 461, "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################" + "'", str3.equals("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 0, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "############################################################################################en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("c OS c OS ", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/uSERS/SOPHIE", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/uSERS/SOPHIE" + "'", str8.equals("/uSERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification" + "'", str9.equals("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("OS c OS", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OS c OS" + "'", str2.equals("OS c OS"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Userssophie", (int) (byte) 100, "                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                            Userssophie                                             " + "'", str3.equals("                                            Userssophie                                             "));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("cOSXa...", "mACosx                          ...#####################################100.0################################################ac#OS#X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str2.equals("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                               100.0                                                ", 170, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                               Java Virtual Machine ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!1Mac OS X0.0hi!", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X SO caM" + "'", str1.equals("X SO caM"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("5.41", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("h/users/sophie", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/users/sophie" + "'", str2.equals("h/users/sophie"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", "                    Userssophie                     ", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 461, " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor" + "'", str3.equals(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("       Oracle Corporation       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("5.41");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "cOSXa...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 1, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/uSERS/SOPHIE", "########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", "ification", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                                :");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                        OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" 24.80-...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15", "mACosx");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                                                                   c OS c OS                                                                    ", "##############################################################Java#Virtual#Machine#Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("mACosx", "h/Users/sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", 458, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444444444444O  c  C          444444444444444444", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" 24.8", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1.7.0_80-b15", "", 608);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("java Platform API Specification", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 3, 608);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java(TM) SE Runtime Environment", 167, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ", "", "hi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "                                                5.41                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.l");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.l" + "'", str1.equals("sun.l"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                            MacOSX 1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 47 + "'", int1 == 47);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                          " + "'", str1.equals("                                                                                                                                                                          "));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "Userssophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) ".0_8", (java.lang.CharSequence) "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + ".0_8" + "'", charSequence2.equals(".0_8"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11" + "'", str3.equals(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("X SO caM", "_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "MACosx", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(".", "c#os#xAm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444" + "'", str2.equals("44444444"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                5.41                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "cOSXa...", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 1, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("O  c  C          ", "############################################################################################en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O  c  C          " + "'", str2.equals("O  c  C          "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80                                                                                            ", (java.lang.CharSequence) "44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "X SO caM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" 24.80-...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-..." + "'", str1.equals("24.80-..."));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("5.41sun.l", (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("4444444444444444444444444444444444444444444c OS c OS", "_8", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0", "MacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oracle corporation", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "C os xAm");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("5.41sun.l", strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "racle corporation" + "'", str7.equals("racle corporation"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", "racle corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 0, 37);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl" + "'", str6.equals("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2", "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS c OS ", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }
}

