import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "   .0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("c OS Xa...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" 24.80-b11", (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                   ", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 92, (long) 167);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 167L + "'", long3 == 167L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) ".aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Sun.lwa...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.14.", "44444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(".0_8", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80                                                                                            ", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "                                              s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                              s" + "'", str1.equals("                                              s"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("sun.l", "AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO", 144);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                                8_0.", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                8_0." + "'", str2.equals("                                                                                                8_0."));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112", "MacOSX                  1.7MacOSX                                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("soph:sophi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str3.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("08_0...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...0_80" + "'", str1.equals("...0_80"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Mac                                                                                                          sOS                                                                                                          sX", "...44444444444444444444444444..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("pLATFORM Java Virtual Machine SpecificationpLATFORM ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "Userssophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                   c os c os                                                                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...a...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwasun.lw" + "'", str2.equals("...a...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwasun.lw"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("MacjAVA pL...jAVA pL...jAVA pL...j...                                                                                          sOS                                                                                                          sX", (float) 18);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 18.0f, 0.0d, (double) 12.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "MacOSX                                                                                              ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                               Java Virtual Machine Specification", "noitacificepS#enihcaM#lautriV#avaJ##############################################################");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi", strArray5, strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java Virtual Machine Specification" + "'", str10.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi" + "'", str14.equals("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("mACosx                          ...#####################################100.0################################################c#OS#X   ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                            MacOSX ", "", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Java Platform API Specification", "mACosx                          ...#####################################100.0################################################ac#OS#X   ", 111);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("   .0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0_80" + "'", str1.equals(".0_80"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(100L, (long) 99, 143L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 99L + "'", long3 == 99L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80", " OS c OS aaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(" 24.80-B11", 111);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                   24.80-B11                                                   " + "'", str2.equals("                                                   24.80-B11                                                   "));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" MacOSX ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX" + "'", str1.equals("MacOSX"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 105, (float) 95, (float) 44);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 44.0f + "'", float3 == 44.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Sun.lwa...", (int) (short) 10, 143);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java Virtual Machine Specification", "sun.awt.CGraphicsEnvironment", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 8, "cOScOS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cOSccOSc" + "'", str3.equals("cOSccOSc"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "cepS#enih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 96, 461);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("US4104.4144.43", 99, "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US4104.4144.43Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat" + "'", str3.equals("US4104.4144.43Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (long) 608, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..", "userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm", 96);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, (int) (byte) 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio" + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "44444444444444444OcC444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                          s", (java.lang.CharSequence) "          MacOSXMacOSX          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("4444444444444444444444444444444444444444444c OS c OS ", "Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(6.0f, (float) (short) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ", (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl..." + "'", str1.equals("...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl..."));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(143, 53, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US10.14.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(" MacOSX                             MacOSX ", "cepS#enih", "O  c  C          MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaaMacOSX  MacOSX  MacOSX  MacO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " MacOSX                             MacOSX " + "'", str3.equals(" MacOSX                             MacOSX "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".0_8                                                                                                ", "51.");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray10 = new char[] { 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence6, charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("mixed mode", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " 24.80-B11", charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 18 + "'", int18 == 18);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("oracle corporatio");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("############################################################################################en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        double[] doubleArray1 = new double[] { 10 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("US10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US10.14.3" + "'", str1.equals("US10.14.3"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("macosxmacosx", "/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "java Platform API Specificatio", (java.lang.CharSequence) "1Mac OS X0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("1Mac OS X0.0", "C os xAm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("NoitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################################################Java#Virtual#Machine#SpecificatioN" + "'", str1.equals("##############################################################Java#Virtual#Machine#SpecificatioN"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("MacOSX1.7.0_80-b15", "                                                   1.7.0_80                                                    ", 271);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...", "5.41", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("RACLE cORPORATIONoRACLE cORPORATION", 10, 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str1.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Userssophie", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("################################", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Userssophie");
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.concatWith("HI!", (java.lang.Object[]) strArray11);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "                   c OS c OS                                                                    ", (int) (byte) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                               ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("51.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "MacOSX1.7MacOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("_8", "10", (int) (short) 10, 458);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "_810" + "'", str4.equals("_810"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", "Mac OS X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("44444444", 1014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44444444 + "'", int2 == 44444444);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                                               100.0                                                ", "", 442);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ", "ification", "c OS XaM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CmACMsx                                                                                              MsmACMsx                                                                                              CmACMsx                                                                                              MsmACMsx                                                                                              " + "'", str3.equals("CmACMsx                                                                                              MsmACMsx                                                                                              CmACMsx                                                                                              MsmACMsx                                                                                              "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MacOSX                  1.7MacOSX", "C#os#xAm", (int) (short) -1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.Class<?> wildcardClass9 = strArray7.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("acOSX", strArray5, strArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny("4444444444444444444444444444444444444444444c OS c OS ", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24.80-b11" + "'", str8.equals("24.80-b11"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "acOSX" + "'", str10.equals("acOSX"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "c#os#xAm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "", (int) (short) 100, (int) ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.CPrinterJob", strArray6, strArray9);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "US", 144, 6);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray24, "MacOSX                                                                                              ");
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray24, "US");
        java.lang.Class<?> wildcardClass29 = strArray24.getClass();
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("/uSERS/SOPHIE", strArray6, strArray24);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str16.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Java Virtual Machine Specification" + "'", str28.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "/uSERS/SOPHIE" + "'", str30.equals("/uSERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray6, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '4', (int) (byte) 1, (int) (byte) 1);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '#', 458, 18);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny(".0_ihpossresU", strArray10);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("51.0", "pLATFORM Java Virtual Machine SpecificationpLATFORM ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("     ", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION", "sPECIFICATION api pLATFORM jAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("s", "44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sEnvironmentsun.awt.CGrcOSXa", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Userssophie", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("################################", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" OS c OS aaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:  OS c OS aaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ", "!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              " + "'", str2.equals("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("c#OS#Xa...#####################################100.0################################################", "c OS Xa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c#OS#Xa...#####################################100.0################################################" + "'", str2.equals("c#OS#Xa...#####################################100.0################################################"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("http://java.oracle.com/", "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  " + "'", str1.equals("  "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU" + "'", str1.equals("SU"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        " + "'", str2.equals("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                   c OS c OS                                                                    ", (int) 'a', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   c OS c OS                                                                     " + "'", str3.equals("                   c OS c OS                                                                     "));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(96, 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten" + "'", str1.equals("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl", (java.lang.CharSequence) "c OS X#...                                     100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("...5.415.415.415.415.415.415.415", "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/", 44);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "MACOSX", 461, 442);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                              s", "_810");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "jAVA pL...", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#P#l08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmCtform#08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#A08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..", "1Mac OS X0.0", 144);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("44444444444444444444444444444444444444444444444444444c4OS4c4OS4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str1.equals("44444444444444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm" + "'", str1.equals("userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 18, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java HotSpot(TM) 64-Bit Server VM", "jAVA pL...jAVA pL...jAVA pL...j...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "... MROFTALp AVAjNOITACIFICEPs ip MROFTALp AVAj");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14." + "'", str1.equals("10.14."));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" MacOSX x86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("     ", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("OS c OS", 44);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44 + "'", int2 == 44);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("  ", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor", "sEnvironmentsun.awt.CGrcOSXa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  " + "'", str3.equals("  "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS " + "'", str2.equals("c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS "));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("################################", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################" + "'", str3.equals("################################"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a');
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/", strArray4, strArray9);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.startsWithAny("4444444444444444444444444444444444444c4OS4c4OS4", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "24.80-b11" + "'", str5.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/" + "'", str19.equals("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("44444444444444444O  c  C          444444444444444444", 92, "c#os#x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c#os#xc#os#xc#os#xc#44444444444444444O  c  C          444444444444444444c#os#xc#os#xc#os#xc#" + "'", str3.equals("c#os#xc#os#xc#os#xc#44444444444444444O  c  C          444444444444444444c#os#xc#os#xc#os#xc#"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("XSOcaM7.1XSOcaM", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "MacOSX1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironment", 16, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("################################", "                                                                                                :", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("5.41");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("va platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi", strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("c#OS#Xa...#####################################100.0################################################", "                                                                                                :");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "c#OS#Xa...#####################################100.0################################################" + "'", str9.equals("c#OS#Xa...#####################################100.0################################################"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "c#OS#Xa...#####################################100.0################################################" + "'", str11.equals("c#OS#Xa...#####################################100.0################################################"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/" + "'", str12.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("noitacificepS#enihcaM#lautriV#avaJ###############################################################", (int) '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ###############################################################" + "'", str3.equals("noitacificepS#enihcaM#lautriV#avaJ###############################################################"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("#");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 53, 181);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 53");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERHI!", (java.lang.CharSequence) "c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444", "US4104.4144.43");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444444444444444c4OS4c4OS4", "ECIFICATIO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444c4OS4c4OS4" + "'", str2.equals("4444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific", "hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific" + "'", str2.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("UTF-8", "O  c  C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "s", (int) (byte) -1, 87);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", "C os xAmC os xAmC os xAm..");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("oracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oitaroproc elcaro" + "'", str1.equals("oitaroproc elcaro"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!1Mac OS X0.0hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-...", "c OS c OS ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS c OS ", charArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", 458);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("MacOSXMacOSX", ".aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 105);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray10 = new char[] { 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence6, charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-b15", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                        OS c OS ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("pLATFORM Java Virtual Machine SpecificationpLATFORM ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "pLATFORM Java Virtual Machine SpecificationpLATFORM " + "'", str1.equals("pLATFORM Java Virtual Machine SpecificationpLATFORM "));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "c OS c OS ", "C#os#xAm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor", (int) (byte) 0, 271);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#..." + "'", str3.equals(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#..."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 9, (int) (byte) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sEnvironmentsun.awt.CGrcOSXa", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_", "5C os xAmC os xAmC os xAm..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_" + "'", str2.equals("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("cMacOcOX    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CmACoCox    " + "'", str1.equals("CmACoCox    "));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE ..." + "'", str2.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE ..."));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 87, (float) 1014);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("7_8", "                                           4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("cMacOcOX    ", "C#OS#XaM", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "44444444", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("24.80-...", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##############################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (-1), 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("...4444444444444444444444444444X4Oc44", "       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...4444444444444444444444444444X4Oc44" + "'", str3.equals("...4444444444444444444444444444X4Oc44"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos", 143, 105);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444" + "'", str1.equals("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "O  c  C", 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 1014, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..." + "'", str2.equals("VA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..."));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("US4104.4144.43", "java Platform API Specificatio");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { '#', ' ', '4', '4', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MacOSX                  1.7MacOSX                                                                                                              ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 44, 458);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 44 + "'", int3 == 44);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java Vi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Vi..." + "'", str1.equals("Java Vi..."));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(271, 144, 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 271 + "'", int3 == 271);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("h/Users/sophie", 741);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("24.80-...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("O  c  C          ", 22, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O  c  C          #####" + "'", str3.equals("O  c  C          #####"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS c OS ", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " 24.80-b11", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "acOSX", 47);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("10.14.", 111);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("userssophi", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", "Userssophie");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-b15", "100.0", 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "hi!");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray14);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "");
        int int18 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("0", strArray8, strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("                ", strArray3, strArray8);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "                " + "'", str20.equals("                "));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..." + "'", str21.equals("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..."));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java Vi...", "", "cMacOcOX    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Vi..." + "'", str3.equals("Java Vi..."));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie", 8, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", "1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15...#####################################100.0################################################AC#os#x1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation" + "'", str2.equals("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("\n", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        float[] floatArray3 = new float[] { 271.0f, 0L, 32 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 271.0f + "'", float4 == 271.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!", 170, "uS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "uSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuHI!uSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuS" + "'", str3.equals("uSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuHI!uSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuS"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("cOScOS", " 24.80-...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cOScOS" + "'", str2.equals("cOScOS"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, (double) (byte) 0, (double) 458L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444" + "'", str2.equals("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", "VA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NoitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str2.equals("NoitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Sun.lwa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...awl.nuS" + "'", str1.equals("...awl.nuS"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                                                :");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "                                                                                                          s", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Xa...                                     100.0                                                Platf", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 1, (byte) -1, (byte) 1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Userssophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Userssophi" + "'", str1.equals("Userssophi"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("java Platform API Specificatio", (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_64", (-1), 461);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " 24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "                                           4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("cOSXa...", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cOSXa..." + "'", str2.equals("cOSXa..."));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi!1Mac OS X0.0hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/su");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24#######", "cOX");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", strArray8);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "444444");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, " OS c OS aaaaaaaaaaaaaaaaaaaaaaa", 0, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "24.80-b11" + "'", str9.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO" + "'", str17.equals("AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("pLATFORM Java Virtual Machine SpecificationpLATFORM ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pLATFORM Java Virtual Machine SpecificationpLATFORM " + "'", str2.equals("pLATFORM Java Virtual Machine SpecificationpLATFORM "));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("C#OS#XaM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", "10.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "h/Users/sophie", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("44cO4X4444444444444444444444444444...", "                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Userssophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Userssophie" + "'", str1.equals("Userssophie"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_", "vironmentM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_" + "'", str2.equals("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("8_0.", 4, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(" #P#latform# #A...", "uS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("44cO4X4444444444444444444444444444...", "C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", "/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 8);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("...4444444444444444444444444444X4Oc44", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...4444444444444444444444444444X4Oc44" + "'", str3.equals("...4444444444444444444444444444X4Oc44"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '4');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split(".0_8", 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concatWith("7_8", (java.lang.Object[]) strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny("VM Server 64-Bit HotSpot(TM) Java", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + ".0_8" + "'", str9.equals(".0_8"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ".0_8" + "'", str10.equals(".0_8"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("MACOSX", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", "24.80-...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MACOSX" + "'", str3.equals("MACOSX"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 1014);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "uSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuHI!uSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuSuS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1Mac OS X0.0                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..AWL.NUS...AWL.NUS...AWL.NUS...AtnemnorivnEscihparGC.twa.nusL.NUS...AWL.NUS...AWL.NUS...AWL.NUs" + "'", str1.equals("..AWL.NUS...AWL.NUS...AWL.NUS...AtnemnorivnEscihparGC.twa.nusL.NUS...AWL.NUS...AWL.NUS...AWL.NUs"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", 44444444);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("   ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "-b15");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("51.0  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0  " + "'", str1.equals("51.0  "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 95, (float) 8, 5.41f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 95.0f + "'", float3 == 95.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("7_8", "/Users/sophi1.7.0_80/Users/sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", 27, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str3.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 16, 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str1.equals("C#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "5.41", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("MacjAVA pL...jAVA pL...jAVA pL...j...                                                                                          sOS                                                                                                          sX", "doop");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(96.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("...0_80", "c#os#xAm", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...0_80" + "'", str3.equals("...0_80"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("mACosx                          ...#####################################100.0################################################ac#OS#X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mACosx                          ...#####################################100.0################################################ac#OS#X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oracle corporation", '#');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8" + "'", str3.equals(".0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 458L, (float) 2, (float) 167L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 458.0f + "'", float3 == 458.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "cMacOcOX   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("             ..._...              ", "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/uSERS/SOPHIE", 95.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 95.0f + "'", float2 == 95.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "5.41");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Pla\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("uS", "userssophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#P#l08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmCtform#08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#A08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/", "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "C OS c OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X" + "'", str2.equals("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                                                                                                8_0.", "c OS Xa...", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.", " 24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6.0f, (double) 111, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                5.41                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                5.41                                                " + "'", str1.equals("                                                5.41                                                "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                            Userssophie                                            ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                            Userssophie                                            " + "'", str3.equals("                                            Userssophie                                            "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10.14.", "444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 741);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("24", "_810", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24" + "'", str3.equals("24"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                   c OS c OS                                                                    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sEnvironmentsun.awt.CGrcOSXaUserssophieUserssophieUserssophieUserssophieUserssophieUserssophieUse");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("soph:sophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"soph:sophi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("...0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "#####4444444444444444444444444444444444444444444c OS c OS############################Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("...awl.nuS", "sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                5.41                                                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cOX", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cOX" + "'", str3.equals("cOX"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4', (int) (byte) 1, (int) (byte) 1);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7", strArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7.0_80" + "'", str10.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Java(TM) SE Runtime Environment", "                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "                                                5.41                                                ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "MacOSX                  1.7MacOSX                   ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("44444444444444444O  c  C          444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "cOScOS", (int) (byte) 10);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 458, (double) 5.41f, (double) 442);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.409999847412109d + "'", double3 == 5.409999847412109d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("mACosx                          ...#####################################100.0################################################ac#OS#X", "1.7.0_80                                                                                            ", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(" MacOSX x86_64", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Userssophie", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                :", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(" 24.8", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                            Userssophie                                            ", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 455 + "'", int2 == 455);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "44444444444444444444444441.7.0_80-b15", "(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor", "/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", "                                                                                            08_0.7", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ", 2, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ACosx " + "'", str3.equals("ACosx "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                        OS c OS ", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        OS c OS " + "'", str3.equals("                        OS c OS "));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(7, 8, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("sun.awt.cgraphicsenvironment", "-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                   c OS c OS                                                                     ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   c OS c OS                                                                     " + "'", str2.equals("                   c OS c OS                                                                     "));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("Oracle Corporation", " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 458, 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 458L, 3.0f, (float) 170);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 458.0f + "'", float3 == 458.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                            MacOSX 1.7.0_80-b15", "s");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "MacOSX                                                                                              ");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "US");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracle corporatio", strArray3, strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Java Virtual Machine Specification" + "'", str11.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "oracle corporatio" + "'", str12.equals("oracle corporatio"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Java Virtual Machine Specification" + "'", str13.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("vironmentM", 442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4', (int) (byte) 1, (int) (byte) 1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '#', 458, 18);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a');
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7.0_80" + "'", str10.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "caOSacaOSa" + "'", str24.equals("caOSacaOSa"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0" + "'", str1.equals("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mixed mode                                                                                                          s                           ", "...#####################################100.0################################################ac#OS#X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("################################", "44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0", "                                                               Java Virtual Machine Specification", "51.0  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophie", 44, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                      sophie" + "'", str3.equals("                                      sophie"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".0_8", "", (int) '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE ...", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE ..." + "'", str9.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE ..."));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("CmACoCox    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cmacocox    " + "'", str1.equals("cmacocox    "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", "", (int) (byte) 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..." + "'", str4.equals("2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..."));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("US", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                            MacOSX 1.7.0_80-b15", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444", 1014, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444" + "'", str3.equals("#############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", "soph:sophi", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("       Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        float[] floatArray2 = new float[] { 6, (byte) -1 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 6.0f + "'", float4 == 6.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" #P#latform# #A...", "                            MacOSX 1.7.0_80-b15");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("oracle corporation", "sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporation" + "'", str2.equals("oracle corporation"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("CmACoCox    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CmACoCox    " + "'", str1.equals("CmACoCox    "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("... MROFTALp AVAjNOITACIFICEPs ip MROFTALp AVAj", "7MacO");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cOX", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444" + "'", str2.equals("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MacOSX                  1.7MacOSX                                                                                                              ", '#');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 16, 170);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("acOSX", "4444444444444444444444444444444444444444444c4OS4c4OS");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("   .0_80", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" MacOSX                             MacOSX ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " MacOSX                             MacOSX " + "'", str2.equals(" MacOSX                             MacOSX "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   " + "'", str2.equals("                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        double[] doubleArray5 = new double[] { (-1L), (byte) -1, 3, 8, 97.0d };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi", "...java pl...java pl...java pl...java pl...j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "...0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("XSOcaM7.1XSOcaM", 87, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("cMacOcOX    ", 170, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("noitacificepS#enihcaM#lautriV#avaJ##############################################################", 461, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444noitacificepS#enihcaM#lautriV#avaJ##############################################################444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444noitacificepS#enihcaM#lautriV#avaJ##############################################################444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "mACosx                          ...#####################################100.0################################################ac#OS#X   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 35L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("... MROFTALp AVAjNOITACIFICEPs ip MROFTALp AVAj", "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 181);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "... MROFTALp AVAjNOITACIFICEPs ip MROFTALp AVAj" + "'", str3.equals("... MROFTALp AVAjNOITACIFICEPs ip MROFTALp AVAj"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("racle corporation", "             ..._...              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...5.415.415.415.415.415.415.415", "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", 92);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...", (java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl..." + "'", charSequence2.equals("...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl..."));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b1" + "'", str1.equals(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b1"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                          ", 0, "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                          " + "'", str3.equals("                                                                                                                                                                          "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("MacOSX1.7MacOSX", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSX" + "'", str2.equals("MacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSX"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "8_0.", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                            MacOSX ", "                                                                                                :");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("cOSX                   acOSX                  1.7MaM", 461, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("s", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                      sophie", (double) 44.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.0d + "'", double2 == 44.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS " + "'", str1.equals("c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("MacOSX                  1.7MacOSX                   ", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("oitaroproc elcaro", (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..." + "'", str1.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..."));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 271, (long) (byte) 10, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "MacOSX1.7.0_80-b15", 3, (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "MacOSX1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O44444444444444444444444444444444444444444444O44O4" + "'", str3.equals("#O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O44444444444444444444444444444444444444444444O44O4"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("uS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"uS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                  Userssophi                   ", "...awl.nuS", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                  Userssophi                   " + "'", str3.equals("                  Userssophi                   "));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x", "caOSacaOSa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "...a...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwasun.lw");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "oracle corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj..." + "'", str1.equals("...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj..."));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("http://java.oracle.com/", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", "eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "", (int) (short) 100, (int) ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.CPrinterJob", strArray6, strArray9);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "US", 144, 6);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray23);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray23, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray23);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray23, 'a');
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("macosxmacosx", strArray6, strArray23);
        java.lang.String[] strArray33 = org.apache.commons.lang3.StringUtils.stripAll(strArray23);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str16.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "macosxmacosx" + "'", str32.equals("macosxmacosx"));
        org.junit.Assert.assertNotNull(strArray33);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(271.0f, (float) 7, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 271.0f + "'", float3 == 271.0f);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("O  c  C          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("-b15", "userssophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("vironmentM", "O  c  C", "51.", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "vironmentM" + "'", str4.equals("vironmentM"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 181, 12.0f, (float) 44);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 181.0f + "'", float3 == 181.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor" + "'", str2.equals("m# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1014");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1014 + "'", int1 == 1014);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("..._...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..._..." + "'", str1.equals("..._..."));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" 24.80-b11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(".0_80", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " #P#latform# #A..", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray8, strArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray12);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '4', (int) (byte) 1, (int) (byte) 1);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.startsWithAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.startsWithAny(".0_80", strArray12);
        int int21 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray12);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.concatWith("3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/su", (java.lang.Object[]) strArray12);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80" + "'", str13.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 143 + "'", int21 == 143);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "c3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/suOS3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/suc3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/suOS3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/su" + "'", str22.equals("c3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/suOS3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/suc3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/suOS3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/su"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, 1.7f, 5.41f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("jAVA pL...jAVA pL...jAVA pL...j...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA pL...jAVA pL...jAVA pL...j...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA.." + "'", str1.equals("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA.."));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                   C os C os                                                                    ", (java.lang.CharSequence) "c#os#x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MacOSX                                                                                              ", "Java(TM) SE Runtime Environment", (int) (byte) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray10);
        java.lang.Class<?> wildcardClass12 = strArray10.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concatWith(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", (java.lang.Object[]) strArray10);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS ", strArray4, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 98");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "cOX" + "'", str11.equals("cOX"));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MacOSX1.7MacOSX", "MacOSXMacOSX", 741);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", "51.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str3.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("...5.415.415.415.415.415.415.415", "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X", 455);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("jAVA pL...jAVA pL...jAVA pL...j...", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 111L, (float) 461, (float) 16);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 461.0f + "'", float3 == 461.0f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("       ", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       " + "'", str3.equals("       "));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                  Userssophi                   ", "C os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  Userssophi                   " + "'", str2.equals("                  Userssophi                   "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...", 111L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 111L + "'", long2 == 111L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 32, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(".", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 8);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "OS c OS", 99, (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".0_ihpossresU", ".0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(47);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophi1.7.0_80/Users/sophi", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                                                               Java Virtual Machine Specification");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-b15", "100.0", 0);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray15);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "hi!");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray18);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray18, "");
        int int22 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray21);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("0", strArray12, strArray21);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("...44444444444444444444444444..", strArray7, strArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "...44444444444444444444444444.." + "'", str24.equals("...44444444444444444444444444.."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("jAVA pLATFORM api sPECIFICATION", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("#############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444" + "'", str1.equals("#############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("24");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1.equals(24));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Platfc OS Xa...                                     100.0                                                Platf", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "                                                                   C os C os                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                   C os C os                                                                    " + "'", str1.equals("                                                                   C os C os                                                                    "));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "jAVA pL...jAVA pL...jAVA pL...j...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             ", "aaaaaaa");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("CmACMsx                                                                                              MsmACMsx                                                                                              CmACMsx                                                                                              MsmACMsx                                                                                              ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                      sophie", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("c#OS#Xa...#####################################100.0################################################", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                    08_0.7.1                                                   ", "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    08_0.7.1                                                   " + "'", str2.equals("                                                    08_0.7.1                                                   "));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio" + "'", str1.equals("platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 34, (float) 99L, (float) 9);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/USERS/SOPHIE", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("08_0.7.144444444", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.144444444" + "'", str2.equals("08_0.7.144444444"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                               Java Virtual Machine Specification", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }
}

