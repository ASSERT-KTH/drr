import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("mACosx                          ...#####################################100.0################################################ac#OS#X   ", "", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("5.41sun.l");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5.41sun.l" + "'", str1.equals("5.41sun.l"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                ", "1Mac OS X0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x" + "'", str2.equals("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl" + "'", str2.equals("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("       Oracle Corporation       ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("4444444444444444444444444444444444444444444c OS c OS", "racle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444c OS c OS" + "'", str2.equals("4444444444444444444444444444444444444444444c OS c OS"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444", "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                :", 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("\n", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        float[] floatArray6 = new float[] { 9, (short) 1, ' ', '#', 100L, 35 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("sun.lwawt.macosx.LWCToolkit", "              24.80-b11              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str1.equals("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("...4444444444444444444444444444X4Oc44", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...44444444444444444444444444..." + "'", str2.equals("...44444444444444444444444444..."));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                   C os C os                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                   c os c os                                                                    " + "'", str1.equals("                                                                   c os c os                                                                    "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("sPECIFICATION api pLATFORM jAVA", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", " 24.80-b11");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Userssophie");
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lw");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("s", "############################################################################################en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                ", " 24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("O  c  C          ", 12, 458);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     " + "'", str3.equals("     "));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("s", " MacOSX                             MacOSX ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s" + "'", str2.equals("s"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Userssophie");
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, 'a');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, ' ', (int) '#', 167);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("                                            Userssophie                                             ", "c OS Xa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44 + "'", int2 == 44);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("7_8", "########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", "1Mac OS X0.0                       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("HI!", "h/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24#######", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("44444444444444444OcC444444444444444444", 461, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "c OS c OS c OS c OS c OS c OS c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.14.", 5.41f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.41f + "'", float2 == 5.41f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "MACosx", (java.lang.CharSequence) "cOSXa...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "MACosx" + "'", charSequence2.equals("MACosx"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("c OS XaM", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS XaM" + "'", str2.equals("c OS XaM"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(9, 2, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ", 22, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vironmentM" + "'", str3.equals("vironmentM"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "5.41sun.l", "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray10 = new char[] { 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence6, charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("mixed mode", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " 24.80-B11", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny(".", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "/Java/Extensions:/usr/lib/java:.", "24.80-B11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("44444444444444444OcC444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444OcC444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", "       Oracle Corporation       ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("s", 144, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("cOSXa...", "/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", "HI!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("44444444", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################", "", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44444444" + "'", str4.equals("44444444"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "racle corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (-1L));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c#OS#Xa...#####################################100.0################################################", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Userssophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ihpossresU" + "'", str1.equals("ihpossresU"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Oracle Corporation", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80", 143);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("c#os#xAm", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c#os#xAm" + "'", str3.equals("c#os#xAm"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", (int) '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str3.equals("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        long[] longArray6 = new long[] { 18, (-1), (short) -1, (byte) 0, 0L, 'a' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray6.getClass();
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w" + "'", str1.equals("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("5.41sun.l", "c OS XaM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC" + "'", str1.equals("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Userssophie");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", "##############################################################Java#Virtual#Machine#Specificatio", 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" 24.80-...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl" + "'", str1.equals("PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie", "", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("c OS c OS ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS c OS " + "'", str3.equals("c OS c OS "));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("###############################################################Java#Virtual#Machine#Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Userssophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "userssophi" + "'", str1.equals("userssophi"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("51.", "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51." + "'", str2.equals("51."));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("08_0.7.144444444", "   ", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444" + "'", str3.equals("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4', (int) (byte) 1, (int) (byte) 1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray18);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7.0_80" + "'", str10.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "       ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi", "cOSXa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java HotSpot(TM) 64-Bit Server VM", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VM Server 64-Bit HotSpot(TM) Java" + "'", str2.equals("VM Server 64-Bit HotSpot(TM) Java"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Userssophie", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC" + "'", str2.equals("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("5.41", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5.41" + "'", str2.equals("5.41"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             " + "'", str1.equals("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             "));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "MacOSX                                                                                              ", "jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Userssophi", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  Userssophi                   " + "'", str2.equals("                  Userssophi                   "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ihpossresU", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("c#OS#c#OS#", "100.0", (int) (byte) 100);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "c#OS#c#OS#" + "'", str4.equals("c#OS#c#OS#"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415" + "'", str1.equals("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("##############################################################Java#Virtual#Machine#Specificatio", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.", "C os xAmC os xAmC os xAm..");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1014" + "'", str4.equals("1014"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", "COX");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Userssophie");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "noitacificepS#enihcaM#lautriV#avaJ##############################################################", (int) 'a', 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 18, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("##############################################################Java#Virtual#Machine#Specificatio", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################Java#Virtual#Machine#Specificatio" + "'", str2.equals("##############################################################Java#Virtual#Machine#Specificatio"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("4444444444444444444444444444444444444444444c4OS4c4OS4", "MacOSX                  1.7MacOSX                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 27);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 27.0d + "'", double2 == 27.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(96, 18, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", (float) 12);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("s", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                                                                8_0.", 97, 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny(" #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("5.41sun.l", "51.0", 0);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR", 9, "MACOSX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR" + "'", str3.equals("pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("...44444444444444444444444444...", 1, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "###############################################################Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "C#os#xAm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sophie", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERHI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Oracle Corporation", "PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("h/users/sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 170, (long) 0, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 170L + "'", long3 == 170L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray6, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '4', (int) (byte) 1, (int) (byte) 1);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.startsWithAny(".0_80", strArray10);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/java/extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 32, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################" + "'", str3.equals("################################"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str1.equals("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", "mACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("mixed mode");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(".", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", "44444444444444444OcC444444444444444444", "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("noitacificepS#enihcaM#lautriV#avaJ##############################################################", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str2.equals("noitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-B11", "mixed mode");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-B11" + "'", str3.equals("24.80-B11"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 3, (float) 111L, (float) 34);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 111.0f + "'", float3 == 111.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                :", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                :" + "'", str2.equals("                                                                                                :"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "1.7.0_80                                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Platform API Specification", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                ", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                " + "'", str2.equals("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       " + "'", str1.equals("       "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("c OS Xa...", 144, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("mACosx                                                                                              ", " MacOSX                             MacOSX ", "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mACosx                                                                                              " + "'", str3.equals("mACosx                                                                                              "));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("pLATFORM Java Virtual Machine SpecificationpLATFORM ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pLATFORM Java Virtual Machine SpecificationpLATFORM " + "'", str2.equals("pLATFORM Java Virtual Machine SpecificationpLATFORM "));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                   c os c os                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ification", "mACosx                          ...#####################################100.0################################################c#OS#X   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ..." + "'", str2.equals("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ..."));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("5.41sun.l", "jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX" + "'", str1.equals("Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".0_8", "", (int) '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 52, 47);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS c OS ", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL.." + "'", str1.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL.."));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 34, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("!ih", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("                                                                   C os C os                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("soph:sophi", " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ", "MACosx", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "soph:sophi" + "'", str4.equals("soph:sophi"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "##############################################################################################en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" MacOSX x86_64", "/uSERS/SOPHIE");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 2, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                5.41                                                ", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                5.41                                                " + "'", str3.equals("                                                5.41                                                "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7.0_80                                                                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                            08_0.7.1" + "'", str1.equals("                                                                                            08_0.7.1"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 608, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 608 + "'", int3 == 608);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                   C os C os                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "8_0.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX" + "'", str2.equals("(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("MacOSX                                                                                              ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1Mac OS X0.0", (java.lang.CharSequence) "                                                                                                              s");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "!ih", 3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("mACosx", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", ' ');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..." + "'", str3.equals("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..."));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..." + "'", str5.equals("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..."));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" 24.80-b11", "", 99);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MacOSX                                                                                              ", "Java(TM) SE Runtime Environment", (int) (byte) -1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray5);
        java.lang.Class<?> wildcardClass7 = strArray5.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concatWith(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", (java.lang.Object[]) strArray5);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Java Virtual Machine Specification", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "cOX" + "'", str6.equals("cOX"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 34 + "'", int9 == 34);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", (int) (short) 100, "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/" + "'", str3.equals("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "08_0.7.144444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("c OS c OS ", ".0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS c OS " + "'", str2.equals("c OS c OS "));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "24.80-b11");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444" + "'", str1.equals("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("userssophie", "McOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "userssophie" + "'", str2.equals("userssophie"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("ECIFICATIO", "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ECIFICATIO" + "'", str2.equals("ECIFICATIO"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Environment", (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("userssophi", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("8_0.", "1.7.0_80                                                                                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("   ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("1.7.0_80                                                                                            ", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("#", "                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "1.7.0_80-b15", 96, 144);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 'a');
        java.lang.String[] strArray5 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw", strArray5, strArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("MACosx", strArray3, strArray8);
        java.lang.Class<?> wildcardClass17 = strArray8.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw" + "'", str15.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "MACosx" + "'", str16.equals("MACosx"));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 458L, (float) 7, (float) 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 458.0f + "'", float3 == 458.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"cOScO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "s", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS ", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "x86_64");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("c#os#xAm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C#OS#XaM" + "'", str1.equals("C#OS#XaM"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 10, 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten" + "'", str3.equals("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(".0_8                                                                                                ", "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" 24.80-...", "Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "userssophie", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("7_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7_8" + "'", str1.equals("7_8"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 144.0f, (double) 111.0f, (double) 461);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 111.0d + "'", double3 == 111.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", "MacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str2.equals("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("       ", "C os xAmC os xAmC os xAm..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/uSERS/SOPHIE", (java.lang.CharSequence) "pLATFORM Java Virtual Machine SpecificationpLATFORM ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/uSERS/SOPHIE" + "'", charSequence2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1014", "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Userssophie", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                                                                   C os C os                                                                    ", "51.0", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "51.0  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "c OS XaM");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("userssophie", 99, "C os xAm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm" + "'", str3.equals("userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 22, 0L, (long) 16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 22L + "'", long3 == 22L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("       ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              " + "'", str2.equals("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("##############################################################################################en", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################################################en" + "'", str2.equals("##############################################################################################en"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        int[] intArray6 = new int[] { 9, 170, 16, 1, (byte) 10, 1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 170 + "'", int7 == 170);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 170 + "'", int8 == 170);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 170 + "'", int10 == 170);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("sun.lwawt.macosx.LWCToolkit", "ihpossresU", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/", "s");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", "cOScOS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("ihpossresU");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2", "pLATFORM Java Virtual Machine SpecificationpLATFORM ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2" + "'", str2.equals(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("                        OS c OS ", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                        OS c OS " + "'", str5.equals("                        OS c OS "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("mACosx                          ...#####################################100.0################################################c#OS#X   ", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl", "       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("08_0...", "                    Userssophie                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0..." + "'", str2.equals("08_0..."));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1014", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1014" + "'", str2.equals("1014"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("US", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "c#OS#Xa...#####################################100.0################################################", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                :", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 143, (double) 22L, (double) 18L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2, (double) ' ', 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 44, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("44444444444444444O  c  C          444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", "", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("jAVA pL...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pL..." + "'", str1.equals("jAVA pL..."));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Oracle Cor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########" + "'", str1.equals("########"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " 24.80-...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob", "/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("vironmentM", "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...", 111);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("MacOSX                  1.7MacOSX                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MacOSX                  1.7MacOSX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 97, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("Oracle Corporation", "XSOcaM7.1XSOcaM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("51.0  ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" 24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " 24.80-B11" + "'", str1.equals(" 24.80-B11"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(".0_8", "ihpossresU", 27, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".0_ihpossresU" + "'", str4.equals(".0_ihpossresU"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("              24.80-b11              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################" + "'", str1.equals("OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "MACOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", "mACosx                          ...#####################################100.0################################################c#OS#X   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mACosx                          ...#####################################100.0################################################c#OS#X   " + "'", str2.equals("mACosx                          ...#####################################100.0################################################c#OS#X   "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mixed mode", 0, "PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        int[] intArray5 = new int[] { 8, 100, (byte) 0, (short) 1, 144 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 144 + "'", int8 == 144);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 144 + "'", int9 == 144);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 144 + "'", int11 == 144);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 144 + "'", int13 == 144);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################", "08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "51.", 461);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "acOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "44444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15", "coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        long[] longArray2 = new long[] { 32L, 'a' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", strArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("Oracle Cor", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b11" + "'", str4.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sophie", "                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", (int) (byte) -1, 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC" + "'", str4.equals("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/uSERS/SOPHIE", "Java Vi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                  Userssophi                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR", 10, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "44444444444444444OcC444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.l", "                                                                   c OS c OS                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.l" + "'", str2.equals("sun.l"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("c os xAm", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("COX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "COX" + "'", str1.equals("COX"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(".0_80", "                  Userssophi                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "c#OS#Xa...#####################################100.0################################################", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                :", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("51.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5L, 5.41f, (float) 22);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 22.0f + "'", float3 == 22.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444444444444444444444444444444444444c OS c OS", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("c#OS#Xa...#####################################100.0################################################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c#OS#Xa...#####################################100.0################################################" + "'", str2.equals("c#OS#Xa...#####################################100.0################################################"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION", 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO" + "'", str3.equals("AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "Userssophi", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "##############################################################################################en", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################" + "'", str4.equals("OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10.14.", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", "C#OS#XaM", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(".0_8", "ification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("XSOcaM7.1XSOcaM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XSOcaM7.1XSOcaM" + "'", str1.equals("XSOcaM7.1XSOcaM"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Java/Extensions:/usr/lib/java:.", 0, "                                                               Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.l", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.l" + "'", str2.equals("sun.l"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Cosx", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Cosx" + "'", str2.equals("Cosx"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ification", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '4', 37, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 170 + "'", int3 == 170);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "                                                5.41                                                ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1014", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1014 + "'", int2 == 1014);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "c OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, 3, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "24.80-...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("US10.14.3", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US10.14.3" + "'", str2.equals("US10.14.3"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(" #P#latform# #A...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " #P#latform# #A.." + "'", str1.equals(" #P#latform# #A.."));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(" #P#latform# #A...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " #P#latform# #A..." + "'", str1.equals(" #P#latform# #A..."));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("soph:sophi", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("h/Users/sophie", " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/Users/sophie" + "'", str2.equals("h/Users/sophie"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("c#OS#c#OS#", "ihpossresU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c#OS#c#OS#" + "'", str2.equals("c#OS#c#OS#"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", "08_0.7.144444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lw", (java.lang.CharSequence) "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "Cosx", 47);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444c OS c OS ", "                  Userssophi                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("5.41");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.41d + "'", double1.equals(5.41d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(143L, 32L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mACosx                          ...#####################################100.0################################################c#OS#X   ", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mACosx                          ...#####################################100.0################################################c#OS#X   " + "'", str3.equals("mACosx                          ...#####################################100.0################################################c#OS#X   "));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hi!", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                              s", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                          s" + "'", str2.equals("                                                                                                          s"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "MacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("cOX", "MacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATION" + "'", str1.equals("JAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATION"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(".");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("...5.415.415.415.415.415.415.415", "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...5.415.415.415.415.415.415.415" + "'", str2.equals("...5.415.415.415.415.415.415.415"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("c os xAm", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 461);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S" + "'", str3.equals("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 99, "       Oracle Corporation       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation" + "'", str3.equals("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(" 24.80-...", "44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14." + "'", str1.equals("10.14."));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                :");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("soph:sophi", "51.0  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("c OS XaM", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS XaM" + "'", str2.equals("c OS XaM"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", "mACosx                          ...#####################################100.0################################################ac#OS#X   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO" + "'", str2.equals("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("##############################################################################################en", " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(" OS c OS ", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                        OS c OS ", "", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "h/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 47);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi" + "'", str2.equals("va platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("mACosx                                                                                              ", 27, 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("08_0.7.144444444", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444" + "'", str2.equals("444444"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80", "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 181 + "'", int2 == 181);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(".");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "." + "'", str1.equals("."));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java Vi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten" + "'", str2.equals("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) " 24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...", "hi!1Mac OS X0.0hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "1.7.0_80                                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos" + "'", str1.equals("eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ", "mACosx                          ...#####################################100.0################################################c#OS#X   ", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "c OS c OS c OS c OS c OS c OS c OS c OS ", 170);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "h/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", "HI!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51.0  ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0  " + "'", str2.equals("51.0  "));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 22.0f, (double) 1, (double) 111);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 111.0d + "'", double3 == 111.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/java/extensions:/usr/lib/java:.", " 24.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java HotSpot(TM) 64-Bit Server VM", "AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("O  c  C          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O  c  C" + "'", str1.equals("O  c  C"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("McOSX", "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "McOSX" + "'", str2.equals("McOSX"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(52);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) -1, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.Class<?> wildcardClass5 = byteArray3.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", "c OS Xa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444", 99);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                            MacOSX 1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("MACosx", "MACosx", "JAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA P" + "'", str3.equals("JAVA P"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        char[] charArray8 = new char[] { '#', 'a', 'a', ' ', '4', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7_8", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(".", 105, ".0_ihpossresU");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU." + "'", str3.equals(".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU."));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie", 170, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie" + "'", str3.equals("sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(" 24.8", "100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("MacOSX                  1.7MacOSX                   ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("MacOSX                  1.7MacOSX                   ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ", "cOX", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cMacOcOX    " + "'", str3.equals("cMacOcOX    "));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl", "vironmentM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w" + "'", str2.equals("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("h/Users/sophie", "mACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/Users/sophie" + "'", str2.equals("h/Users/sophie"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("1.7", "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 271, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##############################################################################################################################################################################" + "'", str3.equals("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##############################################################################################################################################################################"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten", (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!ih", "x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("8_0.", 32, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("MacOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        double[] doubleArray1 = new double[] { 10 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("h/Users/sophie", "userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ficepS#enih", "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ficepS#enih" + "'", str2.equals("ficepS#enih"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("44444444444444444O  c  C          444444444444444444", "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444O  c  C          444444444444444444" + "'", str3.equals("44444444444444444O  c  C          444444444444444444"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("########", "s");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sun.lwa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwa..." + "'", str1.equals("Sun.lwa..."));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray9);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "MacOSX                                                                                              ");
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444", strArray9, strArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7.0_80" + "'", str10.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!", "C#os#xAm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("                                                               Java Virtual Machine Specification", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(".0_ihpossresU", "8_0.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "MacOSX                                                                                              ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "US");
        java.lang.Class<?> wildcardClass9 = strArray4.getClass();
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("...5.415.415.415.415.415.415.415", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...5. 15. 15. 15. 15. 15. 15. 15" + "'", str3.equals("...5. 15. 15. 15. 15. 15. 15. 15"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...", 105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7.0_80", 111);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                   1.7.0_80                                                    " + "'", str2.equals("                                                   1.7.0_80                                                    "));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.7f, (double) 144.0f, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 144.0d + "'", double3 == 144.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mACosx", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cOX");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", 18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                                              s", "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str2.equals("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "...#####################################100.0################################################ac#OS#X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(".");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("                                                               Java Virtual Machine Specification", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.CPrinterJob", 12, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US10.14.3");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str3.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "US4104.4144.43" + "'", str7.equals("US4104.4144.43"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("sun.lw", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ", "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concatWith("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", (java.lang.Object[]) strArray3);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", 2, 167);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "############################################################################################en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444O  c  C          444444444444444444", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444O  c  C          444444444444444444" + "'", str3.equals("44444444444444444O  c  C          444444444444444444"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("7_8", "24.80-...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444444444444444444444444444c OS c OS ", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           4444444444444444444444444444444444444444444c OS c OS " + "'", str2.equals("                                           4444444444444444444444444444444444444444444c OS c OS "));
    }
}

