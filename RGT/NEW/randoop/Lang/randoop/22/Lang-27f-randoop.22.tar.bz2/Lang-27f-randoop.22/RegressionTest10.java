import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API Specification", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    Java Platform API Specification" + "'", str2.equals("    Java Platform API Specification"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test002");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test003");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("C os xAmC os xAmC os xAm..");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test004");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0cepS#enih51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.051.051\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test005");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("C#OS#XaM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"C#OS#XaM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(":#P#l:tform#:#A:::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":#P#l:tform#:#A:::" + "'", str1.equals(":#P#l:tform#:#A:::"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO" + "'", str3.equals("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test008");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("     ", "sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Java/Extensions:/usr/lib/java:.", "44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test012");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test013");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "!ih", 3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "McOSX", 7, (int) (short) 0);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("noitacificepS#enihcaM#lautriV#avaJ###############################################################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", 3);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray4, strArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444" + "'", str15.equals("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ###############################################################" + "'", str16.equals("noitacificepS#enihcaM#lautriV#avaJ###############################################################"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "COX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 96, "C os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC o" + "'", str3.equals("/Users/sophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC o"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test016");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("m# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor", "cOSXa...cOSXa...cOSXa...cOSXa...cOSXa...cOSXa....0_80cOSXa...cOSXa...cOSXa...cOSXa...cOSXa...cOSXa..");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test017");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("HI!");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test018");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444noitacificepS#enihcaM#lautriV#avaJ##############################################################444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test019");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                    Userssophie                     ", 16, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", "1.7.0_80                                                                                            ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test021");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("###############################################################Java#Virtual#Machine#Specification", "c#OS#Xa...#####################################100.0################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", "coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test023");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "jAVA pLATFORM api sPECIFICATION");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("#####4444444444444444444444444444444444444444444c OS c OS############################Java#Virtual#Machine#Specification", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#####4444444444444444444444444444444444444444444c OS c OS############################Java#Virtual#Machine#Specification" + "'", str5.equals("#####4444444444444444444444444444444444444444444c OS c OS############################Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ###############################################################" + "'", str1.equals("noitacificepS#enihcaM#lautriV#avaJ###############################################################"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test025");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#P#l08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmCtform#08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#A08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#P#l08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmCtform#08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#A08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test026");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("iedde", "MacOSX                  1.7MacOSX", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test027");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1Mac OS X0.0", (int) (byte) -1, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-" + "'", str2.equals("Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test029");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("   .0_80");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("44444444444444444OcC44444444444444444", "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444OcC44444444444444444" + "'", str2.equals("44444444444444444OcC44444444444444444"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test032");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test033");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                      ", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "M# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFOR");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Userssophie", "ORATIONoRACLE cORPORATION", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Userssophie" + "'", str3.equals("Userssophie"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test037");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 95, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 95 + "'", int3 == 95);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test038");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" MacOSX ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("##############################################################################################en", ".0_8                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################################################en" + "'", str2.equals("##############################################################################################en"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test040");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("w1 N/:s  4s  1xE/242 /y222b4L/:1x /b4-/ 2j/ 4 H/s1  1  C/kdj.08_0.7.1kdj/s  4h22M-2u124V242 /242 /y222b4L/:s  4s  1xE/242 /y222b4L/ 4h1 s/s2 sU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "w1 N/:s  4s  1xE/242 /y222b4L/:1x /b4-/ 2j/ 4 H/s1  1  C/kdj.08_0.7.1kdj/s  4h22M-2u124V242 /242 /y222b4L/:s  4s  1xE/242 /y222b4L/ 4h1 s/s2 sU/" + "'", str1.equals("w1 N/:s  4s  1xE/242 /y222b4L/:1x /b4-/ 2j/ 4 H/s1  1  C/kdj.08_0.7.1kdj/s  4h22M-2u124V242 /242 /y222b4L/:s  4s  1xE/242 /y222b4L/ 4h1 s/s2 sU/"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test042");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 271.0f, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 271.0d + "'", double3 == 271.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("r                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r", "/Users/sophi1.7.0_80/Users/sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Sun.lwa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S", "userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test047");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/USERS/SOPHIE", "...aaaaaaaaaaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test048");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "en", (java.lang.CharSequence) "       oracle corporation       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test049");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ", "A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                ", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 143, (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("       Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion" + "'", str1.equals("Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test053");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444444444444444444444", (float) 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.4444444E30f + "'", float2 == 4.4444444E30f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                               100.0                                                ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               100.0                                                " + "'", str2.equals("                                               100.0                                                "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test055");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("c OS Xa...                                     100.0", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("7_8", "CmACMsx                                                                                              MsmACMsx                                                                                              CmACMsx                                                                                              MsmACMsx                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x", "##############################################################Java#Virtual#Machine#SpecificatioN");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl" + "'", str1.equals("PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test063");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("#O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O44444444444444444444444444444444444444444444O44O4", "X SO caM", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test064");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 34, (long) 442);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "24.80-...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test066");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "c OS Xa...                                     100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test068");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(608.0d, (double) 96.0f, (double) 99);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 608.0d + "'", double3 == 608.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 15, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############" + "'", str3.equals("###############"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test070");
        double[] doubleArray5 = new double[] { (-1L), (byte) -1, 3, 8, 97.0d };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test071");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test072");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(99);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test073");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 0, 458);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("h/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "H/uSERS/SOPHIE" + "'", str1.equals("H/uSERS/SOPHIE"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test076");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test077");
        char[] charArray4 = new char[] { ' ' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                               100.0                                                ", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0cepS#enih51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 47 + "'", int6 == 47);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", " os C os ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444", "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_", 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444c OS c OS 44444444444444444444444444444444ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_4444444c OS c OS 4444444444444444444444444444444444" + "'", str3.equals("444444444c OS c OS 44444444444444444444444444444444ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_4444444c OS c OS 4444444444444444444444444444444444"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test080");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("Java HotSpot(TM) 64-Bit Server VM", strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "c os c os");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str5.equals("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..", "c OS Xa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL.." + "'", str2.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL.."));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("cOSX                   acOSX                  1.7MaM", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      acOSX                  1.7MaM" + "'", str2.equals("      acOSX                  1.7MaM"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("rporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("c OS XaM", "#############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444" + "'", str2.equals("#############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                            Userssophie                                             ", "", 144);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                            Userssophie                                             " + "'", str5.equals("                                            Userssophie                                             "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1Mac OS X0.0                       ", 110);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     1Mac OS X0.0                                                             " + "'", str2.equals("                                     1Mac OS X0.0                                                             "));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test088");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS Xa...");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", (java.lang.Object[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray7);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "Userssophie");
        int int16 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray15);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r", strArray3, strArray15);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "cNoitacificepS#enihcaM#lautriV#avaJ##############################################################OSNoitacificepS#enihcaM#lautriV#avaJ##############################################################Xa..." + "'", str4.equals("cNoitacificepS#enihcaM#lautriV#avaJ##############################################################OSNoitacificepS#enihcaM#lautriV#avaJ##############################################################Xa..."));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r" + "'", str19.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test089");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5L, (float) 47L, (float) 461);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test090");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test091");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(":#P#l:tform#:#A:::");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("NOITAROPROc ELCARoNOITAROPROc ELCAR", "51.0  ", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test094");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("#####4444444444444444444444444444444444444444444c OS c OS############################Java#Virtual#Machine#Specification", "sPECIFICATION api pLATFORM jAVA", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                        OS c OS ", "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str1.equals("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwa...sun.lwa...sun.lwa...sun.lSUN.AWT.cgRAPHICSeNVIRONMENTa...sun.lwa...sun.lwa...sun.lwa.." + "'", str1.equals("Sun.lwa...sun.lwa...sun.lwa...sun.lSUN.AWT.cgRAPHICSeNVIRONMENTa...sun.lwa...sun.lwa...sun.lwa.."));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("  ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test100");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ECIFICATIO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ECIFICATIO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("c OS Xa...                                     100.0                                                ", "                                              s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS Xa...                                     100.0" + "'", str2.equals("c OS Xa...                                     100.0"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "       Oracle Corporation       ", "C#os#xAm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test103");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("userssophie", "                            MacOSX ", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test104");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test105");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test106");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Userssophie", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                :", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                      sophie", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "cOSccOSc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test108");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("cmacocox    ", (double) 167);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 167.0d + "'", double2 == 167.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Userssophie", 35, "MacOSX                  1.7MacOSX                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacOSX                  Userssophie" + "'", str3.equals("MacOSX                  Userssophie"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test110");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("###############", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test111");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie" + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test113");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0  ", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS Xa...                                     100.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("...44444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...44444444444444444444444444..." + "'", str1.equals("...44444444444444444444444444..."));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test116");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Sun.lwa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test117");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, 458, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 458 + "'", int3 == 458);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", "########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test119");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444", ":#P#l:tform#:#A:::");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test120");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test121");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "O  c  C", (java.lang.CharSequence) "4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################", 110, "###############");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test124");
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS c OS ", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US10.14.3", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/java/extensions:/usr/lib/java:.", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S", "                ", 87);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S" + "'", str4.equals("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor", "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test128");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", " 24.80-b11");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("                        OS c OS ", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test129");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("US10.14.3", 24, "phie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "phiephiephiephiUS10.14.3" + "'", str3.equals("phiephiephiephiUS10.14.3"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Cosx", (int) (byte) 0, "                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Cosx" + "'", str3.equals("Cosx"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test131");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("h/Users/sophie", "44444444", 181);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test132");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(458.0d, (double) 458.0f, 271.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 271.0d + "'", double3 == 271.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test133");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test134");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test135");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", "/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test136");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("pLATFORM Java Virtual Machine SpecificationpLATFORM ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun.lw");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test138");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", "MacOSX1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                   C os C os                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C os C os" + "'", str1.equals("C os C os"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("cNoitacificepS#enihcaM#lautriV#avaJ##############################################################OSNoitacificepS#enihcaM#lautriV#avaJ##############################################################Xa...", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str1.equals("C OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 95, 1014);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str3.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test143");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "cOScOS", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("...java pl...java pl...java pl...java pl...j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...java pl...java pl...java pl...java pl...j" + "'", str1.equals("...java pl...java pl...java pl...java pl...j"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test145");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                            08_0.7.1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test146");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("h/users/sophie", "c OS c OS c OS c OS c OS c OS c OS c OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("44444444444444444444444444444444444444444444444444444444...aaaaaaaaaaaaaaaaaaaaaaaaa...444444444444444444444444444444444444444444444444444444444", 27, 461);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444...aaaaaaaaaaaaaaaaaaaaaaaaa...444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444...aaaaaaaaaaaaaaaaaaaaaaaaa...444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test149");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", "c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":0N 1w" + "'", str2.equals(":0N 1w"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test151");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Mac OS X", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Java Vi...");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("51.", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test152");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test153");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Userssophie", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                :", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test154");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi", "1.7.0_80");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test155");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "Mac OS X");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("c OS c OS ", strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon" + "'", str3.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test157");
        double[] doubleArray1 = new double[] { 10 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                   c OS c OS                                                                     ", "4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test159");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..", "c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS 4c OS c OS ", "XSOcaM7.1XSOcaM", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL.." + "'", str4.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL.."));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test160");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "c#os#x");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test161");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test162");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 135 + "'", int1 == 135);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test163");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5.415.4..." + "'", str2.equals("5.415.4..."));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", "C#OS#XaM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test166");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", 135);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("H/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "H/uSERS/SOPHIE" + "'", str1.equals("H/uSERS/SOPHIE"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test168");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("cNoitacificepS#enihcaM#lautriV#avaJ##############################################################OSNoitacificepS#enihcaM#lautriV#avaJ##############################################################Xa...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test169");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OS X                                                                                        ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                             " + "'", str2.equals("                                                             "));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test172");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       h/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0", "O  c  C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0" + "'", str2.equals("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test175");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-b15", "100.0", 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "hi!");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray12);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "");
        int int16 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("0", strArray6, strArray15);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "", 170);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray6, strArray21);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray21, "ficepS#enih");
        boolean boolean25 = org.apache.commons.lang3.StringUtils.startsWithAny("!ih", strArray24);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray24);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTF-8" + "'", str22.equals("UTF-8"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str26.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", "                                                                   C os C os                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str2.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("cNoitacificepS#enihcaM#lautriV#avaJ##############################################################OSNoitacificepS#enihcaM#lautriV#avaJ##############################################################Xa...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cNoitacificepS#enihcaM#lautriV#avaJ##############################################################OSNoitacificepS#enihcaM#lautriV#avaJ##############################################################Xa..." + "'", str2.equals("cNoitacificepS#enihcaM#lautriV#avaJ##############################################################OSNoitacificepS#enihcaM#lautriV#avaJ##############################################################Xa..."));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test178");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415", "iedde", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test179");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "", (int) (short) 100, (int) ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.CPrinterJob", strArray8, strArray11);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "US", 144, 6);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray25);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray25);
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, 'a');
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.replaceEach("macosxmacosx", strArray8, strArray25);
        java.lang.String[] strArray36 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "h/Users/sophie");
        boolean boolean37 = org.apache.commons.lang3.StringUtils.startsWithAny("/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray36);
        int int38 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("c OS X#...                                     100.0", strArray36);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str18.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "macosxmacosx" + "'", str34.equals("macosxmacosx"));
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#    ", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    " + "'", str2.equals("#    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    #    "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR" + "'", str1.equals("C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test182");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test184");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("cOScOS", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test185");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(455, 741, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test186");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("macosxmacosx", "scs");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test187");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("MACOSX");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                     1Mac OS X0.0                                                             ", "44444444444444444444444444444444444444444444444444444444...aaaaaaaaaaaaaaaaaaaaaaaaa...444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     1Mac OS X0.0                                                             " + "'", str2.equals("                                     1Mac OS X0.0                                                             "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test189");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (java.lang.CharSequence) " #P#latform# #A..");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", charSequence2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test191");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("...4444444444444444444444444444X4Oc44", " OS c OS aaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test192");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test193");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "!ih", 3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "McOSX", 7, (int) (short) 0);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("noitacificepS#enihcaM#lautriV#avaJ###############################################################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", 3);
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray7, strArray16);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny("44444444444444444OcC444444444444444444", strArray16);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                ", strArray1, strArray16);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444" + "'", str18.equals("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "                " + "'", str20.equals("                "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test194");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "cOScOS", (int) (byte) 10);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwa...", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str12.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sun.lwa..." + "'", str13.equals("sun.lwa..."));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", "c OS c OS ", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444O  cc OS c OS  XaM24#######c OS XaM" + "'", str3.equals("44444444444444444O  cc OS c OS  XaM24#######c OS XaM"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test196");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test197");
        long[] longArray4 = new long[] { (-1L), (byte) 1, (short) 10, 458 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 458L + "'", long5 == 458L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 458L + "'", long6 == 458L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 458L + "'", long7 == 458L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 458L + "'", long9 == 458L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk..." + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk..."));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("C os C os", "44cO4X4444444444444444444444444444...", "MACOSX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C os C os" + "'", str3.equals("C os C os"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test200");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "MacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80-b15", "NOITAROPROc ELCARoNOITAROPROc ELCAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test202");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM" + "'", str3.equals("c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "                  Userssophi                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION" + "'", str1.equals(" #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test207");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ihpossresU");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ihpossresU\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test208");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str1.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test210");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("-b15                                                                                                ", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test211");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Userssophie", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("################################", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                   C os C os                                                                    ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("51.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51." + "'", str1.equals("51."));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("cMacOcOX    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cMacOcOX" + "'", str1.equals("cMacOcOX"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test214");
        float[] floatArray1 = new float[] { 167 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 167.0f + "'", float2 == 167.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 167.0f + "'", float3 == 167.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ", 442);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                    "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "cMacOcOX    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test217");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("XSOcaM7.1XSOcaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test218");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("caOSacaOSa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS X", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Java Vi...");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.l");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Msun.lc OS X" + "'", str8.equals("Msun.lc OS X"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("cOSX                   acOSX                  1.7MaM", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test221");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("doop");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"doop\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test222");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test223");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", 37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "_8", "1014");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", " OS c OS aaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos", "O  c  C          #####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos" + "'", str2.equals("eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test228");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("c#os#xc#os#xc#os#xc#44444444444444444O  c  C          444444444444444444c#os#xc#os#xc#os#xc#", "", 53);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test229");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-FTU" + "'", str1.equals("8-FTU"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test231");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" 24.80-B11", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1Mac OS X0.0                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################", "s", 37);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test234");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 143L, (float) 32L, (float) 15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 143.0f + "'", float3 == 143.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test235");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("7_8", "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.", " MacOSX x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test237");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-B11", "c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM2a#######c OS XaM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test238");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("   .0_80", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", "", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lw", "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lw" + "'", str2.equals("sun.lw"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test241");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("C OS c OS ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test242");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                                                              s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s" + "'", str1.equals("s"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!", "US4104.4144.43Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!" + "'", str2.equals("!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test245");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("JavaVirtualMachineSpecification", "c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test246");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                               Java Virtual Machine Specification");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("cNoitacificepS#enihcaM#lautriV#avaJ##############################################################OSNoitacificepS#enihcaM#lautriV#avaJ##############################################################Xa...", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test249");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("macosxmacosx");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: macosxmacosx is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", "jAVA pL...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test251");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test252");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", 18, 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "brary/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/" + "'", str3.equals("brary/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test254");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test255");
        long[] longArray6 = new long[] { 18, (-1), (short) -1, (byte) 0, 0L, 'a' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test256");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test257");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Cosx", "44444444444444444OcC444444444444444444", "51.0", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Cosx" + "'", str4.equals("Cosx"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("r                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r", "OS c OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r" + "'", str2.equals("r                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str1.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US10.14.3");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "CmACoCox    ", (int) (short) -1, (-1));
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str3.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test262");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                          s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                          s" + "'", str1.equals("                                                                                                          s"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test264");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                ", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                " + "'", str2.equals("                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test266");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80                                                                                           ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 5, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                               " + "'", str4.equals("1.7.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                               "));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("C os C os", "ScS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "C os C os" + "'", str2.equals("C os C os"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test268");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Sun.lwa...", "                  Userssophi                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test269");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MacOSX                  1.7MacOSX", (java.lang.CharSequence) "mACosx                          ...#####################################100.0################################################ac#OS#X   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110 + "'", int2 == 110);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                ", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("4", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                " + "'", str4.equals("                                "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test271");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("C os xAmC os xAmC os xAm..", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test272");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-B11", 135);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11                                                                                                                              " + "'", str2.equals("24.80-B11                                                                                                                              "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporation", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "7MacO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-b15                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test278");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", "Msun.lc OS X", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("4444444444444444444444444444444444444c4OS4c4OS4", "", "phie");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!1Mac OS X0.0hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih0.0X SO caM1!ih" + "'", str1.equals("!ih0.0X SO caM1!ih"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "...44444444444444444444444444..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...44444444444444444444444444.." + "'", str1.equals("...44444444444444444444444444.."));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test283");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444444444444444444444444...aaaaaaaaaaaaaaaaaaaaaaaaa...444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "                   c OS c OS                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                   c OS c OS                                                                    " + "'", str1.equals("                   c OS c OS                                                                    "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x" + "'", str1.equals("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test287");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Sun.lwa...", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("CmACoCox    ", "#    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CmACoCox    " + "'", str2.equals("CmACoCox    "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test290");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("ficepS#enih", (long) 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("c#OS#Xa...#####################################100.0################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c#OS#Xa...#####################################100.0################################################" + "'", str1.equals("c#OS#Xa...#####################################100.0################################################"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("cOSXa...cOSXa...cOSXa...cOSXa...cOSXa...cOSXa....0_80cOSXa...cOSXa...cOSXa...cOSXa...cOSXa...cOSXa..", 1014, "                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                                                                                                                                                            MacOSX 1.7.0_80-b15                           cOSXa...cOSXa...cOSXa...cOSXa...cOSXa...cOSXa....0_80cOSXa...cOSXa...cOSXa...cOSXa...cOSXa...cOSXa..                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                                                                                                                                                            MacOSX 1.7.0_80-b15                           " + "'", str3.equals("                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                                                                                                                                                            MacOSX 1.7.0_80-b15                           cOSXa...cOSXa...cOSXa...cOSXa...cOSXa...cOSXa....0_80cOSXa...cOSXa...cOSXa...cOSXa...cOSXa...cOSXa..                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                                                                                                                                                            MacOSX 1.7.0_80-b15                           "));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio" + "'", str1.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/uSERS/SOPHIE", 15, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44/uSERS/SOPHIE" + "'", str3.equals("44/uSERS/SOPHIE"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test295");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("cMacOcOX    ", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test296");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(".", ".0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", "24.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str2.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44c..." + "'", str2.equals("44c..."));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test300");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("ACosx ", "sun.lwa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...", "aaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj..." + "'", str2.equals("...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj..."));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test302");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("MacOSX1.7MacOSX", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test304");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("5.41sun.l", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITACIFICEPs#ENIHCAm#LAUTRIv#AVAj###############################################################" + "'", str1.equals("NOITACIFICEPs#ENIHCAm#LAUTRIv#AVAj###############################################################"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 1, 16);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a/Users/sophi..." + "'", str3.equals("a/Users/sophi..."));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test307");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("java Platform API Specification", "", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("       Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       orcle corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/       orcle corportion" + "'", str1.equals("       orcle corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/       orcle corportion"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test309");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.lwctoolkit5.415.415.415.415.415.415.415.415.415");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.lwctoolkit5.415.415.415.415.415.415.415.415.415\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test311");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("COX", "44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                                                   C os C os                                                                    ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                          x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test314");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(110, (int) (byte) 0, 608);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 608 + "'", int3 == 608);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test315");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("h/users/sophie", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("java Platform API Specification", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java Platform API Specification" + "'", str3.equals("java Platform API Specification"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("cepS#enih", "44/uSERS/SOPHIE");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Xa...                                     100.0                                                Platf", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "latf" + "'", str2.equals("latf"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("cepS#enih", "24.80-B11                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cepS#enih" + "'", str2.equals("cepS#enih"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test320");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("       orcle corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/       orcle corportion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"orcle corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/       orcle corportion\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test321");
        double[] doubleArray5 = new double[] { (-1L), (byte) -1, 3, 8, 97.0d };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass8 = doubleArray5.getClass();
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################", "...awl.nuS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str3.equals(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test323");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                             c os c os                                                                    ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str1.equals("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", "..AWL.NUS...AWL.NUS...AWL.NUS...AtnemnorivnEscihparGC.twa.nusL.NUS...AWL.NUS...AWL.NUS...AWL.NUs", "                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC" + "'", str3.equals("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test327");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                            MacOSX 1.7.0_80-b15", "s");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "MacOSX                                                                                              ");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "US");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracle corporatio", strArray3, strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Java Virtual Machine Specification" + "'", str11.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "oracle corporatio" + "'", str12.equals("oracle corporatio"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "                            MacOSX 1.7.0_80-b15" + "'", str13.equals("                            MacOSX 1.7.0_80-b15"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test328");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), (long) 5, (long) 105);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO" + "'", str2.equals("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test331");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str1.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "10", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test334");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US10.14.3");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str4.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test335");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test336");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl", 97, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...form A..." + "'", str3.equals("...form A..."));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("24.80-B11                                                                                                                              ", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11                                                                                                                              " + "'", str2.equals("24.80-B11                                                                                                                              "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test339");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(95, 741, 271);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                           4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                           4444444444444444444444444444444444444444444c OS c OS " + "'", str1.equals("                                           4444444444444444444444444444444444444444444c OS c OS "));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test341");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("...44444444444444444444444444..");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "RACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RACLE cORPORATIONoRACLE cORPORATION" + "'", str1.equals("RACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test343");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("...a...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwasun.lw", "44444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...a...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwasun.lw" + "'", str2.equals("...a...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwasun.lw"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(".0_80", "1Mac OS X0.0                       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("##############################################JAVA P###############################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################################JAVA P###############################################" + "'", str1.equals("##############################################JAVA P###############################################"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("44444444444444444OcC44444444444444444", "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444OcC" + "'", str2.equals("44444444444444444OcC"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test349");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Msun.lc OS X", (java.lang.CharSequence) "O  c  C");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test350");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test351");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("10", 44444444);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test353");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test354");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("100.0");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0" + "'", str2.equals("100.0"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test355");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test356");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                   24.80-B11                                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test357");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("       Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test358");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "NOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJ", (java.lang.CharSequence) "########    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 536 + "'", int2 == 536);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("scs", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "scs" + "'", str2.equals("scs"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(" OS c OS aaaaaaaaaaaaaaaaaaaaaaa", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("...44444444444444444444444444..", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.." + "'", str2.equals("...44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.....44444444444444444444444444.."));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test362");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("C#OS#XaM", "vironmentM", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "1014");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test366");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl", "x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test367");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", (java.lang.CharSequence) "44444444444444444O  c  C          444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75 + "'", int2 == 75);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/su");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj..." + "'", str3.equals("...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj...Lp AVAj..."));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test370");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("hi!", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(".0_8                                                                                                ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_8                                                                                                " + "'", str2.equals(".0_8                                                                                                "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test372");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test373");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "Platfc OS Xa...                                     100.0                                                Platf");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC" + "'", str1.equals("xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test378");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/moc.elcaro.avaj//:ptth", "", 1014);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test379");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80                                                                                           ", ".0_80", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test380");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...awl.nuS");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "###############");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("phiephiephiephiUS10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test383");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 111);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test384");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("4444444444444444444444444444444444444444444c4OS4c4OS", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str1.equals("44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                             c os c os                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                             c os c os                                                                    " + "'", str1.equals("                                             c os c os                                                                    "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test388");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#P#l08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmCtform#08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#A08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"8_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#P#l08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmCtform#08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#A08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "MacOSXMacOSX", "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "      acOSX                  1.7MaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test391");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "eihpos/sresU/h", (java.lang.CharSequence) "a/Users/sophi...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "MacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSX");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test393");
        double[] doubleArray4 = new double[] { 458, 144, (-1.0f), (-1) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 458.0d + "'", double6 == 458.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 458.0d + "'", double7 == 458.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 458.0d + "'", double8 == 458.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("mixed mode                                                                                                          s                           ", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MacOSX                                                                                              ");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java Virtual Machine Specification" + "'", str7.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test396");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "#O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O##O44444444444444444444444444444444444444444444O44O4", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test397");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("c OS XaM");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "HI!", 442, (-1));
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test398");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.awt.cgraphicsenvironment", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("C OS c OS ", 105, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                   1.7.0_80                                                    ", 53, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444441.7.0_80   444444441.7.0_80   444444441.7.0_80   444444441.7.0_80" + "'", str1.equals("444444441.7.0_80   444444441.7.0_80   444444441.7.0_80   444444441.7.0_80"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", "sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str2.equals("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80", (int) (short) -1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("             ..._...              ", "US4104.4144.43");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("44cO4X4444444444444444444444444444...", "phie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("phie", "44444444444444444OcC", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "phie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie" + "'", str3.equals("phie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie44444444444444444OcCphie"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test409");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] {};
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS c OS ", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(" 24.8", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", (int) '4', "cOSccOSc");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio" + "'", str3.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test411");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "NOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl", " 24.80-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl" + "'", str2.equals("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi!", "1Mac OS X0.0                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test414");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("...5. 15. 15. 15. 15. 15. 15. 15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...5. 15. 15. 15. 15. 15. 15. 15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("/java/extensions:/usr/lib/java:.", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "c#os#x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("O  c  C", "/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r", "MacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSXMacOSX1.7MacOSX", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r" + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                        andoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/frarget/clandoop.pl_10895_1560229361/ta   /Users/sophie/Documents/defectsj/tmp/run_r"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test419");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("US", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test420");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test421");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray10 = new char[] { 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence6, charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "c#OS#Xa...#####################################100.0################################################", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                :", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                               100.0                                                ", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JAVA P", charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ScS", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "MacOSX1.7MacOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/", "5C os xAmC os xAmC os xAm..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test424");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test425");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                                                            MacOSX 1.7.0_80-b15                                                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MacOSX 1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str2.equals("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test427");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "       Oracle Corporation       ", "08_0.7.144444444", 87);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("jAVA pL...jAVA pL...jAVA pL...j...", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test429");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", "                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test431");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.lw");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test432");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 97);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                0.001                                     ...aX SO caMXSOcaMXSOcaMXSOcaMXSOcaMXSOcaMXSOcaMXSOcaM" + "'", str1.equals("                                                0.001                                     ...aX SO caMXSOcaMXSOcaMXSOcaMXSOcaMXSOcaMXSOcaMXSOcaM"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test434");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("MacOSX                  1.7MacOSX                   ", "                                               100.0                                                ", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test435");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("44444444444444444444444444444...aaaaaaaaaaaaaaaaaaaaaaaaa...444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test436");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-b15                                                                                                ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test437");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MacOSXMacOSX", "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test438");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".", "24.80-...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test439");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 6.0f, (float) 24L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("08_0...", " MacOSX                             MacOSX ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "                                                               Java Virtual Machine Specification");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r", strArray3, strArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos", (int) (short) 0, 144);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str11.equals("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test441");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("c#os#xAm", "HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Mac OS X", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("SeNVIRONMENTSUN.AWT.cgRCosxAuSERSSOPHIEuSERSSOPHIEuSERSSOPHIEuSERSSOPHIEuSERSSOPHIEuSERSSOPHIEuSE", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test443");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 271, (double) (byte) -1, (double) 167L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 271.0d + "'", double3 == 271.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("4444444444444444444444444444444444444444444444444444", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444444444444444444c4OS4c4OS4", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444c4OS4c4OS4                                                                                                " + "'", str2.equals("4444444444444444444444444444444444444c4OS4c4OS4                                                                                                "));
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest10.test446");
//        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1Mac OS X0.0                       ");
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1mAC os str1.0                       " + "'", str1.equals("1mAC os str1.0                       "));
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test447");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test448");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "!ih", 3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "McOSX", 7, (int) (short) 0);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("noitacificepS#enihcaM#lautriV#avaJ###############################################################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", 3);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray6, strArray15);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny("44444444444444444OcC444444444444444444", strArray15);
        int int19 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("CmACoCox    ", strArray15);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray15);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444" + "'", str17.equals("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NoitacificepS#enihcaM#lautri..." + "'", str2.equals("NoitacificepS#enihcaM#lautri..."));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test452");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test453");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (byte) -1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test454");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test455");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sEnvironmentsun.awt.CGrcOSXa", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test456");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(5L, 1L, (long) 181);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                              s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                              S" + "'", str1.equals("                                              S"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                               ", 75, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                               " + "'", str3.equals("1.7.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                               "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test460");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80                                                                                           ", "4444444444444444444444444444444444444444444c4OS4c4OS4", 9);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.lwawt.macosx.CPrinterJob");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("#####4444444444444444444444444444444444444444444c OS c OS############################Java#Virtual#Machine#Specification", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "cmacocox    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test462");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("...#####################################100.0################################################ac#OS#X");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "c os xAm", 18, 144);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("44/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44/uSERS/SOPHIE" + "'", str1.equals("44/uSERS/SOPHIE"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test464");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(".aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 5, 608);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("44444444444444444O  cc OS c OS  XaM24#######c OS XaM", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444O  cc OS c OS  XaM24#######c OS XaM" + "'", str3.equals("44444444444444444O  cc OS c OS  XaM24#######c OS XaM"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("CmACoCox    ", " #P#latform# #A...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CmACoCox    " + "'", str2.equals("CmACoCox    "));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("..AWL.NUS...AWL.NUS...AWL.NUS...AtnemnorivnEscihparGC.twa.nusL.NUS...AWL.NUS...AWL.NUS...AWL.NUs");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("5.415.4...", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5.415.4..." + "'", str3.equals("5.415.4..."));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("C#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str3.equals("C#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test471");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                   1.7.0_80                                                    ", "c OS Xa...", 167);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test473");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 442, (long) 144, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test474");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test477");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                                                                                              s", "..AWL.NUS...AWL.NUS...AWL.NUS...AtnemnorivnEscihparGC.twa.nusL.NUS...AWL.NUS...AWL.NUS...AWL.NUs");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test478");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                               Java Virtual Machine ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine" + "'", str1.equals("Java Virtual Machine"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Sun.lwa...sun.lwa...sun.lwa...sun.lSUN.AWT.cgRAPHICSeNVIRONMENTa...sun.lwa...sun.lwa...sun.lwa..", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwa...sun.lwa...sun.lwa...sun.lSUN.AWT.cgRAPHICSeNVIRONMENTa...sun.lwa...sun.lwa...sun.lwa.." + "'", str2.equals("Sun.lwa...sun.lwa...sun.lwa...sun.lSUN.AWT.cgRAPHICSeNVIRONMENTa...sun.lwa...sun.lwa...sun.lwa.."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("51.0  ", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0  " + "'", str2.equals("51.0  "));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test482");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("c OS c OS ", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/uSERS/SOPHIE", strArray3, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/uSERS/SOPHIE" + "'", str8.equals("/uSERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "  ", 458);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", "sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL" + "'", str2.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("08_0.7.144444444", "                                                5.41                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.144444444" + "'", str2.equals("08_0.7.144444444"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test487");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "w1 N/:s  4s  1xE/242 /y222b4L/:1x /b4-/ 2j/ 4 H/s1  1  C/kdj.08_0.7.1kdj/s  4h22M-2u124V242 /242 /y222b4L/:s  4s  1xE/242 /y222b4L/ 4h1 s/s2 sU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("US10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US10.14.3" + "'", str1.equals("US10.14.3"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test489");
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "5.41", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Vi...", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test490");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 1, (byte) -1, (byte) 1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass10 = byteArray6.getClass();
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test491");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(24, 14, 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test492");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", "Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str2.equals("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test494");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATION", "", 144);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(" MacOSX x86_64", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("##############################################################################################en", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################################################en" + "'", str2.equals("##############################################################################################en"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Sun.lwa...", " 24.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwa..." + "'", str2.equals("Sun.lwa..."));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS4444444444444444444444444444444444444444444cOScOS", "      acOSX                  1.7MaM", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test498");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("#", "24.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }
}

