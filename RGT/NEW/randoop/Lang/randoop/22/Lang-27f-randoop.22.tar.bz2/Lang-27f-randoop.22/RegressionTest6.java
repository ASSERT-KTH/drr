import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("userssophi", "44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 608, (float) (byte) 100, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("10.14.3", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 99, 111);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5L, 0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("c OS c OS c OS c OS c OS c OS c OS c OS ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("cMacOcOX    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cMacOcOX   " + "'", str1.equals("cMacOcOX   "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("c#OS#c#OS#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c#OS#c#OS#" + "'", str1.equals("c#OS#c#OS#"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("userssophi", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "userssophi" + "'", str2.equals("userssophi"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str3.equals("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("US", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("c OS Xa...                                     100.0                                                ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" 24.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.8" + "'", str1.equals("24.8"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", (java.lang.CharSequence) "mACosx                          ...#####################################100.0################################################c#OS#X   ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC" + "'", charSequence2.equals("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10.0f, (double) 12.0f, (double) 5.41f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "cMacOcOX   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r", 8, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "..._..." + "'", str3.equals("..._..."));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("racle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "racle corporation" + "'", str1.equals("racle corporation"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" 24.80-b11", "2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 24.80-b11" + "'", str3.equals(" 24.80-b11"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("s", "noitacificepS#enihcaM#lautriV#avaJ###############################################################", 18);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US10.14.3");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", strArray4, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str8.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, "       oracle corporation       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "", "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR", "mACosx                          ...#####################################100.0################################################ac#OS#X   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR" + "'", str2.equals("pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("c OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS Xa...                                     100.0" + "'", str1.equals("c OS Xa...                                     100.0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("########", 12, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########    " + "'", str3.equals("########    "));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("McOSX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"McOSX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("##############################################################################################en", "24.80-b11");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 2, "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  " + "'", str3.equals("  "));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.lw");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray3, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7.0_80" + "'", str8.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("O  c  C          ", 144, "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O  c  C          MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaaMacOSX  MacOSX  MacOSX  MacO" + "'", str3.equals("O  c  C          MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaaMacOSX  MacOSX  MacOSX  MacO"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("c#OS#Xa...#####################################100.0################################################", "  ", 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " 24.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("24#######", "ification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "\n");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("XSOcaM7.1XSOcaM", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("macosxmacosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x", "4444444444444444444444444444444444444444444c OS c OS ", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("noitacificepS#enihcaM#lautriV#avaJ##############################################################", "x86_64", "macosxmacosx");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str3.equals("noitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                           4444444444444444444444444444444444444444444c OS c OS ", " MacOSX x86_64", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS ", "4444444444444444444444444444444444444444444c4OS4c4OS4", 458, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44444444444444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str4.equals("44444444444444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Platform API Specificatio" + "'", str1.equals("java Platform API Specificatio"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/" + "'", str3.equals("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracle Cor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                        OS c OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", "sPECIFICATION api pLATFORM jAVA", "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###############################################################Java#Virtual#Machine#Specification", "java Platform API Specification", 3);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", (int) (byte) 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '#', (int) '#', (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("                            MacOSX ", strArray5, strArray9);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                            08_0.7.1", "AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO");
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("c os xAm", strArray5, strArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 93");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "                            MacOSX " + "'", str14.equals("                            MacOSX "));
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("44444444", "sun.l");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444" + "'", str2.equals("44444444"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                               100.0                                                ", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               100.0                                                " + "'", str2.equals("                                               100.0                                                "));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########" + "'", str1.equals("########"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              " + "'", str2.equals("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mACosx", 167);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "HI!", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("4444444444444444444444444444444444444444444c OS c OS", "jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("###############################################################Java#Virtual#Machine#Specification", "/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################################################Java#Virtual#Machine#Specification" + "'", str2.equals("###############################################################Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA.." + "'", str1.equals("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA.."));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", "                                                                   c OS c OS                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str2.equals("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", 37, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444441.7.0_80-b15" + "'", str3.equals("44444444444444444444444441.7.0_80-b15"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("cMacOcOX   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) " #P#latform# #A...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " #P#latform# #A..." + "'", str1.equals(" #P#latform# #A..."));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("McOSX", 170, 143);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("\n", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 111, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 27, 0.0f, (float) 44);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                  Userssophi                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                               Java Virtual Machine ", "ification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ification" + "'", str2.equals("ification"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "C os xAm", (java.lang.CharSequence) "51.0  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                        OS c OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OS c OS" + "'", str1.equals("OS c OS"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("O  c  C", "mACosx                          ...#####################################100.0################################################ac#OS#X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(" OS c OS ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", "eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11" + "'", str2.equals(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("AVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFO", "1Mac OS X0.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("08_0...", "h/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 34, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                            Userssophie                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Userssophie" + "'", str1.equals("Userssophie"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 16, (double) (byte) -1, (double) 44);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 44.0d + "'", double3 == 44.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion" + "'", str2.equals("       Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("c#OS#Xa...#####################################100.0################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c#OS#Xa...#####################################100.0################################################" + "'", str1.equals("c#OS#Xa...#####################################100.0################################################"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str2.equals("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("###############################################################Java#Virtual#Machine#Specification", "MacOSX                  1.7MacOSX                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################################################Java#Virtual#Machine#Specification" + "'", str2.equals("###############################################################Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU" + "'", str2.equals("3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("!ih", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!ih" + "'", str2.equals("!ih"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("4444444444444444444444444444444444444444444c OS c OS", "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" 24.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("US4104.4144.43", "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("cOScOS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cOScOS" + "'", str1.equals("cOScOS"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "                                                                                                                                                                          ", 35);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "_8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(" MacOSX                             MacOSX ", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(" MacOSX x86_64", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor" + "'", str1.equals("c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80", "C os xAmC os xAmC os xAm..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "XSOcaM7.1XSOcaM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XSOcaM7.1XSOcaM" + "'", str1.equals("XSOcaM7.1XSOcaM"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" 24.80-...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) ' ', 271.0f, (float) 143L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 271.0f + "'", float3 == 271.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.7.0_80                                                                                            ", 144);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray11, strArray15);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray15);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, '4', (int) (byte) 1, (int) (byte) 1);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.startsWithAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray15);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.startsWithAny(".0_80", strArray15);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray15);
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" MacOSX                             MacOSX ", strArray4, strArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7.0_80" + "'", str16.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("24#######");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##############################################################################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("MacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX                                                                                              " + "'", str1.equals("MacOSX                                                                                              "));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "ihpossresU");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("MacOSX                  1.7MacOSX                   ", 32, "  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacOSX                  1.7MacOSX                   " + "'", str3.equals("MacOSX                  1.7MacOSX                   "));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(99, (int) (short) 100, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl..." + "'", str1.equals("...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl..."));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2", "Oracle Cor");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             ", "########", 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("##############################################################Java#Virtual#Machine#Specificatio", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", (java.lang.CharSequence) "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX" + "'", charSequence2.equals("Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", "##############################################################Java#Virtual#Machine#Specificatio", 1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM" + "'", str4.equals("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        long[] longArray6 = new long[] { 18, (-1), (short) -1, (byte) 0, 0L, 'a' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Java/Extensions:/usr/lib/java:.", 27, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("24.80-B11", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                            MacOSX 1.7.0_80-b15", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            MacOSX 1.7.0_80-b15" + "'", str2.equals("                            MacOSX 1.7.0_80-b15"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("US10.14.3", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("acOSX", 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", "Userssophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..." + "'", str4.equals("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..."));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("oracle corporation", "ihpossresU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "OS c OS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, 7.0f, (float) 461);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                   c OS c OS                                                                    ", "1.7.0_80", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "US", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 271);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", (java.lang.CharSequence) "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4444444444444444444444444444444444444444444c OS c OS ", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS " + "'", str2.equals("4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(".0_8", 1014);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8" + "'", str2.equals(".0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8.0_8"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-b15", 0, "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-b15" + "'", str3.equals("-b15"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java(TM) SE Runtime Environment", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("MacOSXMacOSX", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          MacOSXMacOSX          " + "'", str2.equals("          MacOSXMacOSX          "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MacOSX                  1.7MacOSX                                                                                                              ", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                              s", "Userssophi", "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                              s" + "'", str3.equals("                                                                                                              s"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" MacOSX ", "                                                                                                              s", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("                        OS c OS ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "C#os#xAm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 9, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(" #P#latform# #A...", 461, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("########", 105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", "c OS XaM", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE", "                                                                                                :");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Cosx", 0, 271);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Cosx" + "'", str3.equals("Cosx"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(" #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", 608, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", 44, 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(" MacOSX ", "MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " MacOSX " + "'", str2.equals(" MacOSX "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.l", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.l" + "'", str2.equals("sun.l"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("...4444444444444444444444444444X4Oc44", 16, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...44444444444444444444444X4Oc44" + "'", str3.equals("...44444444444444444444444X4Oc44"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR", "/Users/sophi1.7.0_80/Users/sophi", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("soph:sophi", 18, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("08_0.7.144444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", 1, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RACLE cORPORATIONoRACLE cORPORATION" + "'", str3.equals("RACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("08_0...", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa...", 16, 44);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sEnvironmentsun.awt.CGrcOSXa" + "'", str3.equals("sEnvironmentsun.awt.CGrcOSXa"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) " #P#latform# #A...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                          s", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              s" + "'", str2.equals("                                              s"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################", ".0_8                                                                                                ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "jAVA pLATFORM api sPECIFICATION");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("O  c  C          ", "       Oracle Corporation       ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS ", 34, 458);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444" + "'", str3.equals("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "macosxmacosx");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "24.80-b11");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                :", (int) (short) -1, "US4104.4144.43");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                :" + "'", str3.equals("                                                                                                :"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("oracle corporation", 1014, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (long) 16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("24.80-...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 271, (double) 96, (double) 27);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 271.0d + "'", double3 == 271.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("cMacOcOX    ", 9, "5.41sun.l");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cMacOcOX    " + "'", str3.equals("cMacOcOX    "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("24.80-B11");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, 0.0f, (float) 458L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("                                                                                                          s", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac                                                                                                          sOS                                                                                                          sX" + "'", str4.equals("Mac                                                                                                          sOS                                                                                                          sX"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("...4444444444444444444444444444X4Oc44", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...4444444444444444444444444444X4Oc44" + "'", str2.equals("...4444444444444444444444444444X4Oc44"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("0", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "MacOSXMacOSX", 10, 144);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 55");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" OS c OS ", (int) ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " OS c OS aaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals(" OS c OS aaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os x", "444444", "c#OS#c#OS#");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", 144, "                                                                                                          s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode                                                                                                          s                           " + "'", str3.equals("mixed mode                                                                                                          s                           "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor", "", 461);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 110 + "'", int3 == 110);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".0_80", "hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0_80" + "'", str3.equals(".0_80"));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ficepS#enih", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cepS#enih" + "'", str2.equals("cepS#enih"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("44444444444444444OcC444444444444444444", "Userssophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444OcC444444444444444444" + "'", str2.equals("44444444444444444OcC444444444444444444"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                            MacOSX 1.7.0_80-b15", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            MacOSX 1.7.0_80-b15" + "'", str3.equals("                            MacOSX 1.7.0_80-b15"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(144.0f, 111.0f, (float) 111);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 144.0f + "'", float3 == 144.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("java Platform API Specification", 167.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 167.0f + "'", float2 == 167.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " #P#latform# #A..", (java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, (int) (byte) 1, 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 167 + "'", int3 == 167);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java(TM) SE Runtime Environment", "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Userssophi", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("C os xAm", "PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C os xAm" + "'", str3.equals("C os xAm"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific" + "'", str2.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", "          MacOSXMacOSX          ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("44444444444444444O  c  C          444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        int[] intArray2 = new int[] { 144, (byte) 10 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 144 + "'", int4 == 144);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US10.14.3");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Userssophie", (java.lang.CharSequence) "444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("24.80-b11", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...", "Java Vi...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.14.3", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", (java.lang.CharSequence) "C#OS#XaM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95 + "'", int2 == 95);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "jAVA pL...jAVA pL...jAVA pL...j...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Cosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 181);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("24.8", "cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ", 111);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80", " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80" + "'", str4.equals(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", "                            MacOSX ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("                                                                   C os C os                                                                    ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80                                                                                            ", "sun.awt.CGraphicsEnvironment", (int) '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach(" OS c OS ", strArray12, strArray16);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + " OS c OS " + "'", str17.equals(" OS c OS "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "                            MacOSX 1.7.0_80-b15", 0, 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   " + "'", str4.equals("                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   "));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str2.equals("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                            MacOSX ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", "10.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "24.80-...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-..." + "'", str1.equals("24.80-..."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                                                                   c OS c OS                                                                    ", "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "###############################################################Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("...5.415.415.415.415.415.415.415", "!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Userssophie", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                :", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                               Java Virtual Machine ", 32, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                               Java Virtual Machine " + "'", str3.equals("                                                               Java Virtual Machine "));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                   C os C os                                                                    ", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".", "44cO4X4444444444444444444444444444...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" OS c OS ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("C os xAm", " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "MacOSX                  1.7MacOSX                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", "mACosx");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation" + "'", str2.equals("       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray6, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concatWith("MacOSX                                                                                              ", (java.lang.Object[]) strArray10);
        java.lang.String[] strArray15 = null;
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray18);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray18);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw", strArray15, strArray18);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", strArray10, strArray15);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              " + "'", str13.equals("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              "));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw" + "'", str25.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w" + "'", str26.equals("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl" + "'", str2.equals("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("...#####################################100.0################################################ac#OS#X", "MacOSX                  1.7MacOSX", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvironment", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 1, 3.0d, (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("24.80-b11", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa...", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specification", 16, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("##############################################################Java#Virtual#Machine#Specificatio", "A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "acOSX", "userssophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Oracle Corporation", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("acOSX", "##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "acOSX" + "'", str2.equals("acOSX"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("oracle corporation", strArray4, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Platform API Specification", strArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "   ", (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "oracle corporation" + "'", str9.equals("oracle corporation"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 100, (byte) 1, (byte) 1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("4444444444444444444444444444444444444444444c4OS4c4OS4", "44444444444444444OcC444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("########    ", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#    " + "'", str2.equals("#    "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("##############################################################################################en", "24.80-b11");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##############################################################################################en" + "'", str4.equals("##############################################################################################en"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "5.41sun.l", "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("44444444444444444O  c  C          444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444O  c  C          444444444444444444" + "'", str1.equals("44444444444444444O  c  C          444444444444444444"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("444444", ".");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String[] strArray2 = new java.lang.String[] { "noitacificepS#enihcaM#lautriV#avaJ###############################################################" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("pLATFORM Java Virtual Machine SpecificationpLATFORM ", strArray2, strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "http://java.oracle.com/", (int) (byte) 10, 4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "pLATFORM Java Virtual Machine SpecificationpLATFORM " + "'", str6.equals("pLATFORM Java Virtual Machine SpecificationpLATFORM "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("HI!", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4', (int) (byte) 1, (int) (byte) 1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7.0_80" + "'", str10.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "1.7.0_80                                                                                           ", "24#######", 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str4.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "COX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                    Userssophie                     ", "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80                                                                                            ", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("44444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str1.equals("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Userssophie");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", "##############################################################Java#Virtual#Machine#Specificatio", 1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray16);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "cOX");
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.split("Mac OS X", 'a');
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray22, "");
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray22, "Java Vi...");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray19, strArray22);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio" + "'", str1.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "       oracle corporation       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                            MacOSX 1.7.0_80-b15", "s");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str5.equals("/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("44444444444444444OcC444444444444444444#######################################################################################################################################################################################################################################################################################################################################################################################################################################", ".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80", "24.80-B11");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "10.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("hi!", "Sun.lwa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                5.41                                                ", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                   c os c os                                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                  Userssophi                   ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                            Userssophie                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Userssophie" + "'", str1.equals("Userssophie"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                                   1.7.0_80                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "ification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ification" + "'", str1.equals("ification"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("MacOSXMacOSX", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "       Oracle Corporation/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Oracle Corporation", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "24.80-b11");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "MacOSX                                                                                              ");
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray5, strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwa...", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Java Virtual Machine Specification" + "'", str13.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str14.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "sun.lwa..." + "'", str15.equals("sun.lwa..."));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("                                                                                                              s", "XSOcaM7.1XSOcaM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112" + "'", str2.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("4444444444444444444444444444444444444444444c OS c OS ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", 44, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("4444444444444444444444444444444444444444444c4OS4c4OS4", "1014");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444c4OS4c4OS" + "'", str2.equals("4444444444444444444444444444444444444444444c4OS4c4OS"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("RACLE cORPORATIONoRACLE cORPORATION", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 461);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "44444444444444444444444444444444444444444444444444444c4OS4c4OS4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        long[] longArray6 = new long[] { 18, (-1), (short) -1, (byte) 0, 0L, 'a' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("MACosx", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 27, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MacOSX                                                                                              ");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             ", 10, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java Virtual Machine Specification" + "'", str7.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(18L, 32L, (long) 143);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                   c os c os                                                                    ", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("7_8", "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", ".0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("jAVA pL...", "c os xAm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pL..." + "'", str2.equals("jAVA pL..."));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("08_0...", "##############################################################Java#Virtual#Machine#Specificatio", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0..." + "'", str3.equals("08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0...##############################################################Java#Virtual#Machine#Specificatio08_0..."));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(27, (int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("       oracle corporation       ", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       oracle corporation       " + "'", str3.equals("       oracle corporation       "));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "5.41");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ", 9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        int[] intArray2 = new int[] { 144, (byte) 10 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 144 + "'", int5 == 144);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX" + "'", str2.equals("(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("racle corporation", " MacOSX                             MacOSX ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415", "x86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("ECIFICATIO", 608);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 608 + "'", int2 == 608);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("c OS Xa...                                     100.0                                                ", (int) (byte) 0, 105);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS Xa...                                     100.0                                                " + "'", str3.equals("c OS Xa...                                     100.0                                                "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS ", (int) (short) 10, "       Oracle Corporation       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS " + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS "));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MacOSX                  1.7MacOSX                   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 95);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 95.0f + "'", float2 == 95.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(16, 0, 105);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              " + "'", str1.equals("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              "));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/su" + "'", str1.equals("3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/su"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("ification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "...#####################################100.0################################################ac#OS#X", "MacOSX1.7MacOSX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_" + "'", str1.equals("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w" + "'", str2.equals("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("7_8", "acOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7_8" + "'", str2.equals("7_8"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_", "###############################################################Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor" + "'", str1.equals(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("mixed mode                                                                                                          s                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode                                                                                                          s                           " + "'", str1.equals("mixed mode                                                                                                          s                           "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("                                                5.41                                                ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "c#OS#Xa...#####################################100.0################################################", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("Mac                                                                                                          sOS                                                                                                          sX", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("...#####################################100.0################################################ac#OS#X", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " OS c OS aaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sPECIFICATION api pLATFORM jAVA", "", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##############################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sPECIFICATION api pLATFORM jAVA" + "'", str3.equals("sPECIFICATION api pLATFORM jAVA"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("44444444", "Cosx");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_80                                                                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80                                                                                           \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ".0_80", 167, 608);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 167");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str5.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str7.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("c OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS Xa...                                     100.0                                                " + "'", str1.equals("c OS Xa...                                     100.0                                                "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("MacOSX                  1.7MacOSX                   ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cOSX                   acOSX                  1.7MaM" + "'", str2.equals("cOSX                   acOSX                  1.7MaM"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.lwa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwa..." + "'", str1.equals("sun.lwa..."));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        double[] doubleArray6 = new double[] { 8, 99, 18.0d, 22, 8L, 111.0f };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 111.0d + "'", double7 == 111.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##############################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm" + "'", str1.equals("userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##############################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", "sun.lw");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str2.equals("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        double[] doubleArray1 = new double[] { 10 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", (int) (short) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "24#######" + "'", str5.equals("24#######"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "24" + "'", str6.equals("24"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(" OS c OS aaaaaaaaaaaaaaaaaaaaaaa", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str8.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(" OS c OS aaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', 9, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ", "10.14.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (byte) 1, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Java Vi...", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("4444444444444444444444444444444444444444444c OS c OS");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("US10.14.3", 0, 143);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US10.14.3" + "'", str3.equals("US10.14.3"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!" + "'", str3.equals("HI!"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) -1, (float) 1, (float) 16L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 16.0f + "'", float3 == 16.0f);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "                                                                                                :");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                :" + "'", str1.equals("                                                                                                :"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        double[] doubleArray1 = new double[] { 10 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 16, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC" + "'", str4.equals("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("!ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!ih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!", "sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", "10.14.310.14.310.14.310.14.310.14.3", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 34, (double) 6, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "##############################################################Java#Virtual#Machine#Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHIE", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("JAVA P");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA P" + "'", str1.equals("JAVA P"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                   C os C os                                                                    ", 271);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   C os C os                                                                    " + "'", str2.equals("                                                                   C os C os                                                                    "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Userssophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Userssophi is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 110, (long) 97, (long) 458);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   " + "'", str2.equals("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        float[] floatArray6 = new float[] { 9, (short) 1, ' ', '#', 100L, 35 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", "mixed mode                                                                                                          s                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...44444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...44444444444444444444444444.." + "'", str1.equals("...44444444444444444444444444.."));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "mACosx                          ...#####################################100.0################################################ac#OS#X", 34, 95);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 34");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        double[] doubleArray5 = new double[] { (-1L), (byte) -1, 3, 8, 97.0d };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("5.41sun.l", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("RACLE cORPORATIONoRACLE cORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RACLE cO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "24#######");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("c OS Xa...                                     100.0", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS X#...                                     100.0" + "'", str3.equals("c OS X#...                                     100.0"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "_8" + "'", str1.equals("_8"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "51.0  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 37, 167);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("c#os#xAm", " #P#latform# #A..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c#os#x" + "'", str2.equals("c#os#x"));
    }
}

