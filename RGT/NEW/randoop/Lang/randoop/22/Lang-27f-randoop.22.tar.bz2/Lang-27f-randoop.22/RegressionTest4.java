import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "h/Users/sophie", 8, 4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-B11", "mixed mode");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("sun.lw", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "oracle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80                                                                                            ", "mACosx");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("c OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSXMacOSX" + "'", str1.equals("MacOSXMacOSX"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lw", "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lw" + "'", str2.equals("sun.lw"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Cosx");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Cosx" + "'", str1.equals("Cosx"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("OS c OS", "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("en", "mACosx");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 10, 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.LWCToolkit", 143, 37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mACosx", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) 10, (float) 22L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("oracle corporation");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("US10.14.3", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" 24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str2.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", "##############################################################Java#Virtual#Machine#Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..." + "'", str2.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..."));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("MACOSX", ".0_8                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10.14.", "CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("10.14.", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION" + "'", str2.equals("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("7_8", "COX", (int) (short) 1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "hi!");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("                                                5.41                                                ", strArray5, strArray15);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MacOSX                                                                                              ", "Java(TM) SE Runtime Environment", (int) (byte) -1);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray21);
        java.lang.Class<?> wildcardClass23 = strArray21.getClass();
        boolean boolean24 = org.apache.commons.lang3.StringUtils.startsWithAny("MACOSX", strArray21);
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ", strArray5, strArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 98");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "                                                5.41                                                " + "'", str16.equals("                                                5.41                                                "));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "cOX" + "'", str22.equals("cOX"));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "Java HotSpot(TM) 64-Bit Server VM", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                                                                                                :");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS c OS ", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                    Userssophie                     ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("oracle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporatio" + "'", str1.equals("oracle corporatio"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################" + "'", str1.equals("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("...5.415.415.415.415.415.415.415");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl", "MacOSX                  1.7MacOSX                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("noitacificepS#enihcaM#lautriV#avaJ##############################################################", 37, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str3.equals("noitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        " + "'", str1.equals("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        "));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1Mac OS X0.0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1Mac OS X0.0" + "'", str2.equals("1Mac OS X0.0"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mACosx                                                                                              ", 97, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("MacOSX1.7MacOSX", (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MacOSX                  1.7MacOSX                                                                                                              ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########" + "'", str1.equals("########"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".0_8                                                                                                ", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0_8                                                                                                " + "'", str3.equals(".0_8                                                                                                "));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("mACosx                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mACosx" + "'", str1.equals("mACosx"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ", 7, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", " 24.80-B11", 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str3.equals("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35, (double) 0, (double) 6.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("MacOSX1.7MacOSX", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 458, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 458L + "'", long3 == 458L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("4444444444444444444444444444444444444444444c4OS4c4OS4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444c\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("jAVA pL...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0", "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("44cO4X4444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...4444444444444444444444444444X4Oc44" + "'", str1.equals("...4444444444444444444444444444X4Oc44"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime Environment", "UTF-8", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MACOSX", ".0_8                                                                                                ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Java Virtual Machine Specification", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "10.14.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(".0_80", "C os xAmC os xAmC os xAm..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("s", 96.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.0f + "'", float2 == 96.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("ECIFICATIO", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("s", 144.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 144.0d + "'", double2 == 144.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        " + "'", str2.equals("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "5.415.415.415.415.415.415.415.415.41sun.lwawt.macosx.LWCToolkit5.415.415.415.415.415.415.415.415.415");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.14.3", "", "24.80-...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("c OS Xa...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".0_8", "", (int) '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ".0_8" + "'", str5.equals(".0_8"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 32, 0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("...#####################################100.0################################################ac#OS#X", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", 111);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("mACosx", "Java Virtual Machine Specification", "                                                               Java Virtual Machine ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        " + "'", str2.equals("jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        "));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.144444444" + "'", str2.equals("08_0.7.144444444"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("oracle corporation", strArray5, strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Platform API Specification", strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concatWith("jAVA pL...", (java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "oracle corporation" + "'", str10.equals("oracle corporation"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/" + "'", str12.equals("/"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "              24.80-b11              ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80", 18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java Platform API Specification" + "'", charSequence2.equals("Java Platform API Specification"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("...5.415.415.415.415.415.415.415", "4444444444444444444444444444444444444444444c OS c OS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("c OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Oracle Cor", "sun.lw");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ECIFICATIO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ECIFICATIO" + "'", str1.equals("ECIFICATIO"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "       ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("noitacificepS#enihcaM#lautriV#avaJ##############################################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str2.equals("noitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444c4OS4c4OS4", 18, "44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str3.equals("4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("!ih", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!ih" + "'", str2.equals("!ih"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", "/Users/sophie", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("s", 111);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                              s" + "'", str2.equals("                                                                                                              s"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", "h/users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("x86_64####################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("en");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###############################################################Java#Virtual#Machine#Specification", "java Platform API Specification", 3);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", (int) (byte) 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '#', (int) '#', (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("                            MacOSX ", strArray5, strArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny("mACosx                          ...#####################################100.0################################################ac#OS#X", strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "                            MacOSX " + "'", str14.equals("                            MacOSX "));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..." + "'", str1.equals("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..."));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION" + "'", str1.equals(" #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 22L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("Oracle Corporation", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("ficepS#enih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ficepS#enih" + "'", str1.equals("ficepS#enih"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(" #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", "c#OS#Xa...#####################################100.0################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("mACosx                                                                                              ", "MACosx");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mACosx                                                                                              " + "'", str2.equals("mACosx                                                                                              "));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("java Platform API Specification", "...4444444444444444444444444444X4Oc44");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("c os xAm", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c os xAm" + "'", str2.equals("c os xAm"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "##############################################################Java#Virtual#Machine#Specificatio", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 37, (long) 170, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b15", 3, "...4444444444444444444444444444X4Oc44");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11", "                                            Userssophie                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        float[] floatArray2 = new float[] { 6, (byte) -1 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 6.0f + "'", float6 == 6.0f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2", "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("24.80-B11", "51.0  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0  " + "'", str2.equals("51.0  "));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3, 100.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("c OS c OS ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie " + "'", str3.equals("c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("US10.14.3", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "US10.14.3" + "'", str4.equals("US10.14.3"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("   ", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15", "", "24.80-b11");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Userssophie", (float) 608);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 608.0f + "'", float2 == 608.0f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("08_0.7.144444444", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("0", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "24#######", (java.lang.CharSequence) " MacOSX                             MacOSX ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.80-...", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str2.equals("SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("oracle corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporatio" + "'", str1.equals("oracle corporatio"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80                                                                                            ", (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "C#os#xAm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c#os#xAm" + "'", str1.equals("c#os#xAm"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophi1.7.0_80/Users/sophi", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "5.41sun.l");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "McOSX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(144.0d, (double) 18.0f, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 144.0d + "'", double3 == 144.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("noitacificepS#enihcaM#lautriV#avaJ###############################################################", strArray2, strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ###############################################################" + "'", str5.equals("noitacificepS#enihcaM#lautriV#avaJ###############################################################"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ECIFICATIO", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "C os xAmC os xAmC os xAm", (java.lang.CharSequence) "                                                                                                              s");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 271 + "'", int2 == 271);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", "44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lw", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lw" + "'", str3.equals("sun.lw"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4, (double) 0L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("24.80-b11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b15", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444444444444444O  c  C          444444444444444444", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444OcC444444444444444444" + "'", str2.equals("44444444444444444OcC444444444444444444"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) -1, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.Class<?> wildcardClass5 = byteArray3.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!1Mac OS X0.0hi!", "/Java/Extensions:/usr/lib/java:.", "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!1Mac OS X0.0hi!" + "'", str4.equals("hi!1Mac OS X0.0hi!"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("MACosx", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("MacOSX                  1.7MacOSX                                                                                                              ", "java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(" MacOSX ", "x86_64", (int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " MacOSX x86_64" + "'", str4.equals(" MacOSX x86_64"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("MacOSX1.7MacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX1.7MacOSX" + "'", str1.equals("MacOSX1.7MacOSX"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("mixed mode", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(18, (int) 'a', 271);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU" + "'", str1.equals("3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" MacOSX x86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a', 52, 167);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7.0_80" + "'", str9.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("       Oracle Corporation       ", (double) 271);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 271.0d + "'", double2 == 271.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("8_0.", (int) (byte) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                8_0." + "'", str3.equals("                                                                                                8_0."));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("c OS Xa...", "/uSERS/SOPHIE");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray6);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "Userssophie");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" MacOSX ", strArray3, strArray14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " MacOSX " + "'", str18.equals(" MacOSX "));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("C os xAm", (int) (byte) 1, 461);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C os xAm" + "'", str3.equals("C os xAm"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU", 47, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU" + "'", str3.equals("3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("oracle corporation");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 32, 100L, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("macosxmacosx");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "macosxmacosx" + "'", str1.equals("macosxmacosx"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "##############################################################Java#Virtual#Machine#Specificatio");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie ", "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR", "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie " + "'", str3.equals("c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", 461, 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("24#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "C os xAmC os xAmC os xAm..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', (int) (short) -1, 144);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophi1.7.0_80/Users/sophi", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("oracle corporatio", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", 458);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi" + "'", str2.equals("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        long[] longArray4 = new long[] { (-1L), (byte) 1, (short) 10, 458 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 458L + "'", long5 == 458L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 458L + "'", long6 == 458L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 458L + "'", long7 == 458L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 458L + "'", long8 == 458L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" 24.80-...", 143, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("c os xAm", "                                                                                                                                                                          ", 608);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(":");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Java/Extensions:/usr/lib/java:.", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, 7, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_80                                                                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80                                                                                           " + "'", str1.equals("1.7.0_80                                                                                           "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(" #P#latform# #A...", "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " #P#latform# #A..." + "'", str2.equals(" #P#latform# #A..."));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("c OS Xa...", "_8", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS Xa..." + "'", str3.equals("c OS Xa..."));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Userssophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Userssophi" + "'", str1.equals("Userssophi"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION", "0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!", 608, "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("5.41sun.l", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", "100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(" 24.80-...", "!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("51.0  ", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0  " + "'", str2.equals("51.0  "));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!1Mac OS X0.0hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!1Mac OS X0.0hi!" + "'", str1.equals("hi!1Mac OS X0.0hi!"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("44444444444444444O  c  C          444444444444444444", "5.41sun.l");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 37);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str1.equals("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("MacOSX                                                                                              ", "", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("MacOSX                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"M\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                            MacOSX 1.7.0_80-b15", 167, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/Users/sophie", "noitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("cOSXa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", "c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) (byte) 100, (int) (byte) -1);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny("US10.14.3", strArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("c OS c OS ", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS c OS c OS c OS c OS c OS c OS c OS " + "'", str2.equals("c OS c OS c OS c OS c OS c OS c OS c OS "));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10, (double) 100, 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                            Userssophie                                             ", 0, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("c OS Xa...                                     100.0                                                ", "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("C os xAmC os xAmC os xAm..", "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR", 170, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR" + "'", str4.equals("C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int[] intArray5 = new int[] { 8, 100, (byte) 0, (short) 1, 144 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 144 + "'", int8 == 144);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 144 + "'", int9 == 144);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 144 + "'", int10 == 144);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 144 + "'", int11 == 144);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MACOSX", ".0_8                                                                                                ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("4444444444444444444444444444444444444444444c4OS4c4OS4", strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(97L, (long) 5, (long) 143);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "OS c OS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("c OS c OS ", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("C#os#xAm", "100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, ".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("08_0.7.144444444", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "C os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3" + "'", str3.equals("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concatWith("24.80-B11", (java.lang.Object[]) strArray12);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("HI!", 47);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("sun.lwawt.macosx.CPrinterJob", "jAVA(tm) se rUNTIME eNVIRONMENTmACosx                  1.7mACosx                   mACosx        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "5.41", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MACosx", "Userssophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("       Oracle Corporation       ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       Oracle Corporation       " + "'", str2.equals("       Oracle Corporation       "));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("       Oracle Corporation       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444c OS c OS" + "'", str1.equals("4444444444444444444444444444444444444444444c OS c OS"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "acOSX");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              ", "X SO caM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              " + "'", str2.equals("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                              "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("...#####################################100.0################################################ac#OS#X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) -1, (byte) 100, (byte) -1, (byte) 10, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.l", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("44444444444444444O  c  C          444444444444444444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("OS c OS", "###############################################################Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OS c OS" + "'", str2.equals("OS c OS"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 34 + "'", int1 == 34);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################", (int) (short) 1, "oracle corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################" + "'", str3.equals("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("jAVA pLATFORM api sPECIFICATION", (int) (short) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str3.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1Mac OS X0.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!" + "'", str4.equals("!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!a!"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("HI!", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("McOSX", 2, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "McOSX" + "'", str3.equals("McOSX"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("                                                                                                8_0.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("cOScOS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cOScOS" + "'", str1.equals("cOScOS"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("US10.14.3", "macosxmacosx");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("MacOSX                                                                                              ", "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MacOSX                                                                                              " + "'", str2.equals("MacOSX                                                                                              "));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", 12, "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str3.equals("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("h/users/sophie", "", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ", "24.80-B11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80", (java.lang.CharSequence) "3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 167.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 167.0f + "'", float2 == 167.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", "51.0  ", 111);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", "...#####################################100.0################################################ac#OS#X", 608);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", (int) '#', "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w" + "'", str3.equals("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                   C os C os                                                                    ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("mACosx");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: mACosx is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie ", "100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("5.41", "s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5.41" + "'", str2.equals("5.41"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444444444444444444444444444c4OS4c4OS4", 461, "c#OS#c#OS#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str3.equals("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5L, (float) 143, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Mac OS X", "51.0  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("h/users/sophie", "", " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "h/users/sophie" + "'", str4.equals("h/users/sophie"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("5.41", "                            MacOSX ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("mACosx");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mACosx" + "'", str1.equals("mACosx"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MACOSX", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/", "HI!", "                                                5.41                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi!", "noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", (-1), 461);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str4.equals("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("##############################################################################################en", "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "cOSXa...", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##############################################################################################en" + "'", str4.equals("##############################################################################################en"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 97L, (long) 111);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 111L + "'", long3 == 111L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "McOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "MacOSX1.7MacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi", 12, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        float[] floatArray3 = new float[] { 32L, 0L, 3.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass8 = floatArray3.getClass();
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 32.0f + "'", float5 == 32.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 32.0f + "'", float6 == 32.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 32.0f + "'", float7 == 32.0f);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("       ", "oracle corporatio", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       " + "'", str3.equals("       "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("c#os#xAm", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c#os#xAm" + "'", str2.equals("c#os#xAm"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("8_0.", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8_0." + "'", str2.equals("8_0."));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str3.equals("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" MacOSX ", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(458);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) 5, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("44444444444444444O  c  C          444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("X SO caM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mACosx                          ...#####################################100.0################################################ac#OS#X   ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mACosx                          ...#####################################100.0################################################c#OS#X   " + "'", str4.equals("mACosx                          ...#####################################100.0################################################c#OS#X   "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(144.0f, (float) 18L, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.0", (double) 458L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specification", 52, "pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pLATFORM Java Virtual Machine SpecificationpLATFORM " + "'", str3.equals("pLATFORM Java Virtual Machine SpecificationpLATFORM "));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 271);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 271.0f + "'", float2 == 271.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/java/extensions:/usr/lib/java:." + "'", str1.equals("/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("jAVA pLATFORM api sPECIFICATION", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sPECIFICATION api pLATFORM jAVA" + "'", str2.equals("sPECIFICATION api pLATFORM jAVA"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("UTF-8", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 8.0f, 0.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "pLATFORM Java Virtual Machine SpecificationpLATFORM ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oracle corporation", '#');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, (long) 167, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("c OS c OS ", 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("US10.14.3", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 167, (float) 'a', (float) 99);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 167.0f + "'", float3 == 167.0f);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("c OS XaM", "24#######", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str3.equals("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "C os xAm");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        long[] longArray4 = new long[] { 5L, (byte) 100, '#', 18L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", "MacOSX1.7MacOSX", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", "C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..." + "'", str2.equals("...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..."));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("...4444444444444444444444444444X4Oc44", "Cosx", "4444444444444444444444444444444444444444444c OS c OS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...4444444444444444444444444444X4Oc44" + "'", str3.equals("...4444444444444444444444444444X4Oc44"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("cOSXa...", 47, "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa..." + "'", str3.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa..."));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("noitacificepS#enihcaM#lautriV#avaJ###############################################################", "       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ###############################################################" + "'", str2.equals("noitacificepS#enihcaM#lautriV#avaJ###############################################################"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 34, (double) 8.0f, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                            Userssophie                                             ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            Userssophie                                             " + "'", str2.equals("                                            Userssophie                                             "));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("cOScOS", "PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" MacOSX x86_64", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " MacOSX x86_64" + "'", str2.equals(" MacOSX x86_64"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", 0, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...j..." + "'", str3.equals("jAVA pL...jAVA pL...jAVA pL...j..."));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("h/Users/sophie", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/Users/sophie" + "'", str2.equals("h/Users/sophie"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("jAVA pLATFORM api sPECIFICATION", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", 8, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", 1, 111);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                    ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", "sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("   /Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("44444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444" + "'", str1.equals("44444444"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", ".0_80", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("       Oracle Corporation       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       oracle corporation       " + "'", str1.equals("       oracle corporation       "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", " #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", "C#os#xAm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Userssophie", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("oracle corporatio", "mACosx                          ...#####################################100.0################################################c#OS#X   ", 96, 22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   " + "'", str4.equals("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   "));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                :", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "                                                                   c OS c OS                                                                    ", 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444", (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51." + "'", str1.equals("51."));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...5.415.415.415.415.415.415.415", "1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("MacOSX1.7MacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XSOcaM7.1XSOcaM" + "'", str1.equals("XSOcaM7.1XSOcaM"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("userssophie", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("c#OS#c#OS#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c#OS#c#OS#" + "'", str1.equals("c#OS#c#OS#"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("44444444444444444444444444444444444444444444444UTF-844444444444444444444444444444444444444444444444", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(" 24.80-B11");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("macosxmacosx", 167);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 167 + "'", int2 == 167);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lw", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lw" + "'", str3.equals("sun.lw"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" OS c OS ", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4", "C#os#xAm", 271);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("java Platform API Specification", "                                               100.0                                                ", "SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java Platform API Specification" + "'", str4.equals("java Platform API Specification"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("s", 5, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "2sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80", "Oracle Corporation", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("McOSX", (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80                                                                                            ", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "5.41", 27, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7.0_80                                                                                           ", 18, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "8_0.", (java.lang.CharSequence) "_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "NoitacificepS#enihcaM#lautriV#avaJ##############################################################", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java Vi...", "c OS XaM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Vi..." + "'", str2.equals("Java Vi..."));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("US10.14.3", "userssophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mACosx", 52, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", (double) 22L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22.0d + "'", double2 == 22.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 32, (-1));
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.lwawt.macosx.CPrinterJob");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERHI!" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERHI!"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sophie", "1.7.0_80-b15", 167);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie" + "'", str3.equals("sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                            MacOSX ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("h/users/sophie", "pLATFORM Java Virtual Machine SpecificationpLATFORM ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/users/sophie" + "'", str2.equals("h/users/sophie"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 47, (float) 16L, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("08_0...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "08_0..." + "'", str1.equals("08_0..."));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "8_0.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str1.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 170 + "'", int1 == 170);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (long) 100, (long) 170);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 170L + "'", long3 == 170L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", " 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("noitacificepS#enihcaM#lautriV#avaJ##############################################################", 608);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str2.equals("noitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s" + "'", str2.equals("s"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", "c#OS#Xa...#####################################100.0################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" 24.80-B11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ".0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ".0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "macosxmacosx");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", " 24.80-b11", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("US10.14.3", "/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US10.14.3" + "'", str3.equals("US10.14.3"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", " MacOSX                             MacOSX ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str1.equals("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", "                                                                   c OS c OS                                                                    ", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERHI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM" + "'", str3.equals("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "C os xAm", "cOSXa...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("McOSX", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("c OS c OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS c OS " + "'", str1.equals("c OS c OS "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "Java Platform API Specification", "NoitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ".0_8                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1Mac OS X0.0", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1Mac OS X0.0                       " + "'", str2.equals("1Mac OS X0.0                       "));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("userssophie", "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("...4444444444444444444444444444X4Oc44", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Cosx", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("44cO4X4444444444444444444444444444...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44cO4X4444444444444444444444444444...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   " + "'", str1.equals("oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   "));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("C#os#xAm", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("s", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s" + "'", str1.equals("s"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                               100.0                                                ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 96.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                               Java Virtual Machine Specification", "sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie1.7.0_80-b15sophie", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                               Java Virtual Machine Specification" + "'", str3.equals("                                                               Java Virtual Machine Specification"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("c os xAm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java HotSpot(TM) 64-Bit Server VM", "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

