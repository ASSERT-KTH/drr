import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(".0_80", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(51.0d, (double) 99, 144.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 144.0d + "'", double3 == 144.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) " #P#latform# #A..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Mac OS X", "cOSX                   acOSX                  1.7MaM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-b15");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "c#OS#Xa...#####################################100.0################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("\n", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java HotSpot(TM) 64-Bit Server VM", "US10.14.3", "                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                   1.7.0_80                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                   1.7.0_80                                                    " + "'", str1.equals("                                                   1.7.0_80                                                    "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("soph:sophi", "1.7.0_80                                                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                           4444444444444444444444444444444444444444444c OS c OS ", "44cO4X4444444444444444444444444444...", 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                          s", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", "1.7.0_80                                                                                           ", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("vironmentM", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "vironmentM" + "'", str4.equals("vironmentM"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("#    ", "24.80-...", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#    " + "'", str3.equals("#    "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, 1, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("CmACosx                                                                                              osmACosx                                                                                              CmACosx                                                                                              osmACosx                                                                                             ", 32, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', (double) 22L, (double) 170);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.0d + "'", double3 == 22.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "cOSXa...", 10, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("userssophi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", "24.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("     ", "jAVA pL...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("cMacOcOX   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("51.0  ", 96);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0Us 2s0s 1h4 0L4b222y0 2420Ex1  s4  s:0L4b222y0 2420 242V421u2-M22h4  s0jdk1.7.0_80.jdk0C  1  1s0H 4 0j2 0-4b0 x1:0L4b222y0 2420Ex1  s4  s:0N 1w", "                  Userssophi                   ", 110);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "C#os#xAm");
        java.lang.String[] strArray10 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", "sun.lwawt.macosx.LWCToolkit", "\n", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" };
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray14, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", strArray10, strArray14);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach(".0_ihpossresU", strArray2, strArray14);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b11" + "'", str4.equals("24.80-b11"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.7.0_80" + "'", str19.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..." + "'", str20.equals("sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa..."));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + ".0_ihpossresU" + "'", str21.equals(".0_ihpossresU"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("macosxmacosx", "4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(143);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ", (java.lang.CharSequence) "444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...java pl...", 0, 44);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...java pl...java pl...java pl...java pl...j" + "'", str3.equals("...java pl...java pl...java pl...java pl...j"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten" + "'", str1.equals("hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "... MROFTALp AVAjNOITACIFICEPs ip MROFTALp AVAj" + "'", str1.equals("... MROFTALp AVAjNOITACIFICEPs ip MROFTALp AVAj"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray6, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '4', (int) (byte) 1, (int) (byte) 1);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", strArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Mac OS X", strArray10);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("24.80-b11", "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                            MacOSX ", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                            MacOSX ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("24.80-B11", 3, 181);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/" + "'", str1.equals("coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ihpossresU", 271.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 271.0d + "'", double2 == 271.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                                            Userssophie                                             ", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("cepS#enih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cepS#enih" + "'", str1.equals("cepS#enih"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                        OS c OS ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                  Userssophi                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("...44444444444444444444444444..", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10.14.3", "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", "4444444444444444444444444444444444444444444c OS c OS ", 143);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("       oracle corporation       ", "sPECIFICATION api pLATFORM jAVA", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", 181, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO" + "'", str4.equals("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("###############################################################Java#Virtual#Machine#Specification", "4444444444444444444444444444444444444444444c OS c OS", (int) '#', 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#####4444444444444444444444444444444444444444444c OS c OS############################Java#Virtual#Machine#Specification" + "'", str4.equals("#####4444444444444444444444444444444444444444444c OS c OS############################Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("cepS#enih", 105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" MacOSX ", "Mac OS X", 167);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444444", 52, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" 24.80-b11", "hi!1Mac OS X0.0hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mACosx", "                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1014");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "3avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/41avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/.avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/01avaj/bil/rsu/:snoisnetxe/avaj/yrarbil/metsys/:snoisnetxe/avaj/yrarbil/krowten/:snoisnetxe/avaj/yrarbil/:txe/bil/:snoisnetxe/avaj/yrarbil/eihpos/sresu/su", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("44444444444444444444444441.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444444444441.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("MacOSX1.7MacOSX", "1014", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("8_0.", "10.14.", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8_0." + "'", str3.equals("8_0."));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(".0_ihpossresU", "h/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1, 9, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "userssophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "acOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwa...", 0, "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwa..." + "'", str3.equals("sun.lwa..."));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("java Platform API Specification", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("pLATFORM Java Virtual Machine SpecificationpLATFORM ", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pLATFORM Java Virtual Machine SpecificationpLATFORM " + "'", str3.equals("pLATFORM Java Virtual Machine SpecificationpLATFORM "));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("sEnvironmentsun.awt.CGrcOSXa", 181);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", "MacOSX                  1.7MacOSX                                                                                                              ", 111);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", "sun.l", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" #P#latform# #A...", "ification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ification" + "'", str2.equals("ification"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", 167, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Userssophie");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", "##############################################################Java#Virtual#Machine#Specificatio", 1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray16);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray18);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("44cO4X4444444444444444444444444444...", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                   1.7.0_80                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 111 + "'", int1 == 111);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latfor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixed mode                                                                                                          s                           ", 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor", "", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 111, "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 8, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", "cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              " + "'", str2.equals("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.", " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "c#OS#Xa...#####################################100.0################################################", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                :", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX" + "'", str1.equals("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(".0_8                                                                                                ", 47, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 10, 105);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 105 + "'", int3 == 105);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "java Platform API Specification", "sun.lwa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", "...44444444444444444444444X4Oc44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str2.equals(" OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        double[] doubleArray5 = new double[] { (short) 1, 10, 1, (-1), (-1.0f) };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", (int) (short) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "24#######" + "'", str5.equals("24#######"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("c#os#x", "44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c#os#x" + "'", str2.equals("c#os#x"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("cMacOcOX   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"cMacOcOX   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION#j#AVA# #p#LATFORM# #api# #s#PECIFICATION", (java.lang.CharSequence) "Java Vi...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("oracle corporation", strArray4, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Platform API Specification", strArray4);
        java.lang.Class<?> wildcardClass11 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "oracle corporation" + "'", str9.equals("oracle corporation"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", (java.lang.CharSequence) "NoitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("c OS c OS ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS c OS " + "'", str3.equals("c OS c OS "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "c OS c OS " + "'", str4.equals("c OS c OS "));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(100L, 97L, (long) 181);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "1.7", (int) (short) -1);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361" + "'", str6.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r", "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("A/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa...", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO###################################sun.lwa...##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO####################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("c OS Xa...                                     100.0                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 31, "44444444444444444444444444444444444444444444444444444c4OS4c4OS4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(".", "4444444444444444444444444444444444444444444c OS c OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("C os xAmC pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFOR");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU." + "'", str5.equals(".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU."));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(".0_80");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80                                                                                           ", (float) 111);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 111.0f + "'", float2 == 111.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 8, "1014");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "NoitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("macosxmacosx", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "macosxmacosx" + "'", str3.equals("macosxmacosx"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("C os xAm", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "C os xAm" + "'", str2.equals("C os xAm"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "NoitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 458, (double) 18L, (double) 608.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 608.0d + "'", double3 == 608.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "                                                   1.7.0_80                                                    ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str1.equals("SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "...44444444444444444444444444..", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("                               ", "44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, (double) 27, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4444444444444444444444444444444444444444444c4OS4c4OS4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444c4OS4c4OS4" + "'", str1.equals("4444444444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("08_0...", 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String[] strArray2 = new java.lang.String[] { "noitacificepS#enihcaM#lautriV#avaJ###############################################################" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("pLATFORM Java Virtual Machine SpecificationpLATFORM ", strArray2, strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "pLATFORM Java Virtual Machine SpecificationpLATFORM " + "'", str6.equals("pLATFORM Java Virtual Machine SpecificationpLATFORM "));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                            08_0.7.1", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10.14.", "                                                5.41                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "###############################################################Java#Virtual#Machine#Specification", (java.lang.CharSequence) "MacOSX                  1.7MacOSX                   ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "###############################################################Java#Virtual#Machine#Specification" + "'", charSequence2.equals("###############################################################Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "24.80-b11", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10895_1560229361", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "08_0.7.144444444", "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                ", "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0                                                "));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(143, 32, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 143 + "'", int3 == 143);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                   c OS c OS                                                                    ", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   c OS c OS                                                                    " + "'", str2.equals("                   c OS c OS                                                                    "));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(".0_80", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   .0_80" + "'", str2.equals("   .0_80"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("c#OS#c#OS#", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl tform API Specific tionJ v  Pl", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 35, 1014);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("jAVA pL...", "/Users/sophie", "       Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pL..." + "'", str3.equals("jAVA pL..."));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("-b15", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-b15                                                                                                " + "'", str2.equals("-b15                                                                                                "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ", (int) (byte) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("08_0.7.144444444   08_0.7.144444444   08_0.7.144444444   08_0.7.144444444", "noitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("XSOcaM7.1XSOcaM", 10, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        int[] intArray6 = new int[] { 9, 170, 16, 1, (byte) 10, 1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 170 + "'", int7 == 170);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 170 + "'", int8 == 170);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.7f, 0.0d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                            Userssophie                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                            Userssophie                                            " + "'", str1.equals("                                            Userssophie                                            "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "MacOSX", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM pi sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION", "PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/uSERS/SOPHIE", "     ", "8_0.");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM  24.80-B11PECIFICATIONjAVA pLATFORM api sPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String[] strArray3 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw", strArray3, strArray6);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny("Java(TM) SE Runtime Environment", strArray6);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny("1.7.0_80-b15", strArray6);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a', 8, 0);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw" + "'", str13.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Netw"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", "                                                               Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c#OS#c#OS#", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                   1.7.0_80                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                    08_0.7.1                                                   " + "'", str1.equals("                                                    08_0.7.1                                                   "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                            MacOSX 1.7.0_80-b15", (int) (byte) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                            Userssophie                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Userssophie" + "'", str1.equals("Userssophie"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle Cor");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("!ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: !ih is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", 461);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS " + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444c OS c OS "));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".0_8", "", (int) '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("sun.awt.CGraphicsEnvironment", (java.lang.Object[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("4444444444444444444444444444444", (java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ".0_8" + "'", str6.equals(".0_8"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ".0_8" + "'", str7.equals(".0_8"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("MacOSX1.7MacOSX", "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("24.80-...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mACosx                          ...#####################################100.0################################################c#OS#X   ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("ification", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 170 + "'", int2 == 170);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 10, (float) 100, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("10.14.3", "   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                                                8_0.", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) (byte) 100, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                  Userssophi                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  Userssophi                   " + "'", str1.equals("                  Userssophi                   "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        char[] charArray4 = new char[] { ' ' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S", "/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("c OS Xa...                                     100.0                                                ", 110, "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Platfc OS Xa...                                     100.0                                                Platf" + "'", str3.equals("Platfc OS Xa...                                     100.0                                                Platf"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444" + "'", str1.equals("444444"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(22.0f, 95.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 95.0f + "'", float3 == 95.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(1L, 0L, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("51.0  ", "C os xAmC os xAmC os xAm..", (int) (short) 1, 37);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "5C os xAmC os xAmC os xAm.." + "'", str4.equals("5C os xAmC os xAmC os xAm.."));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(" #P#latform# #A...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " #P#LATFORM# #A..." + "'", str1.equals(" #P#LATFORM# #A..."));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 6, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("mACosx", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mACosx" + "'", str2.equals("mACosx"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("##############################################################################################en", " 24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################################################en" + "'", str2.equals("##############################################################################################en"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...", "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ..." + "'", str2.equals("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ..."));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                ", 461);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Mac                                                                                                          sOS                                                                                                          sX", "                ", "jAVA pL...jAVA pL...jAVA pL...j...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacjAVA pL...jAVA pL...jAVA pL...j...                                                                                          sOS                                                                                                          sX" + "'", str3.equals("MacjAVA pL...jAVA pL...jAVA pL...j...                                                                                          sOS                                                                                                          sX"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                               Java Virtual Machine Specification", "                               ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 458);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...", "Java(TM) SE Runtime Environment", "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("-b15", "/Java/Extensions:/usr/lib/java:.", 96, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Java/Extensions:/usr/lib/java:." + "'", str4.equals("/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 442 + "'", int2 == 442);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS#enihcaM#lautriV#avaJ###############################################################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sEnvironmentsun.awt.CGrcOSXa", (int) 'a', "Userssophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sEnvironmentsun.awt.CGrcOSXaUserssophieUserssophieUserssophieUserssophieUserssophieUserssophieUse" + "'", str3.equals("sEnvironmentsun.awt.CGrcOSXaUserssophieUserssophieUserssophieUserssophieUserssophieUserssophieUse"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("...5.415.415.415.415.415.415.415", "4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...5.415.415.415.415.415.415.415" + "'", str2.equals("...5.415.415.415.415.415.415.415"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "ficepS#enih");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1014", (java.lang.CharSequence) "jAVA pL...jAVA pL...jAVA pL...j...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("MACOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MACOSX" + "'", str1.equals("MACOSX"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 458);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Userssophie");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "noitacificepS#enihcaM#lautriV#avaJ##############################################################", (int) 'a', 0);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny("                            MacOSX 1.7.0_80-b15orporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", strArray4);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.startsWithAny("Oracle Cor", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Userssophie", "C#os#xAm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("VM Server 64-Bit HotSpot(TM) Java", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten", "                                                                                                8_0.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten" + "'", str2.equals("hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        long[] longArray6 = new long[] { 18, (-1), (short) -1, (byte) 0, 0L, 'a' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.Class<?> wildcardClass10 = longArray6.getClass();
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO" + "'", str1.equals("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mac OS X", 96, "                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X                                                                                        " + "'", str3.equals("Mac OS X                                                                                        "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("     ", "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S" + "'", str1.equals("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("                                                               Java Virtual Machine ", "cepS#enih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("51.0  ", "", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("userssophieC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAmC os xAm", 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                   c os c os                                                                    ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("cepS#enih", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cepS#enih" + "'", str3.equals("cepS#enih"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten" + "'", str2.equals("hie/library/java/extensions:/lib/ext:/library/java/extensions:/network/library/java/exten"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 18, 110);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 110 + "'", int3 == 110);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("macosxmacosx");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"macosxmacosx\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 144, 97.0d, (double) 5L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str8.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JAVA P", 99, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################JAVA P###############################################" + "'", str3.equals("##############################################JAVA P###############################################"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("noitacificepS#enihcaM#lautriV#avaJ##############################################################", (int) ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str3.equals("noitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 608, 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                               Java Virtual Machine ", "444444444444444444444444444444444444444444444McOSX4444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               Java Virtual Machine " + "'", str2.equals("                                                               Java Virtual Machine "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi1.7.0_80/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachi", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("4444444444444444444444444444444444444444444444XSOcM444444444444444444444444444444444444444444444", "mACosx                          ...#####################################100.0################################################ac#OS#X   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15...#####################################100.0################################################ac#OS#X1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S" + "'", str1.equals("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/S"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGrcOSXa...", (java.lang.CharSequence) "PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("24#######");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24#######\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sEnvironmentsun.awt.CGrcOSXaUserssophieUserssophieUserssophieUserssophieUserssophieUserssophieUse", "Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str1.equals("...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaM", (int) (byte) 1);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80", strArray4, strArray9);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("   ", strArray4, strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80" + "'", str11.equals(".0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_802sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa...sun.lwa....0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80.0_80"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "   " + "'", str17.equals("   "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("cOSXa...", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1Mac OS X0.0", "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("noitacificepS#enihcaM#lautriV#avaJ###############################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS#enihcaM#lautriV#avaJ###############################################################" + "'", str1.equals("noitacificepS#enihcaM#lautriV#avaJ###############################################################"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "VM Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("US4104.4144.43", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("24.80-...", "51.0  ", 44);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51.0", "cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Userssophie", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44OS4XM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 52L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                               Java Virtual Machine ", "sPECIFICATION api pLATFORM jAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               Java Virtual Machine " + "'", str2.equals("                                                               Java Virtual Machine "));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(".0_8", 608);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "oracle corporation", (int) 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", 44, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1L, (double) 31, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("NoitacificepS#enihcaM#lautriV#avaJ##############################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NoitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str1.equals("NoitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hisophie!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("     ", "c OS Xa...                                     100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("       Oracle Corporation       ", "                                                                                            08_0.7.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX", (int) ' ', 37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7MacO" + "'", str3.equals("7MacO"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "O  c  C", "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                               100.0                                                ", "sophie", 100);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("#    ", "/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Userhi!", 22);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str9.equals("/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 110, (float) 461, (float) 111);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 461.0f + "'", float3 == 461.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                      ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("...#####################################100.0################################################ac#OS#X", "5.41");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...#####################################100.0################################################ac#OS#X" + "'", str2.equals("...#####################################100.0################################################ac#OS#X"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("JAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATIONJAVA PLATFORM PI SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJ" + "'", str1.equals("NOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJNOITACIFICEPS IP MROFTALP AVAJ"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sEnvironmentsun.awt.CGrcOSXa", "/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sEnvironmentsun.awt.CGrcOSXa" + "'", str2.equals("sEnvironmentsun.awt.CGrcOSXa"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("44444444444444444O  c  C          444444444444444444", "c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", 110, 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM" + "'", str4.equals("44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "5.41", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "acOSX", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1Mac OS X0.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1Mac OS X0.0", "/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1Mac OS X0.0" + "'", str2.equals("1Mac OS X0.0"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("C os xAmC os xAmC os xAm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C os xAmC os xAmC os xAm" + "'", str1.equals("C os xAmC os xAmC os xAm"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", (int) (byte) 0, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" OS c OS aaaaaaaaaaaaaaaaaaaaaaa", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa" + "'", str2.equals("aaaaaaa"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("...java pl...java pl...java pl...java pl...j", " 24.80-...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...java pl...java pl...java pl...java pl...j" + "'", str2.equals("...java pl...java pl...java pl...java pl...j"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                               Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon" + "'", str1.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("...5.415.415.415.415.415.415.415", "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "c#OS#Xa...#####################################100.0################################################", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                :", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                               100.0                                                ", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "5.41sun.l", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("macosxmacosx");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mac\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("44444444444444444444444444444444444444444444444UTF-8444444444444444444444444444444444444444444444444", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "...4444444444444444444444444444X4Oc44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(":#P#l:tform#:#A:::", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific" + "'", str1.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specific"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                  Userssophi                   ", "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                   c os c os                                                                    ", "JAVA P");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("       ", " #P#latform# #A...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "...4444444444444444444444444444X4Oc44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(".", 110, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals(".aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", "#    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophi1.7.0_80/Users/sophi", "c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#OS#c#O4444444444444444444444444444444444444444444c4OS4c4OS4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi1.7.0_80/Users/sophi" + "'", str2.equals("/Users/sophi1.7.0_80/Users/sophi"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MacOSX                  1.7MacOSX                                                                                                              ", "1014");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52L, 271.0f, 5.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 271.0f + "'", float3 == 271.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "#    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#    " + "'", str2.equals("#    "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("       Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion" + "'", str1.equals("Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(".0_8                                                                                                ", "oracle corporatiomACosx                          ...#####################################100.0################################################c#OS#X   ", "macosxmacosxmacosxmacosxmacosxmacosxmacosxmac os xa...                                     100.0                                                ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444c4OS4c4OS4", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("ECIFICATIO", "", "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ECIFICATIO" + "'", str3.equals("ECIFICATIO"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "c OS c OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C OS c OS " + "'", str1.equals("C OS c OS "));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(7, 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("X SO caM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "...44444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "444444444444444444444444444444444444444444444MacOSX4444444444444444444444444444444444444444444444", "PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c OS c OS ", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US10.14.3", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny("/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("OS c OS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OS c OS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        long[] longArray4 = new long[] { (-1L), (byte) 1, (short) 10, 458 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 458L + "'", long5 == 458L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 458L + "'", long6 == 458L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"PlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MacjAVA pL...jAVA pL...jAVA pL...j...                                                                                          sOS                                                                                                          sX", "44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "OITACIFICEPS#ENIHCAM#LAUTRIV#AVAJ##############################################################", (java.lang.CharSequence) "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 92 + "'", int2 == 92);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(" 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 2", (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("cOScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("UTF-8", "ECIFICATIO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("..._...", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             ..._...              " + "'", str2.equals("             ..._...              "));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("COX", "ficepS#enih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "COX" + "'", str2.equals("COX"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("c OS c OS c OS c OS c OS c OS c OS c OS ", "c OS XaM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS c OS c OS c OS c OS c OS c OS c OS " + "'", str2.equals("c OS c OS c OS c OS c OS c OS c OS c OS "));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                    Userssophie                     ", "24.80-b11", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("h/Users/sophie", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                               100.0", 8, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("8_0.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8_0." + "'", str2.equals("8_0."));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("c os xAm", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentMacOSX                  1.7MacOSX                   MacOSX        ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", charSequence2.equals("44cO4X4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, (int) (short) -1, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "MACOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44cO4X4444444444444444444444444444...44cO4X4444444444444444444444444444...44cO4X44444444444444444!ih", 16L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) ".0_ihpossresU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("44cO4X4444444444444444444444444444...", 3, 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac OS Xa...                                     100.0                                                ", "Java(TM)SERuntimeEnvironmentMacOSX1.7MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3", 111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 741 + "'", int2 == 741);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uS" + "'", str1.equals("uS"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mACosx                                                                                              ", "h/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("24", "hi!1Mac OS X0.0hi!", "...5. 15. 15. 15. 15. 15. 15. 15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24" + "'", str3.equals("24"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("NoitacificepS#enihcaM#lautriV#avaJ##############################################################", "VM Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NoitacificepS#enihcaM#lautriV#avaJ##############################################################" + "'", str2.equals("NoitacificepS#enihcaM#lautriV#avaJ##############################################################"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                    Userssophie                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "MacOSX                  1.7MacOSX                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "sPECIFICATION api pLATFORM jAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "userssophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("OS c OS", "jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ScS" + "'", str3.equals("ScS"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Libr1ry/J1v1/J1v1Virtu1l51.hines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        int[] intArray5 = new int[] { 8, 100, (byte) 0, (short) 1, 144 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 144 + "'", int8 == 144);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 144 + "'", int9 == 144);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 144 + "'", int10 == 144);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("C#os#xAm", "eihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihposeihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "C#os#xAm" + "'", str2.equals("C#os#xAm"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("PltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPl", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151/", (int) (short) -1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "24#######" + "'", str6.equals("24#######"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 96 + "'", int7 == 96);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "coscosatform api specificationjava platform api specificationjava platform api specificationjava pl/", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("c OS c OS ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS c OS " + "'", str2.equals("c OS c OS "));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("44444444444444444O  c  C          444444444444444444c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM24#######c OS XaM", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("c OS XaMc Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platfor");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444444444444444444444444444444444444c4OS4c4OS4");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Exten", (float) 96);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.0f + "'", float2 == 96.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(100.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                               ", "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..." + "'", str2.equals("jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL...jAVA pL..."));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                   1.7.0_80                                                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("cMacOcOX   ", "en", "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cMacOcOX   " + "'", str3.equals("cMacOcOX   "));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MACOSX", ".0_8                                                                                                ");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("4444444444444444444444444444444444444444444c4OS4c4OS4", strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("OS c OS", strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("C os xAm", strArray4, strArray8);
        java.lang.Class<?> wildcardClass11 = strArray8.getClass();
        java.lang.Class<?> wildcardClass12 = strArray8.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "C os xAm" + "'", str10.equals("C os xAm"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.7.0_80                                                                                           ", " MacOSX ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80                                                                                           " + "'", str2.equals("1.7.0_80                                                                                           "));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(44.0d, (double) 10.0f, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "444444");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, " OS c OS aaaaaaaaaaaaaaaaaaaaaaa", 0, 0);
        java.lang.Class<?> wildcardClass11 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                ", "4444444444444444444444444444444444444444444c OS c OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                " + "'", str2.equals("                "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("http://java.oracle.com/", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Co\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1.7", "O  c  C          MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaaMacOSX  MacOSX  MacOSX  MacO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                          s", "8_0.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA...", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str2.equals("SUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "cMacOcOX   ", (java.lang.CharSequence) "MacOSX                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("c OS c OS ");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "c OS c OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "sun.l");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Us5.41ectsj/tmp/run_randoop.pl_10895_1560229361/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("noitacificepS#enihcaM#lautriV#avaJ##############################################################", 144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 144 + "'", int2 == 144);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "sun.awt.CGraphicsEnvironment", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        float[] floatArray6 = new float[] { 9, (short) 1, ' ', '#', 100L, 35 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444", "RACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444" + "'", str2.equals("444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444444444444c OS c OS 4444444444444444444444444444444444"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" #P#latform# #A...", "                            MacOSX 1.7.0_80-b15");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith(":", (java.lang.Object[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":#P#l:tform#:#A:::" + "'", str4.equals(":#P#l:tform#:#A:::"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#P#l08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmCtform#08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#A08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC" + "'", str6.equals("08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#P#l08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmCtform#08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC#A08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                              xsoCAmso                                                                                              xsoCAmC                                                                                              xsoCAmso                                                                                              xsoCAmC"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny(" #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification#J#ava# #P#latform# #API# #S#pecification", strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "444444");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ', (int) (byte) 10, 461);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("44444444444444444444444444444444444444444444444444444c4OS4c4OS4", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444c4OS4c4OS4" + "'", str2.equals("4444444444444444444444444444444444444c4OS4c4OS4"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("US10.14.3", "c/Users/sophie /Users/sophieOS/Users/sophie /Users/sophiec/Users/sophie /Users/sophieOS/Users/sophie ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                            08_0.7.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            08_0.7" + "'", str2.equals("                                                                                            08_0.7"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkit", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", "US/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java10/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java14/Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("cMacOSX                                                                                              OSMacOSX                                                                                              cMacOSX                                                                                              OSMacOSX                                                                                              ", ":#P#l:tform#:#A:::");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("##############################################################JAVA#VIRTUAL#MACHINE#SPECIFICATIO", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11224.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b112", 608);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("c OS X#...                                     100.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" MacOSX x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MacOSX x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("c OS c OS ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w", "   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                               ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("  ", "3avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/41avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/01avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/SU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("jAVA pL...jAVA pL...jAVA pL...j...", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(".0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.0_ihpossresU.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("4444444444444444444444444444444444444444444c4OS4c4OS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX" + "'", str1.equals("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', (int) (byte) 100, (int) (byte) -1);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray16);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("c OS c OS ", ' ');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray16, strArray20);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny("!ih", strArray20);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, '4', (int) (byte) 1, (int) (byte) 1);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEach("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon", strArray6, strArray20);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEach("/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", strArray2, strArray20);
        int int29 = org.apache.commons.lang3.StringUtils.indexOfAny(" #P#LATFORM# #A...", strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.7.0_80" + "'", str21.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon" + "'", str27.equals("Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificatiJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatioon"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str28.equals("/US5.41ECTSJ/TMP/RUN_RANDOOP.PL_10895_1560229361/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" #P#latform# #A...", (double) 22.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22.0d + "'", double2 == 22.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Platfc OS Xa...                                     100.0                                                Platf", 10, 110);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Xa...                                     100.0                                                Platf" + "'", str3.equals("Xa...                                     100.0                                                Platf"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444" + "'", str1.equals("444444"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("1.7.0_80", strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("                                                                   C os C os                                                                    ", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "MACosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444444444444444444444c4OS4c4OS", "0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("a/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "COScOSATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                            MacOSX 1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX1.7.0_80-b15" + "'", str1.equals("MacOSX1.7.0_80-b15"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sUN.LWA...SUN.LWA...SUN.LWA...SUN.Lsun.awt.CGraphicsEnvironmentA...SUN.LWA...SUN.LWA...SUN.LWA..", "jAVA pL...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA/USERHI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "c OS XaM");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray6);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("24", strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Us 2s/s 1h4 /L4b222y/ 242/Ex1  s4  s:/L4b222y/ 242/ 242V421u2-M22h4  s/jdk1.7.0_80.jdk/C  1  1s/H 4 /j2 /-4b/ x1:/L4b222y/ 242/Ex1  s4  s:/N 1w");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "w1 N/:s  4s  1xE/242 /y222b4L/:1x /b4-/ 2j/ 4 H/s1  1  C/kdj.08_0.7.1kdj/s  4h22M-2u124V242 /242 /y222b4L/:s  4s  1xE/242 /y222b4L/ 4h1 s/s2 sU/" + "'", str1.equals("w1 N/:s  4s  1xE/242 /y222b4L/:1x /b4-/ 2j/ 4 H/s1  1  C/kdj.08_0.7.1kdj/s  4h22M-2u124V242 /242 /y222b4L/:s  4s  1xE/242 /y222b4L/ 4h1 s/s2 sU/"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Orcle Corportion/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/       Orcle Corportion\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-b15", "100.0", 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "hi!");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray12);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "");
        int int16 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("0", strArray6, strArray15);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "", 170);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray6, strArray21);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray21, "ficepS#enih");
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "/");
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray27, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray27, "", (int) (short) 100, (int) ' ');
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray27, 'a');
        java.lang.String str36 = org.apache.commons.lang3.StringUtils.replaceEach("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_", strArray21, strArray27);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTF-8" + "'", str22.equals("UTF-8"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_" + "'", str36.equals("ndoop.pl_10895_1560229361a/Users/sophie/Documents/defects4j/tmp/run_"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" #P#latform# #A..", "oracle corporation", "s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " #P#latform# #A.." + "'", str3.equals(" #P#latform# #A.."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_10895_1", 96, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "doop" + "'", str3.equals("doop"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("vironmentM", "44444444444444444OcC444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vironmentM" + "'", str2.equals("vironmentM"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" OS c OS aaaaaaaaaaaaaaaaaaaaaaa", "cOScOS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " OS c OS aaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals(" OS c OS aaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Oracle Corporation is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/", ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "va platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specifi");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("jAVA pLATFORM pi sPECIFICATIONjAVA pLATFORM ...", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/" + "'", str5.equals("/"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX  MacOSX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..." + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA...SUN.LWA..."));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) ".0_8                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java Vi...", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(6.0f, 144.0f, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sPECIFICATION api pLATFORM jAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("C os xAm", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("racle corporation", "08_0.7.144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##############################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "...hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", 0, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##############################################################jAVA#vIRTUAL#mACHINE#sPECIFICATIO", "", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specification", 3, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("coscosatform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "   .0_80", "cMacOcOX   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Java/Extensions:/usr/lib/java:."));
    }
}

