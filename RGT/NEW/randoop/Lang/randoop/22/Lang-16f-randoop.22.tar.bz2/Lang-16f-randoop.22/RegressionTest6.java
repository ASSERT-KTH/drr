import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276/target/classes:/Users/sophi...", "Oracle Corporation", "         ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("            !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "            !" + "'", str1.equals("            !"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("en");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hihi!hi!hi!hi", strArray2, strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!hi!hi!hihi!hi!hi!hi" + "'", str5.equals("hi!hi!hi!hihi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("JAVAPLATFORMAPISPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAPLATFORMAPISPECIFICATION" + "'", str1.equals("JAVAPLATFORMAPISPECIFICATION"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        char[] charArray12 = new char[] { '4', 'a', '#', '4', 'a', 'a' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                        24.80-b11", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#####################################################################Java(TM) SE Runtime Environment", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "           10.14.3            ", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("java platform api specification", "    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "24. 0ab11");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaa/Li                              ", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 6 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("SUN.AWT.cgRAPHICSeNVIRONMENT", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str2.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("44", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7", 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7" + "'", str3.equals("1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                      ", "JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATIO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ", "#############oRACLE cORPORATION", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(30.0f, (float) 50, (float) 4L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (long) 1, (long) 23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "ihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str2.equals("t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#############oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("RACRACL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("           10.14.3            ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           10.14.3            ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("            !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "            !" + "'", str1.equals("            !"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        double[] doubleArray6 = new double[] { '#', 100L, (byte) 1, (short) 1, (short) 1, (short) 1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.Class<?> wildcardClass9 = doubleArray6.getClass();
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "24. 0ab11");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "/Users/sophie");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("24.80-b11", ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio", strArray13, strArray18);
        java.lang.Class<?> wildcardClass20 = strArray18.getClass();
        char[] charArray30 = new char[] { '#', ' ', 'a', ' ', '4', '4' };
        boolean boolean31 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b1", charArray30);
        boolean boolean32 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray30);
        boolean boolean33 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "    Java Platform API Specification", charArray30);
        java.lang.Class<?> wildcardClass34 = charArray30.getClass();
        double[] doubleArray41 = new double[] { '#', 100L, (byte) 1, (short) 1, (short) 1, (short) 1 };
        double double42 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray41);
        double double43 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray41);
        java.lang.Class<?> wildcardClass44 = doubleArray41.getClass();
        java.lang.Class<?> wildcardClass45 = doubleArray41.getClass();
        java.lang.String[] strArray49 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "24. 0ab11");
        java.lang.String[] strArray51 = org.apache.commons.lang3.StringUtils.stripAll(strArray49, "/Users/sophie");
        java.lang.String[] strArray54 = org.apache.commons.lang3.StringUtils.split("24.80-b11", ' ');
        java.lang.String str55 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio", strArray49, strArray54);
        java.lang.Class<?> wildcardClass56 = strArray54.getClass();
        org.apache.commons.lang3.SystemUtils systemUtils57 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils58 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils59 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray60 = new org.apache.commons.lang3.SystemUtils[] { systemUtils57, systemUtils58, systemUtils59 };
        java.lang.String str61 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray60);
        java.lang.Class<?> wildcardClass62 = systemUtilsArray60.getClass();
        java.lang.reflect.Type[] typeArray63 = new java.lang.reflect.Type[] { wildcardClass9, wildcardClass20, wildcardClass34, wildcardClass45, wildcardClass56, wildcardClass62 };
        java.lang.String str64 = org.apache.commons.lang3.StringUtils.join(typeArray63);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio" + "'", str19.equals("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio"));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio" + "'", str55.equals("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio"));
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(systemUtilsArray60);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(typeArray63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "class [Dclass [Ljava.lang.String;class [Cclass [Dclass [Ljava.lang.String;class [Lorg.apache.commons.lang3.SystemUtils;" + "'", str64.equals("class [Dclass [Ljava.lang.String;class [Cclass [Dclass [Ljava.lang.String;class [Lorg.apache.commons.lang3.SystemUtils;"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("      2       ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/Jantents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      2       " + "'", str2.equals("      2       "));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("hi!hi!hi!hihi!hi!hi!hi", "JAVAPLATFORMAPISPE...form...ATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hihi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hihi!hi!hi!hi"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "      ", (java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("U2 .80 b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "U2 .80 b" + "'", str1.equals("U2 .80 b"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en24.0ab11", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie", '#');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "S", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("44444444444444444444444444444444444444444444mac os x444444444444444444444444444444444444444444444", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444mac os x444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444mac os x444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "RACLE.COM/51.0                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444           24.80-B11            ", (java.lang.CharSequence) "1.7j/tmp/run_randoop.pl_96051_1560211276", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Users/sophie/Library/Java/Extensi", (java.lang.CharSequence) "UTF-8", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", "             !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio" + "'", str2.equals("    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      " + "'", str1.equals("                      "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/USERS/SOPHI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "su24. 0ab11.24. 0ab11w24. 0ab11w24. 0ab11.m24. 0ab11sx.24. 0ab11P24. 0ab11J24. 0ab11b", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOR", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" Platform API Specificat");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlatformAPISpecificat" + "'", str1.equals("PlatformAPISpecificat"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           10.14.3            ", (java.lang.CharSequence) "/#Users#/#sophie#/#Documents#/#defects#4#j#/#tmp#/#run#_#randoop#.#pl#_#96051#_#1560211276#/#target#/#classes#:/#Users#/#sophie#/#Documents#/#defects#4#j#/#framework#/#lib#/#test#_#generation#/#generation#/#randoop#-#current#.#jar");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           10.14.3            " + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           10.14.3            "));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion[] javaVersionArray5 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion1, javaVersion2, javaVersion3, javaVersion4 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) javaVersionArray5, '4');
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(javaVersionArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.11.11.71.61.7" + "'", str6.equals("1.11.11.71.61.7"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.141.141.741.641.7" + "'", str8.equals("1.141.141.741.641.7"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/soph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/soph" + "'", str1.equals("/Users/soph"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("java platform api specification", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification" + "'", str2.equals("java platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("2.8", "1.5", "                                                                                                    ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JAVA PLATFORM API SPECIFICATION", 2, "jacosx.CPrinterJobawt.masun.lwja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str3.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "class [Dclass [Ljava.lang.String;class [Cclass [Dclass [Ljava.lang.String;class [Lorg.apache.commons.lang3.SystemUtils;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                        24.80-b11 Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ", ".7/Li1.7/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "EN", (java.lang.CharSequence) "sun.lwawt.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                      sun.lwawt.macosx.cprinterjo", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", ":44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 8, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "            !", (java.lang.CharSequence) "1.aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276", 0, "    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "24s.s s0sabs11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (long) '4', 22L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(57, (-1), 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57 + "'", int3 == 57);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4444444444444", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444" + "'", str2.equals("44444444444444444444444444"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("         ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray7, strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mac OS X", strArray3, strArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "mac OS X" + "'", str14.equals("mac OS X"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ", "24.80-b::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     " + "'", str2.equals("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276/target/classes:/Users/sophi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276/target/classes:/Users/sophi..." + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276/target/classes:/Users/sophi..."));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.141.141.741.641.7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("on    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction", 69);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion0.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str6 = javaVersion0.toString();
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9" + "'", str4.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444           24.80-B11            ", (java.lang.CharSequence) "       ", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(":44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 3379);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X SO cam" + "'", str1.equals("X SO cam"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        long[] longArray3 = new long[] { 0L, '#', 3379 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.Class<?> wildcardClass5 = longArray3.getClass();
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3379L + "'", long4 == 3379L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3379L + "'", long8 == 3379L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/U...", (float) 22);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        short[] shortArray5 = new short[] { (short) 0, (byte) 1, (short) 10, (byte) 100, (byte) 0 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "j#V# hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "24. 0ab11");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sophie");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("24.80-b11", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio", strArray4, strArray9);
        java.lang.Class<?> wildcardClass11 = strArray9.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "24.80-b::::::::::::::::::::::::::::");
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hihi!hi!hi!hi", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio" + "'", str10.equals("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "24.80-b11" + "'", str13.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-B1");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "Oracle Corporation");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("3.41.01", strArray3, strArray7);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "hi!", 100);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", strArray7, strArray14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3.41.01" + "'", str10.equals("3.41.01"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio" + "'", str15.equals("Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', (long) 52, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) ":44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.141.141.741.641.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.141.141.741.641.7" + "'", str1.equals("1.141.141.741.641.7"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.lwwt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWWT" + "'", str1.equals("SUN.LWWT"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("      ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "        ", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "24.0ab11");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7", (java.lang.CharSequence) "racle.com/51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("U2 .80 b", "0ab11", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/Ja ntents/Home/jre");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b11" + "'", str4.equals("24.80-b11"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("a", "24s.s s0sabs11", "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/USERS/SOPHI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/USERS/SOPHI is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("eihpos/sresU/", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/" + "'", str2.equals("eihpos/sresU/"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                  24.80-b                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                  24.80-b                                                   " + "'", str1.equals("                                                  24.80-b                                                   "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction", 8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(":", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                             3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                             3.41.01" + "'", str1.equals("                                                                                             3.41.01"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("2", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2" + "'", str2.equals("2"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1" + "'", str2.equals("24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("    Java Platform API Specificat", "...form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form......form...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.aaaaaaaaaa", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b::::::::::::::::::::::::::::", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "http://java.oracle.com/", 0, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           10.14.3");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificati");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificati" + "'", str1.equals("javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificati"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/soph", "           24.80-B11            ", 0, 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "           24.80-B11            " + "'", str4.equals("           24.80-B11            "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "...form...", (java.lang.CharSequence) "24. 0ab11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b::::::::::::::::::::::::::::", (java.lang.CharSequence) "en24.0ab11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.CPrinterJo1.1...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", 5.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "      2       ", "11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("racle.com/51.0", "             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle.com/51.0" + "'", str2.equals("racle.com/51.0"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "51b-08_0.7.151b-08_0.7.1", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/soph", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/soph" + "'", str2.equals("/Users/soph"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "                                                                      SUN.LWAWT.MACOSX.CPRINTERJO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OS X444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "      2       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7" + "'", str2.equals("1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(".7/Li1.7/", (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOR", (java.lang.CharSequence) "#############oRACLE cORPORATION", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("s1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.24.80-b1", 8, "                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.24.80-b1" + "'", str3.equals("s1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.24.80-b1"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        double[] doubleArray6 = new double[] { '#', 100L, (byte) 1, (short) 1, (short) 1, (short) 1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "AAAAAAAAAA", "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sunlwawtmacosxCPrinterJo", (java.lang.CharSequence) "    jAVA pLATFORM api sPECIFICAT...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Ujerj/jophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("J", "51b-08_0.7.151b-08_0.7.1", (int) (short) 10, 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J51b-08_0.7.151b-08_0.7.1" + "'", str4.equals("J51b-08_0.7.151b-08_0.7.1"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "#####################################################################Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str8 = javaVersion7.toString();
        boolean boolean9 = javaVersion6.atLeast(javaVersion7);
        boolean boolean10 = javaVersion4.atLeast(javaVersion6);
        java.lang.String str11 = javaVersion4.toString();
        boolean boolean12 = javaVersion0.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.2" + "'", str8.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Li", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "J", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("on    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "SUN.LWWT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", 7, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio" + "'", str3.equals("java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en24.0ab11", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("U24.80-b", "/U5");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "1", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "t/NG0000CF4N1X2N1V_/SREDLOF/RAV/" + "'", str3.equals("t/NG0000CF4N1X2N1V_/SREDLOF/RAV/"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B11", "1.7j/tm...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B11" + "'", str2.equals("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B11"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                      sun.lwawt.macosx.cprinterjo", "su24. 0ab11.24. 0ab11w24. 0ab11w24. 0ab11.m24. 0ab11sx.24. 0ab11P24. 0ab11J24. 0ab11b");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificati");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("US", "aaaaaaa/Li                              ", 29);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "    java platform api specificat", 22, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                        24.80-b11 Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(31, 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATIO" + "'", str1.equals("JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATIO"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " Platform API Specificat", charSequence1, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("noitacificepS IPA mroftalP avaJ", "1.7.0_80");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str3.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/U...", (java.lang.CharSequence) "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                      SUN.LWAWT.MACOSX.CPRINTERJO", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                      SUN.LWAWT.MACOSX.CPRINTERJO" + "'", str2.equals("                                                                      SUN.LWAWT.MACOSX.CPRINTERJO"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("           24.80-B11            ", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Virtual Machine Specification.7/Li1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j44444444444444444444444444444444", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(":", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java Virtual Machine Specification.7/Li1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION.7/lI1" + "'", str1.equals("jAVA vIRTUAL mACHINE sPECIFICATION.7/lI1"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "44", charSequence1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaa"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "class [Dclass [Dclass [Dclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        char[] charArray9 = new char[] { '#', ' ', 'a', ' ', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b1", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "     ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("...form...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...form...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("            !");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:             ! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", 6, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class [Dclass [Ljava.lang.String;class [Cclass [Dclass [Ljava.lang.String;class [Lorg.apache.commons.lang3.SystemUtils;", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "     1     ", (java.lang.CharSequence) "                                                  24.80-b                                                   ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("I!", "...form...");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276/target/classes:/Users/sophi...");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "I!" + "'", str4.equals("I!"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#############oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "RACRACL");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (java.lang.CharSequence) "2");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction", "\n");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophi", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi" + "'", str2.equals("/Users/sophi"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaa4444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaa4444444444444" + "'", str1.equals("aaaaaaaaaaaaaa4444444444444"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444" + "'", str2.equals("44444"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "44444444444444444444444444444444444444444444mac os x444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/Ja ntents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("2.8", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.8" + "'", str2.equals("2.8"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "S", "http4://4java4.4oracle4.4com4/");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.141.141.741.641.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.146.147.141.141.1" + "'", str1.equals("7.146.147.141.141.1"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJo1.1...", (int) '4', "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE cOsun.lwawt.macosx.CPrinterJo1.1...oRACLE cOR" + "'", str3.equals("oRACLE cOsun.lwawt.macosx.CPrinterJo1.1...oRACLE cOR"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("ihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/           24.80-B11            Users           24.80-B11            /           24.80-B11            sophie           24.80-B11            /           24.80-B11            Documents           24.80-B11            /           24.80-B11            defects           24.80-B11            4           24.80-B11            j           24.80-B11            /           24.80-B11            tmp           24.80-B11            /           24.80-B11            run           24.80-B11            _           24.80-B11            randoop           24.80-B11            .           24.80-B11            pl           24.80-B11            _           24.80-B11            96051           24.80-B11            _           24.80-B11            1560211276           24.80-B11            /           24.80-B11            target           24.80-B11            /           24.80-B11            classes           24.80-B11            :/           24.80-B11            Users           24.80-B11            /           24.80-B11            sophie           24.80-B11            /           24.80-B11            Documents           24.80-B11            /           24.80-B11            defects           24.80-B11            4           24.80-B11            j           24.80-B11            /           24.80-B11            framework           24.80-B11            /           24.80-B11            lib           24.80-B11            /           24.80-B11            test           24.80-B11            _           24.80-B11            generation           24.80-B11            /           24.80-B11            generation           24.80-B11            /           24.80-B11            randoop           24.80-B11            -           24.80-B11            current           24.80-B11            .           24.80-B11            jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/           24.80-B11            Users           24.80-B11            /           24.80-B11            sophie           24.80-B11            /           24.80-B11            Documents           24.80-B11            /           24.80-B11            defects           24.80-B11            4           24.80-B11            j           24.80-B11            /           24.80-B11            tmp           24.80-B11            /           24.80-B11            run           24.80-B11            _           24.80-B11            randoop           24.80-B11            .           24.80-B11            pl           24.80-B11            _           24.80-B11            96051           24.80-B11            _           24.80-B11            1560211276           24.80-B11            /           24.80-B11            target           24.80-B11            /           24.80-B11            classes           24.80-B11            :/           24.80-B11            Users           24.80-B11            /           24.80-B11            sophie           24.80-B11            /           24.80-B11            Documents           24.80-B11            /           24.80-B11            defects           24.80-B11            4           24.80-B11            j           24.80-B11            /           24.80-B11            framework           24.80-B11            /           24.80-B11            lib           24.80-B11            /           24.80-B11            test           24.80-B11            _           24.80-B11            generation           24.80-B11            /           24.80-B11            generation           24.80-B11            /           24.80-B11            randoop           24.80-B11            -           24.80-B11            current           24.80-B11            .           24.80-B11            jar" + "'", str1.equals("/           24.80-B11            Users           24.80-B11            /           24.80-B11            sophie           24.80-B11            /           24.80-B11            Documents           24.80-B11            /           24.80-B11            defects           24.80-B11            4           24.80-B11            j           24.80-B11            /           24.80-B11            tmp           24.80-B11            /           24.80-B11            run           24.80-B11            _           24.80-B11            randoop           24.80-B11            .           24.80-B11            pl           24.80-B11            _           24.80-B11            96051           24.80-B11            _           24.80-B11            1560211276           24.80-B11            /           24.80-B11            target           24.80-B11            /           24.80-B11            classes           24.80-B11            :/           24.80-B11            Users           24.80-B11            /           24.80-B11            sophie           24.80-B11            /           24.80-B11            Documents           24.80-B11            /           24.80-B11            defects           24.80-B11            4           24.80-B11            j           24.80-B11            /           24.80-B11            framework           24.80-B11            /           24.80-B11            lib           24.80-B11            /           24.80-B11            test           24.80-B11            _           24.80-B11            generation           24.80-B11            /           24.80-B11            generation           24.80-B11            /           24.80-B11            randoop           24.80-B11            -           24.80-B11            current           24.80-B11            .           24.80-B11            jar"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                      sun.lwawt.macosx.cprinterjo");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.cprinterjo\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("http://java.oracle.com/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1", (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("racle.com/51.0", strArray3, strArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/Ja ntents/Home/jre", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "racle.com/51.0" + "'", str8.equals("racle.com/51.0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("     1     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "     1     " + "'", str1.equals("     1     "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "   ", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("    Java Platform API Specificat", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                   ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio" + "'", str3.equals("Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.aaaaaaaaaa" + "'", str1.equals("1.aaaaaaaaaa"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("noitacificepS IPA mroftalP avaJ", "       ", 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str3.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("a", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("24.80-b::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.2aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion[] javaVersionArray5 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion1, javaVersion2, javaVersion3, javaVersion4 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(javaVersionArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(javaVersionArray5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(javaVersionArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.11.11.71.61.7" + "'", str6.equals("1.11.11.71.61.7"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.11.11.71.61.7" + "'", str7.equals("1.11.11.71.61.7"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.11.11.71.61.7" + "'", str8.equals("1.11.11.71.61.7"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51b-08_0.7.151b-08_0.7.1", "                             sun.lwawt.macosx.cprinterjo");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(".7/Li1.7/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".7/Li1.7/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, (float) (short) 1, (float) 35L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("51b-08_0.7.151b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b15" + "'", str1.equals("1.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "                                                  24.80-B                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/USERS/SOPHI", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/USERS/SOPHI" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/USERS/SOPHI"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("AAAAAAAAAAb  ", "aaaaaaaaaaaaaaaaa/Users/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAb  " + "'", str2.equals("AAAAAAAAAAb  "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("24. 0ab11", "           10.14.3            ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24. 0ab11" + "'", str3.equals("24. 0ab11"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/soph", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "oRACLE cOsun.lwawt.macosx.CPrinterJo1.1...oRACLE cOR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                                                        24.80-b11 Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "aaaaaaaaa", 33, 11);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class [Dclass [Dclass [Dclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7j/tmp/run_randoop.pl_96051_1560211276", "24s.s s0sabs11", "", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7j/tmp/run_randoop.pl_96051_1560211276" + "'", str4.equals("1.7j/tmp/run_randoop.pl_96051_1560211276"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo", (java.lang.CharSequence) "Toolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("PlatformAPISpecificat", (int) '4', "1.2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlatformAPISpecificat1.21.21.21.21.21.21.21.21.21.21" + "'", str3.equals("PlatformAPISpecificat1.21.21.21.21.21.21.21.21.21.21"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.0", (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("TION", "aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TION" + "'", str2.equals("TION"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("javaplatformapispecification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.11.11.71.61.7", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100.0f, (double) '4', (double) 6.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaa", "X SO cam");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("AAAAAAAAAA", "11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        int[] intArray4 = new int[] { (byte) 100, (byte) 10, '4', (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0ab11");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("          ", "3.41.0124");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION.7/lI1", (java.lang.CharSequence) "javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("24.80-b::::::::::::::::::::::::::::", 47.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 47.0d + "'", double2 == 47.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification", charSequence1, 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(33L, 0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "    Java Platform API Specificat");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", (double) 256L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 256.0d + "'", double2 == 256.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("8-FTU", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8-FTU" + "'", str2.equals("8-FTU"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("24.80-b11", "sophie", (int) '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b11" + "'", str4.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "24.80-b11" + "'", str5.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "24.80-b11" + "'", str6.equals("24.80-b11"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "      ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96051_1560211276/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("RACRACL", "en24.0ab11", "/Users");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        char[] charArray11 = new char[] { '4', 'a', '#', '4', 'a', 'a' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-B11", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 84 + "'", int16 == 84);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("44444444444444444444444444444444", "Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("J", "    jAVA pLATFORM api sPECIFICAT...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOR", "hi!hi!hi!hihi!hi!hi!hi", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "24.0ab11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "44", (java.lang.CharSequence) "AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("            !", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                       !                                            " + "'", str3.equals("                                                       !                                            "));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwawt.", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        char[] charArray10 = new char[] { '#', ' ', ' ', 'a', 'a', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo1.1...", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "    Java Platform API Specificat", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "SUN.LWWT.", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo1.1...", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaa/Li", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", "8-FTU");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (byte) 10, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio" + "'", str2.equals("Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "                                                       !                                            ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "racle.com                  ", (java.lang.CharSequence) "7.146.147.141.141.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("java(tm) se runtime environment", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tm) se runtime environment" + "'", str2.equals("tm) se runtime environment"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "     1     ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("cosx.CPrinterJobawt.masun.lw", "     1     ", "racle.com/51.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("AAAAAAAAAAb  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAAAAAAAb\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                        24.80-b11", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("   ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0" + "'", str2.equals("51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "44444", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        int[] intArray5 = new int[] { 1, (short) 100, 3, 2, (short) -1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.11.11.71.61.7", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.7" + "'", str2.equals("1.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.7"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Users/sophie/Library/Java/Extensi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie/Library/Java/Extensi" + "'", str3.equals("Users/sophie/Library/Java/Extensi"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "       ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("      2       ", "sun.awt.CGraphicsEnvironment", "1.7.0_80", 69);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "      2       " + "'", str4.equals("      2       "));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("       ", "24s.s s0sabs11", 8, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "       24s.s s0sabs11" + "'", str4.equals("       24s.s s0sabs11"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10.14.3", "10.14.3", 69);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7" + "'", str1.equals("1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        double[] doubleArray6 = new double[] { 2.0f, 30, 5, (short) 0, 2, 1.0f };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 30.0d + "'", double7 == 30.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("jacosx.CPrinterJobawt.masun.lwja", "                                ", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.7", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.7" + "'", str3.equals("1.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.7"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("24.80-b11", "sophie", (int) '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "aa");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "24.80-b11" + "'", str5.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "24.80-b11" + "'", str6.equals("24.80-b11"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7" + "'", str1.equals("1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "    Java Platform API Specificat...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 24, (double) 56L, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 56.0d + "'", double3 == 56.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("PlatformAPISpecificat", "/U5", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlatformAPISpecificat" + "'", str3.equals("PlatformAPISpecificat"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) ".7/Li1.7/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("S", "24.80-bhi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("AAAAAAAAAA", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444           24.80-B11            ", 11);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("       24s.s s0sabs11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24s.s s0sabs11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkit", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/Ja ntents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/Ja ntents/Home/jr" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/Ja ntents/Home/jr"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "class [Dclass [Dclass [Dclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String", 31, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("    java platform api specificat", "oRACLE cOsun.lwawt.macosx.CPrinterJo1.1...oRACLE cOR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    java platform api specificat" + "'", str2.equals("    java platform api specificat"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Jv PltformU24.804b", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv PltformU24.804b" + "'", str2.equals("Jv PltformU24.804b"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("4", "SUN.LWWT.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Li/Li/ ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Li/Li/" + "'", str1.equals("/Li/Li/"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("TION", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TION" + "'", str2.equals("TION"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("#####################################################################Java(TM) SE Runtime Environment", 0, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################" + "'", str3.equals("###################################"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "7.146.147.141.141.1", (java.lang.CharSequence) "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.24.80-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str3.equals("11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str2.equals("t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "j#V# hOTsPOT(tm) 64-bIT sERVER vm", "1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.cprinterjo");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/VAR\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b1");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "\n", 6, 2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("#####################################################################Java(TM) SE Runtime Environment", "J#v# HotSpot(TM) 64-Bit Server VM", "eihpos/sresU/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("24S.S S0SabS11", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2, 3101, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "2EN124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "hi!hi!hi!hihi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/...", "EN", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/..." + "'", str5.equals("/Users/..."));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("UTF-8", "i!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTF-8" + "'", str6.equals("UTF-8"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "24.80...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Li/Li/ ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("    Java Platform API Specificat");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specificat" + "'", str1.equals("Java Platform API Specificat"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("#############oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444" + "'", str1.equals("44444444444444444444444444"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Platform API Specificat");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("jacosx.CPrinterJobawt.masun.lwja#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jacosx.CPrinterJobawt.masun.lwja#" + "'", str1.equals("jacosx.CPrinterJobawt.masun.lwja#"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b::::::::::::::::::::::::::::", (java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 57, 5.0d, (double) 256L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "JAVA PLATFORM API SPECIFICATION");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b1");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray9, strArray13);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "");
        int int21 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Li", (java.lang.CharSequence[]) strArray20);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, '#');
        boolean boolean24 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi", (java.lang.CharSequence[]) strArray20);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("AAAAAAAAAA", strArray9, strArray20);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaa/Li                              ", strArray4, strArray9);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80-b15", strArray4, strArray29);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24.80-b11" + "'", str23.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "AAAAAAAAAA" + "'", str25.equals("AAAAAAAAAA"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "aaaaaaa/Li                              " + "'", str26.equals("aaaaaaa/Li                              "));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1.7.0_80-b15" + "'", str30.equals("1.7.0_80-b15"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        char[] charArray9 = new char[] { '#', ' ', 'a', ' ', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b1", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/U5", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4", (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Li/Li/ ", "/Librry/Jv/J ntents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "24. 0ab11", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        int[] intArray4 = new int[] { (byte) 100, 8, 3, (byte) 10 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("http://j... http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://j... http://java.oracle.com/" + "'", str1.equals("http://j... http://java.oracle.com/"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("SUN.AWT.cgRAPHICSeNVIRONMENT", (int) (short) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "#############oRACLE cORPORATION", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (short) 10, (short) 10, (byte) -1, (byte) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           10.14.3            ", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                 10.14.3            " + "'", str3.equals("                                                                                 10.14.3            "));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification.7/Li1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificatio" + "'", str1.equals("javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificatio"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/Ja ntents/Home/jre", "JAVAPLATFORMAPISPECIFICATION", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("2", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/uSERS/SOPHIE", 4);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("U2 .80 b");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("oRACLE cOsun.lwawt.macosx.CPrinterJo1.1...oRACLE cOR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cOsun.lwawt.macosx.CPrinterJo1.1...oRACLE cOR" + "'", str1.equals("oRACLE cOsun.lwawt.macosx.CPrinterJo1.1...oRACLE cOR"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                      ", 33, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      44444444444" + "'", str3.equals("                      44444444444"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaa/Li                              ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("racle.com/51.0", "1.6", "3.41.0124");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("U24.80-b", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("           24.80-B11            ", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.AWT.cgRAPHICSeNVIRONMENT", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("2EN124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "j#V# hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/uSERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/uSERS/SOPHIE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Jv PltformU24.804b", (java.lang.CharSequence) "                                                  24.80-B                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "sun.lwawt.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("on    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "On    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction" + "'", str1.equals("On    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction    Jv Pltform API Specifiction"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaaaaaa/Li                              ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "http://j... http://java.oracle.com/", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATIO", "44", "t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATIO" + "'", str3.equals("JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATION    JAVA PLATFORM API SPECIFICATIO"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophi", (java.lang.CharSequence) "JvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifiction");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("           10.14.3            ", "1.aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           10.14.3            " + "'", str2.equals("           10.14.3            "));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(".7/Li1.7/", "J51b-08_0.7.151b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J51b-08_0.7.151b-08_0.7.1" + "'", str2.equals("J51b-08_0.7.151b-08_0.7.1"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "24.0ab11", "hi!hi!hi!hihi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(".7/Li1.7/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7/Li1.7/" + "'", str1.equals(".7/Li1.7/"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str8 = javaVersion7.toString();
        boolean boolean9 = javaVersion6.atLeast(javaVersion7);
        boolean boolean10 = javaVersion4.atLeast(javaVersion6);
        boolean boolean11 = javaVersion0.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean16 = javaVersion12.atLeast(javaVersion14);
        boolean boolean17 = javaVersion0.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.2" + "'", str8.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Toolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJO", (java.lang.CharSequence) "JvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifiction");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", (java.lang.CharSequence) "aaaaaaa/Li                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.2aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                      44444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("1.2aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("SUN.LWWT.", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     SUN.LWWT." + "'", str2.equals("                     SUN.LWWT."));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.11.11.71.61.7", (java.lang.CharSequence) "1.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                      ", 3379);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "    Java Platform API Specificat...", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPOR");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/Ja ntents/Home/jre", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Li/Li/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Li/Li/" + "'", str1.equals("/Li/Li/"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0ab11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "aaaaaaa/Li");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "java hotspot(tm) 64-bit server vm");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaa", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "JAVA PLATFORM API SPECIFICATION");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b1");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray9, strArray13);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "");
        int int21 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Li", (java.lang.CharSequence[]) strArray20);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, '#');
        boolean boolean24 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi", (java.lang.CharSequence[]) strArray20);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("AAAAAAAAAA", strArray9, strArray20);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaa/Li                              ", strArray4, strArray9);
        int int27 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "24.80-B11", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24.80-b11" + "'", str23.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "AAAAAAAAAA" + "'", str25.equals("AAAAAAAAAA"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "aaaaaaa/Li                              " + "'", str26.equals("aaaaaaa/Li                              "));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwawt.macosx.LWCToolkit", "U24.804b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("2.80-b11", "24.80-bhi!", (int) (short) -1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("2.80-b11", "24.80-bhi!", (int) (short) -1);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1" + "'", str10.equals("24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 33L, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.0d + "'", double3 == 33.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("AAAAAAAAAAb", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi", (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AAAAAAAAAAb" + "'", str4.equals("AAAAAAAAAAb"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("    jAVA pLATFORM api sPECIFICAT...", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    jAVA pLATFORM api sPECIFIC" + "'", str2.equals("    jAVA pLATFORM api sPECIFIC"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7", "24.80-b1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4444441.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7/Li1.7444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/U5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/U5" + "'", str1.equals("/U5"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.11.11.71.61.7", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/uSERS/SOPHIE");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio", 30, (int) (byte) 1);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "24.80...", (java.lang.CharSequence[]) strArray3);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (-1), 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/!!!!!!!!!!!" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/!!!!!!!!!!!"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "    Java Platform API Specificat...", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                      sun.lwawt.macosx.cprinterjo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjo" + "'", str1.equals("sun.lwawt.macosx.cprinterjo"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mix de", 18, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mix de" + "'", str3.equals("mix de"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1" + "'", str1.equals("24.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b124.80-b1"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("java(tm) se runtime environment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/soph", "tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jtvt(tm)  untim nvinmnt" + "'", str3.equals("jtvt(tm)  untim nvinmnt"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa           10.14.3            ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 5, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "   ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0ab11", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "I!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.7", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATION JAVA PLATFORM API SPECIFICATIO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        int[] intArray5 = new int[] { 1, (short) 100, 3, 2, (short) -1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        char[] charArray7 = new char[] { '#', ' ', '4', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.11.11.71.61.7", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Jv PltformU24.804b", 97, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                               Jv PltformU24.804b" + "'", str3.equals("                                                                               Jv PltformU24.804b"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("x86_64", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.71.11.11.71.61.7", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64" + "'", str4.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { ' ', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24.80-bhi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mac OS X", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                             sun.lwawt.macosx.cprinterjo", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-bhi!", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 29 + "'", int12 == 29);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0.9", "U24.804b", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', (-1), 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444           24.80-B11            ", (int) 'a', 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...44444444..." + "'", str3.equals("...44444444..."));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                      sun.lwawt.macosx.cprinterjo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("...form...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophi", "racle.com/51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...form..." + "'", str3.equals("...form..."));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                                                                                 10.14.3            ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("RACLE.COM/51.0", "http://java.oracle.com/", "3.41.01");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RACLE.COM/51.0" + "'", str3.equals("RACLE.COM/51.0"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "                                                                                        24.80-b11 Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specificatio                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaa/Li                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaa/Li                             " + "'", str1.equals("aaaaaaa/Li                             "));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Li/Li/ ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("24S.S S0SabS11", "11 24.80-B ab 24.80-B 0 24.80-B 24.80-B . 24.80-B 24");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 11, 33.0d, (double) 47);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.0d + "'", double3 == 11.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7/LI1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo1.1...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophie" + "'", str4.equals("sophie"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "j#V# hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.2");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("24S.S S0SabS11", "U24.80-b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        char[] charArray9 = new char[] { '#', ' ', ' ', 'a', 'a', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                ", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo1.1...", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifictionJvPltformAPISpecifiction", ":44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SUN.LWAWT.MACOSX.CPRINTERJO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJO" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJO"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "javaplatformapispecification", (java.lang.CharSequence) "U2 .80 b");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "24.80-B11", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 7.0f, 0.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaa", "mixed mode", "Users/sophie/Library/Java/Extensi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaa" + "'", str3.equals("aaaaaaaaa"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwwt", (java.lang.CharSequence) "           10.14.3            ", 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("       24s.s s0sabs11", "Jv PltformU24.804b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       24s.s s0sabs11" + "'", str2.equals("       24s.s s0sabs11"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("24                                                  24.80-B                                                   .                                                  24.80-B                                                                                                      24.80-B                                                   0                                                  24.80-B                                                   ab                                                  24.80-B                                                   11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24                                                  24.80-B                                                   .                                                  24.80-B                                                                                                      24.80-B                                                   0                                                  24.80-B                                                   AB                                                  24.80-B                                                   11" + "'", str1.equals("24                                                  24.80-B                                                   .                                                  24.80-B                                                                                                      24.80-B                                                   0                                                  24.80-B                                                   AB                                                  24.80-B                                                   11"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification" + "'", str1.equals("javaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Jv PlJv Plt", "    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specificatio", "24S.S S0SabS11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SS2abSS2ab1" + "'", str3.equals("SS2abSS2ab1"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/ http://java.oracle.com/");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "AAAAAAAAAAb", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaaaaaaaaaaaaa4444444444444", (int) (byte) 100, 4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, (long) 23, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 23L + "'", long3 == 23L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                     SUN.LWWT.", 56, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############                     SUN.LWWT.#############" + "'", str3.equals("#############                     SUN.LWWT.#############"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_96051_1560211276/ta/Users/sophie/Documents/defects4j/tmp/run_r", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification    Java Platform API Specification", (double) 14.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.0d + "'", double2 == 14.0d);
    }
}

