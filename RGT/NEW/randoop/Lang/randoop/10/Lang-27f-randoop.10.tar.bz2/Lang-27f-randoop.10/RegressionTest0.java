import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test001");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_HOME;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str0.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Long long0 = org.apache.commons.lang3.math.NumberUtils.LONG_ONE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0.equals(1L));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7" + "'", str0.equals("1.7"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sophie" + "'", str0.equals("sophie"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_HP_UX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserHome();
        org.junit.Assert.assertNotNull(file0);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test017");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_EXT_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str0.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Object[] objArray1 = new java.lang.Object[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(objArray1, '4', (int) (short) 0, 0);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) -1, (double) (short) 100, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "", (int) '4', (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_VISTA;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!", "1.7", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("hi!", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7", (int) (byte) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_IO_TMPDIR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str0.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_6;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Object[] objArray2 = new java.lang.Object[] { '4', "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray2, "sophie");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(objArray2);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str5.equals("4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Long long0 = org.apache.commons.lang3.math.NumberUtils.LONG_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-1L) + "'", long0.equals((-1L)));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!", "4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_COMPILER;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_CLASS_PATH;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str0.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_LANGUAGE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "en" + "'", str0.equals("en"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_SPECIFICATION_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7" + "'", str0.equals("1.7"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_ENDORSED_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str0.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_LIBRARY_PATH;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str0.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VERSION_TRIMMED;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7.0_80" + "'", str0.equals("1.7.0_80"));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) -1 + "'", short0.equals((short) -1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_3;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_ONE;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) 1 + "'", short0.equals((short) 1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0, (double) (short) 0, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_HEADLESS;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("en", 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0.equals((-1)));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_LINUX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        int int0 = org.apache.commons.lang3.SystemUtils.JAVA_VERSION_INT;
//        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 170 + "'", int0 == 170);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.apache.commons.lang3.StringUtils.INDEX_NOT_FOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_UTIL_PREFS_PREFERENCES_FACTORY;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_RUNTIME_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str0.equals("Java(TM) SE Runtime Environment"));
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        float float0 = org.apache.commons.lang3.SystemUtils.JAVA_VERSION_FLOAT;
//        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.7f + "'", float0 == 1.7f);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sophie", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_TIMEZONE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Oracle Corporation", "", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_SPECIFICATION_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Java(TM) SE Runtime Environment", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java(TM) SE Runtime Environment", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_SPECIFICATION_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java Virtual Machine Specification" + "'", str0.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_5;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserDir();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) '4', (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "1.7", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "", 10);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray6);
        java.lang.Object[] objArray8 = new java.lang.Object[] { "Java Virtual Machine Specification", "sophie", int7 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(objArray8);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java Virtual Machine Specificationsophie-1" + "'", str9.equals("Java Virtual Machine Specificationsophie-1"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, 0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_95;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_FONTS;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_XP;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", (int) 'a', "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation" + "'", str3.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(10.0f, (float) (short) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_AIX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.FILE_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/" + "'", str0.equals("/"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Double double0 = org.apache.commons.lang3.math.NumberUtils.DOUBLE_ONE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0d + "'", double0.equals(1.0d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "Oracle Corporation", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ i" + "'", str3.equals("Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ i"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ i", "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.LINE_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "\n" + "'", str0.equals("\n"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100, (double) (short) 10, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_SOLARIS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Virtual Machine Specificationsophie-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specificationsophie-1" + "'", str1.equals("Java Virtual Machine Specificationsophie-1"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb" + "'", str3.equals("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", charSequence2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + (-1.0f) + "'", float0.equals((-1.0f)));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", 0, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_MAC_OSX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0.equals(0));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_COUNTRY;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "US" + "'", str0.equals("US"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.OS_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Mac OS X" + "'", str0.equals("Mac OS X"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specification", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava Virtual Machine Specification" + "'", str2.equals("ava Virtual Machine Specification"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("ava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava Virtual Machine Specification" + "'", str1.equals("ava Virtual Machine Specification"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("en", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_HOME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie" + "'", str0.equals("/Users/sophie"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_PRINTERJOB;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str0.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("\n", (int) (byte) 10, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("ava Virtual Machine Specification", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) -1 + "'", byte0.equals((byte) -1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_NT;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "24.80-b11" + "'", str0.equals("24.80-b11"));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Mac OS X", (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sophie", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java Platform API Specification" + "'", str0.equals("Java Platform API Specification"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Long long0 = org.apache.commons.lang3.math.NumberUtils.LONG_ZERO;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0.equals(0L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("en", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r" + "'", str1.equals("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specificationsophie-1", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specificationsophie-1" + "'", str2.equals("Java Virtual Machine Specificationsophie-1"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_ONE;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0.equals(1.0f));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Platform API Specification", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_UNIX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str0.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        long[] longArray0 = new long[] {};
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.CPrinterJob", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Java Virtual Machine Specification", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r", (int) (short) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r" + "'", str3.equals("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwawt.macosx.CPrinterJob", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle Corporation", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaVirtualMachineSpecification" + "'", str1.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (byte) 100);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (int) (short) 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("hi!", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sophie", "US", (int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "US" + "'", str4.equals("US"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("hi!", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie" + "'", str3.equals("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java Virtual Machine Specificationsophie-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, (float) (short) 1, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_2000;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("hi!", "Mac OS X", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", (int) (short) 0, "4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_SUN_OS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 10, "4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "", 10);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sophie", strArray6, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", (-1));
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Mac OS X", strArray10, strArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 57");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sophie" + "'", str11.equals("sophie"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("/Users/sophie", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie", "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("ava Virtual Machine Specification", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie", 10, "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie" + "'", str3.equals("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("hi!", (int) ' ', 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VENDOR_URL;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "http://java.oracle.com/" + "'", str0.equals("http://java.oracle.com/"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Double double0 = org.apache.commons.lang3.math.NumberUtils.DOUBLE_ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", (int) (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("1.7.0_80", strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str6.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (byte) 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Libr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrery/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreVirtu/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrelM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrechines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 100, (int) (byte) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_4;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("sun.lwawt.macosx.CPrinterJob", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 0, 0L, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_7;
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "Java Virtual Machine Specificationsophie-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Virtual Machine Specificationsophie-1" + "'", str1.equals("java Virtual Machine Specificationsophie-1"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb" + "'", str2.equals("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 0, (float) (byte) 0, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("Java(TM) SE Runtime Environment", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Java Platform API Specification", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) -1, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mac OS X", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X                                                                                            " + "'", str3.equals("Mac OS X                                                                                            "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_CLASS_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "51.0" + "'", str0.equals("51.0"));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("JavaVirtualMachineSpecification", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Platform API Specification", (-1), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Libr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrery/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreVirtu/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrelM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrechines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Libr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrery/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreVirtu/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrelM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrechines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str4.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_DIR;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908" + "'", str0.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908"));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Libr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrery/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreVirtu/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrelM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrechines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (-1), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie" + "'", str3.equals("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 97L, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation", "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 618 + "'", int2 == 618);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0L, (float) '#', (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.OS_ARCH;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "x86_64" + "'", str0.equals("x86_64"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_ZERO;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) 0 + "'", short0.equals((short) 0));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("US", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("x86_64", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.String str0 = org.apache.commons.lang3.StringUtils.EMPTY;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_ME;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Mac OS X", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.PATH_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + ":" + "'", str0.equals(":"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.AWT_TOOLKIT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str0.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("http://java.oracle.com/", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(":");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users//Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users//Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users//Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users//Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie", "", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie" + "'", str3.equals("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users//Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users//Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 10, 618);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.OS_VERSION;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "10.14.3" + "'", str0.equals("10.14.3"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1L), (float) 52L, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("24.80-b11", 97, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_ONE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0.equals((byte) 1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_MAC;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x86_64", 170, "Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ i");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcx86_64" + "'", str3.equals("Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcx86_64"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "br/b/H/iiebie/C/d08_071d/ibevacvMvirvVvlvu/vlvu/rrvrvvj/4" + "'", str1.equals("br/b/H/iiebie/C/d08_071d/ibevacvMvirvVvlvu/vlvu/rrvrvvj/4"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "Java Virtual Machine Specificationsophie-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("US", "24.80-b11");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_98;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", "4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1.7", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java(TM) SE Runtime Environment", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_2;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ i");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ i" + "'", str1.equals("Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ i"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r", "Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcx86_64", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "Mac OS X                                                                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((-1L), 0L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_RUNTIME_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7.0_80-b15" + "'", str0.equals("1.7.0_80-b15"));
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Environment", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specificationsophie-1", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/L..." + "'", str2.equals("/L..."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.isJavaAwtHeadless();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("JavaVirtualMachineSpecification", (java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleJavaVirtualMachineSpecification JavaVirtualMachineSpecificationCorporation" + "'", str3.equals("OracleJavaVirtualMachineSpecification JavaVirtualMachineSpecificationCorporation"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Libr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrery/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreVirtu/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrelM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrechines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Mac OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, 0.0d, (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("US", "ava Virtual Machine Specification", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7", (-1), 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aa!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("51.0", 1000, 618);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_INFO;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "mixed mode" + "'", str0.equals("mixed mode"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(100.0f, (float) 97, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("br/b/H/iiebie/C/d08_071d/ibevacvMvirvVvlvu/vlvu/rrvrvvj/4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"br/b/H/iiebie/C/d08_071d/ibevacvMvirvVvlvu/vlvu/rrvrvvj/4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("en");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/L...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_ZERO;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0.equals((byte) 0));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80-b15", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("br/b/H/iiebie/C/d08_071d/ibevacvMvirvVvlvu/vlvu/rrvrvvj/4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", (int) (byte) 100, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users//Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users//Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 100);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(10.0d, (double) 52L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("US", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "br/b/H/iiebie/C/d08_071d/ibevacvMvirvVvlvu/vlvu/rrvrvvj/4", "4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4/jvvrvrr/uvlv/uvlvVvrivMvcavebi/d170_80d/C/eibeii/H/b/rb");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 100, (long) (byte) 0, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10.14.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcx86_64", "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcx86_64" + "'", str2.equals("Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ iJcva V rJVlVJVlVlv SpVcx86_64"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Platform API Specification", 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava Platform API Specification" + "'", str3.equals("ava Platform API Specification"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Jcva V rJVlVJVlVlv SpVcmVicvtioJJitSitSoJcmiJ i");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jCVA v RjvLvjvLvLV sPvCMvICVTIOjjITsITsOjCMIj I" + "'", str1.equals("jCVA v RjvLvjvLvLV sPvCMvICVTIOjjITsITsOjCMIj I"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 97.0f, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("aa!", "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ava Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_ZERO;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0.equals(0.0f));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.FILE_ENCODING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "UTF-8" + "'", str0.equals("UTF-8"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8097220651_4179_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("\n", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specificationsophie-1");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("http://java.oracle.com/", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("br/b/H/iiebie/C/d08_071d/ibevacvMvirvVvlvu/vlvu/rrvrvvj/4", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908", "Mac OS X                                                                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "1.7", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("OracleJavaVirtualMachineSpecification JavaVirtualMachineSpecificationCorporation", "sophie", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS X                                                                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x                                                                                            " + "'", str1.equals("mac os x                                                                                            "));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "17" + "'", str3.equals("17"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users//Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80", (int) (short) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("ava Virtual Machine Specification", "ava Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("java Virtual Machine Specificationsophie-1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("OracleJavaVirtualMachineSpecification JavaVirtualMachineSpecificationCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oraclejavavirtualmachinespecification javavirtualmachinespecificationcorporation" + "'", str1.equals("oraclejavavirtualmachinespecification javavirtualmachinespecificationcorporation"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, (float) (byte) -1, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "OracleJavaVirtualMachineSpecification JavaVirtualMachineSpecificationCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aa!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa!" + "'", str1.equals("aa!"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("jCVA v RjvLvjvLvLV sPvCMvICVTIOjjITsITsOjCMIj I", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/javOracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jCVA v RjvLvjvLvLV sPvCMvICVTIOjjITsITsOjCMIj I" + "'", str2.equals("jCVA v RjvLvjvLvLV sPvCMvICVTIOjjITsITsOjCMIj I"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", 0, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Mac OS X                                                                                            ", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "4/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/L...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, (int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("OracleJavaVirtualMachineSpecification JavaVirtualMachineSpecificationCorporation", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny("4sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray8);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 13 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Libr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrery/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreVirtu/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrelM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrechines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str12.equals("/Libr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrery/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/J/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrev/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreVirtu/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrelM/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrechines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("mac os x                                                                                            ", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9714_1560227908/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_ONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0.equals(1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaVirtualMachineSpecification" + "'", str1.equals("javaVirtualMachineSpecification"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aa!", (int) (short) 10, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.Object[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.!" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.!"));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }
}

