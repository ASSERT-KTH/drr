import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, (int) (short) 10, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10#1#10", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#1#10" + "'", str2.equals("10#1#10"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0 -1.0 1.0", "Java HotSpot(TM) 64-Bit Server VM", "-1/Users/sophie0.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                 ", "-10.0", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v" + "'", str2.equals("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specificatio", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                                                 ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "-1/Users/sophie0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80-b15", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_COMPILER;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1/Users/sophie0.0", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "-1#100#1#-1#100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1/users/sophie0.0", "", "x86_64");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10#1#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Virtual Machine Specificatio", "", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificatio" + "'", str3.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("#52#-1#1#10#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#52#-1#1#10#10" + "'", str1.equals("#52#-1#1#10#10"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java Virtual Machine Specificatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specificatio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("c0000gn/T/", (int) ' ', "http://java.oracle.com/-1/Users/sophie0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://javac0000gn/T/http://java" + "'", str3.equals("http://javac0000gn/T/http://java"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Object[][] objArray0 = new java.lang.Object[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(objArray0);
        org.junit.Assert.assertNotNull(objArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1.0f, (float) 0L, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ULbyUJvUJvVMUk8kUCUHU", (java.lang.CharSequence) "10#10#1#-1#52#10", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "        24.80-b11         ", 51, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 51");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-10.0", "en", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("tiklooTCWL.xsocam.twawl.nus", "-1/users/sophie0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575", (int) (short) -1, "#52#-1#1#10#10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575" + "'", str3.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("JAVA VIRTUAL MACHINE SPECIFICATION", "(TM) SE Runtime EnvironmentavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "####################################################################################################", (java.lang.CharSequence) "############################################52#-1#1#10#10###########################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("        24.80-b11         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_7;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Virtual Machine Specificatio", (java.lang.CharSequence) "X86_64", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode", "suna.aawta.aCGaraphicsaEanvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("51 1 1 32 32 52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51 1 1 32 32 52" + "'", str1.equals("51 1 1 32 32 52"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7.0_80-b15", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("tiklooTCWL.xsocam.twawl.nus", "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.0 -1.0 1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("        24.80-b11         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "        24.80-b11         " + "'", str1.equals("        24.80-b11         "));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("        24.80-b11         ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#52#-1#1#10#10", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10" + "'", str2.equals("#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "10#52#-1#1#10#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIKLOOTCWL.XSOCAM.TWAWL.NUS" + "'", str1.equals("TIKLOOTCWL.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("mixed mode", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob########################", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10", 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "US");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "mixed mode", (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10a0a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10A0A10" + "'", str1.equals("10A0A10"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkit", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            sun.lwawt.macosx.LWCToolkit             " + "'", str2.equals("            sun.lwawt.macosx.LWCToolkit             "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, charSequence1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("############################################52#-1#1#10#10###########################################", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################################52#-1#1#10#10###########################################" + "'", str2.equals("############################################52#-1#1#10#10###########################################"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specificatio", (int) 'a', 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 47 + "'", int3 == 47);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" ", (int) (byte) -1, "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("http://javac0000gn/T/http://java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://javac0000gn/T/http://java" + "'", str1.equals("http://javac0000gn/T/http://java"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob########################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 1, 51, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double[] doubleArray5 = new double[] { 0.0d, (short) 0, ' ', 100.0d, (-1.0f) };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        char[] charArray6 = new char[] { '4', '#', 'a', 'a', 'a', '4' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "44#4a4a4a44" + "'", str8.equals("44#4a4a4a44"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "X86_64", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java Virtual Machine Specificatio", charSequence1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("UTF-8", 15, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.CPrinterJob", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10.14.310.14.310.14.#############################hi!", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10#10#1#-1#52#10", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//v" + "'", str2.equals("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//v"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM) SE Runtime Environment", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10A0A10", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10A0A10" + "'", str2.equals("10A0A10"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-10.0", 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "-1/Users/sophie0.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "c0000gn/T/", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "            sun.lwawt.macosx.LWCToolkit             ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", (int) (byte) 100, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "0", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("############################################52#-1#1#10#10###########################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"############################################52#-1#1#10#10###########################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim" + "'", str1.equals("edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode", (int) (short) 100, "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode" + "'", str3.equals("mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1#100#1#-1#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "001#1-#1#001#1-" + "'", str1.equals("001#1-#1#001#1-"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  " + "'", str2.equals("                  "));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sophie", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "c0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1L), (double) 1.0f, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "US");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("24.80-b11", "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specificatio", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#############################hi!", "/", (int) '#');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("en");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java Virtual Machine Specificatio", "104524-141410410", "(TM) SE Runtime EnvironmentavaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificatio" + "'", str3.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64" + "'", str1.equals("X86_64"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://javac0000gn/T/http://java", 27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int[] intArray3 = new int[] { 10, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) (short) 0, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) '#', 27);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 0, 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-1/users/sophie0.0", (java.lang.CharSequence) "Java Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("####################################################################################################", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################" + "'", str3.equals("####################################################################################################"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "            sun.lwawt.macosx.LWCToolkit             ", "", 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", "1040410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("!", "001#1-#1#001#1-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.CPrinterJob########################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "51 1 1 32 32 52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob########################" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob########################"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.310.14.310.14.#############################hi!", 1, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("!", (int) (byte) 1, "-1#100#1#-1#100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//v");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "####################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("JAVA VIRTUAL MACHINE SPECIFICATION", "UTF-8", 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str3.equals("JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("TIKLOOTCWL.XSOCAM.TWAWL.NUS", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIKLOOTCWL.XSOCAM.TWAWL.NUS" + "'", str2.equals("TIKLOOTCWL.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "            sun.lwawt.macosx.LWCToolkit             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', (-1), (int) ' ');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime environment" + "'", str1.equals("java(tm) se runtime environment"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.CPrinterJob########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob########################" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob########################"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 10, (float) 'a', (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "############################################52#-1#1#10#10###########################################", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 26, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444" + "'", str3.equals("44444444444444444444444444"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 " + "'", str1.equals("                                                                                                 "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 100, 0L, (long) 15);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.14.31.0 -1.0 1.0", "#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".14.31.0 -1.0 1.0" + "'", str2.equals(".14.31.0 -1.0 1.0"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(26, 45, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 45 + "'", int3 == 45);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specificatio", (java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment                " + "'", str2.equals("Java(TM) SE Runtime Environment                "));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#", (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsocam.twawl.nu" + "'", str1.equals("tiklooTCWL.xsocam.twawl.nu"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1/users/sophie0.0", (java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        byte[][] byteArray0 = new byte[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(byteArray0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10.14.310.14.310.14.#############################hi!", "sun.lwawt.macosx.CPrinterJob########################", (int) (short) 0, 26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.CPrinterJob###############################################hi!" + "'", str4.equals("sun.lwawt.macosx.CPrinterJob###############################################hi!"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                " + "'", str1.equals("                                                                                                "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ULbyUJvUJvVMUk8kUCUHU", 1, "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ULbyUJvUJvVMUk8kUCUHU" + "'", str3.equals("ULbyUJvUJvVMUk8kUCUHU"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "us", 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "104524-141410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "suna.aawta.aCGaraphicsaEanvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_5;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "            sun.lwawt.macosx.LWCToolkit             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "10.14.3", "mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) (short) 10, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("44#4a4a4a44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44#4a4a4a44" + "'", str1.equals("44#4a4a4a44"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode", "tiklooTCWL.xsocam.twawl.nu");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575", (int) (short) 100, "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575///////////////////////////////" + "'", str3.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575///////////////////////////////"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 15, (double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.0d + "'", double3 == 15.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Vi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.CPrinterJob########################", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("#############################hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                " + "'", str1.equals("                                                                                                "));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java(TM) SE Runtime Environment", "1.0a-1.0a1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double[] doubleArray6 = new double[] { 100, 100.0d, 1.0f, (short) 1, (-1L), 10L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specificatio", (java.lang.CharSequence) "x86_64", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 -1.0 1.0" + "'", str1.equals("1.0 -1.0 1.0"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) -1 + "'", short0.equals((short) -1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        short[] shortArray5 = new short[] { (byte) -1, (short) 100, (byte) 1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#100#1#-1#100" + "'", str7.equals("-1#100#1#-1#100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("UTF-8", "                                                                                                 ", 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0, 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie");
        java.lang.Class<?> wildcardClass10 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-10.0", "1.0a-1.0a1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("tiklooTCWL.xsocam.twawl.nus", "10A0A10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java(TM) SE Runtime Environment                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                tnemnorivnE emitnuR ES )MT(avaJ" + "'", str1.equals("                tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("24.80-b11", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(" ", "001#1-#1#001#1-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                  ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10" + "'", str2.equals("#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10#10#1#-1#52#10", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        long[] longArray6 = new long[] { (short) 10, '4', (short) -1, 1, (short) 10, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#52#-1#1#10#10" + "'", str8.equals("10#52#-1#1#10#10"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.14.31.0 -1.0 1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.CPrinterJob", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("tiklooTCWL.xsocam.twawl.nus", "mixed mode", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nus" + "'", str3.equals("tiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("http://javac0000gn/T/http://java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://javac0000gn/T/http:" + "'", str2.equals("http://javac0000gn/T/http:"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                tnemnorivnE emitnuR ES )MT(avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                tnemnorivnE emitnuR ES )MT(avaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", (java.lang.CharSequence) "-1#100#1#-1#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://javac0000gn/T/http://java", "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("java(tm) se runtime environment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://javac0000gn/T/http:", 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100a1a0a0a1", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1a0a0a1" + "'", str2.equals("100a1a0a0a1"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("############################################52#-1#1#10#10###########################################", "US", "10.14.310.14.310.14.#############################hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################52#-1#1#10#10###########################################" + "'", str3.equals("############################################52#-1#1#10#10###########################################"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double[] doubleArray6 = new double[] { 100, 100.0d, 1.0f, (short) 1, (-1L), 10L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', 15, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("en", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1#100#1#-1#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("            sun.lwawt.macosx.LWCToolkit             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"            sun.lwawt.macosx.LWCToolkit             \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.CPrinterJob########################", 18, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PrinterJob########################" + "'", str3.equals("PrinterJob########################"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10#10#1#-1#52#10", (java.lang.CharSequence) "44#4a4a4a44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10A0A10", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10#1#10", (java.lang.CharSequence) "Java(TM) SE Runtime Environment                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime environment" + "'", str1.equals("java(tm) se runtime environment"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1#100#1#-1#100", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "suna.aawta.aCGaraphicsaEanvironment", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#100#1#-1#100" + "'", str8.equals("-1#100#1#-1#100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '4', (double) 10, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("en", "#############################hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#############################hi!" + "'", str2.equals("#############################hi!"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) ' ', 0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1040410", (java.lang.CharSequence) "#52#-1#1#10#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10A0A10", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10A0A10                                            " + "'", str2.equals("10A0A10                                            "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1#100#1#-1#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1#100#1#-1#100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("c0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C0000GN/T/" + "'", str1.equals("C0000GN/T/"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '4', (long) 15, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, 51, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 51 + "'", int3 == 51);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(".14.31.0 -1.0 1.0", "http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14.31.0 -1.0 1.0" + "'", str2.equals("14.31.0 -1.0 1.0"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("PrinterJob########################", (int) '#', ".14.31.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PrinterJob########################." + "'", str3.equals("PrinterJob########################."));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-10.0", (int) '#', "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "http://java.oracle.com/-1/Users/sophie0.0", (java.lang.CharSequence) "Java(TM) SE Runtime Environment                ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java(TM) SE Runtime Environment");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-1/Users/sophie", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://javac0000gn/T/http://java", 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim", "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        short[] shortArray5 = new short[] { (byte) 100, (byte) 1, (short) 0, (byte) 0, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "10.14.310.14.310.14.#############################hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("#############################hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#############################hi!" + "'", str1.equals("#############################hi!"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("java(tm) se runtime environment", "PrinterJob########################.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PrinterJob########################." + "'", str2.equals("PrinterJob########################."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1/Users/sophie", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1/Users/sophie" + "'", str6.equals("-1/Users/sophie"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/", "1.7", "C0000GN/T/", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporation", "sophie", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("-10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-10.0" + "'", str1.equals("-10.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.31.0 -1.0 1.0", (int) (byte) 100, 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.310.14.310.14.#############################hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0", "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "suna.aawta.aCGaraphicsaEanvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("en", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "##########", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "##########" + "'", charSequence2.equals("##########"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("java(tm) se runtime environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: java(tm) se runtime environment is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, 1L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (byte) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "-1#100#1#-1#100", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", 18, "1.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########" + "'", str1.equals("##########"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575///////////////////////////////", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.PATH_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + ":" + "'", str0.equals(":"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                 ", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("http://javac0000gn/T/http:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://javac0000gn/T/http:" + "'", str1.equals("http://javac0000gn/T/http:"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10.14.31.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(".14.31.0 -1.0 1.0", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java Platform API Specification", "-1/Users/sophie0.0", "10#52#-1#1#10#10", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification" + "'", str4.equals("Java Platform API Specification"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("PrinterJob########################.", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PrinterJob########################." + "'", str2.equals("PrinterJob########################."));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie", "0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "104524-141410410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575///////////////////////////////");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575///////////////////////////////" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575///////////////////////////////"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("UTF-8", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.31.0 -1.0 1.0", "tiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nus", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("100a1a0a0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a1a0a0a1" + "'", str1.equals("100a1a0a0a1"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", (int) ' ');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "/Users/sophie", 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.awt.CGraphicsEnvironment", strArray7, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("##########", strArray2, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 8 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str12.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80" + "'", str13.equals("1.7.0_80"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("100a1a0a0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a1a0a0a1" + "'", str1.equals("100a1a0a0a1"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ULbyUJvUJvVMUk8kUCUHU", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ULbyUJvUJvVMUk8kUCUHU" + "'", str2.equals("ULbyUJvUJvVMUk8kUCUHU"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "PrinterJob########################.", (java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//v", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.0 -1.0 1.0", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 -1.0 1.0" + "'", str2.equals("1.0 -1.0 1.0"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("-1/Users/sophie", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          -1/Users/sophie          " + "'", str2.equals("          -1/Users/sophie          "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "10.14.31.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "UTF-8", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 12, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                  ", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("c0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C0000gn/T/" + "'", str1.equals("C0000gn/T/"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (byte) 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("############################################52#-1#1#10#10###########################################", (int) (byte) -1, "C0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################52#-1#1#10#10###########################################" + "'", str3.equals("############################################52#-1#1#10#10###########################################"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaa/Users/sophieaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaa/Users/sophieaaaaaaaaaaa"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", ' ');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1#100#1#-1#100", strArray3, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#100#1#-1#100" + "'", str7.equals("-1#100#1#-1#100"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", " ", "104524-141410410", 26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', (int) (byte) 1, 12);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "##########", (java.lang.CharSequence) "10A0A10", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1#100#1#-1#100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(":", (long) 27);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27L + "'", long2 == 27L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "          -1/Users/sophie          ", (java.lang.CharSequence) "001#1-#1#001#1-", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100a1a0a0a1", (java.lang.CharSequence) "-1#100#1#-1#100", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str1.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        long[] longArray6 = new long[] { (short) 10, '4', (short) -1, 1, (short) 10, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#52#-1#1#10#10" + "'", str8.equals("10#52#-1#1#10#10"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#52#-1#1#10#10" + "'", str10.equals("10#52#-1#1#10#10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("-1#100#1#-1#100", "#52#-1#1#10#10", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1/Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10A0A10", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10A0A10" + "'", str3.equals("10A0A10"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim", 35, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim" + "'", str3.equals("edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                  ", "Java HotSpot(TM) 64-Bit Server VM", "hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("PrinterJob########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PrinterJob########################" + "'", str1.equals("PrinterJob########################"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10.14.31.0 -1.0 1.0", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment                ", (-1), "PrinterJob########################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment                " + "'", str3.equals("Java(TM) SE Runtime Environment                "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//v", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                 ", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#a#a4a4a a#", (java.lang.CharSequence) "############################################52#-1#1#10#10###########################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10A0A10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10A0A10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1/users/sophie0.0", (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "suna.aawta.aCGaraphicsaEanvironment", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://java.oracle.com/", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/", 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ULbyUJvUJvVMUk8kUCUHU", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "sun.lwawt.macosx.CPrinterJob", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("(TM) SE Runtime EnvironmentavaJ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM) SE Runtime EnvironmentavaJ" + "'", str2.equals("(TM) SE Runtime EnvironmentavaJ"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "-1/Users/sophie0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "ULbyUJvUJvVMUk8kUCUHU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("JAVA VIRTUAL MACHINE SPECIFICATION", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "N" + "'", str2.equals("N"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 1, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1/Users/sophie", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/-1/Users/sophie0.0", (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("suna.aawta.aCGaraphicsaEanvironment", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.6", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10.14.31.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.31.0-1.01.0" + "'", str1.equals("10.14.31.0-1.01.0"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("(TM) SE Runtime EnvironmentavaJ", "        24.80-b11         ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(TM) SE Runtime EnvironmentavaJ" + "'", str3.equals("(TM) SE Runtime EnvironmentavaJ"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 'a', (double) (short) 1, 1.7d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "            sun.lwawt.macosx.LWCToolkit             ", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 3, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("51 1 1 32 32 52", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51 1 1 32 32 52" + "'", str2.equals("51 1 1 32 32 52"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("UTF-8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "          -1/Users/sophie          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "#a#a4a4a a#");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "PrinterJob########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        float[] floatArray3 = new float[] { 1L, (-1), (short) 1 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "ULbyUJvUJvVMUk8kUCUHU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, '#', (int) (byte) 10, (int) (byte) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob########################", (java.lang.CharSequence) "51 1 1 32 32 52", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("jAVA hOTsPOT(tm) 64-bIT sERVER vm", "-10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "C0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("c0000gn/T/", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10A0A10                                            ", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10A0A10                                            " + "'", str2.equals("10A0A10                                            "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.3", 45, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ":", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(" ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10.14.31.0-1.01.0", "        24.80-b11         ", "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("C0000GN/T/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.3", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "#############################hi!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "#############################hi!" + "'", charSequence2.equals("#############################hi!"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 10, (double) 26, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime environment" + "'", str1.equals("java(tm) se runtime environment"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("        24.80-b11         ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.CharSequence[] charSequenceArray4 = new java.lang.CharSequence[] { "Java HotSpot(TM) 64-Bit Server VM", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575", "        24.80-b11         ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0" };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray4);
        org.junit.Assert.assertNotNull(charSequenceArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "sophie", "10A0A10", 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10#52#-1#1#10#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#52#-1#1#10#10" + "'", str1.equals("10#52#-1#1#10#10"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                                 ", "c0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                ", "UTF-8", "#52#-1#1#10#10");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "1.6", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.0a-1.0a1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10#10#1#-1#52#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#10#1#-1#52#10" + "'", str1.equals("10#10#1#-1#52#10"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("US", "PrinterJob########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PrinterJob########################" + "'", str2.equals("PrinterJob########################"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("UTF-8", "                                                                                                 ", 1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTF-8" + "'", str6.equals("UTF-8"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "suna.aawta.aCGaraphicsaEanvironment", (java.lang.CharSequence) "1.3", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, (float) (byte) 100, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "10#52#-1#1#10#10", "10041404041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/T/"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#100#1#-1#100", (java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#4#44444 4#" + "'", str16.equals("#4#44444 4#"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0a-1.0a1.0", "                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java(TM) SE Runtime Environment                ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        long[] longArray2 = new long[] { (byte) 10, (byte) 0 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', (-1), (-1));
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) (byte) 0, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.CPrinterJob###############################################hi!", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33 + "'", int3 == 33);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 45, "ULbyUJvUJvVMUk8kUCUHU");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL" + "'", str3.equals("ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("us", ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("############################################52#-1#1#10#10###########################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10#10#1#-1#52#10", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob########################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10A0A10                                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10A0A10                                            \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "", (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "08_0.7.1" + "'", str1.equals("08_0.7.1"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "          -1/Users/sophie          ", (java.lang.CharSequence) "(TM) SE Runtime EnvironmentavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-10.0", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0", (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.3", (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 100, (long) (short) 1, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("tiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nus", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 100, (int) (byte) 0);
        try {
            byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1 100 1 -1 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) (-1), (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "-1 100 1 -1 100", (java.lang.CharSequence) "10#52#-1#1#10#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("tiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nusmixed modetiklooTCWL.xsocam.twawl.nus", (int) (short) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100a1a0a0a1", "sun.lwawt.macosx.CPrinterJob########################", "sun.lwawt.macosx.CPrinterJob########################", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100a1a0a0a1" + "'", str4.equals("100a1a0a0a1"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime environment" + "'", str1.equals("java(tm) se runtime environment"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "#a#a4a4a a#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("10.14.31.0-1.01.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.31.0-1.01.0" + "'", str1.equals("10.14.31.0-1.01.0"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("http://java.oracle.com/-1/Users/sophie0.0", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "htt" + "'", str2.equals("htt"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################" + "'", str1.equals("####################################################################################################"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.9", (double) 47);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9d + "'", double2 == 0.9d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "10#10#1#-1#52#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}

