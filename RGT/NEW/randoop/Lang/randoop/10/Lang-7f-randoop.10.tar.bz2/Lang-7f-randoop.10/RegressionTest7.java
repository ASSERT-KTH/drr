import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("PrinterJob########################.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PRINTERJOB########################." + "'", str1.equals("PRINTERJOB########################."));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8" + "'", str1.equals("utf-8"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "104524-1414104");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a", (java.lang.CharSequence) "10#10#1#-1#52#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" ", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10408_0.7.11045", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        float[] floatArray3 = new float[] { 1L, (-1), (short) 1 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a-1.0a1.0" + "'", str7.equals("1.0a-1.0a1.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("///////////////////////////////5757721651_35615_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "///////////////////////////////5757721651_35615_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/" + "'", str1.equals("///////////////////////////////5757721651_35615_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(33, 20, 40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.6");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("   1040   ", "############tiklooTCWL.xsocam.twawl.nus#############", "en", 16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "   1040   " + "'", str4.equals("   1040   "));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "suna.aawta.acgaraphicsaeanvironment", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("suwu8_u.7.ssuw5                             ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10.14UTF-810.14");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14utf-810.14" + "'", str1.equals("10.14utf-810.14"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-1/users/sophie0.0", "sun.lwawt.macosx.lwctoolkit1.3sun.lwawt.macosx.lwctoolkit1.3sun.lwawt.macosx.lwctoolki");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1/users/sophie0.0" + "'", str2.equals("-1/users/sophie0.0"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "8_0.7.1", 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/var/fo...", (java.lang.CharSequence) "10.14.310.14.310.14.#############################1.0a-1.0a1.0a45.0a100.0a1.0###");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.14.31.0-1.01.0", 7, 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0-1.0" + "'", str3.equals("1.0-1.0"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("AAAAAAAAAA\n", "", 79, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AAA" + "'", str4.equals("AAA"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.3", 33, "ULbyUJ UJ VMUk8kUCUH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ULbyUJ UJ VMUk8kUCUHULbyUJ UJ 1.3" + "'", str3.equals("ULbyUJ UJ VMUk8kUCUHULbyUJ UJ 1.3"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1#100#1#-1#100           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "          -1/Users/sophie          ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.4" + "'", charSequence2.equals("1.4"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaa\n", ") 64-Bit Serv", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        int[] intArray3 = new int[] { (byte) 10, 1, 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#1#10" + "'", str5.equals("10#1#10"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#1#10" + "'", str7.equals("10#1#10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a1a10" + "'", str9.equals("10a1a10"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10a1a10" + "'", str13.equals("10a1a10"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("phicsaeanvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sun.lwawt.macos");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macos\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "en     ...", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("suna.aawta.aCGaraphicsaEanvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"suna.aawta.aCGaraphicsaEanvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10a100a10", "", "        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         ", 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a100a10" + "'", str4.equals("10a100a10"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1052-111010");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10#10#1#-1#52#10", "(TM)JSEJRuntimeJEnvironmentavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#10#1#-1#52#10" + "'", str2.equals("10#10#1#-1#52#10"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1040104010401040104010401040104010401040", (java.lang.CharSequence) "sUNA.AAWTA.AcgARAPHICSAeANVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 27, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("java(tm) se runtime environment", strArray3, strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java(tm) se runtime environment" + "'", str5.equals("java(tm) se runtime environment"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/t/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "JAVA(TM) SE RUNTIME ENVI1.4JAVA(TM) SE RUN...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/t/" + "'", str4.equals("/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/t/"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("            sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt                         sunlwawtmacosxLWCToolkt             ", (long) 275);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 275L + "'", long2 == 275L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("SUNA.AAWTA.ACGARAPHICSAEANVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUNA.AAW\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1f + "'", float1 == 1.1f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "############", (java.lang.CharSequence) "1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/System/Library/Java/Extensions:/usr/lib/jav", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/System/Library/Java/Extensions:/usr/lib/jav" + "'", str3.equals("/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 1, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.0-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("AAAAAAAAAAAAAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAAAAA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4", (java.lang.CharSequence) "0.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.0", 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        int[] intArray3 = new int[] { (byte) 10, 1, 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', (-1), 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#1#10" + "'", str5.equals("10#1#10"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("100.0#100.0#1.0#1.0#-1.0#10.0", 45);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#100.0#1.0#1.0#-1.0#10.0" + "'", str2.equals("100.0#100.0#1.0#1.0#-1.0#10.0"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0.0 0.0 32.0 100.0 -1.010.0 0.0 32.0 100.0 -1.000.0 0.0 32.0 100.0 -1.0.0.0 0.0 32.0 100.0 -1.010.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.0.0.0 0.0 32.0 100.0 -1.030.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.0", (java.lang.CharSequence) "100a1a0a0a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("htt", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "htt" + "'", str6.equals("htt"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 7, (double) 47, 1.7d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7d + "'", double3 == 1.7d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "SUNA.AAWTA.AcgARAPHICSAeANVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("(T08_0.7.1", "java virtual machine specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(T08_0.7.1" + "'", str2.equals("(T08_0.7.1"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("44444444444444444444444444", "(t08_0.7.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444" + "'", str2.equals("44444444444444444444444444"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specificatio", 11, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificatio" + "'", str3.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaa", (java.lang.CharSequence) ") 64-Bit Serv");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100.0 100.0 1.0 1.0 -1.0 10.0", (java.lang.CharSequence) "0.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("AAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10#1#100#10#1#-1#52#10", (int) 'a', "1.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#1#100#10#1#-1#52#101.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.1" + "'", str3.equals("10#1#100#10#1#-1#52#101.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.1"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0.0eihpos/sresu/1-", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A" + "'", str1.equals("A"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("10a100a10", "0.0 0.0 32.0 100.0 -1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a100a10" + "'", str2.equals("10a100a10"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        float[] floatArray3 = new float[] { 1L, (-1), (short) 1 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) 'a', 4);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a-1.0a1.0" + "'", str7.equals("1.0a-1.0a1.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        double[] doubleArray6 = new double[] { 100, 100.0d, 1.0f, (short) 1, (-1L), 10L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 3, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/aaaaaaaaa...", (java.lang.CharSequence) "http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("         10#1#10          ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-1/users/sophie0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("(TM)aSEaRuntimens:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("AAAAAAAAAA", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAA444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("AAAAAAAAAA444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10 1 10", (java.lang.CharSequence) "10.14.310.14.310.14.############...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) 'a', 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa" + "'", str3.equals("aaa"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence2, (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob########################", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) 'a', (int) (byte) 10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str7.equals("sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("  edom dexim   ", "/venen/enenldenens/_v/6v497zmen4_v31enq1en1x1en4enen0000gen/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Mac OS X");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sUNA.AAWTA.ACGARAPHICSAEANVIRONMENT", (java.lang.CharSequence) "(TM) SE Runtime EnvironmentavaJ", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "(TM)aSEaRuntimeaEnvironmentavaJ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10408_0.7.11045", "0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean6 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        java.lang.String str10 = javaVersion8.toString();
        boolean boolean11 = javaVersion5.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean15 = javaVersion13.atLeast(javaVersion14);
        boolean boolean16 = javaVersion12.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean19 = javaVersion17.atLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean21 = javaVersion17.atLeast(javaVersion20);
        boolean boolean22 = javaVersion13.atLeast(javaVersion17);
        boolean boolean23 = javaVersion5.atLeast(javaVersion17);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.6" + "'", str10.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                Java(TM) SE Runtime Environment                ", (java.lang.CharSequence) "51.0#############################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64" + "'", str1.equals("X86_64"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("edom dexim", "aaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("a");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                 ", "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        int[] intArray6 = new int[] { 51, (short) 1, (byte) 1, ' ', ' ', '4' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 0, 1);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "51 1 1 32 32 52" + "'", str8.equals("51 1 1 32 32 52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "51 1 1 32 32 52" + "'", str11.equals("51 1 1 32 32 52"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "51" + "'", str15.equals("51"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        double[] doubleArray6 = new double[] { 100, 100.0d, 1.0f, (short) 1, (-1L), 10L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10 100 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "# # 4 4   #", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(97L, (long) 26, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                 !", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 !" + "'", str3.equals("                 !"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence1, (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob########################", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "                            phie0.0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.04-1.041.0445.04100.041.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.04-1.041.0445.04100.041.0" + "'", str2.equals("1.04-1.041.0445.04100.041.0"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("tiklooTCWL0xsoc#m0tw#wl0nu", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL0xsoc#m0tw#wl0nu" + "'", str2.equals("tiklooTCWL0xsoc#m0tw#wl0nu"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ULbyUJvUJvVMUk8kUCUHU", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("PRINTERJOB########################.", "1.0a-1.0a1.0pecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PRINTERJOB########################" + "'", str2.equals("PRINTERJOB########################"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575///////////////////////////////", "AAAAAAAAAAAAAAAAAAAAAAAAAA", "(TM)aSEaRuntimeaEnvironmentavaJ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 77L, (float) 97L, 27.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", 'a');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("3.41.01", "/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.01" + "'", str2.equals("3.41.01"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("25 23 23 1 1 15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "25 23 23 1 1 15" + "'", str1.equals("25 23 23 1 1 15"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        long[] longArray2 = new long[] { (byte) 10, (byte) 0 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', (-1), (-1));
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 44, 0);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1041410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1041410" + "'", str1.equals("1041410"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444" + "'", str2.equals("4444444444444444"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10404101040410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.0#100.0#1.0#1.0#-1.0#10.0", "ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL1.0412.044.0410.0410.0ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0", "#############################hi!", "100.0a100.0a1.0a1.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 34L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 34.0f + "'", float3 == 34.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", (int) ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nusJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', 100, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.0", charArray10);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', 0, 4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "####4#4# ##" + "'", str19.equals("####4#4# ##"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "#4#4444" + "'", str24.equals("#4#4444"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob########################", ' ');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HTTP://JAVAC0000GN/T/HTTP://JAVA", "sophie");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("104524-1414104", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "104524-1414104" + "'", str8.equals("104524-1414104"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#", "UTF-8", 52);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes", 0, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("utf-8", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8" + "'", str2.equals("utf-8"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                                ", "104524-141410410", 11, (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "           104524-141410410                                                             " + "'", str4.equals("           104524-141410410                                                             "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("enTIKLOOTCWL.XSOCAM.TWAWL.NUSTIKLOOTCWL.XSOCAM.TWAWL", "sun.lwawt.macos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enTIKLOOTCWL.XSOCAM.TWAWL.NUSTIKLOOTCWL.XSOCAM.TWAWL" + "'", str2.equals("enTIKLOOTCWL.XSOCAM.TWAWL.NUSTIKLOOTCWL.XSOCAM.TWAWL"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("...##############################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...##############################################################################################" + "'", str1.equals("...##############################################################################################"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0a-1.0a1.0", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ORCLE CORPORTION", 79, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################ORCLE CORPORTION################################" + "'", str3.equals("###############################ORCLE CORPORTION################################"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10a0a10", (java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkit1.3sun.lwawt.macosx.lwctoolkit1.3sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa\n444444444444444444444444444444444444", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "utf-8", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int[] intArray3 = new int[] { 10, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) (short) 0, 0);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ns:/usr/lib/java:.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("utf-8", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1/Users/sophie", 1.1f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1f + "'", float2 == 1.1f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1/Users/sophie0.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("###############################ORCLE CORPORTION################################", "iklooTCWL.xsocam.twawl.nus", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################" + "'", str3.equals("###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################iklooTCWL.xsocam.twawl.nus###############################ORCLE CORPORTION################################"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("11b-08.42", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11b-08.42" + "'", str2.equals("11b-08.42"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("        24.80-b11         ", "25 23 23 1 1 15", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "        24.80-b11         " + "'", str4.equals("        24.80-b11         "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaa\n444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/va");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.0", "c0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.0" + "'", str3.equals("1.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.0"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, '#', 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T", 14, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 100, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#a#a4a4a a#" + "'", str18.equals("#a#a4a4a a#"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 22, (long) '4', (long) 14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "8_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100.0#100.0#1.0#1.0#-1.0#10.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        float[] floatArray3 = new float[] { 1L, (-1), (short) 1 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 77, 34);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "1.0 -1.0 1.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 100, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10.14.31.0-1.01.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.31.0-1.01.0" + "'", str1.equals("10.14.31.0-1.01.0"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 11, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#a#a4a4a a#", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#a#a4a4a a#" + "'", str12.equals("#a#a4a4a a#"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10041404041", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/T/", 4, 79);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/T/"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecification", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                                                                                 ", 9, 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/so                                                                                                 j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/so                                                                                                 j/tmp/run_randoop.pl_50653_1560277575/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        short[] shortArray5 = new short[] { (byte) -1, (short) 100, (byte) 1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#100#1#-1#100" + "'", str7.equals("-1#100#1#-1#100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1 100 1 -1 100" + "'", str12.equals("-1 100 1 -1 100"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("(T08_0.7.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(T08_0.7.1" + "'", str2.equals("(T08_0.7.1"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10 100 10                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10 100 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        double[] doubleArray5 = new double[] { 1, 0.0f, (short) 1, 100.0d, 27 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1052-111010", (java.lang.CharSequence) "############");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("java virtual machine specificatio", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.14.31.0 -1.0 1.0", "10 52 -1 1 10 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.31.0 -1.0 1.0" + "'", str2.equals("10.14.31.0 -1.0 1.0"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 3, 13L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "44#4a4a4a44");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0a-1.0a1.0a45.0a100.0a1.0", "10#0#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("   100 1 0 0 1", "en", "0.0 0.0 32.0 100.0 -1.010.0 0.0 32.0 100.0 -1.000.0 0.0 32.0 100.0 -1.0.0.0 0.0 32.0 100.0 -1.010.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.0.0.0 0.0 32.0 100.0 -1.030.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.040.0 0.0 32.0 100.0 -1.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "08_0.7.1", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35, (double) 51, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444444444444444444444444444   100 1 0 0 1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("tiklooTCWL.xsocam.twawl.nus", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("104524-1414104", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104524-1414104" + "'", str2.equals("104524-1414104"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("PRINTERJOB########################.", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "###############################ORCLE CORPORTION################################", (java.lang.CharSequence) "0.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.0", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/var/fo...", "10.14.310.14.310.14.#############################1.0a-1.0a1.0a45.0a100.0a1.0###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/fo" + "'", str2.equals("/var/fo"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-14100414-14100", 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "java virtual machine specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10a100a10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "#4#44444 4#", (java.lang.CharSequence) "#a#a4a4a a#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = javaVersion4.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion4.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        java.lang.String str14 = javaVersion12.toString();
        boolean boolean15 = javaVersion9.atLeast(javaVersion12);
        java.lang.String str16 = javaVersion9.toString();
        java.lang.String str17 = javaVersion9.toString();
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        java.lang.String str19 = javaVersion9.toString();
        boolean boolean20 = javaVersion1.atLeast(javaVersion9);
        java.lang.String str21 = javaVersion9.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.6" + "'", str14.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.6" + "'", str16.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.6" + "'", str17.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.6" + "'", str19.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.6" + "'", str21.equals("1.6"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 48, (double) ' ', (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51 1 1 32 32 52");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaa...", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 2, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("####################################################################################################", 29, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################" + "'", str3.equals("#######################"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("///////////////////////////////5757721651_35615_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/", "(T08_0.7.1", 51);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("   1040   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   1040  " + "'", str1.equals("   1040  "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                    ", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        double[] doubleArray5 = new double[] { 1, 0.0f, (short) 1, 100.0d, 27 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("11b-08.42ixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode", 0, "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11b-08.42ixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode" + "'", str3.equals("11b-08.42ixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("     Java Virtual Machine Specification      ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.LWCToolkit", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("44444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("N", "#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOB" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnviro", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("///////////////////////////////5757721651_35615_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(") 64-Bit Serv", "JAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATION", 69);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("tIKLOOTCWL.XSOCAM.TWAWL.NUS", "JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATIONUTF-8JAVA VIRTUAL MACHINE SPECIFICATION", 20);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("java virtual machine specificatio", (double) 1.1f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.100000023841858d + "'", double2 == 1.100000023841858d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("iklooTCWL.xsocam.twawl.nus", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        short[] shortArray5 = new short[] { (byte) 100, (byte) 1, (short) 0, (byte) 0, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 10, 0);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a1a0a0a1" + "'", str13.equals("100a1a0a0a1"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10A0A10", "SUN.LWAWT.MACOSX.LWCTOOLKIT", "SUNA.AAWTA.ACGARAPHICSAEANVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10A0A10" + "'", str3.equals("10A0A10"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("!", ") 64-Bit Serv#a#a4a4a a#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Envi1.4Java(TM) SE Runtime Envir", charSequence1, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("0.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.0" + "'", str1.equals("0.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.01.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.10.0 0.0 32.0 100.0 -1.0"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "http://javac0000gn/T/http://java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("LUUHUCUk kUMVvJUvJUybLUUUHUCUk kUMVvJUvJUybLU", "/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                 ", (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100", "ORCLE CORPORTION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100" + "'", str2.equals("http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100http://javac0000gn/T/http:-1 100 1 -1 100"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80", charArray10);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', 34, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 34");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "#4#44444 4#" + "'", str15.equals("#4#44444 4#"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("51.0#############################################################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaa/Users/sophieaaaaaaaaaaa", "10a1a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaa/Users/sophieaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaa/Users/sophieaaaaaaaaaaa"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "(TM)aSEaRuntimens:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 0, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 32, (int) (byte) 0);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 275, 26);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophie", "1.1O1.1R1.1C1.1L1.1E1.1 1.1C1.1O1.1R1.1P1.1O1.1R1.1T1.1I1.1O1.1N1.1", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "en", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("08_0.7.1", "1.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "sun/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T./var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tawt/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T./var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/TCG/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Traphics/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/TE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tnvironment", (java.lang.CharSequence) "utf-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "(TM) SE Runtime EnvironmentavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 'a', (float) 27);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.1tIKLOOTCWL.XSOCAM.TWAWL.NUS", "aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.0 -1.0 1.0", (int) (byte) 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#4#4444", (java.lang.CharSequence) "(TM)JSEJRuntimeJEnvironmentavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("#######################", "10 100 10                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######################" + "'", str2.equals("#######################"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java(TM) SE Runtime Environment", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "10.14UTF-810.14");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1 100 1 -1 100", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "444444444444444444444444444444444444444444444444" + "'", charSequence2.equals("444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "10#52#-1#1#10#10");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10408_0.7.11045                             ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        float[] floatArray1 = new float[] { '4' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("suna.aawta.acgaraphicsaeanvironment", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Suna.aawta.aCGaraphicsaEanvironment", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Suna.aawta.aCGaraphicsaEanvironment" + "'", str2.equals("Suna.aawta.aCGaraphicsaEanvironment"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int[] intArray6 = new int[] { 51, (short) 1, (byte) 1, ' ', ' ', '4' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 0, 1);
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "51 1 1 32 32 52" + "'", str8.equals("51 1 1 32 32 52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "51 1 1 32 32 52" + "'", str11.equals("51 1 1 32 32 52"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "51" + "'", str15.equals("51"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.0a-1.0a1.0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a-1.0a1.0" + "'", str2.equals("1.0a-1.0a1.0"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaa", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1/users/sophie0.0.14.31.0 -1.0 1.0.14.31.0 -1.0 1.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a            " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a            "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        long[] longArray6 = new long[] { (short) 10, '4', (short) -1, 1, (short) 10, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#52#-1#1#10#10" + "'", str8.equals("10#52#-1#1#10#10"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#52#-1#1#10#10" + "'", str10.equals("10#52#-1#1#10#10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10 52 -1 1 10 10" + "'", str15.equals("10 52 -1 1 10 10"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10a52a-1a1a10a10" + "'", str17.equals("10a52a-1a1a10a10"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-14100414-14100", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("tiklootcwl.xsocam.twawl.nu", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 22, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("x86_64", "                 !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("####4#4# ##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "## #4#4####" + "'", str1.equals("## #4#4####"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("JAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATION", "10#1#100#10#1#-1#52#10", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATION" + "'", str3.equals("JAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("SUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str1.equals("sUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sUNA.AAWTA.AcgARAPHICSAeANVIRONMENT", "ra O.raO.rpecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "AAAAAAAAAA444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "44 4a4a4a44", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean6 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        java.lang.String str10 = javaVersion8.toString();
        boolean boolean11 = javaVersion5.atLeast(javaVersion8);
        java.lang.String str12 = javaVersion5.toString();
        java.lang.String str13 = javaVersion5.toString();
        java.lang.Class<?> wildcardClass14 = javaVersion5.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean16 = javaVersion5.atLeast(javaVersion15);
        java.lang.String str17 = javaVersion15.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.6" + "'", str10.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.6" + "'", str12.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.6" + "'", str13.equals("1.6"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.8" + "'", str17.equals("1.8"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("tiklooTCWL.xsocam.twawl.nusJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaa001#1-#1#001#1-aaaaaaaaaaaaaaaaaa", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/aaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Environment Runtime SE Java(TM)", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "14.31.0 -1.0 1.0", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("ULbyUJ UJ VMUk8kUCUH1.7", (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[][] strArray4 = new java.lang.String[][] { strArray0, strArray1, strArray2, strArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "tiklooTCWL.xsocam.twawl.nus");
        java.lang.Class<?> wildcardClass8 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("O.ra O.raO.rpecification", "m.9", 52, 33);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "O.ra O.raO.rpecificationm.9" + "'", str4.equals("O.ra O.raO.rpecificationm.9"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".0 100.0 1.0 1.0 -1.0 10.0", 15, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("          -1/Users/sophie          ", "-1/users/sophie0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          -1/Users/sophie          " + "'", str2.equals("          -1/Users/sophie          "));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-14100414-14100", (java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", (int) ' ');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "/Users/sophie", 10);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.awt.CGraphicsEnvironment", strArray4, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "10.14.310.14.310.14.#############################hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '4', 26, (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str9.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1 100 1 -1 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 100 1 -1 100" + "'", str1.equals("-1 100 1 -1 100"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("us", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaa/Users/sophieaaaaaaaaaaa", (java.lang.CharSequence) "ns:/usr/lib/java:.", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10.14.31.0 -1.0 1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10#1#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10#1#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        short[] shortArray3 = new short[] { (short) 10, (short) 100, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 26, 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#Java HotSpot(TM) 64-Bit Server VM#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 100, (int) (byte) 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 444444444444444444444444444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("11b-08.42ixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "11B-08.42IXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE" + "'", str1.equals("11B-08.42IXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str1.equals("sUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.31.0 -1.0 1.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410" + "'", str2.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1040410"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("01 1 01", 77);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 01" + "'", str2.equals("01 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 0101 1 01"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410", "java virtual machine specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410" + "'", str2.equals("104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                     0.0 0.0 32.0 100.0 -1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.lwawt....", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt...." + "'", str2.equals("sun.lwawt...."));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "            a-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("            a-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "c0000gn/T/", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Mac OS X", "", "                 !");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "sun.lwawt.macosx.CPrinterJob###############################################hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, (double) 1.1f, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "10A0A10                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence6, charArray7);
        java.lang.Class<?> wildcardClass9 = charArray7.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray7);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1 100 1 -1 100", charArray7);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Environment Runtime SE Java(TM)", charArray7);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.0a-1.0a1.0###############", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaa/Users/sophieaaaaaaaaaaa", "jAVA(tm) se rUNTIME eNVIRONMENT                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaa/Users/sophieaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaa/Users/sophieaaaaaaaaaaa"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("############", "####4#4# ##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############" + "'", str2.equals("############"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "tIKLOOTCWL.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                 ", (int) (byte) 0, "!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        long[] longArray2 = new long[] { (byte) 10, (byte) 0 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10a0" + "'", str5.equals("10a0"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean5 = javaVersion0.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "001#1-#1#001#1-", 14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.3", (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL" + "'", str3.equals("ULbyUJvUJvVMUk8kUCUHUUULbyUJvUJvVMUk8kUCUHUUL"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporation", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(275L, (long) 42, 8L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, 11, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 26, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("SUNA.AAWTA.ACGARAPHICSAEANVIRONMENT", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUNA.AAWTA.ACGARAPHICSAEANVIRONMENT" + "'", str3.equals("SUNA.AAWTA.ACGARAPHICSAEANVIRONMENT"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ns:/usr/lib/java:.", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ns:/usr/lib/java:." + "'", str3.equals("ns:/usr/lib/java:."));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v497zmn4_v31cq1n1x1n4fc0000gn/T/"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                tnemnorivnE emitnuR ES )MT(avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("tiklooTCWL.xsocam.twawl.nu");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsocam.twawl.nu" + "'", str1.equals("tiklooTCWL.xsocam.twawl.nu"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        float[] floatArray3 = new float[] { 1L, (-1), (short) 1 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10A0A10                                            ", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10A0A10                                            " + "'", str4.equals("10A0A10                                            "));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.0A-1.0A1.0A45.0A100.0A1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        short[] shortArray5 = new short[] { (byte) -1, (short) 100, (byte) 1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#100#1#-1#100" + "'", str7.equals("-1#100#1#-1#100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1 100 1 -1 100" + "'", str9.equals("-1 100 1 -1 100"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("http://javac0000gn/T/http:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://javac0000gn/T/http:" + "'", str1.equals("Http://javac0000gn/T/http:"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("51");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51" + "'", str1.equals("51"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "c0000gn/T/", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51653_1561277575///////////////////////////////", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444" + "'", str1.equals("44444444444444444444444444"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", 0, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410104524-141410410", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141410410" + "'", str2.equals("-141410410"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("11B-08.42IXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11B-08.42IXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE" + "'", str3.equals("11B-08.42IXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE(TM) SE RUNTIME ENVIRONMENTAVAJMIXED MODE"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.31.0 -1.0 1.0", "                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Environment Runtime SE Jv(TM)", "4", "100.04100.041.041.04-1.0410.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "           104524-141410410                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#a#a4a4a a#", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        float[] floatArray3 = new float[] { 1L, (-1), (short) 1 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', (int) 'a', (int) (short) -1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) '4', 7);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("52#3#-1#27");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52#3#-1#27" + "'", str1.equals("52#3#-1#27"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.0-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0-1.0" + "'", str1.equals("1.0-1.0"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.444444444444444E15d + "'", double1.equals(4.444444444444444E15d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        short[] shortArray5 = new short[] { (byte) -1, (short) 100, (byte) 1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#100#1#-1#100" + "'", str7.equals("-1#100#1#-1#100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aa                                                                                                -a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa                                                                                                -a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         ", "# # 4 4   #", 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         " + "'", str3.equals("        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                      ", (java.lang.CharSequence) ".14.31.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10A0A10                                           ", "jAVA(tm) se rUNTIME eNVIRONMENT                ", "ULbyUJ UJ VMUk8kUCUH1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("100.0 100.0 1.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 100.0 1.0 1.0 -1.0 10.0" + "'", str1.equals("100.0 100.0 1.0 1.0 -1.0 10.0"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(".0 100.0 1.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0 100.0 1.0 1.0 -1.0 10.0" + "'", str1.equals(".0 100.0 1.0 1.0 -1.0 10.0"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("# # 4 4   #");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.3", (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", 40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray3);
        java.lang.Class<?> wildcardClass5 = charArray3.getClass();
        java.lang.Class<?> wildcardClass6 = charArray3.getClass();
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#############################hi!", charArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ', 69, 48);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/System/Library/Java/Extensions:/usr/lib/jav", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ULbyUJ UJ VMUk8kUCUHU", (int) (short) -1, "phicsaeanvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ULbyUJ UJ VMUk8kUCUHU" + "'", str3.equals("ULbyUJ UJ VMUk8kUCUHU"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0-1.0", "tiklooTCWL.xsocam.twawl.nusJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ORCLE CORPORTION", "4444444444444444", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        float[] floatArray3 = new float[] { 1L, (-1), (short) 1 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 32, 4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 -1.0 1.0" + "'", str6.equals("1.0 -1.0 1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 -1.0 1.0" + "'", str9.equals("1.0 -1.0 1.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.04-1.041.0" + "'", str16.equals("1.04-1.041.0"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.04-1.041.0445.04100.041.0", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.041.0445.04100.041.0" + "'", str2.equals("-1.041.0445.04100.041.0"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//v", (java.lang.CharSequence) "sUNA.AAWTA.AcgARAPHICSAeANVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("eihpos/sresU/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "Java Virtual Machine Specificatio");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10.14UTF-810.14", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("phie0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/target/classes"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/aaaaaaaaa...", "en                                                                                                  ", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        double[] doubleArray6 = new double[] { 100, 100.0d, 1.0f, (short) 1, (-1L), 10L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "SUNA.AAWTA.AcgARAPHICSAeANVIRONMENT", (java.lang.CharSequence) "SUNA.AAWTA.ACGARAPHICSAEANVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(")", "10408_0.7.11045");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50653_1560277575///////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1040", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1040                                                                                                " + "'", str2.equals("1040                                                                                                "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aa  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "Http://javac0000gn/T/http:", 51);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 0, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 32, (int) (byte) 0);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 1 + "'", byte10 == (byte) 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (-1L), (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray11 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#a#a4a4a a#", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.0a-1.0a1.0a45.0a100.0a1.0", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaa\n", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob###############################################hi!", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 28 + "'", int16 == 28);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.0a-1.0a1.0###############");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.awt.CGraphicsEnvironment", "Suna.aawta.aCGaraphicsaEanvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/var/fo...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        float[] floatArray6 = new float[] { (byte) 1, (short) -1, 1L, 45, (short) 100, 1.0f };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a-1.0a1.0a45.0a100.0a1.0" + "'", str8.equals("1.0a-1.0a1.0a45.0a100.0a1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0a-1.0a1.0a45.0a100.0a1.0" + "'", str10.equals("1.0a-1.0a1.0a45.0a100.0a1.0"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("O.ra O.raO.rpecificationm.9");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray2);
        java.lang.Class<?> wildcardClass4 = charArray2.getClass();
        java.lang.Class<?> wildcardClass5 = charArray2.getClass();
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "en");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575", (int) ' ');
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "/Users/sophie", 10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.awt.CGraphicsEnvironment", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray2, strArray13);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str14.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.1.7.0_80_81.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str15.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.1.7.0_80_81.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/fo", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/fo" + "'", str2.equals("/var/fo"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x86_64", (int) '#', "aaaaaaaaaaa/Users/sophieaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaa/Users/sophieaaaaax86_64" + "'", str3.equals("aaaaaaaaaaa/Users/sophieaaaaax86_64"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         ", "#a#a4a4a aa45.0a100.0a1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         " + "'", str2.equals("24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         # # 4 4   #        24.80-b11                 24.80-b11                 24.80-b11                 24.80-b11         "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80-b15", "10#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("java virtual machine specification", "phie0.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("25 23 23 1 1 15", 35, "1.04-1.041.0445.04100.041.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "25 23 23 1 1 151.04-1.041.0445.0410" + "'", str3.equals("25 23 23 1 1 151.04-1.041.0445.0410"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("ns:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ns:/usr/lib/java:." + "'", str1.equals("ns:/usr/lib/java:."));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "r/folders/_v/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "aa  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        short[] shortArray5 = new short[] { (byte) -1, (short) 100, (byte) 1, (short) -1, (short) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 51, 29);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#100#1#-1#100" + "'", str7.equals("-1#100#1#-1#100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "(TM)aSEaRuntimeaEnvironmentavaJ", (int) (short) 0, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("001#1-#1#001#1-", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("51.0#############################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51.0#############################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10#52#-1#1#10#10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.awt.CGraphicsEnvir", (java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.0a-1.0a1.0pecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0a-1.0a1.0pecification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1040410", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "///////////////////////////////5757721651_35615_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 11, (double) (short) 10, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("UTF-8", "                                                                                                 ", 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0, 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sophie");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray5);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "25 23 23 1 1 151.04-1.041.0445.0410", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        int[] intArray3 = new int[] { 10, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) (short) 0, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a0a10" + "'", str9.equals("10a0a10"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "##1.0a-1.0a1.0a45.0a100.0a1.0###", "O.ra O.raO.rpecificationaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1/Users/sophie0.0", "", 1);
        java.lang.CharSequence charSequence7 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkitava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence7, (java.lang.CharSequence[]) strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob########################", (java.lang.CharSequence[]) strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("us", strArray5, strArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "51.0#############################################################################################", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "us" + "'", str13.equals("us"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a            ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a            " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-a            "));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean6 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        java.lang.String str10 = javaVersion8.toString();
        boolean boolean11 = javaVersion5.atLeast(javaVersion8);
        java.lang.String str12 = javaVersion5.toString();
        java.lang.String str13 = javaVersion5.toString();
        java.lang.String str14 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.6" + "'", str10.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.6" + "'", str12.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.6" + "'", str13.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.6" + "'", str14.equals("1.6"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10 52 -1 1 10 10", "1040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.04-1.041.0", (java.lang.CharSequence) "mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt....");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt..." + "'", str1.equals("sun.lwawt..."));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS X", (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#4#4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("100.0 100.0 1.0 1.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 100.0 1.0 1.0" + "'", str2.equals("100.0 100.0 1.0 1.0"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10#0#10", 34, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############10#0#10##############" + "'", str3.equals("#############10#0#10##############"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.7.0_80", "        24.80-b11         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10a0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("##1.0A-1.0A1.0A45.0A100.0A1.0###", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##1.0A-1.0A1.0A45.0A100.0A1.0###" + "'", str2.equals("##1.0A-1.0A1.0A45.0A100.0A1.0###"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...##############################################################################################", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.1.7.0_80_81.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "01 1 01", (java.lang.CharSequence) "#a#a4a4a a#", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("412.044.0410.04", 14, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...0410.04" + "'", str3.equals("...0410.04"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("####################################################################################################", "Orcle Corportion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################" + "'", str2.equals("####################################################################################################"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#############################hi!", 9, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 " + "'", str2.equals("                                 "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("#######################", "", "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################" + "'", str3.equals("#######################"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/var/fo", "(T08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/fo" + "'", str2.equals("/var/fo"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("iklooTCWL.xsocam.twawl.nus", "TIKLOOTCWL.XSOCAM.TWAWL.NUS", (int) (byte) 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("51", "AAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51" + "'", str2.equals("51"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14utf-810.14", "sun.lwawt....", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        int[] intArray3 = new int[] { 10, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) (short) 0, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) '#', 27);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1040410" + "'", str13.equals("1040410"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("c0000gn/T/", "edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom deximJavatnemnorivnE emitnuR ES )MT(edom dexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c0000gn/T/" + "'", str2.equals("c0000gn/T/"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { '#', '#', '4', '4', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "001#1-#1#001#1-", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "# # 4 4   #" + "'", str14.equals("# # 4 4   #"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("               ", "Java Virtual Machine Specific...");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51653_1561277575///////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "08_0.7.1", 42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#############################hi!", "/", (int) '#');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "mixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode(TM) SE Runtime EnvironmentavaJmixed mode", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "51#1#1#32#32#52");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#############################hi!" + "'", str7.equals("#############################hi!"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1040                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(":", "1.0 -1.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaa/Users/sophieaaaaax86_64", 11, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophieaaaaax86_64" + "'", str3.equals("/Users/sophieaaaaax86_64"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("#52#-1#1#10#10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "C0000GN/T/", (java.lang.CharSequence) "44 4a4a4a44", 275);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####################################################################################################", "Java Virtual Machine Specific...");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50653_1560277575/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("##1.0a-1.0a1.0a45.0a100.0a1.0###", "   100 1 0 0 1", 47, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#   100 1 0 0 1" + "'", str4.equals("#   100 1 0 0 1"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sophie", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray6);
        java.lang.Class<?> wildcardClass8 = charArray6.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray6);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1 100 1 -1 100", charArray6);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10A0A10                                            ", charArray6);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "PrinterJob########################.", charArray6);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44#4a4a4a44", "http://java.oracle.com/-1/Users/sophie0.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10.14.31.0-1.01.0", "edom dexim", "tiklooTCWL.xsocam.twawl.nusJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.31.0-1.01.0" + "'", str3.equals("10.14.31.0-1.01.0"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1040                                                                                                ", 69, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1040                                                                                                " + "'", str3.equals("1040                                                                                                "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "52#3#-1#27", (java.lang.CharSequence) "10#1#100#10#1#-1#52#101.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (long) (short) -1, (long) 34);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10 1 10", ".0 100.0 1.0 1.0 -1.0 10.0", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        float[] floatArray3 = new float[] { 1L, (-1), (short) 1 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 28, (int) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 -1.0 1.0" + "'", str6.equals("1.0 -1.0 1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 -1.0 1.0" + "'", str9.equals("1.0 -1.0 1.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0#-1.0#1.0" + "'", str12.equals("1.0#-1.0#1.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "10#1#100#10#1#-1#52#101.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.1", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        long[] longArray6 = new long[] { (short) 10, '4', (short) -1, 1, (short) 10, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', 51, (int) (byte) -1);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#52#-1#1#10#10" + "'", str8.equals("10#52#-1#1#10#10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[][] strArray4 = new java.lang.String[][] { strArray0, strArray1, strArray2, strArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(strArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "0.1 0.1- 0.13.41", 18, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaa\n", "phie0.0", (int) (byte) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "############################################52#-1#1#10#10###########################################", 47, 8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T", 69, "/va");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/va/va/va/va/va/va/va/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T" + "'", str3.equals("/va/va/va/va/va/va/va/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) ".14.31.0 -1.0 1.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.0", "444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.0" + "'", str2.equals("1.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.01.0a-1.0a1.0a45.0a100.0a1.0"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("            a-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                 !", (java.lang.CharSequence) "10#1#100#10#1#-1#52#10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }
}

