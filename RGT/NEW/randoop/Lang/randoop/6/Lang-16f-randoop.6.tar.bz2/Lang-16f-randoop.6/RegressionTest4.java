import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24###########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1773 + "'", int1 == 1773);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "noracle co", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("NOr...", 68, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.Class<?> wildcardClass5 = intArray1.getClass();
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/Library/Java/JavaVirtualMachines/jdk1.7.0...");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "MAC OS X         ", charSequence1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("corporati", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", "\n", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "chin\nibr" + "'", str3.equals("chin\nibr"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 0, "mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x                                                                                        1.7.0_80-b15mac os x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str3.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("s", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss" + "'", str2.equals("ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("    ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("\n", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) ' ', (float) 18, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 18.0f + "'", float3 == 18.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.8", "class [Iclass [Sclass org.apache.commons.lang3.StringUtilsclass [S", "Java Platform API Specification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "v/r...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "chin\nibr", "cification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", " CORPORATI", 100);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-B15", "51.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("rn", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("en", strArray1, strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "en" + "'", str7.equals("en"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 53, (double) 1773, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1773.0d + "'", double3 == 1773.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("tnemnorivnE emitnuR ES )MT(avaJ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str2.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "                                                                           ###############################                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/", 45, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      /                      " + "'", str3.equals("                      /                      "));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("fc0000gn/T/ _v31cq2n2x1n /var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "fc0000gn/T/ _v31cq2n2x1n /var/folders/_v/6v597zmn" + "'", str1.equals("fc0000gn/T/ _v31cq2n2x1n /var/folders/_v/6v597zmn"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("v/r...", "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("MAC OS X", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS X" + "'", str2.equals("MAC OS X"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", 17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X" + "'", str3.equals("MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun7lwawt7macosx7CPrinterJob", 4, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Platform API Specification", "##1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##" + "'", str1.equals("##"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("NR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NR" + "'", str1.equals("NR"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("un.lwawt.macosx.LWCToolkit", (float) 19);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 19.0f + "'", float2 == 19.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "UTF10.14.3aaaaaaaUTF10.14.3aaaaaaaUTF10.14.3aaaaaaa", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "JUTF10.14.3##########################################vUTF10.14.3##########################################VirtuUTF10.14.3##########################################lMUTF10.14.3##########################################chineSpecificUTF10.14.3##########################################tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "chin\nibr", (java.lang.CharSequence) "##################Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                 Oracle Corporatio                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Jv Virtul Mchine Specifiction", (java.lang.CharSequence) "Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("UTF10.14.3aaaaaaaUTF10.14.3aaaaaaaUTF10.14.3aaaaaaa", "NR", "                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF10.14.3aaaaaaaUTF10.14.3aaaaaaaUTF10.14.3aaaaaaa" + "'", str3.equals("UTF10.14.3aaaaaaaUTF10.14.3aaaaaaaUTF10.14.3aaaaaaa"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("rn", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rn                                              " + "'", str2.equals("rn                                              "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1773, 0L, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1773L + "'", long3 == 1773L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("a", (int) ' ', "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.31a10.14.310.14.310" + "'", str3.equals("10.14.310.14.31a10.14.310.14.310"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("############################################################################################Mac OS X", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################################################################################Mac OS X" + "'", str2.equals("#########################################################################################Mac OS X"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("JUTF10.14.3##########################################vUTF10.14.3##########################################VirtuUTF10.14.3##########################################lMUTF10.14.3##########################################chineSpecificUTF10.14.3##########################################tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JUTF10.14.3##########################################vUTF10.14.3##########################################VirtuUTF10.14.3##########################################lMUTF10.14.3##########################################chineSpecificUTF10.14.3##########################################tion" + "'", str1.equals("JUTF10.14.3##########################################vUTF10.14.3##########################################VirtuUTF10.14.3##########################################lMUTF10.14.3##########################################chineSpecificUTF10.14.3##########################################tion"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-B15", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-B15" + "'", str3.equals("1.7.0_80-B15"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1", "Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "UTF10.14.3##########################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/", "#", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os " + "'", str1.equals("mac os "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "                      /                      ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a", (java.lang.CharSequence) "US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Oracle CorporationOracle Corpora");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", 35, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.7.0_80-b151.7.0_80-b151.7.0_80-b1", "/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/uSERS/SOPHIE", "porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/S PHIE" + "'", str3.equals("/uSERS/S PHIE"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("  1.7.0_80-b15  ", "sun7lwawt7macosx7CPrinterJob", "24", 48);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  1.7.0_80-b15  " + "'", str4.equals("  1.7.0_80-b15  "));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../httpracle Corporat1.7.0_80-b151.7.0_80-b151.7.0_80-b1/", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        long[] longArray1 = new long[] { 16 };
        long[] longArray3 = new long[] { 16 };
        long[][] longArray4 = new long[][] { longArray1, longArray3 };
        long[] longArray6 = new long[] { 16 };
        long[] longArray8 = new long[] { 16 };
        long[][] longArray9 = new long[][] { longArray6, longArray8 };
        long[] longArray11 = new long[] { 16 };
        long[] longArray13 = new long[] { 16 };
        long[][] longArray14 = new long[][] { longArray11, longArray13 };
        long[][][] longArray15 = new long[][][] { longArray4, longArray9, longArray14 };
        long[] longArray17 = new long[] { 16 };
        long[] longArray19 = new long[] { 16 };
        long[][] longArray20 = new long[][] { longArray17, longArray19 };
        long[] longArray22 = new long[] { 16 };
        long[] longArray24 = new long[] { 16 };
        long[][] longArray25 = new long[][] { longArray22, longArray24 };
        long[] longArray27 = new long[] { 16 };
        long[] longArray29 = new long[] { 16 };
        long[][] longArray30 = new long[][] { longArray27, longArray29 };
        long[][][] longArray31 = new long[][][] { longArray20, longArray25, longArray30 };
        long[] longArray33 = new long[] { 16 };
        long[] longArray35 = new long[] { 16 };
        long[][] longArray36 = new long[][] { longArray33, longArray35 };
        long[] longArray38 = new long[] { 16 };
        long[] longArray40 = new long[] { 16 };
        long[][] longArray41 = new long[][] { longArray38, longArray40 };
        long[] longArray43 = new long[] { 16 };
        long[] longArray45 = new long[] { 16 };
        long[][] longArray46 = new long[][] { longArray43, longArray45 };
        long[][][] longArray47 = new long[][][] { longArray36, longArray41, longArray46 };
        long[] longArray49 = new long[] { 16 };
        long[] longArray51 = new long[] { 16 };
        long[][] longArray52 = new long[][] { longArray49, longArray51 };
        long[] longArray54 = new long[] { 16 };
        long[] longArray56 = new long[] { 16 };
        long[][] longArray57 = new long[][] { longArray54, longArray56 };
        long[] longArray59 = new long[] { 16 };
        long[] longArray61 = new long[] { 16 };
        long[][] longArray62 = new long[][] { longArray59, longArray61 };
        long[][][] longArray63 = new long[][][] { longArray52, longArray57, longArray62 };
        long[][][][] longArray64 = new long[][][][] { longArray15, longArray31, longArray47, longArray63 };
        java.lang.String str65 = org.apache.commons.lang3.StringUtils.join(longArray64);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertNotNull(longArray40);
        org.junit.Assert.assertNotNull(longArray41);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertNotNull(longArray47);
        org.junit.Assert.assertNotNull(longArray49);
        org.junit.Assert.assertNotNull(longArray51);
        org.junit.Assert.assertNotNull(longArray52);
        org.junit.Assert.assertNotNull(longArray54);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertNotNull(longArray57);
        org.junit.Assert.assertNotNull(longArray59);
        org.junit.Assert.assertNotNull(longArray61);
        org.junit.Assert.assertNotNull(longArray62);
        org.junit.Assert.assertNotNull(longArray63);
        org.junit.Assert.assertNotNull(longArray64);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " corporati", "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("UTF10.14.3aaaaaaa", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF10.14.3aaaaaaa" + "'", str2.equals("UTF10.14.3aaaaaaa"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "httpracle Corporationaaaaaaaaaaa...", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("avaVirtualMachines/jdk1.7.0_80.j", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("class [Iclass [Sclass org.apache.commons.lang3.StringUtilsclass [S");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: class [Iclass [Sclass org.apache.commons.lang3.StringUtilsclass [S is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lw", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lw" + "'", str2.equals("sun.lw"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 45.0f, (double) (short) 0, (double) 24.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("ORACLE CORPORATION", '#');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "##1.7.0_80", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "class [Ljava.lang.String;class [Dclass [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("597zmn4_v31cq2n2x1n4fc0000gn/t/", "Oracle Corporation", "24");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.8", 6, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a1.8aa" + "'", str3.equals("a1.8aa"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("24###########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 48, (long) 1, (long) 53);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 53L + "'", long3 == 53L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "\n", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 4, 0.0f, (float) 34);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 34.0f + "'", float3 == 34.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("444444444444444444444444444444444444444444444", (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.444444444444444E44d + "'", double2 == 4.444444444444444E44d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "rn                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aa08_0.7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.StringUtils");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Jv(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jv(TM) SE Runtime Environment" + "'", str1.equals("Jv(TM) SE Runtime Environment"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                   ", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                   " + "'", str3.equals("                                                   "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 177 + "'", int2 == 177);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.3   ", 1773);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24", "vr/folders/_v/6v5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        short[] shortArray2 = new short[] { (byte) 0, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Virtual Machine Specif", "Mac OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specif" + "'", str2.equals("Java Virtual Machine Specif"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aa08_0.7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa08_0.7.1" + "'", str1.equals("aa08_0.7.1"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 32);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', 45, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 45");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Oracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Oracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("##################Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##################Java Virtual Machine Specif" + "'", str1.equals("##################Java Virtual Machine Specif"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment44444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("rn                                              ", "3.41.013.41.013.41.013.41.013.41.013.41.013.4", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../Libr#ry/J#v#/J");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rn                                              " + "'", str3.equals("rn                                              "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0...", "a", "1.7");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                  3", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "s", (java.lang.CharSequence) "httpracle Corporat1.7.0_80-b151.7.0_80-b151.7.0_80-b1/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Virtual Machine Specif", (java.lang.CharSequence) "                                                   /");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94562_1560209309", "24###########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Oracle CorporationOracle Corpora", "en", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "3.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.5", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("FC0000GN/t/ _V31CQ2N2X1N /VAR/FOLDERS/_V/6V597ZMN", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../Libr#ry/J#v#/J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FC0000GN/t/ _V31CQ2N2X1N /VAR/FOLDERS/_V/6V597ZMN" + "'", str2.equals("FC0000GN/t/ _V31CQ2N2X1N /VAR/FOLDERS/_V/6V597ZMN"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!", "httpracle Corporationaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 16, 48);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/v/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Virtu/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/lM/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/chineSpecific/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/tion", "porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("3.41.013.41.013.41.013.41.013.41.013.41.013.4", "porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X", "                      /                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, 0.0d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaa...", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("##################Java Virtual Machine Specif", ".", "Jv Virtul Mchine Specifiction");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "#############################################NOracle Co#############################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("cification", "rn                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cificatio" + "'", str2.equals("cificatio"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "vr/frl", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("UTF10.14.3##########################################", "hi!", 8);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80-B15");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("                                  3", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "08_0.7.1", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 1, 45, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "##", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", "###############################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("#############################################NOracle Co#############################################", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################" + "'", str2.equals("##################"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("\n\n\n\n\n\n\n\n", "\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Oracle CorporationOracle Corpora", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle Corpora" + "'", str2.equals("Oracle CorporationOracle Corpora"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", "Sun.awt.CGraphicsEnvironment", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str3.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##################", (int) (byte) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", 0, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("NOracle Co", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 597ZMN4_V31CQ2N2X1N4FC0000GN/T/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server VM", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("AA08_0.7.1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AA08_0.7.1" + "'", str2.equals("AA08_0.7.1"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7#", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("                        sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("51.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment44444444444444444", (java.lang.CharSequence) "                                                                                        1.7.0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                        sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                        sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("                        sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.5", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "porationaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("porationaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94562_1560209309/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "s", 16);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", "hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                  3", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94562_1560209309");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("vr/folders/_v/6v5", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "##################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vr/folders/_v/6v5" + "'", str3.equals("vr/folders/_v/6v5"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", (java.lang.CharSequence) "                                                   /");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "#########################################################################################Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("############################################################################################Mac OS X", "httpracle Corporationaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################################################################################Mac OS X" + "'", str2.equals("############################################################################################Mac OS X"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.3", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("J/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/v/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Virtu/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/lM/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/chineSpecific/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/tion", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15", (float) 8L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl", "un.lwawt.macosx.LWCToolkit");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("3", strArray1, strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 0, 10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "3" + "'", str5.equals("3"));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94562_1560209309/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "RACLE CORPORATION", 62);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        long[] longArray2 = new long[] { (byte) 1, 2 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("##1.7.0_80", "4444444444444444444444444444444444", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_80" + "'", str3.equals("##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_80"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 97, 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "mixed   mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "racle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.StringUtils", "10.14.3   ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) " corporati");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aa08_0.7.1", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa08_0.7.1" + "'", str2.equals("aa08_0.7.1"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("  1.7.0_80-b15  ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("##################Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "#############################################NOracle Co#############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporatio", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corporatio" + "'", str4.equals("Oracle Corporatio"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 177, 0.0d, 17.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9", (int) (byte) 1, 1773);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("tnemnorivnE emitnuR ES )MT(avaJ", '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US", 45);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("x86_64", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Hi!                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", (java.lang.CharSequence) "NOr...", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                    " + "'", str1.equals("                                                    "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94562_1560209309", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                        sun.lwawt.macosx.CPrinterJob", "444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("                        sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 177, 1.7f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("r                                                    rporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"r                                                    rporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF10.14.3##########################################", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "racle Corporationaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("avaVnrtualMachnnes/jdk1.7.0_80.jdk/Contents/uome/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x                                                                                        1.7.0_80-B15mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("ORACLE CORPORATION", '#');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "mixed mode");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("597ZMN4_V31CQ2N2X1N4FC0000GN/T/", strArray4, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str8.equals("597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("vr/folders/_v/6v");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "vr/folders/_v/6v" + "'", str1.equals("vr/folders/_v/6v"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, (long) 34, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 32, 52L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Oracle CorporationOracle Corpora44444444444444444444444444444444444444444444444444444444444444444444", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.LWCToolkit", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "avaVirtualMachines/jdk1.7.0_80.j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                   ", "UTF10.14.3aaaaaaaUTF10.14.3aaaaaaaUTF10.14.3aaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Mac OS ", (java.lang.CharSequence) "3.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.01", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ORACLE CORPORATION", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "3", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "444444444444444444444444444444444444444444444", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "MAC OS X         ", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("##");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MAC OS X         ", "sun.awt.CGraphicsEnvironment44444444444444444");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "fc0000gn/T/ _v31cq2n2x1n /var/folders/_v/6v597zmn");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MA  OS X         " + "'", str4.equals("MA  OS X         "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "MAfc0000gn/T/ _v31cq2n2x1n /var/folders/_v/6v597zmn OS X         " + "'", str6.equals("MAfc0000gn/T/ _v31cq2n2x1n /var/folders/_v/6v597zmn OS X         "));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        org.apache.commons.lang3.StringUtils[] stringUtilsArray0 = new org.apache.commons.lang3.StringUtils[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray0);
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) stringUtilsArray0, "mixed4 4mode", (int) (byte) 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stringUtilsArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("corporati", "##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "corporati" + "'", str2.equals("corporati"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("RACLE CORPORATION", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7.0_80-B15", (java.lang.CharSequence) "racle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "corporati", (java.lang.CharSequence) "sun.lw", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("  1.7.0_80-b15  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  1.7.0_80-B15  " + "'", str1.equals("  1.7.0_80-B15  "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("###################http://java.oracle.com/####################", "Java Platform API Specification", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", "NOracle Co");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                      /                      ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 45 + "'", int1 == 45);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "avaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "##################Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("3.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.013.41.01");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "x86_64444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1, "class [Iclass [Sclass org.apache.commons.lang3.StringUtilsclass [S");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("24", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24" + "'", str3.equals("24"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("class [Iclass [Sclass org.apache.commons.lang3.StringUtilsclass [S", "HTTPRACLE cORPORATIONAAAAAAAAAAAAAA//JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime Environment", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1", "/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Platform API Specification", "cification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("NOracle Co", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Library/Java/JavaVirtualMachines/jdk1.7.0...", "porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 53, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0...porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0...porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixed mode", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " CORPORATI", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("#########################################################################################Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################################################################################Mac OS X" + "'", str1.equals("#########################################################################################Mac OS X"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", "/Lxbu#uy/J#v#/J#v#Vxusu#lM#.hxnws/jdk1.7.0...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "vr/folders/_v/6v5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/", "aa08_0.7.1", 68);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle CorporationOracle Corpora", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle Corpora" + "'", str2.equals("Oracle CorporationOracle Corpora"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle Corpora");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach(" CORPORATI", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str5.equals("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 100);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("r                                                    rporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "R                                                    RPORATION" + "'", str1.equals("R                                                    RPORATION"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Hi!                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str2.equals("Hi!                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "racle Corporationaaaaaaaaaaaaaa", (java.lang.CharSequence) "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "24");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("51.0");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 51.0f + "'", number1.equals(51.0f));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("44740_80-b4444740_80-b4444740_80-b4");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "class [Iclass [Sclass org.apache.commons.lang3.StringUtilsclass [S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        float[] floatArray2 = new float[] { 1L, (-1.0f) };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                    ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                    " + "'", str3.equals("                                                    "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "vr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/NRvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/f", (java.lang.CharSequence) "Oracle Corporation", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "##1.7.0_80", (java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("racle Corporation", "                      /                      ", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.2", "/Lxbu#uy/J#v#/J#v#Vxusu#lM#.hxnws/jdk1.7.0...", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Mac OS ", (java.lang.CharSequence) "cification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Hi!", (java.lang.CharSequence) "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0...", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0..." + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0..."));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF10.14.3aaaaaaaUTF10.14.3aaaaaaaUTF10.14.3aaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, 52L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("3", 182);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          3                                                                                           " + "'", str2.equals("                                                                                          3                                                                                           "));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 " + "'", str1.equals("                                                                                                 "));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "v/r...", 100, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "v/r..." + "'", str4.equals("v/r..."));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        double[] doubleArray5 = new double[] { 100.0d, 0.0f, 35, 52L, 10L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "PORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_80-b151.7.0_80-b151.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 0, (float) (short) 1, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "n", (java.lang.CharSequence) "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "rn                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 48, (long) 19, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("vr/frl", "", 3, 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "vr/rl" + "'", str4.equals("vr/rl"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str5 = javaVersion0.toString();
        java.lang.String str6 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9" + "'", str5.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/uSERS/S PHIE", "vr/frl", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/S PHIE" + "'", str3.equals("/uSERS/S PHIE"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '4', (double) 97, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mac os ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "PORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) '#', 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("FC0000GN/t/ _V31CQ2N2X1N /VAR/FOLDERS/_V/6V597ZMN", "sun.awt.CGraphicsEnvironment44444444444444444", "", 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "FC0000GN/t/ _V31CQ2N2X1N /VAR/FOLDERS/_V/6V597ZMN" + "'", str4.equals("FC0000GN/t/ _V31CQ2N2X1N /VAR/FOLDERS/_V/6V597ZMN"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java HotSpot(TM) 64-Bit Server VM", 34, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("...rs/_...", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("a1.8aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        char[] charArray6 = new char[] { '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ORACLE CORPORATION", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n\n\n\n\n\n\n\n", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixed4 4mode", (int) (short) -1, "class [Ljava.lang.String;class [Dclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed4 4mode" + "'", str3.equals("mixed4 4mode"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("rn", 177, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94562_1560209309", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../httpracle Corporat1.7.0_80-b151.7.0_80-b151.7.0_80-b1/", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../httpracle Corporat1.7.0_80-b151.7.0_80-b151.7.0_80-b1/" + "'", str2.equals("/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../httpracle Corporat1.7.0_80-b151.7.0_80-b151.7.0_80-b1/"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0.../httpracle Corporat1.7.0_80-b151.7.0_80-b151.7.0_80-b1/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("UTF10.14.3", "##################", "1.7.0_80-b15");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", "porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ORACLE CORPORATION", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "3", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.6", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                        1.7.0_80-b15", 17, 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java HotSpot(TM) 64-Bit Server VM is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "r                                                    rporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.6", 5, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 1.6 " + "'", str3.equals(" 1.6 "));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (float) 53);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 53.0f + "'", float2 == 53.0f);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("racle Corporationaaaaaaaaaaaaaa", "###################http://java.oracle.com/####################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle Corporationaaaaaaaaaaaaaa" + "'", str2.equals("racle Corporationaaaaaaaaaaaaaa"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("NOr...", "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("RACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RACLE CORPORATION" + "'", str1.equals("RACLE CORPORATION"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "NOr...", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("un.lwawt.macosx.LWCToolkit", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.awt.CGraphicsEnvironment", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "t" + "'", str2.equals("t"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("  1.7.0_80-b15  ", "##1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  1.7.0_80-b15  " + "'", str3.equals("  1.7.0_80-b15  "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("cification", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("UTF-8", 48);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_80-b151.7.0_80-b151.7.0_80-b1", "###################http://java.oracle.com/####################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################http://java.oracle.com/####################" + "'", str2.equals("###################http://java.oracle.com/####################"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7.0_80-B15", (java.lang.CharSequence) "Jv(TM) SE Runtime Environment", 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("UTF10.14.3aaaaaaaUTF10.14.3aaaaaaaUTF10.14.3aaaaaaa", "597zmn4_v31cq2n2x1n4fc0000gn/t/", 35, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTF10.14.3aaaaaaaUTF10.14.3aaaaa597zmn4_v31cq2n2x1n4fc0000gn/t/TF10.14.3aaaaaaa" + "'", str4.equals("UTF10.14.3aaaaaaaUTF10.14.3aaaaa597zmn4_v31cq2n2x1n4fc0000gn/t/TF10.14.3aaaaaaa"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94562_1560209309", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94562_1560209309" + "'", str3.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94562_1560209309"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "JavaVirtualMachineSpecification", 2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("tnemnorivnE emitnuR ES )MT(avaJ", '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("aaa...", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aaa..." + "'", str8.equals("aaa..."));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " 1.6 ", (java.lang.CharSequence) "Hi!", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.StringUtils", "x86_64444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.StringUtils" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.StringUtils"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8, "1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("cificatio", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cificatio" + "'", str2.equals("cificatio"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JavaVirtualMachineSpecification", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.Class<?> wildcardClass7 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JavaVirtualMachineSpecification" + "'", str6.equals("JavaVirtualMachineSpecification"));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0...");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10vr/folders/_v/6v50.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("R                                                    RPORATION", (int) (byte) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "R" + "'", str3.equals("R"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        double[] doubleArray5 = new double[] { 100L, (short) 10, 100, (byte) 10, 'a' };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("560209309/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("nOracle Co", "Java Virtual Machine Specif", "1.7#");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94562_1560209309aaaaaaaaaaaaaa", "############################################################################################Mac OS X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "vr/folders/_v/6v5", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.StringUtils");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.STRINGUTILS" + "'", str1.equals("CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.STRINGUTILS"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/uSERS/S PHIE", (java.lang.CharSequence) "UTF10.14.3aaaaaaaUTF10.14.3aaaaa597zmn4_v31cq2n2x1n4fc0000gn/t/TF10.14.3aaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                      /                      ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Oracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80", (int) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", 10, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Jv(TM) SE Runtime Environment", (java.lang.CharSequence) "                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "rl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", (int) (short) 10, "PORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str3.equals("444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " corporati", (java.lang.CharSequence) "fc0000gn/T/ _v31cq2n2x1n /var/folders/_v/6v597zmn", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("mixed mode", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X                                                                                        1.7.0_80-b15MAC OS X", "vr/folders/_v/6v5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Oracle CorporationOracle Corpora");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOracle Corpora" + "'", str1.equals("Oracle CorporationOracle Corpora"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32.0f, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        float[] floatArray4 = new float[] { 0L, (-1), 10, 0 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("MAC OS X         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "R                                                    RPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 981 + "'", int2 == 981);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "v/r...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80", 45, "##################Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80##################Java Virtual Machin" + "'", str3.equals("1.7.0_80##################Java Virtual Machin"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7#" + "'", str1.equals("1.7#"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(" corporati", 0, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " corporati" + "'", str3.equals(" corporati"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        char[] charArray3 = new char[] { '4' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MAfc0000gn/T/ _v31cq2n2x1n /var/folders/_v/6v597zmn OS X         ", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("08_0.7.1", "rl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.1" + "'", str2.equals("08_0.7.1"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US", "597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US" + "'", str2.equals("US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("CORPORATI", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15", "/T/ng0000cf n1x2n2qc13v_ nmz795v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15" + "'", str2.equals("                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US1.7US                                                                                        1.7.0_80-b15"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("597ZMN4_V31CQ2N2X1N4FC0000GN/T/", "t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str2.equals("597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, (long) (short) 0, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lw", "##################Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lw" + "'", str2.equals("sun.lw"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_804444444444444444444444444444444444##1.7.0_80", "noracle co", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 8, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MAC OS X         ", "sun.awt.CGraphicsEnvironment44444444444444444");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 97, 182);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MA  OS X         " + "'", str4.equals("MA  OS X         "));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        char[] charArray1 = new char[] { '4' };
        char[] charArray3 = new char[] { '4' };
        char[] charArray5 = new char[] { '4' };
        char[] charArray7 = new char[] { '4' };
        char[] charArray9 = new char[] { '4' };
        char[][] charArray10 = new char[][] { charArray1, charArray3, charArray5, charArray7, charArray9 };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray10);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("avaVnrtualMachnnes/jdk1.7.0_80.jdk/Contents/uome/jre", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("CORPORATI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-b11", strArray4, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4', (int) (short) 10, (int) (short) -1);
        java.lang.Class<?> wildcardClass15 = strArray8.getClass();
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("3.41.013.41.013.41.013.41.013.41.013.41.013.4", strArray5, strArray8);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mac os ", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "24.80-b11" + "'", str6.equals("24.80-b11"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "mixed mode" + "'", str10.equals("mixed mode"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3.41.013.41.013.41.013.41.013.41.013.41.013.4" + "'", str16.equals("3.41.013.41.013.41.013.41.013.41.013.41.013.4"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94562_1560209309aaaaaaaaaaaaaa", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94562_1560209309aaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94562_1560209309aaaaaaaaaaaaaa"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", "HTTPRACLE cORPORATIONAAAAAAAAAAAAAA//JAVA.ORACLE.COM/", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("UTF-8", (int) '4', 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94562_1560209309", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("NOracle Co", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NOracle Co" + "'", str3.equals("NOracle Co"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "                      /                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      /                      " + "'", str2.equals("                      /                      "));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(97L, (long) 182, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 182L + "'", long3 == 182L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                   ", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(7, 8, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("\n", "MAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "44740_80-b4444740_80-b4444740_80-b4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "NR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "1.7");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("3.41.013.41.013.41.013.41.013.41.013.41.013.4", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion2.atLeast(javaVersion3);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean8 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str9 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.5" + "'", str9.equals("1.5"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "class [Iclass [Sclass org.apache.commons.lang3.StringUtilsclass [S", (java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("cification", "1.2", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "444/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 10L, (long) 19);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 19L + "'", long3 == 19L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("24.80-b11", "#########################################################################################Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("24");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24" + "'", str1.equals("24"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                        1.7.0_80-b15", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("chin\nibr", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chin\nibr" + "'", str2.equals("chin\nibr"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("v/r...", 1, "httpracle Corporationaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "v/r..." + "'", str3.equals("v/r..."));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94562_1560209309", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                        sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "racle Corporationaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 1.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Sun.awt.CGraphicsEnvironment", 0, "MAC OS X         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str3.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (float) 18);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporatio", ".", "vr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/NRvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/frlvr/f");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporatio" + "'", str3.equals("Oracle Corporatio"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "rn                                              ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 48 + "'", int1 == 48);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("httpracle Corporationaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTPRACLE CORPORATIONAAAAAAAAAAA..." + "'", str1.equals("HTTPRACLE CORPORATIONAAAAAAAAAAA..."));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        short[] shortArray4 = new short[] { (byte) 100, (byte) -1, (byte) 10, (byte) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##################", (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit", "Oracle CorporationOracle Corpora44444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-b11", strArray5, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4', (int) (short) 10, (int) (short) -1);
        java.lang.Class<?> wildcardClass16 = strArray9.getClass();
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("3.41.013.41.013.41.013.41.013.41.013.41.013.4", strArray6, strArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("UTF-8", strArray1, strArray6);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "24.80-b11" + "'", str7.equals("24.80-b11"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "mixed mode" + "'", str11.equals("mixed mode"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3.41.013.41.013.41.013.41.013.41.013.41.013.4" + "'", str17.equals("3.41.013.41.013.41.013.41.013.41.013.41.013.4"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTF-8" + "'", str18.equals("UTF-8"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7#");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        float[] floatArray4 = new float[] { 0L, (-1), 10, 0 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss", "                      /                      ", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss" + "'", str3.equals("ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("R", "nOracle Co");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "R" + "'", str2.equals("R"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "UTF10.14.3aaaaaaaUTF10.14.3aaaaaaaUTF10.14.3aaaaaaa", (java.lang.CharSequence) "utf10.14.3##########################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "444444444444444444444444444444444444444444444", (java.lang.CharSequence) "UTF10.14.3aaaaaaaUTF10.14.3aaaaa597zmn4_v31cq2n2x1n4fc0000gn/t/TF10.14.3aaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mode                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", (java.lang.CharSequence) "3", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("3.41.013.41.013.41.013.41.013.41.013.41.013.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.013.41.013.41.013.41.013.41.013.41.013.4" + "'", str1.equals("3.41.013.41.013.41.013.41.013.41.013.41.013.4"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("rn");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Jv Virtul Mchine Specifiction");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("rn", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rn" + "'", str2.equals("rn"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "rn                                              ", charSequence1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("  1.7.0_80-b15  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:   1.7.0_80-b15   is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("HTTPRACLE cORPORATIONAAAAAAAAAAAAAA//JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/MOC.ELCARO.AVAJ//AAAAAAAAAAAAAANOITAROPROc ELCARPTTH" + "'", str1.equals("/MOC.ELCARO.AVAJ//AAAAAAAAAAAAAANOITAROPROc ELCARPTTH"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun7lwawt7macosx7CPrinterJob", "/Library/Java/JavaVirtualMachines/jdk1.7.0...porationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mixed4 4mode", 1773, "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwmixed4 4mode" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwmixed4 4mode"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("un.lwawt.macosx.LWCToolkit", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("  1.7.0_80-B15  ", "Java HotSpot(TM) 64-Bit Server VM", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  " + "'", str3.equals("  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  Java HotSpot(TM) 64-Bit Server VM  1.7.0_80-B15  "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("rl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl", 19, "chin\nibr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl" + "'", str3.equals("rl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl/vr/frl"));
    }
}

