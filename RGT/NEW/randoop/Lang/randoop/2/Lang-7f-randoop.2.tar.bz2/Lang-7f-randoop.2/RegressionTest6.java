import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("#                      aaaa#########################   ", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       #                      aaaa#########################   " + "'", str2.equals("       #                      aaaa#########################   "));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "Java Platform API Specification");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1004100404-1", (java.lang.CharSequence[]) strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "10.1J.3");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0#32", (java.lang.CharSequence[]) strArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "us");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7.0_80" + "'", str9.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7.0_80" + "'", str14.equals("1.7.0_80"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 27, (int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                               aaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = javaVersion3.atLeast(javaVersion7);
        boolean boolean11 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str12 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.1" + "'", str12.equals("1.1"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "SophieJava Virtual Machine ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                 ...", "# # a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "en", 32);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', (int) (short) 0, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JavaVirtualMachineSpecificationa", "32", (int) (byte) 100);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("JavaVirtualMachineSpecificationa", strArray4, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str9.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JavaVirtualMachineSpecificationa" + "'", str14.equals("JavaVirtualMachineSpecificationa"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR..." + "'", str2.equals("/VAR..."));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("01 1 01", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class [Dclass [Cclass [Cclass [Ljava.lang.String;class [Cclass [C", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str1.equals("100.0#-1.0#10.0#10.0#100.0"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("5", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa" + "'", charSequence2.equals("aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1#0", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#0" + "'", str3.equals("1#0"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { ' ', '#', '#', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', 22, 1142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " a#a#aa" + "'", str16.equals(" a#a#aa"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444", "1.5");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1#0aaaSu0 -Su0 0u0 32u", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-Su0 0u0 32u" + "'", str4.equals("1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-Su0 0u0 32u"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "52 100", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        char[] charArray9 = new char[] { ' ', '4', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1#10#0", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '#', 35, 13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0 -1.0 0.0 32.0     ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("   51.0   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "2#1", "#32", 26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("HI!", "mixedmod", "1.7");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10452");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10452L + "'", long1 == 10452L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444", "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Ophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("     aaasophi", "vM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 0, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0", (java.lang.CharSequence) "vM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Sophie", 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "52 100", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("OLPRoERLE ROLPRoERLE ROLPRo", (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(". . Pf0 API .f Pf0 API .f Pf0 API .");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..Pf0API.fPf0API.fPf0API." + "'", str1.equals("..Pf0API.fPf0API.fPf0API."));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("class [Dclass [Cclass [Cclass [Ljava.lang.String;class [Cclass [C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "10a1a-1a1a-1a1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 14 + "'", int1 == 14);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        int[] intArray2 = new int[] { (byte) 0, '4' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 9, 1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "32a1a35a0a10", (java.lang.CharSequence) "vM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 326 + "'", int2 == 326);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ".100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.", (java.lang.CharSequence) "1004100404-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.11.11.1", "1.0#-1.0#0.0#32.0                                                                                   ", (int) (short) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 211, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi" + "'", str2.equals("     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0.032.0100.0", "1.0 -1.0 0.0 32.0                  ", "                                                              10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.032.0100.0" + "'", str3.equals("0.032.0100.0"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0A32", "", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 7, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("LIB/JAVA:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"LIB/JAVA:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "###############################################0a32##############################################", (java.lang.CharSequence) "1#0aaaSu0 -Su0 0u0 32u", 326);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " sophie ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", (-1));
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("Users", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Users" + "'", str9.equals("Users"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("#########hi!##########", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sun.awt.CGraphicsEnvironmen", "0.0 10.0 32.0 10.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 10, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#32" + "'", str11.equals("0#32"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0#32" + "'", str13.equals("0#32"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 197, (float) 47, (float) 51);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 197.0f + "'", float3 == 197.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 197);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("###                                               US                                                ", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###                                               US                                                " + "'", str2.equals("###                                               US                                                "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(" 44444a", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               44444a                              " + "'", str2.equals("                               44444a                              "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, 7, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10a1a10", (java.lang.CharSequence) "lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.0 -1.0 0.0 32.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("         ", "                                                                                                                                                                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Su0 -Su0 0u0 32u", (java.lang.CharSequence) "/Users...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.0a-1.0a0.0a32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "LIB/JAVA:", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie", "0.0 32.0 100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.0 -1.0 0.0 32.0                  ", "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str12.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk", "100.0#-1.0#10.0#10.0#100.0", 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1#10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#10#-1" + "'", str1.equals("-1#10#-1"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.0 -1.0 0.0 32.0                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "", (java.lang.CharSequence) "   Hi!    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                        0#32                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                        0#32                        " + "'", str1.equals("                        0#32                        "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                  1", 5, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Library", "JavaVirtualMachineSpecificationa", "Hi! ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library" + "'", str4.equals("/Library"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("32a1a35a0a10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###", "sophie", 26);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#########hi!##########", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100.0a-1.0a10.0a10.0a100.0", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/t/NG0...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4...", 14, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4..." + "'", str3.equals("/Users/sophie/Documents/defects4..."));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("4444444444", "                                                              10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "2#1", (java.lang.CharSequence) "JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "2#1" + "'", charSequence2.equals("2#1"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("#Mac OS X#", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10A1A10", (java.lang.CharSequence) "2#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "32a1a35a0a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "SophieJava Virtua");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("100.0a-1.0a10.0a10.0a100.0", "aaasophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaasophi" + "'", str2.equals("aaasophi"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1 1- 1 1- 1 01", "#4a4#4 4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 1- 1 1- 1 01" + "'", str2.equals("1 1- 1 1- 1 01"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", (java.lang.CharSequence) "aaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 " + "'", charSequence2.equals("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 "));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence) "       sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/VAR...", (double) 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                                 ", (int) (byte) 100);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.8", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("JAVA VIRTUAL MACHIN 444# SP 444#CIFICATIONA", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHIN 444# SP 444#CIFICATIONA" + "'", str2.equals("JAVA VIRTUAL MACHIN 444# SP 444#CIFICATIONA"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#32");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#32" + "'", str2.equals("0#32"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#32" + "'", str3.equals("0#32"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1#10#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "52a10", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2L, (float) 67, (float) 143);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, "5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                                 ", (int) (byte) 100);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "      0.0a10.0a32.0a10.0a10.0a100.0");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray5);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(" a#a#aa", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a#a#aa" + "'", str2.equals(" a#a#aa"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java ( TM )   SE   Runtime   Environment" + "'", str3.equals("Java ( TM )   SE   Runtime   Environment"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " 444#", (java.lang.CharSequence) "       #                      aaaa#########################   ", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "                         hi!    ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "OLPRoERLE ROLPRoERLE ROLPRo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jree/Librnry/Jnvn/JnvnVirtunlMnchines/jdke.7._8.jdk/Contents/Home/jre");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/ L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jre" + "'", str3.equals("/ L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jre"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 10452L, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.0" + "'", str2.equals("0.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.0"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specification", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a Virtual Machine Specification" + "'", str2.equals("a Virtual Machine Specification"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        char[] charArray10 = new char[] { ' ', '4', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1#10#0", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-111-1", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk                                                                                                                                        ", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Su0-Su00u032ua1#0", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        short[] shortArray2 = new short[] { (short) 100, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100a10" + "'", str5.equals("100a10"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("...4444444444444444444", "0.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32.0f, (double) 97.0f, (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("   1    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a10a-1", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1", charArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#aaa#a a#" + "'", str12.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#aaa#a a#" + "'", str17.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "# a #   #" + "'", str19.equals("# a #   #"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Mac OS X", "", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(" a4a#", (int) (byte) 0, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " a4a#" + "'", str3.equals(" a4a#"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a10a-1", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100us100.", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#aaa#a a#" + "'", str13.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4...", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4..." + "'", str3.equals("/Users/sophie/Documents/defects4..."));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" eihpos ", "", "MIXED MODEjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICAT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " eihpos " + "'", str3.equals(" eihpos "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "52#100 ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.8");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 252 + "'", int3 == 252);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("\n", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                       mixed mode", "141040", "44444444444444444444444444444444444444444444444444444444444444444      0.0a10.0a32.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                       mixed mode" + "'", str3.equals("                                                                                       mixed mode"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        long[][] longArray0 = new long[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(longArray0);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo" + "'", str1.equals("oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                               US                                                ", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100.0#-1.0#10.0#10.0#100.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("24.80-b11", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Su0 -Su0 0u0 32u", "   51.0   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) ' ', (float) 'a', (float) 35);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Sophie", (java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "X86_64");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52#100" + "'", str7.equals("52#100"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("      0...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ", 67);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("###################4##");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk", 47);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71 + "'", int2 == 71);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "Users");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Users" + "'", charSequence2.equals("Users"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (byte) 32, (int) ' ');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 8, 0);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 10 + "'", byte13 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 10 + "'", byte14 == (byte) 10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("100.0 -1.0 10.0 10.0 100.0", "...4444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 -1.0 10.0 10.0 100.0" + "'", str2.equals("100.0 -1.0 10.0 10.0 100.0"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.0", (java.lang.CharSequence) "110a1a10", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("JavaVirtualMachineSpecificationa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JavaVirtualMachineSpecificationa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("0.0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0#100.0" + "'", str1.equals("0.0#100.0"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                   ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.0a-1.0a0.0a32.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("001#25", "VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "001#25" + "'", str2.equals("001#25"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44444444444444444444444444444444", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("   1    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.04100.041.041.5462.0432.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10452104521045210452104521045210452104521045AAASOPHI104521045210452104521045210452104521045210452");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "M10a1a10Ma", (java.lang.CharSequence) "10 1 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0A32", (long) 49);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49L + "'", long2 == 49L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("52a10", "sun.lwawt.macosx.LWCToolkit", "-1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(9, 2, 197);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 197 + "'", int3 == 197);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100us100.", "...itacificepSIPAmroftalPavaJ", "0.910.9.0.9");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100us1000" + "'", str3.equals("100us1000"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("#aaa#a a#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: #aaa#a a# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 326, (float) (short) 10, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 326.0f + "'", float3 == 326.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("32", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ":");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "JavaVirtualMachineSpecificationa", (-1), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.", "...4444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " a4a#", "####################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 179, 0.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-8");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1.0#100a320a320a320a320a320a320a320a320a320a321.0#1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#100a320a320a320a320a320a320a320a320a320a321.0#1.5" + "'", str1.equals("-1.0#100a320a320a320a320a320a320a320a320a320a321.0#1.5"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("100.0a-1.0a10.0a10.0a100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        short[] shortArray1 = new short[] { (byte) 1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1a10a0", 179, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                             1a10a0" + "'", str3.equals("                                                                                                                                                                             1a10a0"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        float[] floatArray2 = new float[] { 0.0f, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) (byte) 10, 10);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " 444#", (java.lang.CharSequence) "Java Platform API Specificati...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-111-1", "10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-111-1" + "'", str2.equals("-111-1"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0a-1.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.", "################################   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#4 4#4a4#", "                         Hi!    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4 4#4a4#" + "'", str2.equals("#4 4#4a4#"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "0.0#32.0#100.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 14, 179);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a32" + "'", str8.equals("0a32"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0.910.9.0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        float[] floatArray2 = new float[] { 0.0f, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10#1#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "52#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Su0 -Su0 0u0 32ua1#0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Su0 -Su0 0u0 32ua1#0" + "'", str2.equals("Su0 -Su0 0u0 32ua1#0"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "aaa", 62);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "#Mac OS X#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", "", "aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat" + "'", str3.equals("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                      aaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 26 + "'", int1 == 26);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-111-1", (java.lang.CharSequence) "mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 53 + "'", int1 == 53);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                 ...", "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 ..." + "'", str2.equals("                                                 ..."));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!############################################### 444#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("   ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 62);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "SophieJava Virtual Machine ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mixedmod", (java.lang.CharSequence) "100.0 -1.0 10.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "1.", (int) (short) 1, 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1." + "'", str4.equals("1."));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100404-1", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#aaa#a a#" + "'", str10.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100.0a-1.0a10.0a10.0a100.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                  1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ", (java.lang.CharSequence) "0.0a10.0a32.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   " + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ", ".8", 197);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Specificati... API Platform Specificati...1Java API Platform Specificati...-Java API Platform Specificati...1Java API Platform Specificati...1Java API Platform Specificati...1Java API Platform Specificati...-Java API Platform Java", (java.lang.CharSequence) "                                              HI!                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, 49L, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 8, 0);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 71, 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 10 + "'", byte14 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a32" + "'", str9.equals("0a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#32" + "'", str11.equals("0#32"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0a32" + "'", str14.equals("0a32"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("AAASOPHI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAASOPHI\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        short[] shortArray3 = new short[] { (short) 10, (byte) 1, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 47, (int) (short) 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10a1a10" + "'", str6.equals("10a1a10"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#1#10" + "'", str8.equals("10#1#10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10 1 10" + "'", str14.equals("10 1 10"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10#1#10" + "'", str16.equals("10#1#10"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("ophi", (int) (byte) -1, 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i" + "'", str3.equals("i"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#', 52, (int) (byte) 1);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#100#100#0" + "'", str6.equals("-1#100#100#0"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                   ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#                      aaaa#########################   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#                      aaaa#########################" + "'", str1.equals("#                      aaaa#########################"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "vM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java", (java.lang.CharSequence) "       #                      aaaa#########################   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10A1A10", 326);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10A1A10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10A1A10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################################################################" + "'", str2.equals("################################################################################################"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java", (java.lang.CharSequence) "-1.04100.041.041.5462.0432.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("52 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"52 100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("JAVA VIRTUAL MACHIN 444# SP 444#CIFICATIONA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHIN 444# SP 444#CIFICATIONA" + "'", str1.equals("JAVA VIRTUAL MACHIN 444# SP 444#CIFICATIONA"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        short[] shortArray3 = new short[] { (short) 10, (byte) 1, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 10, (int) (byte) 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10a1a10" + "'", str6.equals("10a1a10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("00010000", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray2 = (java.lang.Class<?>[]) classArray1;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Class<?>[]) classArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) classArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) classArray1);
        org.junit.Assert.assertNotNull(classArray1);
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 1132);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/VAR...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR..." + "'", str1.equals("/VAR..."));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.0 -1.0 0.0 32.0                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 -1.0 0.0 32.0                  " + "'", str1.equals("1.0 -1.0 0.0 32.0                  "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("2#100", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              2#100" + "'", str2.equals("                              2#100"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", '4');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        int[] intArray4 = new int[] { 100, 100, 0, (-1) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1004100404-1" + "'", str6.equals("1004100404-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1004100404-1" + "'", str8.equals("1004100404-1"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mixed ...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed ..." + "'", str2.equals("mixed ..."));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35, 0.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 17, (double) 27, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                         hi!    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\n", (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("524100", (float) 252);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 524100.0f + "'", float2 == 524100.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.0 -1.0 0.0 32.0", (java.lang.CharSequence) "###############################################0a32##############################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "e", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "e" + "'", charSequence2.equals("e"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', (int) (short) 10, 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 1, (int) (byte) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', 51, 5);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#100#100#0" + "'", str6.equals("-1#100#100#0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1#100#100#0" + "'", str17.equals("-1#100#100#0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/ L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jree / L ibrnry / J nvn / J nvn V irtunl M nchines / jdke . 7 . _ 8 . jdk / C ontents / H ome / jre", (java.lang.CharSequence) "100.04-1.0410.0410.04");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622", charSequence1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("  # # a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("       sun.awt.CGraphicsEnvironment", "10452", "52 100", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "       sun.awt.CGraphicsEnvironment" + "'", str4.equals("       sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        short[] shortArray3 = new short[] { (short) 10, (byte) 1, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 32);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java Virtual Machine Specification", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Specificati... API Platform Specificati...1Java API Platform Specificati...-Java API Platform Specificati...1Java API Platform Specificati...1Java API Platform Specificati...1Java API Platform Specificati...-Java API Platform Java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sPECIFICATI... api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...-jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...-jAVA api pLATFORM jAVA" + "'", str1.equals("sPECIFICATI... api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...-jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...-jAVA api pLATFORM jAVA"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("          ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SophieJava Virtual Machine ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Su0 -Su0 0u0 32ua1#0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1041410", 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.910.9.0.9");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        int[] intArray2 = new int[] { (byte) 0, '4' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 9, 1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "          ", (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "   " + "'", charSequence2.equals("   "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixedmod");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##" + "'", str1.equals("##"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Su0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("################################   ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1" + "'", str6.equals("-1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.0a17.0a97.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0a17.0a97.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 252, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "################################", (java.lang.CharSequence) "0 -1.0 0.0 32.0     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        float[] floatArray4 = new float[] { 1L, (-1L), (byte) 0, ' ' };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', (int) (byte) 0, 0);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0 -1.0 0.0 32.0" + "'", str7.equals("1.0 -1.0 0.0 32.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0#-1.0#0.0#32.0" + "'", str9.equals("1.0#-1.0#0.0#32.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0#-1.0#0.0#32.0" + "'", str12.equals("1.0#-1.0#0.0#32.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 32.0f + "'", float14 == 32.0f);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("       #                      aaaa#########################   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#                      aaaa#########################" + "'", str1.equals("#                      aaaa#########################"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa" + "'", str2.equals("aaaa"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.", 47, "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100." + "'", str3.equals("100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100."));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("a### ##", "sophie", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        float[] floatArray6 = new float[] { 0.0f, (-1L), (-1L), (-1L), 0.0f, (byte) 1 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "OLPRoERLE ROLPRoERLE ROLPRo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-1#10#-1", (java.lang.CharSequence) "   sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("################################444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################444" + "'", str2.equals("################################444"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("       #                      aaaa#########################   ", (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(":OphiOphiO", "10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1#0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "52a10");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 100, 35);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        float[] floatArray2 = new float[] { 0.0f, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) (byte) 100, (int) (byte) 10);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("javaVirtualMachineSpecificationa", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                              10 1 -1 1 -1 1                     ", "1.1", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0 -1.0 0.0 32.0     ", "100.04-1.0410.0410.04100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10 1 -1 1 -1 1", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100.04-1.0410.0410.04", charSequence1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                                                                                                             1a10a0", "0.0#-1.0#-1.0#-1.0#0.0#1.0", 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                             1a10a0" + "'", str3.equals("                                                                                                                                                                             1a10a0"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.0#-1.0#0.0#32.0                                                                                   ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 8, 0);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 10 + "'", byte13 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie", "                                                                                                 ", (int) (short) 100);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie" + "'", str5.equals("/Users/sophie"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("32a1a35a0a10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(".100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.100us100.", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                               aaaa", "LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.Class<?> wildcardClass10 = intArray2.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a32" + "'", str8.equals("0a32"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.11.11.1", "#4 4#4a4#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 34, (long) 4, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("01 1 01", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01 1 01" + "'", str2.equals("01 1 01"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        char[] charArray10 = new char[] { ' ', '4', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1#10#0", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "141040", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " 44444a", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("############lib/java:.", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############lib/jv:." + "'", str2.equals("############lib/jv:."));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "############################################### 444#", (java.lang.CharSequence) "10a1a-1a1a-1a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                         hi!    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATI...", (java.lang.CharSequence) "################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Ophi", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.0 -1.0 0.0 32.0", (java.lang.CharSequence) "      0.0a10.0a32.0a10.0a10.0a100.0", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str9 = javaVersion4.toString();
        java.lang.String str10 = javaVersion4.toString();
        boolean boolean11 = javaVersion0.atLeast(javaVersion4);
        java.lang.Class<?> wildcardClass12 = javaVersion4.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.1" + "'", str9.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.1" + "'", str10.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################################################################################" + "'", str1.equals("###################################################################################################"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "!", (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "       sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                                 ", (int) (byte) 100);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "Java Platform API Specification");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "2#100");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("class [Dclass [Cclass [Cclass [Ljava.lang.String;class [Cclass [C", strArray5, strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "class [Dclass [Cclass [Cclass [Ljava.lang.String;class [Cclass [C" + "'", str12.equals("class [Dclass [Cclass [Cclass [Ljava.lang.String;class [Cclass [C"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SU0 -SU0 0U0 32U", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 32, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100us1000");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("..Pf0API.fPf0API.fPf0API.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..Pf0API.fPf0API.fPf0API." + "'", str1.equals("..Pf0API.fPf0API.fPf0API."));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#100#100#0" + "'", str6.equals("-1#100#100#0"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...", (java.lang.CharSequence) "lib/java:.", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Http://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/VAR...", 62, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################################################/VAR..." + "'", str3.equals("#######################################################/VAR..."));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("TNEMNORIVNESCIHPARGC.TWA.NUS      ", "#4 4#4a4#", 326);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TNEMNORIVNESCIHPARGC.TWA.NUS      " + "'", str3.equals("TNEMNORIVNESCIHPARGC.TWA.NUS      "));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "52#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" eihpos ", "Ophi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0#32");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#32\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("# # a", 53, 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sophie", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("TNEMNORIVNESCIHPARGC.TWA.NUS      ", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        double[] doubleArray6 = new double[] { (byte) 0, 10.0f, ' ', (short) 10, 10.0d, 100L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 100, 8);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', (int) 'a', 47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0a10.0a32.0a10.0a10.0a100.0" + "'", str9.equals("0.0a10.0a32.0a10.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "su" + "'", str1.equals("su"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 3, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        char[] charArray10 = new char[] { ' ', '#', '#', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0 32", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        long[] longArray2 = new long[] { '4', (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "52#100" + "'", str4.equals("52#100"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "524100" + "'", str6.equals("524100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("00010000", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 1, 71);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a32" + "'", str9.equals("0a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#32" + "'", str11.equals("0#32"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0a32" + "'", str14.equals("0a32"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 32" + "'", str16.equals("0 32"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java" + "'", str1.equals("VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(" #4##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " #4##" + "'", str1.equals(" #4##"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaa", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("a Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "       sun.awt.CGraphicsEnvironmen", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.0#100.0", "                  #4##");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 34, 143);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 34");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10452104521045210452104521045210452104521045AAASOPHI104521045210452104521045210452104521045210452", "1.0 -1.0 0.0 32.0                  ", "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", 22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10452104521045210452104521045210452104521045AAASOPHI104521045210452104521045210452104521045210452" + "'", str4.equals("10452104521045210452104521045210452104521045AAASOPHI104521045210452104521045210452104521045210452"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        float[] floatArray2 = new float[] { 0.0f, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.04100.0" + "'", str5.equals("0.04100.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0.0432.04100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "...itacificepSIPAmroftalPavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                ", "!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        double[] doubleArray6 = new double[] { (byte) 0, 10.0f, ' ', (short) 10, 10.0d, 100L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0a10.0a32.0a10.0a10.0a100.0" + "'", str9.equals("0.0a10.0a32.0a10.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                   ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0###################4##0.032.0100.0", "10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0 -1.0 0.0 32.0     ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaa", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa" + "'", str2.equals("aaaa"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#                      aaaa#########################", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa#########################" + "'", str2.equals("#                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa##########################                      aaaa#########################"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1#100#100#0", 3, "100.04-1.0410.0410.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#100#100#0" + "'", str3.equals("-1#100#100#0"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.81.1", "001#25", (int) (byte) 10, 19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.81.1001#25" + "'", str4.equals("1.81.1001#25"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0 -1.0 0.0 32.0", ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 17, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 62, 22);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a32" + "'", str9.equals("0a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#32" + "'", str11.equals("0#32"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0a32" + "'", str14.equals("0a32"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 32" + "'", str16.equals("0 32"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10A1A10/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a10a-1" + "'", str9.equals("-1a10a-1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1#10#-1" + "'", str12.equals("-1#10#-1"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed ...", "Hi!", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                         hi!    ", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        java.lang.String str4 = javaVersion0.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "-1", (java.lang.CharSequence) "1.0 -1.0 0.0 32.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " a#a#aa", 67);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("       sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 0, 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library..." + "'", str3.equals("/Library..."));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(".8");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.8f + "'", float1 == 0.8f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "5", 1, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("#Mac OS X#", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X# OS #Mac" + "'", str2.equals("X# OS #Mac"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-111-1", (java.lang.CharSequence) "14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.8/Users/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "x86_64");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 0, 4);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a.aa/" + "'", str7.equals("1a.aa/"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a0aaaa0", "lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(". . Pf0 API .f Pf0 API .f Pf0 API .", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1 10 -1" + "'", str10.equals("-1 10 -1"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "SophieJava Virtual Machine ", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(".", "1a10a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444      0.0a10.0a32.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                               aaaa", (java.lang.CharSequence) "/Users/sophie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                               aaaa" + "'", charSequence2.equals("                               aaaa"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 5.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) " 444#", (java.lang.CharSequence) "0 32", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects410A1A10/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", "4444444444", "52100", 13);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects410A1A10/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str4.equals("/Users/sophie/Documents/defects410A1A10/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "32", (java.lang.CharSequence) "1.6", 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("su");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("# a #   #", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# a #   #" + "'", str2.equals("# a #   #"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14104-1" + "'", str12.equals("-14104-1"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 10 + "'", byte13 == (byte) 10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("################################################################################################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################################################################" + "'", str2.equals("################################################################################################"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "vM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0 -1.0 0.0 32.0     ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 -1.0 0.0 32.0     " + "'", str2.equals("0 -1.0 0.0 32.0     "));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("jAVApLATFORMapisPECIFICATI...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVApLATFORMapisPECIFICATI..." + "'", str1.equals("jAVApLATFORMapisPECIFICATI..."));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.0", (java.lang.CharSequence) "aaasophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("a Virtual Machine Specification", 67, " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a Virtual Machine Specification                                    " + "'", str3.equals("a Virtual Machine Specification                                    "));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                    1.0 -1.0 0.0 32.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "   Hi!    ", (java.lang.CharSequence) "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "0.0 32.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(" #4##");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", ". . Pf0 API .f Pf0 API .f Pf0 API .");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     ", (java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 53, "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironm" + "'", str3.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironm"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("  4 #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 #" + "'", str1.equals("4 #"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1 10 -1" + "'", str9.equals("-1 10 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1#10#-1" + "'", str13.equals("-1#10#-1"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java ( TM )   SE   Runtime   Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA ( tm )   se   rUNTIME   eNVIRONMENT" + "'", str1.equals("jAVA ( tm )   se   rUNTIME   eNVIRONMENT"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0 -1.0 0.0 32.0     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("       sun.awt.CGraphicsEnvironmen", "      0...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       sun.awt.CGraphicsEnvironmen" + "'", str2.equals("       sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################" + "'", str1.equals("####################################################################################################"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                        1.81.1", (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" eihpos ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:  eihpos  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', 8, (int) (short) 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1 10 -1" + "'", str9.equals("-1 10 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1#10#-1" + "'", str13.equals("-1#10#-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sPECIFICATI... api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...-jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...1jAVA api pLATFORM sPECIFICATI...-jAVA api pLATFORM jAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "       sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str12.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0.032.0100.0", "            aaasophi            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.032.0100.0" + "'", str2.equals("0.032.0100.0"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a0" + "'", str9.equals("1a10a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1a10a0" + "'", str11.equals("1a10a0"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", (java.lang.CharSequence) "aaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0#32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0a320a320a320a320a320a320a320a320a320a32");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.0#-1.0#0.0#32.0                                                                                   ", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#-1.0#0.0#32.0                                                                                   " + "'", str2.equals("1.0#-1.0#0.0#32.0                                                                                   "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 11, (float) 52, (float) 49L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("      0...", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, 11L, (long) 13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("################################################################################################", 19, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################################################################################" + "'", str3.equals("################################################################################################"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a Virtual Machine Specification                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a Virtual Machine Specification" + "'", str1.equals("a Virtual Machine Specification"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-Su0 0u0 32u", (java.lang.CharSequence) "#4 4#4a4#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("52#100", "            aaasophi            ", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        long[] longArray2 = new long[] { '4', (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 0, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "52#100" + "'", str4.equals("52#100"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "524100" + "'", str6.equals("524100"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 32, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "100.04-1.0410.0410.04", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.00.0", "0a320a320a320a320a320a320a320a320a320a32");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a10a-1", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.71.71.71.71./Users/sophie1.71.71.71.71.71.", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#aaa#a a#" + "'", str13.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}

