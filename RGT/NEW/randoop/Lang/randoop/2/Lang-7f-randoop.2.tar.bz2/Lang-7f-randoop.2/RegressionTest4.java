import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0#32", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        0#32                        " + "'", str2.equals("                        0#32                        "));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 8, (long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...", "-1.04100.041.041.5462.0432.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati..." + "'", str2.equals("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati..."));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", "", 49);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (byte) 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 1, (byte) -1, (byte) 1, (byte) -1, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10 1 -1 1 -1 1" + "'", str9.equals("10 1 -1 1 -1 1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " #4##", (java.lang.CharSequence) "...itacificepSIPAmroftalPavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("...4444444444444444444", "#4a4#4 4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...4444444444444444444" + "'", str2.equals("...4444444444444444444"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) ". . Pf0 API .f Pf0 API .f Pf0 API .f");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("524100", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        long[] longArray5 = new long[] { ' ', (short) 1, '#', 0L, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', 35, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "32a1a35a0a10" + "'", str9.equals("32a1a35a0a10"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "                                                 ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                   ", "1.11.11.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "52#100 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1", (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.0#-1.0#0.0#32.0", (java.lang.CharSequence) "/Users/sophie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk", 211);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" 44444a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " 44444a" + "'", str1.equals(" 44444a"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.0 -1.0 0.0 32.0                  ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "10.1J.3", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("############################################### 444#", (int) 'a', "HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!############################################### 444#" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!############################################### 444#"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("# a #   #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" a #   #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("141040", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444", "10#1#10", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("us", 9, "100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100us100." + "'", str3.equals("100us100."));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("2#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2#10" + "'", str1.equals("2#10"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("      0.0a10.0a32.0a10.0a10.0a100.0", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      0..." + "'", str2.equals("      0..."));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "LIB/JAVA:.", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10a1a10", (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("01 1 01", (int) '4', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " 4#4#4a", (java.lang.CharSequence) "/Users/sophie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) -1, 10, 1142);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1142 + "'", int3 == 1142);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1 10 -1 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 10 -1" + "'", str1.equals("-1 10 -1"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("...4444444444444444444", 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a32" + "'", str9.equals("0a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#32" + "'", str11.equals("0#32"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Platform API Specificati...", "52 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specificati..." + "'", str2.equals("Java Platform API Specificati..."));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        short[] shortArray3 = new short[] { (short) 10, (byte) 1, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 3, 197);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a10a-1", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ". . Pf0 API .f Pf0 API .f Pf0 API .f", charArray9);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 11, 62);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#aaa#a a#" + "'", str12.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10, (float) 52L, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) ". . Pf0 API .f Pf0 API .f Pf0 API .");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1004100404-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004100404-1" + "'", str1.equals("1004100404-1"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati..." + "'", str1.equals("JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati..."));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("M", "   1    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M" + "'", str2.equals("M"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("0A32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A32" + "'", str1.equals("0A32"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ophi", (java.lang.CharSequence) "10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0.032.0100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.032.0100.0" + "'", str1.equals("0.032.0100.0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        short[] shortArray6 = new short[] { (short) 100, (byte) 10, (short) 100, (byte) 1, (short) 100, (byte) 10 };
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 31, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', (long) 13, (long) 22);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        float[] floatArray3 = new float[] { ' ', 35L, 0 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 67, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 67");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 35.0f + "'", float4 == 35.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Platform API Specificati...", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1132 + "'", int2 == 1132);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0 -1.0 0.0 32.0     ", (-1), "     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 -1.0 0.0 32.0     " + "'", str3.equals("0 -1.0 0.0 32.0     "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        double[] doubleArray6 = new double[] { (byte) 0, 10.0f, ' ', (short) 10, 10.0d, 100L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', (int) (byte) 10, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 0, 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0a10.0a32.0a10.0a10.0a100.0" + "'", str14.equals("0.0a10.0a32.0a10.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0.0" + "'", str18.equals("0.0"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "Sophie");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (java.lang.CharSequence) "                                                 ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1 10 -1", "", "\n", (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 10 -1" + "'", str4.equals("-1 10 -1"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "     ", (java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1#0aaaSu0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#0aaaSu0 -Su0 0u0 32u" + "'", str1.equals("1#0aaaSu0 -Su0 0u0 32u"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", "/Library", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        float[] floatArray2 = new float[] { 0.0f, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 9, 211);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1, (float) 32, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Java Platform API Specificati...", "100.04-1.0410.0410.04");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specificati..." + "'", str2.equals("Java Platform API Specificati..."));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 1142, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "444444444444444444444444444444444Ja/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str4.equals("444444444444444444444444444444444Ja/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("JavaVirtualMachineSpecificationa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaVirtualMachineSpecificationa" + "'", str2.equals("JavaVirtualMachineSpecificationa"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        char[] charArray10 = new char[] { ' ', '4', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1#10#0", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "141040", charArray10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.#", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " #4##" + "'", str18.equals(" #4##"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10 1 -1 1 -1 1                     ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     " + "'", str2.equals("10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     "));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("52#100 ", 0, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52#100 " + "'", str3.equals("52#100 "));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(" a4a#", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a4a#" + "'", str2.equals(" a4a#"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(":OphiOphiO", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":OphiOphiO" + "'", str2.equals(":OphiOphiO"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.0 -1.0 0.0 32.0                  ", (-1), "# a #   #");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 -1.0 0.0 32.0                  " + "'", str3.equals("1.0 -1.0 0.0 32.0                  "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "#32", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.#", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100" + "'", str1.equals("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("  # # a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# # a" + "'", str1.equals("# # a"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.032.0100.0", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.032.0100.0" + "'", str3.equals("0.032.0100.0"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.0 -1.0 0.0 32.0", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 -1.0 0.0 32.0                                             " + "'", str2.equals("1.0 -1.0 0.0 32.0                                             "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "10452");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Su0 -Su0 0u0 32ua1#0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Http://java.oracle.com/", "   1    ", 4);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "/Library", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("oRACLE cORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: oRACLE cORPORATION is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.1", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("52a10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java Virtual Machine Specificationa", "", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificationa" + "'", str3.equals("Java Virtual Machine Specificationa"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "Java Platform API Specification");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                        1.81.1", 1132, 32);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                  #4##", "10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     ", "############lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################4##" + "'", str3.equals("###################4##"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) '4', (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/Users/sophie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   " + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   "));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.71.71.71.71.71./Users/sophie1.71.71.71.71.71.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71./Users/sophie1.71.71.71.71.71." + "'", str2.equals("1.71.71.71.71.71./Users/sophie1.71.71.71.71.71."));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 2.0f, (double) 13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.0d + "'", double3 == 13.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#aaa#a a#", (java.lang.CharSequence[]) strArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " #4##", (java.lang.CharSequence[]) strArray7);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 " + "'", str2.equals("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.71.71.71.71.71./Users/sophie1.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44444444444444444444444444444444444444444444444444444444444444444      0.0a10.0a32.0a10.0a10.0a100.0", (long) 67);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 67L + "'", long2 == 67L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 32, 4);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        double[] doubleArray6 = new double[] { (byte) 0, 10.0f, ' ', (short) 10, 10.0d, 100L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0a10.0a32.0a10.0a10.0a100.0" + "'", str9.equals("0.0a10.0a32.0a10.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a32" + "'", str9.equals("0a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#32" + "'", str11.equals("0#32"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 32" + "'", str13.equals("0 32"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32 + "'", int14 == 32);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("AAASOPHI", (int) 'a', "10452");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10452104521045210452104521045210452104521045AAASOPHI104521045210452104521045210452104521045210452" + "'", str3.equals("10452104521045210452104521045210452104521045AAASOPHI104521045210452104521045210452104521045210452"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 197, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####################################################################################################################################################################################################" + "'", str3.equals("#####################################################################################################################################################################################################"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification" + "'", str1.equals("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ", 0, "1.71.71.71.71.71./Users/sophie1.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   " + "'", str3.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.0#-1.0#-1.0#-1.0#0.0#1.0", (java.lang.CharSequence) "1#0aaaSu0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.0", "10.14.3", "############################################### 444#", (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (byte) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                        1.81.1", "lib/java:.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed ..." + "'", str2.equals("mixed ..."));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) ' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0#32", (java.lang.CharSequence) "-1.04100.041.041.5462.0432.0", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.0#-1.0#0.0#32.0                                                                                   ", 26.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 26.0d + "'", double2 == 26.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4...", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "JAVA VIRTUAL MACHIN 444# SP 444#CIFICATIONA", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("2#10", "0 -1.0 0.0 32.0     ", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97L, 0.0f, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Platform API Specification", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JavaVirtualMachineSpecificationa", "                                                 ...", "1.0 -1.0 0.0 32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaVirtualMachineSpecificationa" + "'", str3.equals("JavaVirtualMachineSpecificationa"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Su0 -Su0 0u0 32ua1#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Su0-Su00u032ua1#0" + "'", str1.equals("Su0-Su00u032ua1#0"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "         ", (java.lang.CharSequence) "0#32", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0A32", 1142, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "       sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "################################", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("524100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "524100" + "'", str2.equals("524100"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.8", "52 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".8" + "'", str2.equals(".8"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10#1#-1#1#-1#1", "52#100", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1" + "'", str3.equals("10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "oRACLE cORPORATION");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati..." + "'", str1.equals("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati..."));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion2.atLeast(javaVersion6);
        java.lang.String str10 = javaVersion2.toString();
        java.lang.String str11 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray12 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion1, javaVersion2 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(javaVersionArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.1" + "'", str10.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.1" + "'", str11.equals("1.1"));
        org.junit.Assert.assertNotNull(javaVersionArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.11.11.1" + "'", str13.equals("1.11.11.1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.11.11.1" + "'", str14.equals("1.11.11.1"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("...itacificepSIPAmroftalPavaJ", 26.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 26.0d + "'", double2 == 26.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specificati...", 1132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "us", (java.lang.CharSequence) "10 1 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("   Hi!    ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   Hi!    " + "'", str2.equals("   Hi!    "));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        char[] charArray9 = new char[] { ' ', '#', '#', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                  1", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(22, 211, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixedmod");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "0.0#32.0#100.0");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "0 32", 1142, (int) ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 9, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0a-1.0a10.0a10.0a100.0" + "'", str13.equals("100.0a-1.0a10.0a10.0a100.0"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 31, "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0 32", "jAVApLATFORMapisPECIFICATI...", 1132);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "52a10", (java.lang.CharSequence) "      0...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "   51.0   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-1.0#100.0#1.0#1.5", "MIXED MODEjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICAT", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#100.0#1.0#1.5" + "'", str3.equals("-1.0#100.0#1.0#1.5"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                   ", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "2#100", 26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                 ", "mixedmode");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                 " + "'", str4.equals("                                                                                                 "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("5", "0.0#32.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("32", "SU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32" + "'", str2.equals("32"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#########hi!##########", 67);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Http://java.oracle.com/", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Http://java.oracle.com/" + "'", str3.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("52410", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52410" + "'", str3.equals("52410"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0a32", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a320a320a320a320a320a320a320a320a320a32" + "'", str2.equals("0a320a320a320a320a320a320a320a320a320a32"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0a32", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str1.equals("100.0#-1.0#10.0#10.0#100.0"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("32");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 32 + "'", byte1 == (byte) 32);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("\n", "1.0a-1.0a0.0a32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specification", "1.0 -1.0 0.0 32.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Http://java.oracle.com/", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Http://java.oracle.com/" + "'", str2.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "   51.0   ", "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################" + "'", str1.equals("################################"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.71", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", (int) 'a', 62);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.io.File[] fileArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(fileArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100" + "'", str1.equals("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "001#25", "0 32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5.1" + "'", str1.equals("5.1"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("...4444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...4444444444444444444" + "'", str1.equals("...4444444444444444444"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a10a-1", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", charArray9);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#aaa#a a#" + "'", str12.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("      0...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("mixed modeJava Platform API SpecificationJava Pla...", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modeJava Platform API SpecificationJava Pla..." + "'", str2.equals("mixed modeJava Platform API SpecificationJava Pla..."));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10a1a10", (java.lang.CharSequence) "Java Virtual Machine Specificationa", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100us100.", (java.lang.CharSequence) "                                                                  1", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.CPrinterJob", (int) '#', 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        float[] floatArray3 = new float[] { ' ', 35L, 0 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 35.0f + "'", float4 == 35.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 35.0f + "'", float6 == 35.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"LIB/JAVA:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "M");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100", (java.lang.CharSequence) "Su0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.#" + "'", str1.equals("1.#"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".8", "", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".8" + "'", str3.equals(".8"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "0a320a320a320a320a320a320a320a320a320a32", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1" + "'", str2.equals("10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "-1", (java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "JavaVirtualMachineSpecificationa", 13, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaVirtualMachineSpecificationa" + "'", str4.equals("JavaVirtualMachineSpecificationa"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0" + "'", str2.equals("0.0"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10 1 -1 1 -1 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 179);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                   " + "'", str2.equals("                                                                                                                                                                                   "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                  1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("############lib/java:.", "110a1a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "110a1a10" + "'", str2.equals("110a1a10"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("AAASOPHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAASOPHI" + "'", str1.equals("AAASOPHI"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Sun.awt.CGraphicsEnvironment", "", "         ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("#####################################################################################################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####################################################################################################################################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "      0.0a10.0a32.0a10.0a10.0a100.0");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0#32", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0a32", (java.lang.CharSequence) "1.5", 211);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("   51.0   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ":");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4444444444", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 67L, (float) 3L, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 67.0f + "'", float3 == 67.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        char[] charArray5 = new char[] { ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus       ", charArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 1, 211);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("MIXED MODEjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICAT");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 1, (byte) -1, (byte) 1, (byte) -1, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "32");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 32");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("52a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52a10" + "'", str1.equals("52a10"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("JavaVirtualMachineSpecificationa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaVirtualMachineSpecificationa" + "'", str1.equals("javaVirtualMachineSpecificationa"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "###################4##", "444444444444444444444444444444444Ja/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("110a1a10", "  # # a", "1.81.1", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "110a1a10" + "'", str4.equals("110a1a10"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray11 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a10a-1", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1#10#0", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " 44444a", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#aaa#a a#" + "'", str14.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                   ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 10, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-1.0#100.0#1.0#1.5", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10452", "0a320a320a320a320a320a320a320a320a320a32", "0.0#32.0#100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10452" + "'", str3.equals("10452"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ", "# # a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   " + "'", str2.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 7, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.0 -1.0 0.0 32.0                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 -1.0 0.0 32.0                                             " + "'", str1.equals("1.0 -1.0 0.0 32.0                                             "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("M10a1a10Ma", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M10a1a10Ma" + "'", str2.equals("M10a1a10Ma"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "52#100" + "'", str5.equals("52#100"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(100.0f, 67.0f, (float) 211L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 211.0f + "'", float3 == 211.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a1052#100", "       sun.awt.CGraphicsEnvironment", 0, 1132);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "       sun.awt.CGraphicsEnvironment" + "'", str4.equals("       sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 22, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("LIB/JAVA:.", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LIB/JAVA:." + "'", str2.equals("LIB/JAVA:."));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        short[] shortArray3 = new short[] { (short) 10, (byte) 1, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10a1a10" + "'", str6.equals("10a1a10"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#1#10" + "'", str8.equals("10#1#10"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1041410" + "'", str11.equals("1041410"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        byte[][] byteArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(byteArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, (float) 11L, (float) 1132);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1" + "'", str1.equals("-1"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("M10a1a10Ma", "52 100", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10#1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#1#10" + "'", str1.equals("10#1#10"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                        1.81.1", 22, "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                        1.81.1" + "'", str3.equals("                                                        1.81.1"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "MIXED MODEjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICAT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("5.1", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.0 -1.0 0.0 32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 -1.0 0.0 32.0" + "'", str1.equals("1.0 -1.0 0.0 32.0"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                                                                                                   ", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Virtual Machine Specificationa", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("AAASOPHI", "java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAASOPHI" + "'", str2.equals("AAASOPHI"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.0#-1.0#0.0#32.0                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#-1.0#0.0#32.0" + "'", str1.equals("1.0#-1.0#0.0#32.0"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0.0#32.0#100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.0#32.0#100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        char[] charArray10 = new char[] { ' ', '4', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1#10#0", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "141040", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixedmod", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATI...", 49, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.0a-1.0a0.0a32.0", "", "M10a1a10Ma");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a-1.0a0.0a32.0" + "'", str3.equals("1.0a-1.0a0.0a32.0"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1#0aaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk", 211);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk                                                                                                                                        " + "'", str2.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk                                                                                                                                        "));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...", (java.lang.CharSequence) "/Users/so");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("UTF-8", 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 32" + "'", str11.equals("0 32"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":" + "'", str5.equals(":"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ":" + "'", str7.equals(":"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 -1 1 -1 1                     " + "'", str2.equals("10 1 -1 1 -1 1                     "));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("   ###    ", "32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo", (float) 197L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 197.0f + "'", float2 == 197.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                               ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 17, 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oRoRLE ROLP/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse ROLPRoERLE ROLPRo" + "'", str4.equals("oRoRLE ROLP/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse ROLPRoERLE ROLPRo"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("UTF-8", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "us", (java.lang.CharSequence) "/Users...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        long[] longArray2 = new long[] { '4', (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', 0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "52#100" + "'", str4.equals("52#100"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52 100" + "'", str6.equals("52 100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "524100" + "'", str8.equals("524100"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaa", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               aaaa" + "'", str2.equals("                               aaaa"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("# a #   #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# a #   #" + "'", str1.equals("# a #   #"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) '#', 17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "sun.awt.CGraphicsEnvironment", "JavaPlatformAPISpecificati...");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Platform API Specificati...", (java.lang.CharSequence[]) strArray10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "/Users/sophie", (int) '#', (int) (byte) 1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("       sun.awt.CGraphicsEnvironment", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "       sun.awt.CGraphicsEnvironment" + "'", str20.equals("       sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', (int) (byte) 0, (int) (short) -1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray9);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a1a10", charArray9);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray9, '#', (int) (short) 1, 5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#aaa#a a#" + "'", str12.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "a### ##" + "'", str23.equals("a### ##"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("141040", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141040" + "'", str2.equals("141040"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java Virtual Machin 444# Sp 444#cificationa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "anoitacific#444 pS #444 nihcaM lautriV avaJ" + "'", str1.equals("anoitacific#444 pS #444 nihcaM lautriV avaJ"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10452");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "0a32", "!");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 31, 1132);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Su0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0 -1.0 0.0 32.0                                             ", "-1 10 -1 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 -1.0 0.0 32." + "'", str2.equals("1.0 -1.0 0.0 32."));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", "1.7.0_80-b15", (int) (short) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (short) 0, (int) (short) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 1142, 97);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaa", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaa" + "'", str3.equals("aaaa"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati..." + "'", str3.equals("JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati..."));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "#####################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 197 + "'", int1 == 197);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "en", 32);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', (int) (short) 0, 0);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("oRoRLE ROLP/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse ROLPRoERLE ROLPRo", "", "                                   ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oRoRLE ROLP/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse ROLPRoERLE ROLPRo" + "'", str4.equals("oRoRLE ROLP/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse ROLPRoERLE ROLPRo"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1004100404-1", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Su0 -Su0 0u0 32ua1#0", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Su0 -Su0 0u0 32ua1#0" + "'", str2.equals("Su0 -Su0 0u0 32ua1#0"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "52#100" + "'", str5.equals("52#100"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(5, (int) '4', 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("100.04-1.0410.0410.04100.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0.0#32.0#100.0", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0#32.0#100.0" + "'", str2.equals("0.0#32.0#100.0"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sophie", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " sophie " + "'", str2.equals(" sophie "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OLPRoERLE ROLPRoERLE ROLPRo" + "'", str2.equals("OLPRoERLE ROLPRoERLE ROLPRo"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("LIB/JAVA:.", (int) (short) 0, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LIB/JAVA:" + "'", str3.equals("LIB/JAVA:"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("01 1 01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01 1 01" + "'", str1.equals("01 1 01"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622", "mixed ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1 1- 1 1- 1 01", (int) (short) 0, "2#10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 1- 1 1- 1 01" + "'", str3.equals("1 1- 1 1- 1 01"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, 211L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) ' ', 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100.0 -1.0 10.0 10.0 100.0" + "'", str15.equals("100.0 -1.0 10.0 10.0 100.0"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "# a #   #", (java.lang.CharSequence) "5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Hi! ", "1.7", "100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Platform API Specification", 1132);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', (int) (short) 1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1a10a0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java hotspot(tm) 64-bit server vm");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100.04-1.0410.0410.04100.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 62, (int) ' ');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "100.04-1.0410.0410.04");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1142, (long) 3, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1#10#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#10#0" + "'", str1.equals("1#10#0"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        long[] longArray6 = new long[] { 1142, 97L, 1142, 2L, 100L, 49 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Su0-Su00u032ua1#0", ":OphiOphiO");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", "1.7.0_80-b15", (int) (short) 100);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', (int) (short) 0, (int) (short) -1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixedmod", (java.lang.CharSequence[]) strArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "", 31, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                               aaaa", (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("x86_64", "Su0 -Su0 0u0 32ua1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "110a1a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', (int) (byte) 0, (int) (short) -1);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                               US                                                ", charArray9);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "...4444444444444444444", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#aaa#a a#" + "'", str12.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 47 + "'", int18 == 47);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        double[] doubleArray6 = new double[] { (byte) 0, 10.0f, ' ', (short) 10, 10.0d, 100L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        short[] shortArray3 = new short[] { (short) 10, (byte) 1, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 32);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#1#10" + "'", str10.equals("10#1#10"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("# # a", "Su0 -Su0 0u0 32ua1#0", 179);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10452", "java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification" + "'", str2.equals("java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "444444444444444444444444444444444Ja/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) " 4#4#4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.81.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/t/NG0...", charSequence1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 2, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a0" + "'", str9.equals("1a10a0"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("5.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5.1" + "'", str1.equals("5.1"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1041410", (java.lang.CharSequence) "10#1#-1#1#-1#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0.0#32.0#100.0", "Oracle Corporation", "1.0 -1.0 0.0 32.0                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0#32.0#100.0" + "'", str3.equals("0.0#32.0#100.0"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { ' ', '#', '#', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', 9, (int) (short) -1);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode", "1.81.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "1.8/Users/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "       sun.awt.CGraphicsEnvironment", "1.#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("-1.0#100.0#1.0#1.5", "0a320a320a320a320a320a320a320a320a320a32", 7, 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0#100a320a320a320a320a320a320a320a320a320a321.0#1.5" + "'", str4.equals("-1.0#100a320a320a320a320a320a320a320a320a320a321.0#1.5"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#152#10010#1#-1#1#-1#1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("JavaPlatformAPISpecificati...", "", "0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecificati..." + "'", str3.equals("JavaPlatformAPISpecificati..."));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10a1a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("110a1a10", "HI!", (-1));
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "110a1a10" + "'", str5.equals("110a1a10"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", "1.11.11.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1004100404-1", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("2#100", "1.71.71.71.71.71./Users/sophie1.71.71.71.71.71.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("hi!", "Java Virtual Machine Specification");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52#100", (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray8);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "!" + "'", str10.equals("!"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("en", "1a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a10a01a1052#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.8/Users/", 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "     aaasophi", (java.lang.CharSequence) "10 1 -1 1 -1 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ophi", (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.1", "###################4##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ", " #4##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0" + "'", str2.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU" + "'", str1.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "   51.0   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 32, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "Java Virtual Machine Specification");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52#100", (java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "", 1132, 9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "!" + "'", str5.equals("!"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#aaa#a a#", "0.0#-1.0#-1.0#-1.0#0.0#1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 34, (int) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str12.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "############lib/java:.", (java.lang.CharSequence) "############################################### 444#", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-1#100#100#0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                        1.81.1", (java.lang.CharSequence) "001#25", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0.032.0100.0", "SU");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0 -1.0 0.0 32.", "", "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 -1.0 0.0 32." + "'", str3.equals("1.0 -1.0 0.0 32."));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     ", "01 1 01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     " + "'", str2.equals("10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0.0 10.0 32.0 10.0 10.0 100.0", "524100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0 10.0 32.0 10.0 10.0 100.0" + "'", str2.equals("0.0 10.0 32.0 10.0 10.0 100.0"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10.1J.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.1J.3" + "'", str1.equals("10.1J.3"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", (int) (short) 10, "JavaVirtualMachineSpecificationa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        char[] charArray8 = new char[] { ' ', '4', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1#10#0", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52#100", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...", charArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "  4 #" + "'", str15.equals("  4 #"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specificati... API Platform Specificati...1Java API Platform Specificati...-Java API Platform Specificati...1Java API Platform Specificati...1Java API Platform Specificati...1Java API Platform Specificati...-Java API Platform Java" + "'", str2.equals("Specificati... API Platform Specificati...1Java API Platform Specificati...-Java API Platform Specificati...1Java API Platform Specificati...1Java API Platform Specificati...1Java API Platform Specificati...-Java API Platform Java"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1041410", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "52410", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" #4##", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("2#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2#100" + "'", str1.equals("2#100"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("...itacificepSIPAmroftalPavaJ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("2#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2#10" + "'", str1.equals("2#10"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0 -1.0 0.0 32.0                  ", (byte) 32);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 32 + "'", byte2 == (byte) 32);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixedmod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.0#-1.0#0.0#32.0                                                                                   ", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#-1.0#0.0#32.0                                                                                   " + "'", str2.equals("1.0#-1.0#0.0#32.0                                                                                   "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        double[] doubleArray6 = new double[] { (byte) 0, 10.0f, ' ', (short) 10, 10.0d, 100L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', (int) '#', 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.0 10.0 32.0 10.0 10.0 100.0" + "'", str15.equals("0.0 10.0 32.0 10.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################" + "'", str1.equals("################################"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Ophi", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####################################################################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#", (java.lang.CharSequence) "0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10a1a-1a1a-1a1", (int) (byte) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1a-1a1a-1a1" + "'", str3.equals("10a1a-1a1a-1a1"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("MIXED MODEjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICAT", 1.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5d + "'", double2 == 1.5d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Su0-Su00u032ua1#0", "-111-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("     aaasophi", "# # a", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi" + "'", str3.equals("     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi# # a     aaasophi"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10L, (double) 1L, 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("MIXED MODEjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICAT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        double[] doubleArray6 = new double[] { (byte) 0, 10.0f, ' ', (short) 10, 10.0d, 100L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 100, 8);
        java.lang.Class<?> wildcardClass15 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0a10.0a32.0a10.0a10.0a100.0" + "'", str9.equals("0.0a10.0a32.0a10.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                  0.23 0.0 0.1- 0.1", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  0.23 0.0 0.1- 0.1" + "'", str2.equals("                  0.23 0.0 0.1- 0.1"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10a1a10", (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "001#25");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.0 -1.0 0.0 32.0", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("################################   ", "java hotspot(tm) 64-bit server vm", "-1.04100.041.041.5462.0432.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################444" + "'", str3.equals("################################444"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        float[] floatArray4 = new float[] { 1L, (-1L), (byte) 0, ' ' };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0 -1.0 0.0 32.0" + "'", str7.equals("1.0 -1.0 0.0 32.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0#-1.0#0.0#32.0" + "'", str9.equals("1.0#-1.0#0.0#32.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0#-1.0#0.0#32.0" + "'", str12.equals("1.0#-1.0#0.0#32.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.0a-1.0a0.0a32.0" + "'", str14.equals("1.0a-1.0a0.0a32.0"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10 1 -1 1 -1 1                     ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                              10 1 -1 1 -1 1                     " + "'", str2.equals("                                                              10 1 -1 1 -1 1                     "));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1a10a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk                                                                                                                                        ", (java.lang.CharSequence) "lib/java:.", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Sophie", "141040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sophie" + "'", str2.equals("Sophie"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1#0", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "     aaasophi", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5, (float) 9, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                               aaaa", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charSequence1, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java" + "'", str2.equals("VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1#0aaaSu0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1#100#100#0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "      0...", (java.lang.CharSequence) "10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                                                                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" a4a#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '4', 47, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java" + "'", str1.equals("VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM) Java"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0A32", "                                                        1.81.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence) "   Hi!    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("lib/java:.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("  4 #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  4 #" + "'", str1.equals("  4 #"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("         ", (int) (byte) 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...mixed modeJava Platform API SpecificationJava Pla.../t/NG0...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(" sophie ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " eihpos " + "'", str1.equals(" eihpos "));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("52 100", "   1    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52 100" + "'", str2.equals("52 100"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", "Java Virtual Machine Specification");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52#100", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10 1 -1 1 -1 1", "sophie");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("52#100", strArray13, strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("jAVApLATFORMapisPECIFICATI..", strArray9, strArray13);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "!" + "'", str6.equals("!"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "52#100" + "'", str17.equals("52#100"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "jAVApLATFORMapisPECIFICATI.." + "'", str18.equals("jAVApLATFORMapisPECIFICATI.."));
        org.junit.Assert.assertNotNull(strArray20);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        java.lang.Class<?> wildcardClass6 = javaVersion3.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        java.lang.String str12 = javaVersion7.toString();
        java.lang.String str13 = javaVersion7.toString();
        boolean boolean14 = javaVersion3.atLeast(javaVersion7);
        boolean boolean15 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.1" + "'", str12.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.1" + "'", str13.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "!", (java.lang.CharSequence) "                  0.23 0.0 0.1- 0.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", "1 1- 1 1- 1 01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification" + "'", str2.equals("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaa", "10 1 10", 179);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.lwawt.macosx.LWCToolkit", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10 1 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10 1 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4444444444", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }
}

