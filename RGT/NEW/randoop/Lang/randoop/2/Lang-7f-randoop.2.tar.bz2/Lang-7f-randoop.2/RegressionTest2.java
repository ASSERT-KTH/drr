import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("24.80-b11", ". . Pf0 API .f Pf0 API .f Pf0 API .f");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#0" + "'", str1.equals("1#0"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51.0", "10 1 -1 1 -1 1                     ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                  1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "4444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 4444444444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a10a-1" + "'", str9.equals("-1a10a-1"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("524100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52410" + "'", str1.equals("52410"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("51.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0 -1.0 0.0 32.0     ", "Java HotSpot(TM) 64-Bit Server VM", "/t/NG0...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 -1.0 0.0 32.0     " + "'", str3.equals("0 -1.0 0.0 32.0     "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1#10#0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Sophie", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.71", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71" + "'", str2.equals("1.71"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("MAC OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MAC OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        float[] floatArray2 = new float[] { 0.0f, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.Class<?> wildcardClass5 = floatArray2.getClass();
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("52#100 ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52#100 " + "'", str2.equals("52#100 "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10.1J.3");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Sun.awt.CGraphicsEnvironment", " ", "###");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str3.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaasophi", "0.0a10.0a32.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaasophi" + "'", str2.equals("aaasophi"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, (int) (byte) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "52#100", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 1, (byte) -1, (byte) 1, (byte) -1, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10 1 -1 1 -1 1" + "'", str9.equals("10 1 -1 1 -1 1"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("####################################################################################################", "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444", "a0aaaa0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################" + "'", str3.equals("####################################################################################################"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "############lib/java:.", (java.lang.CharSequence) "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...itacificepSIPAmroftalPavaJ" + "'", str1.equals("...itacificepSIPAmroftalPavaJ"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("524100");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(" 444#", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "-1#100#100#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 444#" + "'", str3.equals(" 444#"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "###", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51.0", "1.#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (java.lang.CharSequence) "/Users...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str1.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-1#100#100#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#100#100#0" + "'", str1.equals("-1#100#100#0"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaasophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaasophi" + "'", str1.equals("aaasophi"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users...", "sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users..." + "'", str2.equals("/Users..."));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("en", "-1#100#100#0", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a1a10", "-1#100#100#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("5", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.awt.CGraphicsEnvironment", 0, 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.8");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.8f + "'", float1.equals(1.8f));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " 4#4#4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("############lib/java:.", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "                                                                  1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#aaa#a a#", (java.lang.CharSequence) " 4#4#4a", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        long[] longArray5 = new long[] { ' ', (short) 1, '#', 0L, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, '4', 0, (int) (byte) 1);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32" + "'", str11.equals("32"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users...", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users..." + "'", str2.equals("/Users..."));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1 10 -1", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-111-1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-111-1" + "'", str2.equals("-111-1"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10a1a10", (int) (byte) 10, "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M10a1a10Ma" + "'", str3.equals("M10a1a10Ma"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(". . Pf0 API .f Pf0 API .f Pf0 API .f");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("x86_64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sophi", (java.lang.CharSequence) "Oracle Corporation", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.0 -1.0 0.0 32.0", 31, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa" + "'", str3.equals("aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/t/NG0...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users...", "JavaVirtualMachineSpecificationa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users..." + "'", str2.equals("/Users..."));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1#10#0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1#10#0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "       sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#aaa#a a#", "44444444444444444444444444444444", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0 32", (java.lang.CharSequence) " 444#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        long[] longArray5 = new long[] { ' ', (short) 1, '#', 0L, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) (byte) 100, 31);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1", 8, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   1    " + "'", str3.equals("   1    "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "US", (java.lang.CharSequence) "...itacificepSIPAmroftalPavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "-1#100#100#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 211, (long) 8, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 211L + "'", long3 == 211L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "...itacificepSIPAmroftalPavaJ", "1.0 -1.0 0.0 32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("jAVApLATFORMapisPECIFICATI...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVApLATFORMapisPECIFICATI.." + "'", str1.equals("jAVApLATFORMapisPECIFICATI.."));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "32a1a35a0a10", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("10 1 -1 1 -1 1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 9, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.71", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10 1 -1 1 -1 1", "sophie");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("52#100", strArray3, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52#100" + "'", str7.equals("52#100"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10#1#10", 5, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#1#10" + "'", str3.equals("10#1#10"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", "###");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Hi!", "", 9, 26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Hi!" + "'", str4.equals("Hi!"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.0#-1.0#0.0#32.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#-1.0#0.0#32.0                                                                                   " + "'", str2.equals("1.0#-1.0#0.0#32.0                                                                                   "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("#aaa#a a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#aaa#a a#" + "'", str1.equals("#aaa#a a#"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10A1A10", (java.lang.CharSequence) "aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "a0aaaa0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10#1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#1#10" + "'", str1.equals("10#1#10"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.71");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("   51.0   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   51.0   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.8", "####################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10#1#10");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.8", 10, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8/Users/" + "'", str3.equals("1.8/Users/"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "   1    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "32a1a35a0a10", charSequence1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1 10 -1", (java.lang.CharSequence) "Su0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("jAVApLATFORMapisPECIFICATI...", "2#100", "-111-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVApLATFORMapisPECIFICATI..." + "'", str3.equals("jAVApLATFORMapisPECIFICATI..."));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("52410", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10452" + "'", str2.equals("10452"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10#1#10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users...", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users..." + "'", str3.equals("/Users..."));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("51.0", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-8", (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.0#-1.0#0.0#32.0                                                                                   ", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#-1.0#0.0#32.0                                                                                   " + "'", str2.equals("1.0#-1.0#0.0#32.0                                                                                   "));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specificati...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10 1 -1 1 -1 1                     ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("############lib/java:.", "...itacificepSIPAmroftalPavaJ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.0#-1.0#0.0#32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#-1.0#0.0#32.0" + "'", str1.equals("1.0#-1.0#0.0#32.0"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("110a1a10", (float) 2L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1#10#0", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52#100" + "'", str9.equals("52#100"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a10a-1", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#aaa#a a#" + "'", str13.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!", 22, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########hi!##########" + "'", str3.equals("#########hi!##########"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("52410", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52a10" + "'", str3.equals("52a10"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", (java.lang.CharSequence) "1.0 -1.0 0.0 32.0                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "Oracle Corporation", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("   51.0   ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 51.0f + "'", float1.equals(51.0f));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("ophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ophi" + "'", str1.equals("Ophi"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("-1a10a-1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a10a-1" + "'", str2.equals("-1a10a-1"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "52a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("JavaVirtualMachineSpecificationa", 32, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("5", 1, "0a32");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5" + "'", str3.equals("5"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "32", (java.lang.CharSequence) "524100", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "   1    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "      0.0a10.0a32.0a10.0a10.0a100.0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "a0aaaa0", (java.lang.CharSequence) "100.04-1.0410.0410.04100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.71");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users...", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "1.0a17.0a97.0", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0#-1.0#0.0#32.0", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("  # # a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  # # a" + "'", str1.equals("  # # a"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "44444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.0 -1.0 0.0 32.0", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 -1.0 0.0 32.0" + "'", str2.equals("1.0 -1.0 0.0 32.0"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 0, (float) '#', 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.71", "Ophi", "####################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71" + "'", str3.equals("1.71"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "mixed mode", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 49 + "'", int1 == 49);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100.0#-1.0#10.0#10.0#100.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#########hi!##########", "001#25");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                  1", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("jAVApLATFORMapisPECIFICATI..", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVApLATFORMapisPECIFICATI.." + "'", str2.equals("jAVApLATFORMapisPECIFICATI.."));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0 -1.0 0.0 32.0     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 -1.0 0.0 32.0     " + "'", str1.equals("0 -1.0 0.0 32.0     "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        short[] shortArray3 = new short[] { (short) 10, (byte) 1, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) (byte) 1, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10a1a10" + "'", str6.equals("10a1a10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10 1 10" + "'", str13.equals("10 1 10"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("24.80-b11", "0A32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("52#100 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"52#100 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("SU", "0 -1.0 0.0 32.0     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SU" + "'", str2.equals("SU"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "############lib/java:.", (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###", (java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) ' ', 5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.04-1.0410.0410.04100.0" + "'", str12.equals("100.04-1.0410.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "  # # a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "mixedmod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JavaVirtualMachineSpecificationa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("JavaPlatformAPISpecificati...", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecificati..." + "'", str2.equals("JavaPlatformAPISpecificati..."));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 7, 0L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "2#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users...", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users..." + "'", str2.equals("/Users..."));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.04-1.0410.0410.04100.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.0 -1.0 0.0 32.0", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1#0", " 4#4#4a", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#0" + "'", str3.equals("1#0"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("     ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!", "Java Virtual Machine Specification");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "!" + "'", str7.equals("!"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str2.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.71", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0A32", "Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0A32" + "'", str3.equals("0A32"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", 8, "MAC OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str3.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("a0aaaa0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaasophi", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat" + "'", str1.equals("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.5");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5d + "'", double1 == 1.5d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "   1    ", (java.lang.CharSequence) "x86_64", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0 -1.0 0.0 32.0", "", "10.1J.3");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 22, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("52#100 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52#100" + "'", str1.equals("52#100"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("2#100", 4, "1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2#100" + "'", str3.equals("2#100"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "############lib/java:.", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10#1#-1#1#-1#1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("   1    ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1    " + "'", str2.equals("   1    "));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Su0 -Su0 0u0 32u0", (java.lang.CharSequence) "10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100.0#-1.0#10.0#10.0#100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0#-1.0#10.0#10.0#100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaasophi", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     aaasophi" + "'", str2.equals("     aaasophi"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        char[] charArray7 = new char[] { ' ', '4', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1#10#0", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", charArray7);
        java.lang.Class<?> wildcardClass11 = charArray7.getClass();
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#32", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        long[] longArray5 = new long[] { ' ', (short) 1, '#', 0L, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', 4, 62);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("001#25", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "001#25" + "'", str2.equals("001#25"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Mac OS X", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 9, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a10a-1" + "'", str9.equals("-1a10a-1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "a0aaaa0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("SU", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU" + "'", str2.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) (byte) 0, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10.1J.3", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.1J.3" + "'", str3.equals("10.1J.3"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1#10#0", (java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "141040");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecificati..." + "'", str1.equals("JavaPlatformAPISpecificati..."));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0A32", (java.lang.CharSequence) "0.0a10.0a32.0a10.0a10.0a100.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4444444444444444444444444444444444444444444444444444", "aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10#1#10", "1004100404-1", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#1#10" + "'", str3.equals("10#1#10"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10452");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10452L + "'", long1.equals(10452L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("JavaVirtualMachineSpecificationa", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat" + "'", str2.equals("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa" + "'", str2.equals("aaaa"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double[] doubleArray3 = new double[] { 0L, 32, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', (int) (byte) 100, (int) (short) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0#32.0#100.0" + "'", str12.equals("0.0#32.0#100.0"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("      0.0a10.0a32.0a10.0a10.0a100.0", "     aaasophi", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      0.0a10.0a32.0a10.0a10.0a100.0" + "'", str3.equals("      0.0a10.0a32.0a10.0a10.0a100.0"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("32a1a35a0a10", 22, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("M10a1a10Ma", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M" + "'", str2.equals("M"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "  # # a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0.0#32.0#100.0", (java.lang.CharSequence) "Ophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 100, (double) 0, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("mixedmod", "Su0 -Su0 0u0 32u0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10.14.3", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("################################", 35, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################   " + "'", str3.equals("################################   "));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("       sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnEscihparGC.twa.nus       " + "'", str1.equals("tnemnorivnEscihparGC.twa.nus       "));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10#1#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", "       sun.awt.CGraphicsEnvironment", " 444#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0a32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a32" + "'", str1.equals("0a32"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1 1- 1 1- 1 01", "10 1 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 1- 1 1- 1 01" + "'", str2.equals("1 1- 1 1- 1 01"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "0.0#32.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java(TM) SE Runtime Environment", "###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.#", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.#" + "'", str2.equals("1.#"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80", 3, "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0.0a10.0a32.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-111-1", (java.lang.CharSequence) "1.0 -1.0 0.0 32.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "Java Platform API Specificati...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "1.1");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1" + "'", str6.equals("-1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 10, "10452");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5" + "'", str1.equals("5"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.11.11.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "en", 32);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (short) 0, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "US", (int) (short) 100, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "141040", 9, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str9.equals("100.0#-1.0#10.0#10.0#100.0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0 -1.0 0.0 32.0", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a-1.0a0.0a32.0" + "'", str3.equals("1.0a-1.0a0.0a32.0"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa", (java.lang.CharSequence) "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("M", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.0#32.0#100.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 4, (float) (short) 1, (float) 67);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JavaVirtualMachineSpecificationa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaVirtualMachineSpecificationa" + "'", str1.equals("JavaVirtualMachineSpecificationa"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "5", "100.04-1.0410.0410.04100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("      0.0a10.0a32.0a10.0a10.0a100.0", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0A32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A32" + "'", str1.equals("0A32"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("141040");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141040" + "'", str1.equals("141040"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "   51.0   ", (java.lang.CharSequence) "0 32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("-1a10a-1", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a10a-1" + "'", str2.equals("-1a10a-1"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("####################################################################################################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java HotSpot(TM) 64-Bit Server VM", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaasophi", "       sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 67, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double[] doubleArray5 = new double[] { 100.0d, (-1.0f), 10, 10, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', (int) (byte) 1, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str7.equals("100.0#-1.0#10.0#10.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1 10 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 10 -1" + "'", str1.equals("-1 10 -1"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "en", 32);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Platform API Specificati...", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("524100", "32a1a35a0a10", "#aaa#a a#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "524100" + "'", str3.equals("524100"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(". . Pf0 API .f Pf0 API .f Pf0 API .f");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ". . Pf0 API .f Pf0 API .f Pf0 API ." + "'", str1.equals(". . Pf0 API .f Pf0 API .f Pf0 API ."));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("####################################################################################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10a1a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10a1a10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 35, (double) 67);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 67.0d + "'", double3 == 67.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "4444444444", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("51.0", "1#10#0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "32", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.1", "2#100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, (int) (byte) 10, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444", "################################", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100.04-1.0410.0410.04100.0", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("   51.0   ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0#32", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("  # # a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  # # a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("jAVApLATFORMapisPECIFICATI...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVApLATFORMapisPECIFICATI...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int[] intArray2 = new int[] { 1, (byte) 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0a32", (java.lang.CharSequence) "0.0#32.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.71", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71" + "'", str2.equals("1.71"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double[] doubleArray3 = new double[] { 0L, 32, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', (int) (byte) 100, (int) (short) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', 49, 0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("2#100", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2#100" + "'", str2.equals("2#100"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Environment");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "\n", (int) 'a', 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str4.equals("5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10 1 10", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 10" + "'", str2.equals("10 1 10"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0A32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A32" + "'", str1.equals("0A32"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                  1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "0.0#32.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(":", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1#10#0", "1#10#0", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 31, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "141040" + "'", str7.equals("141040"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "#########hi!##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1142 + "'", int2 == 1142);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1", charSequence1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("############lib/java:.", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 8, 0);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 10 + "'", byte14 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 10 + "'", byte15 == (byte) 10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1#0", 7, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#0aaaa" + "'", str3.equals("1#0aaaa"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("         ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(26.0d, (double) (byte) 1, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1 10 -1", ". . Pf0 API .f Pf0 API .f Pf0 API .");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("!", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("100.04-1.0410.0410.04100.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.04-1.0410.0410.04" + "'", str2.equals("100.04-1.0410.0410.04"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Su0 -Su0 0u0 32u", "1.0a17.0a97.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Su0 -Su0 0u0 32u" + "'", str2.equals("Su0 -Su0 0u0 32u"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "32", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(" ", "52410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10#1#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.#", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", 0, "110a1a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str3.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", 2, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modeJava Platform API SpecificationJava Pla..." + "'", str3.equals("mixed modeJava Platform API SpecificationJava Pla..."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "lib/java:.", (java.lang.CharSequence) "Hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "en", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 1142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaasophi", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            aaasophi            " + "'", str2.equals("            aaasophi            "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "52#100 ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "       sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...", (java.lang.CharSequence) "mixedmod", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0A32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A32" + "'", str1.equals("0A32"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int[] intArray2 = new int[] { 1, (byte) 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://java.oracle.com/" + "'", str1.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", charSequence2.equals("5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaasophi", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10452L, (long) (short) 100, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10452L + "'", long3 == 10452L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Su0 -Su0 0u0 32u", 22, "1#0aaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#0aaaSu0 -Su0 0u0 32u" + "'", str3.equals("1#0aaaSu0 -Su0 0u0 32u"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("52a10", "5", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52#100", (java.lang.CharSequence) "     aaasophi", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati..." + "'", str2.equals("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati..."));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        java.lang.String str8 = javaVersion3.toString();
        java.lang.String str9 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray10 = new org.apache.commons.lang3.JavaVersion[] { javaVersion1, javaVersion3 };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.1" + "'", str8.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.1" + "'", str9.equals("1.1"));
        org.junit.Assert.assertNotNull(javaVersionArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.81.1" + "'", str11.equals("1.81.1"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "   51.0   ", (java.lang.CharSequence) "-1#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1#0aaaSu0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("   1    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " 4#4#4a", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1#0", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1#0" + "'", charSequence2.equals("1#0"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 1 -1 1 -1 1                     " + "'", str1.equals("10 1 -1 1 -1 1                     "));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("100.04-1.0410.0410.04100.0", "1.5", "1#0aaaSu0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.04-1.0410.0410.04100.0" + "'", str3.equals("100.04-1.0410.0410.04100.0"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10#1#10", (java.lang.CharSequence) "10A1A10", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "         ", (java.lang.CharSequence) "1.81.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk", 11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("US", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               US                                                " + "'", str2.equals("                                               US                                                "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0.0#32.0#100.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.032.0100.0" + "'", str2.equals("0.032.0100.0"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ophi");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ophi" + "'", str4.equals("ophi"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        float[] floatArray1 = new float[] { (-1) };
        float[][] floatArray2 = new float[][] { floatArray1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray2);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", "4444444444444444444444444444444444444444444444444444", "sophie");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100.04-1.0410.0410.04");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", "Java Virtual Machine Specification");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52#100", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split(":");
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk", strArray7, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "!" + "'", str6.equals("!"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk" + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0.0a10.0a32.0a10.0a10.0a100.0", "100.0a-1.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a10.0a32.0a10.0a10.0a100.0" + "'", str2.equals("0.0a10.0a32.0a10.0a10.0a100.0"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.0 -1.0 0.0 32.0                  ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 -1.0 0.0 32.0                  " + "'", str2.equals("1.0 -1.0 0.0 32.0                  "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 8, 0);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray3, " 4#4#4a");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:  4#4#4a");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        short[] shortArray3 = new short[] { (short) 10, (short) 100, (byte) -1 };
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) ' ', 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati..." + "'", str1.equals("JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati..."));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU", (java.lang.CharSequence) "2#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1", "1.0#-1.0#0.0#32.0                                                                                   ", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "141040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141040" + "'", str2.equals("141040"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0 -1.0 0.0 32.0     ", 9, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 -1.0 0.0 32.0     " + "'", str3.equals("0 -1.0 0.0 32.0     "));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("     aaasophi", "!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0.032.0100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.032.0100.0" + "'", str1.equals("0.032.0100.0"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.#", "5sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "10#1#10");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444444444444444444", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444444444444", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        char[] charArray8 = new char[] { ' ', '#', '#', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "001#25", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ophi");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "###");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4', (int) '#', (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 31, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               " + "'", str3.equals("                               "));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10 1 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixed modeJava Platform API SpecificationJava Pla...", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("110a1a10", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "   51.0   ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODEjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICAT" + "'", str1.equals("MIXED MODEjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICAT"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 100, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.81.1", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                        1.81.1" + "'", str2.equals("                                                        1.81.1"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        float[] floatArray4 = new float[] { 1L, (-1L), (byte) 0, ' ' };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', (int) (short) 10, 9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0 -1.0 0.0 32.0" + "'", str11.equals("1.0 -1.0 0.0 32.0"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, (int) '4', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4..." + "'", str2.equals("/Users/sophie/Documents/defects4..."));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("5", (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                   ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################" + "'", str2.equals("################################"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", 11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4...", 13, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                               ", " 444#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("     ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.1J.3", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(". . Pf0 API .f Pf0 API .f Pf0 API .", ". . Pf0 API .f Pf0 API .f Pf0 API .", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo" + "'", str3.equals("oRoRLE ROLPRoERLE ROLPRoERLE ROLPRo"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(" 4#4#4a", "JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...-JavaPlatformAPISpecificati...1JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 4#4#4a" + "'", str2.equals(" 4#4#4a"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK", "001#25");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa" + "'", str3.equals("aaaaaaa1.0 -1.0 0.0 32.0aaaaaaa"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

