import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun.awt.CGraphicsEnvironment", "1.", "/Users/sophie", 211);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str4.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 26 + "'", int1 == 26);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 67);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", "\n");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 0, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1.7.0_80", "Su0 -Su0 0u0 32u0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("51.0", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(10.0f, (float) 35, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.0 -1.0 0.0 32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 -1.0 0.0 32.0" + "'", str1.equals("1.0 -1.0 0.0 32.0"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "#aaa#a a#", (java.lang.CharSequence) "10 1 -1 1 -1 1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Platform API Specification", "1.0#-1.0#0.0#32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str1.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1 1- 1 1- 1 01", charSequence1, 211);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', (int) (byte) 1, (int) (byte) -1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a0aaaa0", (java.lang.CharSequence) "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "", (java.lang.CharSequence) "001#25");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java Platform API Specificati...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0a32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A32" + "'", str1.equals("0A32"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8", (int) (short) -1, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0a32");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a32\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophie", "a0aaaa0", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("52#100", "5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2#100" + "'", str2.equals("2#100"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray6 = new double[] { (byte) 0, 10.0f, ' ', (short) 10, 10.0d, 100L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', (int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0a10.0a32.0a10.0a10.0a100.0" + "'", str9.equals("0.0a10.0a32.0a10.0a10.0a100.0"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("\n", "", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0L, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0a32", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(":", "1.8", "Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java Platform API Specificati...", "a0aaaa0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specificati..." + "'", str2.equals("Java Platform API Specificati..."));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("MAC OS X", 32, 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10 1 -1 1 -1 1", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 -1 1 -1 1                     " + "'", str2.equals("10 1 -1 1 -1 1                     "));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10a1a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a1a10" + "'", str1.equals("10a1a10"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ". . Pf0 API .f Pf0 API .f Pf0 API .f" + "'", str3.equals(". . Pf0 API .f Pf0 API .f Pf0 API .f"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("a0aaaa0", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a0aaaa0" + "'", str2.equals("a0aaaa0"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) " ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" ", "\n", "52#100 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "52#100", (java.lang.CharSequence) "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("001#25", "", "4444444444");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "1.0#-1.0#0.0#32.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_VISTA;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "001#25", (java.lang.CharSequence) "100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("JavaPlatformAPISpecificati...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Oracle Corporation is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2#100", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.14.3", "4444444444", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.1J.3" + "'", str3.equals("10.1J.3"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ":");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, 0L, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1", "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "0#32");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "4444444444", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hi!", "1#10#0", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "Java Platform API Specificati...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/t/NG0..." + "'", str2.equals("/t/NG0..."));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_HEADLESS;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/", (java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "52#100 ", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "001#25");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0.0a10.0a32.0a10.0a10.0a100.0", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      0.0a10.0a32.0a10.0a10.0a100.0" + "'", str2.equals("      0.0a10.0a32.0a10.0a10.0a100.0"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) 'a', (int) ' ');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a32" + "'", str8.equals("0a32"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "java hotspot(tm) 64-bit server vm");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "\n", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        short[] shortArray3 = new short[] { (short) 10, (byte) 1, (byte) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, 32);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1#10#0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("         ", "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         " + "'", str3.equals("         "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("#aaa#a a#", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#aaa#a a#" + "'", str3.equals("#aaa#a a#"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.0#-1.0#0.0#32.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10 1 -1 1 -1 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 1 -1 1 -1 1" + "'", str1.equals("10 1 -1 1 -1 1"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificationa" + "'", str3.equals("Java Virtual Machine Specificationa"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("52#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52#100" + "'", str1.equals("52#100"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0a32", "Java(TM) SE Runtime Environment", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("       sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("001#25");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "001#25" + "'", str1.equals("001#25"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1a10a-1", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Mac OS X", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Su0 -Su0 0u0 32u0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0 -1.0 0.0 32.0", 35, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 -1.0 0.0 32.0                  " + "'", str3.equals("1.0 -1.0 0.0 32.0                  "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "a0aaaa0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVApLATFORMapisPECIFICATI..." + "'", str1.equals("jAVApLATFORMapisPECIFICATI..."));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specificationa", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specificationa" + "'", str2.equals("Java Virtual Machine Specificationa"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "       sun.awt.CGraphicsEnvironment", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10 1 -1 1 -1 1", "sophie");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0#-1.0#0.0#32.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UTF-8", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, (double) (short) 10, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.awt.CGraphicsEnvironmen");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "   51.0   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "en", (java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sophi", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("5");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Hi!", "", 67);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 35, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1", "/Users/sophie", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 0, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OS X", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 17, 211);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mixedmode", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedmode" + "'", str3.equals("mixedmode"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie", "10 1 -1 1 -1 1", "sun.awt.CGraphicsEnvironmen", 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie" + "'", str4.equals("/Users/sophie"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users..." + "'", str3.equals("/Users..."));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10a1a10", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a10" + "'", str2.equals("10a1a10"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("-1a10a-1", "-1a10a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 1 -1 1 -1 1" + "'", str1.equals("10 1 -1 1 -1 1"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10 1 -1 1 -1 1", "sophie");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("52#100", strArray3, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52#100" + "'", str7.equals("52#100"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52#100" + "'", str10.equals("52#100"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ". . Pf0 API .f Pf0 API .f Pf0 API .f", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double[] doubleArray3 = new double[] { (byte) 1, 17, 'a' };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a17.0a97.0" + "'", str6.equals("1.0a17.0a97.0"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "      0.0a10.0a32.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        char[] charArray4 = new char[] { ' ', '4', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 4, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str1.equals("100.0#-1.0#10.0#10.0#100.0"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52#100", "Oracle Corporation");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = null;
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray5, strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "-1");
        java.lang.String[] strArray12 = null;
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1", strArray11, strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ". . Pf0 API .f Pf0 API .f Pf0 API .f", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("100.0#-1.0#10.0#10.0#100.0", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str2.equals("100.0#-1.0#10.0#10.0#100.0"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1004100404-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "0.0a10.0a32.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0 32", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Hi!", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("   51.0   ", (int) (short) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   51.0   " + "'", str3.equals("   51.0   "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("52#100 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"52#100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1004100404-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_80-b15", 10, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("52#100 ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.LWCToolkit", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1004100404-1", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.0 -1.0 0.0 32.0                  ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100.0#-1.0#10.0#10.0#100.0", "sun.awt.CGraphicsEnvironmen", "/t/NG0...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0#-1.0#10.0#10.0#100.0" + "'", str3.equals("100.0#-1.0#10.0#10.0#100.0"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 9, (float) 26, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1.equals(1.0d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.0 -1.0 0.0 32.0                  ", 0, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("MAC OS X", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str1.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", "1.7.0_80-b15", (int) (short) 100);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', (int) (short) 0, (int) (short) -1);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "mixed modeJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificat", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1L, (double) 1.1f, (double) 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "44444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("524100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "524100" + "'", str1.equals("524100"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622", "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1004100404-1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1L), (double) (-1L), 211.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 211.0d + "'", double3 == 211.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie", "Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/Users...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Platform API Specificati...");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1#10#0", (int) 'a', 17);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Hi!", (java.lang.CharSequence) "-1#100#100#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "      0.0a10.0a32.0a10.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "1.0 -1.0 0.0 32.0", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", (int) (short) 1, "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification" + "'", str3.equals("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("52#100 ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 " + "'", str2.equals("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 "));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("MAC OS X", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS X" + "'", str2.equals("MAC OS X"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("   51.0   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   51.0   " + "'", str1.equals("   51.0   "));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.0#-1.0#0.0#32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1");
        java.lang.Class<?> wildcardClass4 = bigDecimal3.getClass();
        java.math.BigDecimal bigDecimal6 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1");
        java.lang.Class<?> wildcardClass7 = bigDecimal6.getClass();
        java.math.BigDecimal bigDecimal9 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1");
        java.math.BigDecimal[] bigDecimalArray10 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal6, bigDecimal9 };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray10);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(bigDecimal6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(bigDecimal9);
        org.junit.Assert.assertNotNull(bigDecimalArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-111-1" + "'", str11.equals("-111-1"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int[] intArray0 = new int[] {};
        try {
            java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', (int) ' ', 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATI...", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################" + "'", str2.equals("####################################################################################################"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10#1#-1#1#-1#1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("2#100", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_ENDORSED_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str0.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1L, (float) (short) -1, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1 1- 1 1- 1 01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 1- 1 1- 1 01" + "'", str1.equals("1 1- 1 1- 1 01"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java HotSpot(TM) 64-Bit Server VM", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 100L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ":");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10a1a10", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oracle Corporation" + "'", str5.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 32, (int) (short) -1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "100.0#-1.0#10.0#10.0#100.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100.0#-1.0#10.0#10.0#100.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("   51.0   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   51.0   " + "'", str2.equals("   51.0   "));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("52#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52#100" + "'", str1.equals("52#100"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10 1 -1 1 -1 1", "-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", "1 1- 1 1- 1 01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lib/java:." + "'", str2.equals("lib/java:."));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.0a17.0a97.0", (java.lang.CharSequence) "lib/java:.", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie", "                                                                                                 ", (int) (short) 100);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("MAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5" + "'", str1.equals("5"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7", 4, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71" + "'", str3.equals("1.71"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0L, (double) 100.0f, (double) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "Mac OS X", "0 32");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("#aaa#a a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#aaa#a a#" + "'", str1.equals("#aaa#a a#"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("-1#100#100#0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specificati...", (java.lang.CharSequence) "1.0a17.0a97.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10.1J.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.1J.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("a0aaaa0", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence) "JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("52#100", (int) (byte) -1, "5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52#100" + "'", str3.equals("52#100"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1#10#0" + "'", str7.equals("1#10#0"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("####################################################################################################", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###" + "'", str2.equals("###"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.0#-1.0#0.0#32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("       sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       sun.awt.CGraphicsEnvironmen" + "'", str1.equals("       sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "524100", "         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "       sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("mixedmode", "/Users...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmod" + "'", str2.equals("mixedmod"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        short[] shortArray3 = new short[] { (short) 1, (byte) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 4, (int) (short) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10#0" + "'", str5.equals("1#10#0"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################" + "'", str3.equals("################################"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("524100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "524100" + "'", str2.equals("524100"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1 1- 1 1- 1 01", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double[] doubleArray3 = new double[] { 0L, 32, 100.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', (int) (byte) 100, (int) (short) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "", "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("en", "", "/Users...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("####################################################################################################", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.0 -1.0 0.0 32.0                  ", 2, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 -1.0 0.0 32.0     " + "'", str3.equals("0 -1.0 0.0 32.0     "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.0 -1.0 0.0 32.0                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 -1.0 0.0 32.0                  " + "'", str1.equals("1.0 -1.0 0.0 32.0                  "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.1", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "0#32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("US", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("5");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-111-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-111-1" + "'", str1.equals("-111-1"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (short) 10, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "mixedmode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU" + "'", str1.equals("SU"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), (double) (short) 10, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b15", (int) (byte) -1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("0 32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 32" + "'", str1.equals("0 32"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("###", 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10 1 -1 1 -1 1                     ", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixedmod", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedmod" + "'", str3.equals("mixedmod"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaVirtualMachineSpecificationa" + "'", str1.equals("JavaVirtualMachineSpecificationa"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-111-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str1.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0 -1.0 0.0 32.0                  ", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("a0aaaa0", (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(" 4#4#4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " 4#4#4a" + "'", str1.equals(" 4#4#4a"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "2#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sophi", "/Users...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophi" + "'", str2.equals("ophi"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "001#25", (java.lang.CharSequence) "-1a10a-1", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_AIX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.1", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0 32", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users..." + "'", str1.equals("/Users..."));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixedmod", "10 1 -1 1 -1 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "/", 32, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "0 -1.0 0.0 32.0     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.0a17.0a97.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification:Java Platform API Specification", "", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "################################", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Hi!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        long[] longArray1 = new long[] { (-1) };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 4, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Su0 -Su0 0u0 32u0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Su0 -Su0 0u0 32u" + "'", str1.equals("Su0 -Su0 0u0 32u"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1#100#100#0", (java.lang.CharSequence) "Su0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 17, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10 1 -1 1 -1 1", (int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100.0#-1.0#10.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "5", (java.lang.CharSequence) "lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(100, 26, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80", (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Su0 -Su0 0u0 32u", "################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Su0 -Su0 0u0 32u" + "'", str2.equals("Su0 -Su0 0u0 32u"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10.14.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.14.3", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specificationa" + "'", str1.equals("Java Virtual Machine Specificationa"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.0 -1.0 0.0 32.0                  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-111-1", "", "Java Platform API Specificati...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati..." + "'", str3.equals("Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...1Java Platform API Specificati...-Java Platform API Specificati...1Java Platform API Specificati..."));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0 -1.0 0.0 32.0", (java.lang.CharSequence) "a0aaaa0", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "mixed mode", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int[] intArray2 = new int[] { (short) 0, ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', (int) '#', (-1));
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a32" + "'", str10.equals("0a32"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Sophie", " ", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sophie" + "'", str3.equals("Sophie"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0 32");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "   51.0   ", (java.lang.CharSequence) "-111-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0 -1.0 0.0 32.0     ", (int) (short) 10, "/t/NG0...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 -1.0 0.0 32.0     " + "'", str3.equals("0 -1.0 0.0 32.0     "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0a17.0a97.0", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(". . Pf0 API .f Pf0 API .f Pf0 API .f");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \". . Pf0 A\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_COMPILER;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("2#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2#100" + "'", str1.equals("2#100"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100.0#-1.0#10.0#10.0#100.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/t/NG0...", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.0 -1.0 0.0 32.0                  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sophie", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "524100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("jAVApLATFORMapisPECIFICATI...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Su0 -Su0 0u0 32u0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Su0 -Su0 0u0 32u0" + "'", str2.equals("Su0 -Su0 0u0 32u0"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", (java.lang.CharSequence) "5", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.0 -1.0 0.0 32.0", "10a1a10", 67, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "110a1a10" + "'", str4.equals("110a1a10"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("mixedmod", "1.0a17.0a97.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, 2L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.", 3, "###");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.#" + "'", str3.equals("1.#"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.0a17.0a97.0", "   51.0   ", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.", "Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-b11", "Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.1", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 97, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophi", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaasophi" + "'", str3.equals("aaasophi"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0 -1.0 0.0 32.0     ", 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 -1.0 0.0 32.0     " + "'", str3.equals("0 -1.0 0.0 32.0     "));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1", 67, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                  1" + "'", str3.equals("                                                                  1"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1", "", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("110a1a10", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', (int) (byte) 0, (int) (short) -1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray9);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a1a10", charArray9);
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#aaa#a a#" + "'", str12.equals("#aaa#a a#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ":");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "001#25");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4444444444444444444444444444444", (java.lang.CharSequence) "http://java.oracle.com/", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Java Platform API Specificati...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 4, 100L, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0A32", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10.14.3", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("52#100 ", "!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52#100 " + "'", str3.equals("52#100 "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("MAC OS X", (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Su0 -Su0 0u0 32u");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "JavaVirtualMachineSpecificationa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 26, (double) 10, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 26.0d + "'", double3 == 26.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("   51.0   ", 97, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1 1- 1 1- 1 01");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 " + "'", str2.equals("52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 52#100 "));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("44444444444444444444444444444444", "", "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "52#100", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", 67, "Su0 -Su0 0u0 32u0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("52#100");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaasophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10a1a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10A1A10" + "'", str1.equals("10A1A10"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, (int) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("x86_64", "524100");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.0#-1.0#0.0#32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#-1.0#0.0#32.0" + "'", str1.equals("1.0#-1.0#0.0#32.0"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("10.1J.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.1J.3" + "'", str1.equals("10.1J.3"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("2#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2#100" + "'", str1.equals("2#100"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1004100404-1", "1004100404-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004100404-1" + "'", str2.equals("1004100404-1"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" 444#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:  444# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("#aaa#a a#", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49910_1560276622");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "2#100", 35, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporation", "Oracle Corporation", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specification", (int) (byte) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444Java Virtual Machine Specification444444444444444444444444444444444"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        float[] floatArray4 = new float[] { 1L, (-1L), (byte) 0, ' ' };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', (int) (short) 100, (int) (short) 0);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int[] intArray2 = new int[] { 1, (byte) 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#0" + "'", str5.equals("1#0"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (long) 9, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixedmode", (java.lang.CharSequence) "4444444444444444444444444444444", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   51.0   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: / is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.#", "0#32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.#" + "'", str2.equals("1.#"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10 1 -1 1 -1 1                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 1 -1 1 -1 1" + "'", str1.equals("10 1 -1 1 -1 1"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#aaa#a a#", 3, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1004100404-1", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "JavaVirtualMachineSpecificationa", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("524100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "524100" + "'", str1.equals("524100"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.Class<?> wildcardClass4 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java(TM) SE Runtime Environment", 211);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 211 + "'", int2 == 211);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaVirtualMachineSpecificationa", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "sophi", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironmen", "/Users/sophie", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "lib/java:.", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("lib/java:.", 22, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############lib/java:." + "'", str3.equals("############lib/java:."));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#aaa#a a#", "4444444444444444444444444444444", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ophi", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1", 0, "mixedmode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Su0 -Su0 0u0 32u0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (short) 1, (float) 2L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1004100404-1", "JavaPlatformAPISpecificati...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004100404-1" + "'", str2.equals("1004100404-1"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                  1", "################################", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str1.equals("Sun.awt.CGraphicsEnvironment"));
    }
}

